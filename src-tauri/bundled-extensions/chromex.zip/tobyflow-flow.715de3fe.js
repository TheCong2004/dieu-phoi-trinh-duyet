(() => {
  // src/platforms/labs.toby.vn/content.ts
  if (self.__tobyflowContentJsLoaded__) {
  } else {
    let _getFlowLocaleStrings = function(key, field) {
      var config = _getDynamicSelector(key);
      var arr = config?.[field];
      if (!Array.isArray(arr) || arr.length === 0) {
        console.debug("[Tier3] _getFlowLocaleStrings: " + key + "." + field + " cache miss/empty");
        return [];
      }
      return arr;
    }, _getFlowLocaleStringsWithFallback = function(key, field) {
      const fromServer = _getFlowLocaleStrings(key, field);
      if (fromServer.length > 0) return fromServer;
      const fb = _FLOW_LOCALE_FALLBACKS[key]?.[field];
      if (Array.isArray(fb) && fb.length > 0) {
        console.log("[TobyFlow] _getFlowLocaleStringsWithFallback:", key + "." + field, "\u2192", fb.length, "fallback(s)");
        return fb;
      }
      return [];
    }, _isGroupViewTabLabel = function(label) {
      const s = String(label || "").toLowerCase();
      return s.includes("group") || s.includes("nh\xF3m") || s.includes("theo nh\xF3m");
    }, _isNonViewSettingsControlLabel = function(label) {
      const s = String(label || "").toLowerCase().replace(/\s+/g, " ");
      return s.includes("more_vert") || s.includes("more_horiz") || s.includes("more options") || s.includes("tu\u1EF3 ch\u1ECDn") || s.includes("tuy chon") || s.includes("t\xF9y ch\u1ECDn") || s.includes("tuy ch\u1ECDn") || s.includes("options") || s.includes("settings") || s.includes("c\xE0i \u0111\u1EB7t") || s.includes("cai dat") || s.includes("overflow") || s.includes("menu") || /^more[_\s]?vert/.test(s);
    }, _isLikelyGridViewLabel = function(label) {
      const s = String(label || "").toLowerCase();
      if (!s || _isGroupViewTabLabel(s) || _isNonViewSettingsControlLabel(s)) return false;
      return s.includes("grid") || s.includes("l\u01B0\u1EDBi") || s.includes("luoi") || s.includes("ch\u1EBF \u0111\u1ED9 l\u01B0\u1EDBi") || s.includes("che do luoi") || s === "grid view";
    }, _queryInputsByAriaLabels = function(labels) {
      for (const label of labels) {
        const inputs = document.querySelectorAll(`input[aria-label="${label}"]`);
        if (inputs.length > 0) return inputs;
      }
      return [];
    }, _ariaLabelMatches = function(label, expected) {
      const l = String(label || "").trim().toLowerCase();
      if (!l) return false;
      return (expected || []).some((e) => {
        const e2 = String(e || "").trim().toLowerCase();
        if (!e2) return false;
        return l === e2 || l.includes(e2) || e2.includes(l);
      });
    }, _textIncludesAny = function(text, patterns) {
      const textLower = text.toLowerCase();
      return patterns.some((p) => textLower.includes(p.toLowerCase()));
    }, _getTileSelector = function() {
      var config = _getDynamicSelector("tile_container");
      var selectors = config?.selectors?.length ? config.selectors : [];
      var attribute = config?.attribute || "data-tile-id";
      if (!selectors.length) {
        console.debug("[Tier3] _getTileSelector: tile_container config miss \u2014 fallback [data-tile-id]");
        return { selector: "[data-tile-id]", attribute: "data-tile-id" };
      }
      for (var i = 0; i < selectors.length; i++) {
        try {
          var els = document.querySelectorAll(selectors[i]);
          if (els.length > 0) {
            return { selector: selectors[i], attribute };
          }
        } catch (e) {
        }
      }
      return { selector: selectors[0] || "[data-tile-id]", attribute: attribute || "data-tile-id" };
    }, _getTileSelectorString = function() {
      var now = Date.now();
      if (!_tileSelectorCache || now - _selectorConfigTime > _SELECTOR_CACHE_TTL) {
        _tileSelectorCache = _getTileSelector();
        console.log('[TobyFlow] _getTileSelectorString: refreshed cache, selector="' + (_tileSelectorCache?.selector || "NULL") + '"');
      }
      return _tileSelectorCache?.selector || null;
    }, _getSlateEditorSelectorString = function() {
      var config = _getDynamicSelector("slate_editor");
      if (config?.selectors?.length) return config.selectors[0];
      console.debug("[Tier3] _getSlateEditorSelectorString miss \u2014 using DOM fallback");
      return _SLATE_EDITOR_FALLBACK_SELECTORS[0];
    }, _queryAllSlateEditors = function() {
      var seen = /* @__PURE__ */ new Set();
      var editors = [];
      function addFrom(sel) {
        if (!sel) return;
        document.querySelectorAll(sel).forEach(function(el) {
          if (!seen.has(el)) {
            seen.add(el);
            editors.push(el);
          }
        });
      }
      var dynCfg = _getDynamicSelector("slate_editor");
      if (dynCfg?.selectors?.length) {
        dynCfg.selectors.forEach(addFrom);
      }
      if (editors.length === 0) {
        _SLATE_EDITOR_FALLBACK_SELECTORS.forEach(addFrom);
      }
      return editors;
    }, _ensureSelectorsForExecution = function(source) {
      if (_getDynamicSelector("slate_editor")?.selectors?.length) return;
      _applyFlowSelectorBootstrap(source || "execution");
    }, _getMediaUrlPattern = function() {
      try {
        var cfg = _apiConfigsCacheLocal?.data?.flow?.configs?.image_url_pattern;
        if (cfg?.url_substring) return cfg.url_substring;
      } catch (_) {
      }
      if (!_apiConfigsCacheLocal) {
        chrome.storage.local.get(["toby_provider_api_configs"], function(res) {
          if (res.toby_provider_api_configs?.data) {
            _apiConfigsCacheLocal = res.toby_provider_api_configs;
            _apiConfigsCacheLocalTime = Date.now();
          }
        });
      }
      console.debug("[Tier3] _getMediaUrlPattern miss");
      return null;
    }, _getCachedTiles = function() {
      var now = Date.now();
      if (_tileCache && now - _tileCacheTime < _TILE_CACHE_TTL) {
        return _tileCache;
      }
      if (!_tileSelectorCache || now - _selectorConfigTime > _SELECTOR_CACHE_TTL) {
        _tileSelectorCache = _getTileSelector();
      }
      _tileCache = _tileSelectorCache.selector ? document.querySelectorAll(_tileSelectorCache.selector) : [];
      _tileCacheTime = now;
      return _tileCache;
    }, _invalidateTileCache = function() {
      _tileCache = null;
      _tileCacheTime = 0;
      _tileSelectorCache = null;
      _fileNameCache.clear();
    }, _getTileById = function(tileId) {
      var config = _getDynamicSelector("tile_container");
      var attribute = config?.attribute || "data-tile-id";
      return document.querySelector(`[${attribute}="${tileId}"]`);
    }, _loadRadixTriggerPattern = function() {
      try {
        chrome.storage.local.get(["toby_provider_api_configs"], function(res) {
          var cfg = res?.toby_provider_api_configs?.data?.flow?.configs?.radix_trigger_button_pattern;
          if (typeof cfg === "string" && cfg.includes("{suffix}")) {
            _radixTriggerPattern = cfg;
          }
        });
      } catch (_) {
      }
    }, _buildRadixTriggerSelector = function(suffix) {
      if (_radixTriggerPattern) {
        return _radixTriggerPattern.replace("{suffix}", String(suffix));
      }
      console.debug("[Tier3] radix_trigger_button_pattern config miss \u2014 using last-resort inline pattern");
      return 'button[id$="-trigger-' + String(suffix) + '"]';
    }, _shouldAllowFlowSelectorBootstrap = function(cb) {
      try {
        chrome.storage.local.get(["apiBaseUrl", "af_api_url", "af_auth"], function(res) {
          var urls = [
            res && res.apiBaseUrl,
            res && res.af_api_url,
            res && res.af_auth && res.af_auth.apiBaseUrl
          ].map(function(v) {
            return String(v || "");
          });
          if (urls.some(function(u) {
            return /localhost|127\.0\.0\.1/.test(u);
          })) {
            cb(true);
            return;
          }
          try {
            chrome.runtime.sendMessage({ action: "tobyflow:isDevBuild" }, function(resp) {
              if (!chrome.runtime.lastError && resp && resp.isDevBuild) {
                cb(true);
                return;
              }
              cb(true);
            });
          } catch (_) {
            cb(true);
          }
        });
      } catch (_) {
        cb(true);
      }
    }, _storageTargetsLocalDev = function(cb) {
      _shouldAllowFlowSelectorBootstrap(cb);
    }, _applyFlowSelectorBootstrap = function(source, existingData) {
      var merged = Object.assign({}, existingData || {}, _FLOW_LOCAL_DEV_BOOTSTRAP);
      if (existingData && existingData.flow && existingData.flow.selectors) {
        merged.flow = {
          selectors: Object.assign(
            {},
            _FLOW_LOCAL_DEV_BOOTSTRAP.flow && _FLOW_LOCAL_DEV_BOOTSTRAP.flow.selectors || {},
            existingData.flow.selectors
          )
        };
      }
      _selectorConfig = merged;
      _selectorConfigTime = Date.now();
      _selectorConfigReady = true;
      try {
        chrome.storage.local.set({
          toby_provider_configs: {
            data: merged,
            expiresAt: Date.now() + 5 * 60 * 1e3,
            fetchedAt: Date.now(),
            source: source || "content_bootstrap"
          }
        });
      } catch (_) {
      }
      var keyCount = Object.keys(merged.flow && merged.flow.selectors || {}).length;
      console.log("[Selector:flow:ensure] \u2705 Local bootstrap (" + (source || "content") + ", " + keyCount + " selector keys)");
      return true;
    }, _tfInjectHintStyle = function() {
      if (document.getElementById("tf-open-hint-style")) return;
      var st = document.createElement("style");
      st.id = "tf-open-hint-style";
      st.textContent = '@keyframes tf-pulse{0%,100%{box-shadow:0 0 0 0 rgba(204,255,0,.6)}50%{box-shadow:0 0 0 9px rgba(204,255,0,0)}}#tobyflow-open-sidebar-btn.tf-pulse-on{animation:tf-pulse 1.6s ease-out infinite}.tf-open-hint{position:absolute;top:calc(100% + 10px);right:0;background:#1a1a1a;color:#fff;padding:7px 12px;border-radius:8px;font-size:12px;font-weight:600;white-space:nowrap;box-shadow:0 6px 20px rgba(0,0,0,.35);z-index:2147483647;animation:tf-hint-bounce 1.4s ease-in-out infinite}.tf-open-hint::before{content:"";position:absolute;bottom:100%;right:20px;border:6px solid transparent;border-bottom-color:#1a1a1a}@keyframes tf-hint-bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}';
      (document.head || document.documentElement).appendChild(st);
    }, _tfAttachHint = function(btn) {
      if (_tfHintSeen) return;
      _tfInjectHintStyle();
      btn.style.position = "relative";
      btn.classList.add("tf-pulse-on");
      if (!btn.querySelector(".tf-open-hint")) {
        var tip = document.createElement("span");
        tip.className = "tf-open-hint";
        tip.textContent = _TF_HINT_LABEL;
        btn.appendChild(tip);
      }
    }, _tfDismissHint = function(btn) {
      _tfHintSeen = true;
      try {
        chrome.storage.local.set({ tf_open_hint_seen: true });
      } catch (_) {
      }
      if (btn) {
        btn.classList.remove("tf-pulse-on");
        var tip = btn.querySelector(".tf-open-hint");
        if (tip) tip.remove();
      }
    }, _tfBuildOpenButton = function(label) {
      var logoUrl = "";
      try {
        logoUrl = chrome.runtime.getURL("icons/icon-48.png");
      } catch (_) {
      }
      var btn = document.createElement("button");
      btn.id = "tobyflow-open-sidebar-btn";
      btn.type = "button";
      btn.title = label;
      btn.style.cssText = "display:inline-flex;align-items:center;gap:6px;margin-left:8px;padding:7px 14px;border:none;border-radius:30px;cursor:pointer;font-size:13px;font-weight:600;line-height:1;white-space:nowrap;flex-shrink:0;background:linear-gradient(90deg, rgb(204, 255, 0) 0%, rgb(234 255 152) 100%);color:#292929;";
      btn.innerHTML = (logoUrl ? '<img src="' + logoUrl + '" alt="" style="width:18px;height:18px;border-radius:5px;display:block">' : "") + '<span class="tf-open-label">' + label + "</span>";
      btn.addEventListener("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        _tfDismissHint(btn);
        try {
          chrome.runtime.sendMessage({ action: "flow:openSidebar" }, function() {
            void chrome.runtime.lastError;
          });
        } catch (_) {
        }
      });
      _tfAttachHint(btn);
      return btn;
    }, _tfFindBrandLink = function() {
      var links = document.querySelectorAll('a[href$="/tools/flow"]');
      for (var i = 0; i < links.length; i++) {
        if ((links[i].textContent || "").trim() === "Google Flow") return links[i];
      }
      return null;
    }, _tfWatchAnchor = function(anchorParent, btn) {
      if (_tfNavObserver) {
        try {
          _tfNavObserver.disconnect();
        } catch (_) {
        }
        _tfNavObserver = null;
      }
      if (!anchorParent || typeof MutationObserver === "undefined") return;
      _tfNavObserver = new MutationObserver(function() {
        if (!_tfContextValid()) {
          try {
            _tfNavObserver.disconnect();
          } catch (_) {
          }
          _tfNavObserver = null;
          return;
        }
        if (document.body.contains(anchorParent) && !anchorParent.contains(btn)) {
          try {
            anchorParent.appendChild(btn);
          } catch (_) {
          }
        }
      });
      _tfNavObserver.observe(anchorParent, { childList: true });
    }, _tfContextValid = function() {
      try {
        return !!(chrome.runtime && chrome.runtime.id);
      } catch (_) {
        return false;
      }
    }, _injectTobyFlowOpenButton = function() {
      if (!_tfContextValid()) {
        try {
          clearInterval(_tfInjectInterval);
        } catch (_) {
        }
        if (_tfNavObserver) {
          try {
            _tfNavObserver.disconnect();
          } catch (_) {
          }
          _tfNavObserver = null;
        }
        return;
      }
      var label = _TF_OPEN_LABEL;
      var existing = document.getElementById("tobyflow-open-sidebar-btn");
      if (existing) return;
      var nav = document.querySelector("nav");
      if (nav) {
        var b = _tfBuildOpenButton(label);
        nav.appendChild(b);
        _tfWatchAnchor(nav, b);
        return;
      }
      var brand = _tfFindBrandLink();
      if (brand && brand.parentElement) {
        var b2 = _tfBuildOpenButton(label);
        brand.insertAdjacentElement("afterend", b2);
        _tfWatchAnchor(brand.parentElement, b2);
      }
    }, _runSelectorWaitLoop = function() {
      var startTime = Date.now();
      var attempts = 0;
      var lastLogElapsed = 0;
      console.log("[Selector:flow:ensure] \u23F3 Waiting for server config in chrome.storage.local (timeout " + _SELECTOR_WAIT_MAX_MS + "ms)...");
      function checkStorage() {
        attempts++;
        chrome.storage.local.get(["toby_provider_configs"], function(res) {
          if (res.toby_provider_configs?.data?.flow) {
            _selectorConfig = res.toby_provider_configs.data;
            _selectorConfigTime = Date.now();
            _selectorConfigReady = true;
            var keyCount = Object.keys(_selectorConfig.flow?.selectors || {}).length;
            console.log("[Selector:flow:ensure] \u2705 Loaded " + keyCount + " Flow selectors after " + attempts + " attempts (" + (Date.now() - startTime) + "ms)");
            var existingOverlay = document.getElementById("tobyflow-config-error-overlay");
            if (existingOverlay) existingOverlay.remove();
            async function _runFlowReadyCheckChain() {
              window._tobyAgentChainLastRunAt = Date.now();
              let r1 = null, r2 = null, r3 = null;
              try {
                if (typeof _ensureFlowAgentInstructionDone === "function") {
                  r1 = await _ensureFlowAgentInstructionDone();
                  if (r1.wasOpen && r1.success) console.log("[FlowAgentInstruction:chain] \u2713 Done clicked");
                  else if (r1.found) console.log("[FlowAgentInstruction:chain] \u2713 Dialog already closed");
                }
                if (typeof _ensureFlowChatAgentClosed === "function") {
                  r2 = await _ensureFlowChatAgentClosed();
                  if (r2.wasOpen && r2.success) console.log("[FlowChatAgent:chain] \u2713 Panel closed");
                  else if (r2.found) console.log("[FlowChatAgent:chain] \u2713 Panel already closed");
                }
                if (r2?.wasOpen && r2?.success) {
                  await sleep(1500);
                }
                if (typeof _ensureFlowAgentModeOff === "function") {
                  r3 = await _ensureFlowAgentModeOff();
                  if (r3.wasOn && r3.success) console.log("[FlowAgent:chain] \u2713 Agent disabled");
                  else if (r3.found && window._tobyVerboseFlowDebug) {
                    console.log("[FlowAgent:chain] \u2713 Agent already OFF");
                  }
                }
              } catch (e) {
                console.warn("[FlowReadyChain] step exception:", e.message);
              }
              return {
                anyFound: !!(r1?.found || r2?.found || r3?.found),
                anyActioned: !!(r1?.wasOpen && r1?.success || r2?.wasOpen && r2?.success || r3?.wasOn && r3?.success),
                r1,
                r2,
                r3
              };
            }
            document.addEventListener("toby-debug-flow-ready", async () => {
              console.log("[FlowReadyChain:manual] === Triggered manually (verbose ON) ===");
              if (typeof _findFlowChatAgentCloseButton === "function") {
                const src = _findFlowChatAgentCloseButton.toString();
                const hasStats = src.includes("stats.iconCloseMatched");
                const hasVerbose = src.includes("_tobyVerboseFlowDebug");
                console.log(`[FlowReadyChain:manual] CodeVersion check: hasStats=${hasStats} hasVerbose=${hasVerbose}`);
                if (!hasStats || !hasVerbose) {
                  console.warn("[FlowReadyChain:manual] \u26A0 OLD CODE VERSION DETECTED \u2014 extension/tab needs reload");
                }
              }
              const cfgChat = typeof _getDynamicSelector === "function" ? _getDynamicSelector("flow_chat_agent_close_button") : null;
              const cfgInstr = typeof _getDynamicSelector === "function" ? _getDynamicSelector("flow_agent_instruction_done_button") : null;
              const cfgAgent = typeof _getDynamicSelector === "function" ? _getDynamicSelector("flow_agent_toggle_button") : null;
              const cfgIcon = typeof _getDynamicSelector === "function" ? _getDynamicSelector("icon_element") : null;
              console.log("[FlowReadyChain:manual] flow_chat_agent_close_button JSON:", JSON.stringify(cfgChat));
              console.log("[FlowReadyChain:manual] flow_agent_instruction_done_button JSON:", JSON.stringify(cfgInstr));
              console.log("[FlowReadyChain:manual] flow_agent_toggle_button JSON:", JSON.stringify(cfgAgent));
              console.log("[FlowReadyChain:manual] icon_element JSON:", JSON.stringify(cfgIcon));
              _tobyVerboseFlowDebug = true;
              try {
                const dialogBtn = typeof _findFlowAgentInstructionDoneButton === "function" ? _findFlowAgentInstructionDoneButton() : null;
                const chatBtn = typeof _findFlowChatAgentCloseButton === "function" ? _findFlowChatAgentCloseButton() : null;
                const agentBtn = typeof _findFlowAgentButton === "function" ? _findFlowAgentButton() : null;
                console.log("[FlowReadyChain:manual] Instruction Done button:", dialogBtn);
                console.log("[FlowReadyChain:manual] Chat Close button:", chatBtn);
                console.log("[FlowReadyChain:manual] Agent toggle button:", agentBtn);
                const r = await _runFlowReadyCheckChain();
                console.log("[FlowReadyChain:manual] Chain result:", r);
              } finally {
                _tobyVerboseFlowDebug = false;
              }
            });
            (async function _bootstrapWithRetry() {
              const MAX_ATTEMPTS = 6;
              const RETRY_DELAY = 1500;
              await new Promise((res2) => setTimeout(res2, 1e3));
              let actionedInBootstrap = false;
              for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
                const result = await _runFlowReadyCheckChain();
                if (result.anyActioned) {
                  console.log(`[FlowReadyChain:bootstrap] \u2713 Actioned at attempt ${attempt}/${MAX_ATTEMPTS}`);
                  actionedInBootstrap = true;
                  window._tobyBootstrapAgentActioned = true;
                  await new Promise((res2) => setTimeout(res2, 1e3));
                  await _runFlowReadyCheckChain();
                  break;
                }
                if (attempt < MAX_ATTEMPTS) {
                  await new Promise((res2) => setTimeout(res2, RETRY_DELAY));
                }
              }
              if (!actionedInBootstrap) {
                console.log(`[FlowReadyChain:bootstrap] No panel/dialog/agent detected after ${MAX_ATTEMPTS} attempts \u2014 starting lifetime DOM monitor`);
              }
              if (!actionedInBootstrap && !window._tobyOneShotPollInstalled) {
                window._tobyOneShotPollInstalled = true;
                const POLL_INTERVAL_MS = 1500;
                const MAX_POLL_DURATION_MS = 6e4;
                const MAX_POLLS = Math.ceil(MAX_POLL_DURATION_MS / POLL_INTERVAL_MS);
                let pollCount = 0;
                let pollRunning = false;
                let pollerRef = null;
                const cleanup = (reason) => {
                  if (pollerRef) {
                    clearInterval(pollerRef);
                    pollerRef = null;
                  }
                  console.log(`[FlowReadyChain:oneShot] uninstalled (${reason}, polls=${pollCount}/${MAX_POLLS})`);
                };
                pollerRef = setInterval(async () => {
                  pollCount++;
                  if (pollCount > MAX_POLLS) {
                    cleanup("timeout 60s");
                    return;
                  }
                  if (pollRunning) return;
                  pollRunning = true;
                  try {
                    const r = await _runFlowReadyCheckChain();
                    if (r.anyActioned) {
                      cleanup("actioned");
                    }
                  } catch (e) {
                    console.warn("[FlowReadyChain:oneShot] error:", e.message);
                  } finally {
                    pollRunning = false;
                  }
                }, POLL_INTERVAL_MS);
                console.log(`[FlowReadyChain:oneShot] \u2713 Periodic poll installed (${POLL_INTERVAL_MS}ms \xD7 ${MAX_POLLS} = ${MAX_POLL_DURATION_MS / 1e3}s window)`);
              }
            })();
            return;
          }
          try {
            chrome.runtime.sendMessage({ action: "getProviderConfigs", provider: "flow" }, function() {
              if (chrome.runtime.lastError) {
              }
            });
          } catch (_) {
          }
          var elapsed = Date.now() - startTime;
          if (elapsed - lastLogElapsed >= 1e3) {
            lastLogElapsed = elapsed;
            console.log("[Selector:flow:ensure] \u23F3 Still waiting (" + (elapsed / 1e3).toFixed(1) + "s/" + _SELECTOR_WAIT_MAX_MS / 1e3 + "s, attempt #" + attempts + ") \u2014 re-triggering background fetch");
          }
          if (elapsed > _SELECTOR_WAIT_MAX_MS) {
            _shouldAllowFlowSelectorBootstrap(function(allowBootstrap) {
              if (allowBootstrap) {
                chrome.storage.local.get(["toby_provider_configs"], function(res2) {
                  var existing = res2 && res2.toby_provider_configs && res2.toby_provider_configs.data || {};
                  if (_applyFlowSelectorBootstrap("timeout_fallback", existing)) {
                    var existingOverlay2 = document.getElementById("tobyflow-config-error-overlay");
                    if (existingOverlay2) existingOverlay2.remove();
                    checkStorage();
                  }
                });
                return;
              }
              console.error("[Selector:flow:ensure] \u274C Timeout after " + attempts + " attempts (" + elapsed + "ms). Server unreachable \u2014 showing overlay.");
              _showConfigErrorOverlay();
            });
            return;
          }
          setTimeout(checkStorage, _SELECTOR_WAIT_INTERVAL_MS);
        });
      }
      _shouldAllowFlowSelectorBootstrap(function(allowBootstrap) {
        if (!allowBootstrap) {
          checkStorage();
          return;
        }
        chrome.storage.local.get(["toby_provider_configs"], function(res) {
          var data = res && res.toby_provider_configs && res.toby_provider_configs.data;
          var hasFlow = !!(data && data.flow && data.flow.selectors && (data.flow.selectors.slate_editor || data.flow.selectors.composer));
          if (hasFlow) {
            checkStorage();
            return;
          }
          console.log("[Selector:flow:ensure] Bootstrap selectors immediately (server/cache ch\u01B0a s\u1EB5n s\xE0ng)");
          _applyFlowSelectorBootstrap("immediate_fallback", data || {});
          checkStorage();
        });
      });
    }, _showConfigErrorOverlay = function() {
      if (document.getElementById("tobyflow-config-error-overlay")) {
        console.log("[Selector:flow:overlay] \u21A9 Overlay already mounted \u2014 skip");
        return;
      }
      var lang = _overlayLocale || "vi";
      var t = _OVERLAY_I18N[lang] || _OVERLAY_I18N.vi;
      var overlay = document.createElement("div");
      overlay.id = "tobyflow-config-error-overlay";
      overlay.className = "tobyflow-cfg-err-overlay";
      overlay.innerHTML = '<style>.tobyflow-cfg-err-overlay { position: fixed; inset: 0; z-index: 2147483647; background: rgba(10,10,14,0.95); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }.tobyflow-cfg-err-content { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 32px; max-width: 320px; }.tobyflow-cfg-err-icon { width: 80px; height: 80px; border-radius: 50%; background: rgba(239,68,68,0.15); display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }.tobyflow-cfg-err-icon svg { color: #ef4444; }.tobyflow-cfg-err-title { font-size: 18px; font-weight: 600; color: #fff; margin: 0 0 8px 0; }.tobyflow-cfg-err-desc { font-size: 14px; color: rgba(255,255,255,0.6); margin: 0 0 24px 0; line-height: 1.5; }.tobyflow-cfg-err-retry-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #fff; color: #1a1a1e; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: opacity 0.2s; }.tobyflow-cfg-err-retry-btn:hover { opacity: 0.9; }.tobyflow-cfg-err-retry-btn:active { opacity: 0.8; }.tobyflow-cfg-err-retry-btn svg { color: #1a1a1e; }</style><div class="tobyflow-cfg-err-content"><div class="tobyflow-cfg-err-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="2" y1="2" x2="22" y2="22"></line><path d="M8.5 16.5a5 5 0 0 1 7 0"></path><path d="M2 8.82a15 15 0 0 1 4.17-2.65"></path><path d="M10.66 5c4.01-.36 8.14.9 11.34 3.76"></path><path d="M16.85 11.25a10 10 0 0 1 2.22 1.68"></path><path d="M5 13a10 10 0 0 1 5.24-2.76"></path><line x1="12" y1="20" x2="12.01" y2="20"></line></svg></div><h3 class="tobyflow-cfg-err-title"></h3><p class="tobyflow-cfg-err-desc"></p><button class="tobyflow-cfg-err-retry-btn" type="button"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 2v6h-6"></path><path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path><path d="M3 22v-6h6"></path><path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path></svg><span></span></button></div>';
      overlay.querySelector(".tobyflow-cfg-err-title").textContent = t.title;
      overlay.querySelector(".tobyflow-cfg-err-desc").textContent = t.desc;
      overlay.querySelector(".tobyflow-cfg-err-retry-btn span").textContent = t.retry;
      document.body.appendChild(overlay);
      overlay.querySelector(".tobyflow-cfg-err-retry-btn").addEventListener("click", function() {
        console.log("[Selector:flow:overlay] \u{1F504} User clicked retry \u2014 re-fetching config in background");
        overlay.remove();
        _selectorConfigReady = false;
        try {
          chrome.runtime.sendMessage({ action: "getProviderConfigs", provider: "flow" }, function() {
            if (chrome.runtime.lastError) {
            }
          });
        } catch (_) {
        }
        _runSelectorWaitLoop();
      });
      console.warn("[Selector:flow:overlay] \u{1F6AB} Config error overlay shown (lang=" + lang + ") \u2014 server unreachable, user action required");
    }, _showCloneDetectedOverlay = function() {
      if (document.getElementById("tobyflow-clone-detected-overlay")) return;
      var lang = _overlayLocale || "vi";
      var titleMap = {
        vi: "Extension kh\xF4ng h\u1EE3p l\u1EC7",
        en: "Extension Not Authorized",
        ja: "\u62E1\u5F35\u6A5F\u80FD\u304C\u8A31\u53EF\u3055\u308C\u3066\u3044\u307E\u305B\u3093",
        th: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2D\u0E19\u0E38\u0E0D\u0E32\u0E15"
      };
      var descMap = {
        vi: "Phi\xEAn b\u1EA3n extension n\xE0y kh\xF4ng c\xF3 quy\u1EC1n truy c\u1EADp API Toby Flow. Vui l\xF2ng c\xE0i l\u1EA1i t\u1EEB Chrome Web Store \u0111\u1EC3 ti\u1EBFp t\u1EE5c s\u1EED d\u1EE5ng.",
        en: "This extension version is not authorized to access Toby Flow API. Please reinstall from the Chrome Web Store to continue.",
        ja: "\u3053\u306E\u62E1\u5F35\u6A5F\u80FD\u306E\u30D0\u30FC\u30B8\u30E7\u30F3\u306F Toby Flow API \u3078\u306E\u30A2\u30AF\u30BB\u30B9\u304C\u8A31\u53EF\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002Chrome \u30A6\u30A7\u30D6\u30B9\u30C8\u30A2\u304B\u3089\u518D\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
        th: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E40\u0E27\u0E2D\u0E23\u0E4C\u0E0A\u0E31\u0E19\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2D\u0E19\u0E38\u0E0D\u0E32\u0E15\u0E43\u0E2B\u0E49\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07 API \u0E02\u0E2D\u0E07 Toby Flow \u0E42\u0E1B\u0E23\u0E14\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E08\u0E32\u0E01 Chrome \u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E42\u0E15\u0E23\u0E4C"
      };
      var btnMap = {
        vi: "M\u1EDF Chrome Web Store",
        en: "Open Chrome Web Store",
        ja: "Chrome \u30A6\u30A7\u30D6\u30B9\u30C8\u30A2\u3092\u958B\u304F",
        th: "\u0E40\u0E1B\u0E34\u0E14 Chrome \u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E42\u0E15\u0E23\u0E4C"
      };
      var overlay = document.createElement("div");
      overlay.id = "tobyflow-clone-detected-overlay";
      overlay.innerHTML = '<style>#tobyflow-clone-detected-overlay { position: fixed; inset: 0; z-index: 2147483647; background: rgba(10,10,14,0.97); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }#tobyflow-clone-detected-overlay .cd-content { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 32px; max-width: 340px; }#tobyflow-clone-detected-overlay .cd-icon { width: 80px; height: 80px; border-radius: 50%; background: rgba(239,68,68,0.15); display: flex; align-items: center; justify-content: center; margin-bottom: 20px; color: #ef4444; }#tobyflow-clone-detected-overlay .cd-title { font-size: 18px; font-weight: 600; color: #fff; margin: 0 0 8px 0; }#tobyflow-clone-detected-overlay .cd-desc { font-size: 14px; color: rgba(255,255,255,0.65); margin: 0 0 24px 0; line-height: 1.55; }#tobyflow-clone-detected-overlay .cd-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #fff; color: #1a1a1e; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; transition: opacity 0.2s; }#tobyflow-clone-detected-overlay .cd-btn:hover { opacity: 0.9; }</style><div class="cd-content"><div class="cd-icon"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><line x1="9" y1="9" x2="15" y2="15"></line><line x1="15" y1="9" x2="9" y2="15"></line></svg></div><h3 class="cd-title"></h3><p class="cd-desc"></p><a class="cd-btn" target="_blank" rel="noopener" href="https://chromewebstore.google.com/"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg><span></span></a></div>';
      overlay.querySelector(".cd-title").textContent = titleMap[lang] || titleMap.vi;
      overlay.querySelector(".cd-desc").textContent = descMap[lang] || descMap.vi;
      overlay.querySelector(".cd-btn span").textContent = btnMap[lang] || btnMap.vi;
      document.body.appendChild(overlay);
      console.error("[Auth:flow] \u{1F6E1}\uFE0F Clone-detected overlay shown \u2014 extension not authorized");
    }, _hideCloneDetectedOverlay = function() {
      var el = document.getElementById("tobyflow-clone-detected-overlay");
      if (el) el.remove();
    }, _getDynamicSelector = function(key) {
      var now = Date.now();
      if (_selectorConfig && now - _selectorConfigTime < _SELECTOR_CACHE_TTL) {
        return _selectorConfig?.flow?.selectors?.[key] || null;
      }
      chrome.storage.local.get(["toby_provider_configs"], function(res) {
        if (res.toby_provider_configs?.data?.flow) {
          _selectorConfig = res.toby_provider_configs.data;
          _selectorConfigTime = Date.now();
        }
      });
      if (!_selectorConfig && !_coldStartWarnedKeys.has(key)) {
        _coldStartWarnedKeys.add(key);
        console.debug('[Selector:flow] _getDynamicSelector("' + key + '") called before config ready \u2014 returning null (cold start race)');
      }
      return _selectorConfig?.flow?.selectors?.[key] || null;
    }, _selStr = function(key) {
      var cfg = _getDynamicSelector(key);
      return cfg?.selectors?.length ? cfg.selectors.join(", ") : null;
    }, _q = function(key, scope) {
      var s = _selStr(key);
      if (!s) {
        console.debug(`[Tier3] _q(${key}) miss`);
        return null;
      }
      return (scope || document).querySelector(s);
    }, _qa = function(key, scope) {
      var s = _selStr(key);
      if (!s) {
        console.debug(`[Tier3] _qa(${key}) miss`);
        return [];
      }
      return (scope || document).querySelectorAll(s);
    }, _queryWithFallback = function(key, defaultSelectors) {
      var config = _getDynamicSelector(key);
      var isDynamic = config?.selectors?.length > 0;
      var selectors = isDynamic ? config.selectors : defaultSelectors || [];
      console.log(`[Selector:${key}] Source: ${isDynamic ? "\u{1F310} DYNAMIC" : "\u{1F4E6} FALLBACK"} | Trying ${selectors.length} selectors`);
      for (var i = 0; i < selectors.length; i++) {
        try {
          var el = document.querySelector(selectors[i]);
          if (el) {
            console.log(`[Selector:${key}] \u2705 Match #${i + 1}: ${selectors[i]}`);
            return el;
          }
        } catch (e) {
        }
      }
      console.log(`[Selector:${key}] \u274C No match found`);
      return null;
    }, _findIconInElement = function(parent) {
      if (!parent) return null;
      var config = _getDynamicSelector("icon_element");
      if (!config?.selectors?.length) return null;
      for (var i = 0; i < config.selectors.length; i++) {
        try {
          var icon = parent.querySelector(config.selectors[i]);
          if (icon) return icon;
        } catch (e) {
        }
      }
      return null;
    }, _findIconsInElement = function(parent) {
      if (!parent) return [];
      var config = _getDynamicSelector("icon_element");
      if (!config?.selectors?.length) return [];
      for (var i = 0; i < config.selectors.length; i++) {
        try {
          var icons = parent.querySelectorAll(config.selectors[i]);
          if (icons.length > 0) return Array.from(icons);
        } catch (e) {
        }
      }
      return [];
    }, _getApiConfigValue = function(provider, key) {
      var now = Date.now();
      if (_apiConfigsCacheLocal && now - _apiConfigsCacheLocalTime < _API_CONFIGS_CACHE_TTL) {
        return _apiConfigsCacheLocal?.data?.[provider]?.configs?.[key] || null;
      }
      chrome.storage.local.get(["toby_provider_api_configs"], function(res) {
        if (res.toby_provider_api_configs?.data) {
          _apiConfigsCacheLocal = res.toby_provider_api_configs;
          _apiConfigsCacheLocalTime = Date.now();
        }
      });
      return _apiConfigsCacheLocal?.data?.[provider]?.configs?.[key] || null;
    }, _detectFlowUploadError = function() {
      try {
        const cfg = _getApiConfigValue("flow", "error_patterns");
        const raw = cfg && cfg.upload_blocked_text;
        if (!raw || typeof raw !== "string") return null;
        const patterns = raw.split("|").map(function(s) {
          return s.trim().toLowerCase();
        }).filter(Boolean);
        if (patterns.length === 0) return null;
        const toasts = document.querySelectorAll("[data-sonner-toast]");
        for (const t of toasts) {
          const text = (t.textContent || "").toLowerCase();
          if (!text) continue;
          if (patterns.some(function(p) {
            return text.indexOf(p) !== -1;
          })) {
            const titleEl = t.querySelector("[data-title]") || t;
            return (titleEl.textContent || "").trim();
          }
        }
      } catch (e) {
      }
      return null;
    }, _clickUploadConsentModal = function() {
      const cfg = _getDynamicSelector("upload_consent_confirm");
      const sels = cfg?.selectors?.length ? cfg.selectors : ['[role="dialog"][data-state="open"] button', '[role="dialog"] button'];
      const texts = Array.isArray(cfg?.text_match) && cfg.text_match.length ? cfg.text_match : ["T\xF4i \u0111\u1ED3ng \xFD", "I agree, Do not show again", "I agree"];
      const lowered = texts.map((t) => t.toLowerCase());
      for (const sel of sels) {
        let btns;
        try {
          btns = Array.from(document.querySelectorAll(sel));
        } catch (_) {
          continue;
        }
        for (const lt of lowered) {
          const agree = btns.find((b) => (b.textContent || "").trim().toLowerCase().includes(lt));
          if (agree) {
            console.log(`[uploadConsent] click "${(agree.textContent || "").trim()}"`);
            simulateClick(agree);
            return true;
          }
        }
      }
      return false;
    }, _getDownloadMenuLabel = function(resolution, isVideo) {
      var cfg = _getApiConfigValue("flow", "download_resolutions");
      if (!cfg) {
        console.debug("[Tier3] _getDownloadMenuLabel: download_resolutions cache empty \u2014 returning null");
        return null;
      }
      var mode = isVideo ? "video" : "image";
      var list = Array.isArray(cfg[mode]) ? cfg[mode] : [];
      var found = list.find(function(r) {
        return r.value === resolution;
      });
      return found?.menu_label || null;
    }, _getDownloadFallbackChain = function(isVideo) {
      var cfg = _getApiConfigValue("flow", "download_resolutions");
      if (!cfg) {
        console.debug("[Tier3] _getDownloadFallbackChain: download_resolutions cache empty \u2014 returning []");
        return [];
      }
      var key = isVideo ? "video_fallback_chain" : "image_fallback_chain";
      return Array.isArray(cfg[key]) ? cfg[key] : [];
    }, _getDownloadPixelWidth = function(resolution) {
      var cfg = _getApiConfigValue("flow", "download_resolutions");
      if (!cfg) {
        console.debug("[Tier3] _getDownloadPixelWidth: download_resolutions cache empty \u2014 returning null");
        return null;
      }
      var list = Array.isArray(cfg.image) ? cfg.image : [];
      var found = list.find(function(r) {
        return r.value === resolution;
      });
      return found?.pixel_width || null;
    }, _getTrackerT = function(key, params) {
      var t = _trackerTranslations[_trackerLocale] || _trackerTranslations.vi;
      var text = t[key] || _trackerTranslations.vi[key] || key;
      if (params) {
        for (var k in params) {
          text = text.replace("{" + k + "}", params[k]);
        }
      }
      return text;
    }, incrementDownloadCounter = function() {
      downloadCounter++;
      try {
        chrome.runtime.sendMessage({ action: "downloadCountUpdate", count: downloadCounter }).catch(() => {
        });
      } catch (e) {
      }
    }, getDownloadCounter = function() {
      return downloadCounter;
    }, debounce = function(fn, delay) {
      let timer;
      return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
      };
    }, sleep = function(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }, _setReactInputValue = function(el, value) {
      if (!el) return;
      try {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) {
          setter.call(el, value);
        } else {
          el.value = value;
        }
        el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      } catch (e) {
        el.value = value;
      }
    }, _findTabByIconText = function(iconText) {
      if (!iconText) return null;
      const cfg = _getDynamicSelector("advanced_menu_voices_tab");
      if (cfg?.selectors?.length) {
        for (const sel of cfg.selectors) {
          try {
            const candidates = document.querySelectorAll(sel);
            for (const btn of candidates) {
              const icon = btn.querySelector('i.google-symbols, i[class*="symbol"]');
              if (icon && icon.textContent?.trim() === iconText) return btn;
            }
          } catch (_) {
          }
        }
      }
      const tabCfg = _getDynamicSelector("tab_button_generic");
      const tabSelectors = tabCfg?.selectors?.length ? tabCfg.selectors : ['button[role="tab"]'];
      for (const sel of tabSelectors) {
        try {
          const tabs = document.querySelectorAll(sel);
          for (const btn of tabs) {
            const icon = btn.querySelector('i.google-symbols, i[class*="symbol"]');
            if (icon && icon.textContent?.trim() === iconText) return btn;
          }
        } catch (_) {
        }
      }
      return null;
    }, _closeFlowAdvancedMenu = function() {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
    }, _extractCharOption = function(opt, nameSelectors) {
      const img = opt.querySelector("img");
      if (!img) return null;
      let name = "";
      for (const sel of nameSelectors || []) {
        try {
          const v = opt.querySelector(sel)?.textContent?.trim();
          if (v && v.length < 80) {
            name = v;
            break;
          }
        } catch (_) {
        }
      }
      if (!name) {
        name = (opt.textContent || "").trim();
      }
      if (!name || name.length >= 80) return null;
      let thumb = img.getAttribute("src") || "";
      if (thumb && thumb.startsWith("/")) thumb = "https://labs.google" + thumb;
      return { name, thumbnail: thumb || null };
    }, _incrementDailyStat = function(key) {
      _statQueue = _statQueue.then(async () => {
        const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        const currentUserId = window.authManager?.user?.id || null;
        const res = await new Promise((resolve) => chrome.storage.local.get(["af_daily_stats"], resolve));
        const stats = res.af_daily_stats || {};
        if (stats._date !== today || stats._user_id !== currentUserId) {
          stats._date = today;
          stats._user_id = currentUserId;
          stats.flow_prompt_total = 0;
          stats.chatgpt_prompt_total = 0;
          stats.gemini_prompt_total = 0;
          stats.grok_prompt_total = 0;
          stats.flow_fail = 0;
          stats.chatgpt_fail = 0;
          stats.gemini_fail = 0;
          stats.grok_fail = 0;
          stats.task_run = 0;
          stats.workflow_run = 0;
          stats.angles_run = 0;
          stats.flow_refresh_success = 0;
          stats.flow_refresh_fail = 0;
        }
        stats[key] = (stats[key] || 0) + 1;
        await new Promise((resolve) => chrome.storage.local.set({ af_daily_stats: stats }, resolve));
      }).catch((err) => {
        console.warn("[content.js] _incrementDailyStat error:", err.message);
      });
    }, getInputTimeoutMs = function() {
      if (typeof _cachedInputTimeoutMs === "number" && _cachedInputTimeoutMs > 0) {
        return _cachedInputTimeoutMs;
      }
      return window._afSettings?.inputTimeout || 1200;
    }, getClearEditorDelay = function() {
      return Math.round(getInputTimeoutMs() * 0.4);
    }, getSubmitDelay = function() {
      return Math.round(getInputTimeoutMs() * 0.5);
    }, getAfterSubmitDelay = function() {
      return Math.round(getInputTimeoutMs() * 0.8);
    }, getSettingsStepDelay = function() {
      return Math.round(getInputTimeoutMs() * 0.3);
    }, getDelayBetweenPromptsMs = function() {
      if (typeof _cachedDelayBetweenMs === "number" && _cachedDelayBetweenMs > 0) {
        return _cachedDelayBetweenMs;
      }
      const seconds = window._afExecConfig?.timing?.delay_between_prompts_sec || 5;
      return seconds * 1e3;
    }, getRandomDelay = function() {
      const min = (window._afSettings?.randomDelayMin || 3) * 1e3;
      const max = (window._afSettings?.randomDelayMax || 10) * 1e3;
      return min + Math.random() * (max - min);
    }, _isLogSelectorsEnabled = function() {
      return !!(typeof window !== "undefined" && window._afDebug);
    }, _logSelectorPick = function(name, tier, tierName, result) {
      if (!_isLogSelectorsEnabled()) return;
      const status = result ? "found" : "null";
      console.log(`[Selector] ${name} \u2192 tier ${tier} (${tierName}) = ${status}`);
    }, getEditor = function() {
      const allEditors = _queryAllSlateEditors();
      for (const ed of allEditors) {
        const hasPlaceholder = !!ed.querySelector("[data-slate-placeholder]");
        let container = ed;
        let containerHit = false;
        for (let i = 0; i < 5 && container; i++) {
          container = container.parentElement;
          if (!container) break;
          const iconsInContainer = _findIconsInElement(container);
          const submitIconText = _getDynamicSelector("submit_button")?.icon_text;
          const settingsIconText = _getDynamicSelector("settings_button")?.icon_text;
          const hasIcon = iconsInContainer.some((ic) => {
            const t = ic.textContent.trim();
            if (submitIconText && t === submitIconText) return true;
            if (settingsIconText && t.startsWith(settingsIconText)) return true;
            return /^add_2/.test(t);
          });
          const hasRadixBtn = !!_q("settings_button", container);
          const _stCfg = _getDynamicSelector("settings_button");
          const _menuSel = _stCfg?.selectors?.[0];
          const hasMenuBtn = !!(_menuSel && container.querySelector(_menuSel));
          const hasDialogBtn = !!container.querySelector('button[aria-haspopup="dialog"]');
          if (hasIcon || hasRadixBtn || hasMenuBtn || hasDialogBtn) {
            containerHit = true;
            break;
          }
        }
        if (hasPlaceholder || containerHit) {
          _logSelectorPick("getEditor", 1, hasPlaceholder ? "placeholder" : "container-marker", ed);
          return ed;
        }
      }
      if (allEditors.length > 0) {
        const last = allEditors[allEditors.length - 1];
        _logSelectorPick("getEditor", "fallback", "last-of-list", last);
        return last;
      }
      _logSelectorPick("getEditor", "fail", "no-slate-editor", null);
      return null;
    }, getSettingsButton = function(submitBtn = null) {
      const settingsConfig = _getDynamicSelector("settings_button");
      const settingsIconPrefix = settingsConfig?.icon_text || null;
      const iconPrefixMatch = (icon) => settingsIconPrefix && icon && icon.textContent.trim().startsWith(settingsIconPrefix);
      const _sb1 = settingsConfig?.selectors?.[0];
      const menuBtns = _sb1 ? document.querySelectorAll(_sb1) : [];
      for (const btn of menuBtns) {
        const icon = _findIconInElement(btn);
        if (iconPrefixMatch(icon)) {
          _logSelectorPick("getSettingsButton", 1, "aria-menu+icon", btn);
          return btn;
        }
      }
      const radixBtns = _qa("settings_button");
      for (const btn of radixBtns) {
        const icon = _findIconInElement(btn);
        if (iconPrefixMatch(icon)) {
          _logSelectorPick("getSettingsButton", 2, "radix-id+icon", btn);
          return btn;
        }
      }
      const sb = submitBtn || getSubmitButton();
      if (sb?.previousElementSibling && sb.previousElementSibling.tagName === "BUTTON") {
        _logSelectorPick("getSettingsButton", 3, "positional", sb.previousElementSibling);
        return sb.previousElementSibling;
      }
      if (settingsIconPrefix) {
        const escapedPrefix = settingsIconPrefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const prefixRegex = new RegExp(escapedPrefix);
        const allBtns = document.querySelectorAll("button");
        for (const btn of allBtns) {
          if (prefixRegex.test(btn.textContent || "")) {
            _logSelectorPick("getSettingsButton", 4, "text-prefix", btn);
            return btn;
          }
        }
      }
      _logSelectorPick("getSettingsButton", "fail", "all", null);
      return null;
    }, _getActiveSettingsPanel = function() {
      const _candCfg = _getDynamicSelector("settings_panel_candidates");
      const _candSelectors = _candCfg?.selectors?.length ? _candCfg.selectors : [];
      const _markerCfg = _getDynamicSelector("settings_panel_marker");
      const _markerSelector = _markerCfg?.selectors?.[0] || null;
      if (!_candSelectors.length || !_markerSelector) {
        console.debug("[Tier3] _getActiveSettingsPanel: settings_panel_candidates/marker config miss");
        return document;
      }
      const candidates = document.querySelectorAll(_candSelectors.join(", "));
      for (let i = candidates.length - 1; i >= 0; i--) {
        const el = candidates[i];
        try {
          if (el.querySelector(_markerSelector)) return el;
        } catch (_) {
        }
      }
      if (candidates.length > 0) return candidates[candidates.length - 1];
      return document;
    }, getSubmitButton = function() {
      var config = _getDynamicSelector("submit_button");
      var hasConfig = !!config;
      var selectors = config?.selectors || [];
      var iconText = config?.icon_text;
      var submitTexts = config?.button_text?.length ? config.button_text : [];
      if (!iconText) {
        console.debug("[Tier3] getSubmitButton: submit_button.icon_text cache miss");
        iconText = "";
      }
      console.log(`[Selector:submit_button] Source: ${hasConfig ? "\u{1F310} DYNAMIC" : "\u{1F4E6} HARDCODED"} | selectors=${selectors.length} | icon_text="${iconText}" | button_text=[${submitTexts.join(", ")}]`);
      for (var s = 0; s < selectors.length; s++) {
        try {
          var el = document.querySelector(selectors[s]);
          if (el) {
            console.log(`[Selector:submit_button] \u2705 Tier 0 Match #${s + 1}: ${selectors[s]}`);
            _logSelectorPick("getSubmitButton", 0, "selector", el);
            return el;
          } else {
            console.log(`[Selector:submit_button] \u274C Tier 0 No match: ${selectors[s]}`);
          }
        } catch (e) {
        }
      }
      var buttons = document.querySelectorAll("button");
      for (var i = 0; i < buttons.length; i++) {
        var btn = buttons[i];
        var icon = _findIconInElement(btn);
        if (icon && icon.textContent.trim() === iconText) {
          _logSelectorPick("getSubmitButton", 1, "icon", btn);
          return btn;
        }
      }
      for (var j = 0; j < buttons.length; j++) {
        var btn2 = buttons[j];
        var btnText = btn2.textContent.trim();
        if (submitTexts.some(function(t) {
          return btnText.includes(t);
        })) {
          _logSelectorPick("getSubmitButton", 2, "text", btn2);
          return btn2;
        }
      }
      var submitBtn = _queryWithFallback("submit_button");
      if (submitBtn) {
        _logSelectorPick("getSubmitButton", 3, "type=submit", submitBtn);
        return submitBtn;
      }
      _logSelectorPick("getSubmitButton", "fail", "all", null);
      return null;
    }, sendLog = function(msg, level = "info") {
      console.log(`[FlowAuto] ${msg}`);
      const logContainer = document.getElementById("logContainer");
      if (logContainer) {
        const div = document.createElement("div");
        div.className = `log-entry ${level}`;
        div.textContent = `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] ${msg}`;
        logContainer.appendChild(div);
        logContainer.scrollTop = logContainer.scrollHeight;
      }
      const logTabBtn = document.querySelector('.tab-btn[data-tab="tab-logs"]');
      if (logTabBtn && !logTabBtn.classList.contains("active")) {
        logTabBtn.classList.add("has-new");
      }
      if (!chrome.runtime?.id) return;
      try {
        chrome.runtime.sendMessage({ action: "contentLog", msg, level }).catch(() => {
        });
      } catch (e) {
      }
    }, sendRetryStatus = function(text) {
      try {
        chrome.runtime.sendMessage({ action: "retry:status", text }).catch(() => {
        });
      } catch (e) {
      }
    }, isAutoDownloadEnabled = function() {
      const genTabToggle = document.getElementById("genTabAutoDownload");
      if (genTabToggle) return genTabToggle.checked;
      return false;
    }, getDownloadSettings = function() {
      return new Promise((resolve) => {
        chrome.storage.local.get(["af_settings"], (res) => {
          const s = res.af_settings || {};
          resolve({
            folder: s.downloadFolder || "tobyflow_output",
            template: s.fileNameTemplate || "[Date]_[Project]_[Prompt]_[Index]",
            project: s.fileNameProject || "",
            resolution: s.downloadResolution || "1k"
          });
        });
      });
    }, _toAscii = function(str) {
      if (!str) return str;
      return str.replace(/[đĐ]/g, (c) => c === "\u0111" ? "d" : "D").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    }, _buildFilename = function({ template, project, prompt, index, taskName, folder, ext }) {
      const now = /* @__PURE__ */ new Date();
      const date = now.toISOString().slice(0, 10);
      const time = now.toTimeString().slice(0, 8).replace(/:/g, "-");
      const safeProject = _toAscii(project || "").substring(0, 30).replace(/[^a-zA-Z0-9_-]/g, "_");
      const safePrompt = _toAscii(prompt || "flow").substring(0, 40).replace(/[^a-zA-Z0-9_-]/g, "_");
      const safeIndex = index ? String(index).padStart(3, "0") : "";
      let filename = (template || "[Date]_[Prompt]").replace(/\[Date\]/gi, date).replace(/\[Time\]/gi, time).replace(/\[Project\]/gi, safeProject).replace(/\[Prompt\]/gi, safePrompt).replace(/\[Index\]/gi, safeIndex);
      filename = filename.replace(/_+/g, "_").replace(/^_|_$/g, "");
      if (!filename) filename = "flow_" + Date.now();
      const baseFolder = folder || "tobyflow_output";
      const extension = ext || "png";
      if (taskName) {
        const safeTaskName = _toAscii(taskName).substring(0, 30).replace(/[^a-zA-Z0-9_-]/g, "_");
        if (safeTaskName.toLowerCase() === baseFolder.toLowerCase()) {
          console.warn("[TobyFlow] _buildFilename: taskName tr\xF9ng baseFolder, skip duplicate layer:", baseFolder);
          return `${baseFolder}/${filename}.${extension}`;
        }
        return `${baseFolder}/${safeTaskName}/${filename}.${extension}`;
      }
      return `${baseFolder}/${filename}.${extension}`;
    }, applyResolutionToUrl = function(url, resolution) {
      if (!url || resolution === "original") return url;
      const targetWidth = _getDownloadPixelWidth(resolution);
      if (!targetWidth) return url;
      try {
        if (url.includes("googleusercontent.com") || url.includes("storage.googleapis.com") || url.includes("lh3.")) {
          let cleanUrl = url.replace(/=w\d+(-h\d+)?/g, "").replace(/=s\d+/g, "").replace(/=h\d+/g, "");
          cleanUrl = cleanUrl.replace(/=+$/, "");
          const separator = cleanUrl.includes("=") ? "-" : "=";
          return `${cleanUrl}${separator}w${targetWidth}`;
        }
        const urlObj = new URL(url);
        urlObj.searchParams.set("w", targetWidth.toString());
        return urlObj.toString();
      } catch (e) {
        return url;
      }
    }, _waitForElement = function(selector, timeoutMs = 3e3, excludeEl = null) {
      return new Promise((resolve) => {
        const existing = document.querySelectorAll(selector);
        for (const el of existing) {
          if (!excludeEl || el !== excludeEl) {
            resolve(el);
            return;
          }
        }
        const observer = new MutationObserver(() => {
          const els = document.querySelectorAll(selector);
          for (const el of els) {
            if (!excludeEl || el !== excludeEl) {
              observer.disconnect();
              clearTimeout(timer);
              resolve(el);
              return;
            }
          }
        });
        observer.observe(document.body, { childList: true, subtree: true });
        const timer = setTimeout(() => {
          observer.disconnect();
          resolve(null);
        }, timeoutMs);
      });
    }, _waitForTileMediaReady = function(tile, timeoutMs = 1e4, preferVideo = false) {
      return new Promise((resolve) => {
        const startTime = Date.now();
        const videoFallbackMs = Math.min(8e3, timeoutMs * 0.6);
        const check = () => {
          const status = detectTileStatus(tile);
          if (status === "failed") {
            console.warn("[TobyFlow] _waitForTileMediaReady: tile is failed, skip download");
            resolve(null);
            return;
          }
          let media;
          if (preferVideo) {
            media = _q("tile_video", tile);
            if (!media && status === "success" && Date.now() - startTime >= videoFallbackMs) {
              const img = tile.querySelector("img");
              if (img) {
                const imgSrc = img.src || "";
                const imgRaw = img.getAttribute("src") || "";
                const isValidUrl = imgSrc.startsWith("http") && !imgSrc.includes("media.html") && !imgSrc.endsWith(".html") && !imgRaw.endsWith(".html");
                if (isValidUrl) {
                  console.warn("[TobyFlow] _waitForTileMediaReady: video not in DOM after " + Math.round(videoFallbackMs / 1e3) + "s, falling back to img early");
                  resolve(img);
                  return;
                }
              }
            }
          } else {
            media = _q("tile_video", tile) || tile.querySelector("img");
          }
          if (media && status === "success") {
            const src = media.src || "";
            const rawSrc = media.getAttribute("src") || "";
            const isVideoMedia = media.tagName === "VIDEO";
            const isVideoBlobOrRelative = isVideoMedia && (src.startsWith("blob:") || rawSrc.startsWith("/fx/"));
            const isPlaceholderUrl = src.includes("media.html") || src.endsWith(".html") || rawSrc === "media.html" || rawSrc.endsWith(".html");
            const hasValidSrc = (isVideoBlobOrRelative || (src.startsWith("http://") || src.startsWith("https://"))) && !src.includes("chrome-extension") && !isPlaceholderUrl;
            const isTabHidden = document.visibilityState === "hidden" || !document.hasFocus();
            const isLoaded = isVideoMedia ? true : isTabHidden ? true : media.naturalWidth > 0 && media.complete;
            if (hasValidSrc && isLoaded) {
              resolve(media);
              return;
            }
          }
          if (Date.now() - startTime >= timeoutMs) {
            if (preferVideo) {
              const img = tile.querySelector("img");
              if (img) {
                const imgSrc = img.src || "";
                const imgRaw = img.getAttribute("src") || "";
                const isValidUrl = imgSrc.startsWith("http") && !imgSrc.includes("media.html") && !imgSrc.endsWith(".html") && !imgRaw.endsWith(".html");
                if (isValidUrl) {
                  console.warn("[TobyFlow] _waitForTileMediaReady: video not ready, falling back to img");
                  resolve(img);
                  return;
                }
              }
            }
            resolve(null);
            return;
          }
          setTimeout(check, 200);
        };
        check();
      });
    }, _closeContextMenu = function() {
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    }, _releaseCtxMenuLock = function() {
      if (_ctxMenuLockQueue.length > 0) {
        const next = _ctxMenuLockQueue.shift();
        next();
      } else {
        _ctxMenuLocked = false;
        if (!ExecutionBlocker._blocking) {
          document.body.classList.remove("tobyflow-execution-blocking");
        }
      }
    }, extractFileName = function(tile) {
      if (!tile) return null;
      const tileId = tile.dataset?.tileId;
      if (tileId && _fileNameCache.has(tileId)) return _fileNameCache.get(tileId);
      const urlPattern = _getMediaUrlPattern();
      if (!urlPattern) return null;
      const candidates = [
        ...tile.querySelectorAll(`img[src*="${urlPattern}"]`),
        ...tile.querySelectorAll(`a[href*="${urlPattern}"]`),
        ...tile.querySelectorAll(`[src*="${urlPattern}"]`)
      ];
      if (candidates.length === 0) {
        const img = tile.querySelector("img");
        if (img?.src?.includes(urlPattern)) candidates.push(img);
      }
      for (const el of candidates) {
        const url = el.src || el.href;
        if (!url) continue;
        const fn = extractFileNameFromUrl(url);
        if (fn) {
          if (tileId) _fileNameCache.set(tileId, fn);
          return fn;
        }
      }
      return null;
    }, extractFileNameFromUrl = function(url) {
      if (!url || !url.includes(_getMediaUrlPattern())) return null;
      try {
        const urlObj = new URL(url, window.location.origin);
        const name = urlObj.searchParams.get("name");
        if (name && /^[a-f0-9-]{8,}$/i.test(name)) return name;
        const input = urlObj.searchParams.get("input");
        if (input) {
          const parsed = JSON.parse(decodeURIComponent(input));
          const json = parsed?.json || parsed?.["0"]?.json || parsed;
          if (json?.name && /^[a-f0-9-]{8,}$/i.test(json.name)) return json.name;
        }
      } catch (e) {
      }
      return null;
    }, extractThumbnailUrl = function(tile) {
      if (!tile) return null;
      const _muPat = _getMediaUrlPattern();
      if (_muPat) {
        const imgFlow = tile.querySelector(`img[src*="${_muPat}"]`);
        if (imgFlow?.src) return imgFlow.src;
        const video = tile.querySelector(`video[src*="${_muPat}"]`);
        if (video?.src) return video.src;
      }
      const imgCdn = _q("tile_image", tile);
      if (imgCdn?.src) return imgCdn.src;
      const anyImg = tile.querySelector('img[src^="http"]');
      if (anyImg?.src) return anyImg.src;
      const relativeImg = tile.querySelector('img[src^="/fx/"]');
      if (relativeImg?.src) return relativeImg.src;
      return null;
    }, extractVideoUrl = function(tile) {
      if (!tile) return null;
      const video = _q("tile_video", tile);
      if (!video) return null;
      let videoUrl = video.src || video.currentSrc || "";
      if (!videoUrl) return null;
      if (!videoUrl.startsWith("http")) {
        try {
          videoUrl = new URL(videoUrl, window.location.origin).href;
        } catch (e) {
          console.warn("[extractVideoUrl] Cannot resolve:", videoUrl);
          return null;
        }
      }
      return videoUrl;
    }, extractFlowFileInfo = function(tile) {
      if (!tile) return null;
      const link = _q("project_link", tile);
      if (!link) return null;
      const match = link.href.match(/\/project\/([a-f0-9-]+)\/edit\/([a-f0-9-]+)/);
      if (!match) return null;
      return { project_id: match[1], file_id: match[2] };
    }, getCurrentProjectId = function() {
      const urlMatch = location.pathname.match(/\/project\/([a-f0-9-]+)/);
      if (urlMatch) return urlMatch[1];
      if (!location.pathname.includes("/project/")) {
        return null;
      }
      const link = _q("project_link");
      if (link) {
        const m = link.href.match(/\/project\/([a-f0-9-]+)/);
        if (m) return m[1];
      }
      return null;
    }, _isFlowProjectErrorState = function() {
      if (!location.pathname.includes("/project/")) return false;
      if (!_selectorConfig?.flow?.selectors) return false;
      if (_q("slate_editor") || _q("submit_button") || _q("tile_container")) {
        return false;
      }
      return !!(_q("project_error_indicator") || document.querySelector('#__next a[href$="/tools/flow"]'));
    }, _isFlowMediaViewerOpen = function() {
      return /\/project\/[a-f0-9-]+\/edit\/[a-f0-9-]+/.test(location.pathname);
    }, findTileByFileId = function(fileId) {
      if (!fileId) return null;
      const editLinks = _qa("edit_link");
      let link = null;
      for (const el of editLinks) {
        if (el.href && el.href.includes(`/edit/${fileId}`)) {
          link = el;
          break;
        }
      }
      return link ? link.closest(_getTileSelectorString()) : null;
    }, extractProjectName = function() {
      if (!location.pathname.match(/\/project\/[a-f0-9-]+/)) {
        return null;
      }
      const projectNameLabels = _getFlowLocaleStrings("project_name_input", "aria_labels");
      const inputs = _queryInputsByAriaLabels(projectNameLabels);
      const _slSel2 = _getSlateEditorSelectorString();
      const slateEditor = _slSel2 ? document.querySelector(_slSel2) : null;
      let promptContainer = null;
      if (slateEditor) {
        let probe = slateEditor.parentElement;
        for (let i = 0; i < 6 && probe; i++) {
          if (probe.children.length > 1) {
            promptContainer = probe;
            break;
          }
          probe = probe.parentElement;
        }
        if (!promptContainer) {
          promptContainer = slateEditor.parentElement?.parentElement?.parentElement;
        }
      }
      for (const input of inputs) {
        if (!input.closest("nav")) continue;
        if (input.closest(_getTileSelectorString())) continue;
        if (input.closest('[role="dialog"]')) continue;
        if (promptContainer && promptContainer.contains(input)) continue;
        if (slateEditor && input.closest("[data-slate-editor]")) continue;
        const val = input.value?.trim();
        if (val) return val;
      }
      const title = document.title;
      if (title) {
        const parts = title.split(/\s*[-–—|]\s*/);
        for (const part of parts) {
          const candidate = part.trim();
          if (!candidate || candidate.length === 0 || candidate.length >= 100) continue;
          const lower = candidate.toLowerCase();
          if (lower === "flow" || lower === "labs" || lower.includes("labs.google") || lower.includes("google")) continue;
          return candidate;
        }
      }
      return null;
    }, _qaProjectLinks = function(scope) {
      const fromConfig = _qa("project_link", scope);
      if (fromConfig.length > 0) return fromConfig;
      const root = scope || document;
      return Array.from(root.querySelectorAll('a[href*="/project/"]')).filter(
        (a) => /\/project\/[a-f0-9-]{8,}/i.test(a.href || "")
      );
    }, _getFlowGoogleLoginState = function() {
      const url = location.href || "";
      if (/\/(ServiceLogin|signin|accounts\.google\.com)/i.test(url)) {
        return { loggedIn: false, reason: "login_page" };
      }
      if (getCurrentProjectId()) {
        return { loggedIn: true, reason: "in_project" };
      }
      if (_qaProjectLinks().length > 0) {
        return { loggedIn: true, reason: "has_projects" };
      }
      const signinLink = document.querySelector(
        'a[href*="accounts.google.com"], a[href*="/signin"], button[aria-label*="Sign in" i], button[aria-label*="\u0110\u0103ng nh\u1EADp" i]'
      );
      if (signinLink) {
        return { loggedIn: false, reason: "signin_prompt" };
      }
      if (/\/tools\/flow/i.test(location.pathname)) {
        return { loggedIn: true, reason: "flow_homepage" };
      }
      return { loggedIn: null, reason: "unknown" };
    }, _collectFlowProjects = function() {
      const projects = [];
      const seen = /* @__PURE__ */ new Set();
      let flowOrder = 0;
      const links = _qaProjectLinks();
      for (const link of links) {
        const m = link.href.match(/\/project\/([a-f0-9-]+)/);
        if (!m || seen.has(m[1])) continue;
        seen.add(m[1]);
        const order = flowOrder++;
        const card = link.closest(_getTileSelectorString()) || link.parentElement;
        let name = null;
        if (card) {
          let renameInput = null;
          const renameLabels = _getFlowLocaleStrings("project_name_input", "aria_labels");
          for (const label of renameLabels) {
            renameInput = card.querySelector(`input[aria-label="${label}"]`);
            if (renameInput) break;
          }
          if (renameInput?.value?.trim()) name = renameInput.value.trim();
          if (!name) {
            const ariaLabel = link.getAttribute("aria-label") || card.getAttribute("aria-label");
            if (ariaLabel && ariaLabel.length < 100) name = ariaLabel;
          }
          if (!name) {
            const textEls = card.querySelectorAll("span, p");
            for (const el of textEls) {
              if (el.closest("button")) continue;
              let directText = "";
              for (const node of el.childNodes) {
                if (node.nodeType === 3) directText += node.textContent;
              }
              const txt = directText.trim();
              if (!txt || txt.length > 80) continue;
              if (/^\d+$/.test(txt)) continue;
              if (/^(chỉnh sửa|xoá|xóa|edit|delete|remove|sửa|new project|tạo|create)/i.test(txt)) continue;
              name = txt;
              break;
            }
          }
        }
        projects.push({ id: m[1], name, flowOrder: order });
      }
      return projects;
    }, getUniqueTileIds = function(forceRefresh = false) {
      if (forceRefresh) {
        _invalidateTileCache();
      }
      const tiles = _getCachedTiles();
      let ids = [...new Set([...tiles].map((t) => t.dataset?.tileId || t.getAttribute?.("data-tile-id")).filter(Boolean))];
      if (ids.length === 0) {
        try {
          const raw = document.querySelectorAll("[data-tile-id]");
          const fallback = [];
          raw.forEach((el) => {
            const id = el.getAttribute("data-tile-id");
            if (id) fallback.push(id);
          });
          ids = [...new Set(fallback)];
          if (ids.length > 0) {
            console.log("[getUniqueTileIds] fallback [data-tile-id] count=", ids.length);
          }
        } catch (_) {
        }
      }
      return ids;
    }, getExistingFileNames = function() {
      const fileNameSet = /* @__PURE__ */ new Set();
      const _pat = _getMediaUrlPattern();
      if (!_pat) return fileNameSet;
      const mediaEls = document.querySelectorAll(`[src*="${_pat}"], [href*="${_pat}"]`);
      for (const el of mediaEls) {
        const url = el.src || el.href || "";
        const fn = extractFileNameFromUrl(url);
        if (fn) fileNameSet.add(fn);
      }
      return fileNameSet;
    }, isTileComplete = function(tile) {
      if (!tile) return false;
      const fileName = extractFileName(tile);
      return !!fileName;
    }, validateTileFile = function(tileId, expectedFileName) {
      if (!expectedFileName) return true;
      const tile = _getTileById(tileId);
      if (!tile) return false;
      const currentFileName = extractFileName(tile);
      if (!currentFileName) return true;
      return currentFileName === expectedFileName;
    }, clickTileRetryButton = function(tileId) {
      const tile = _getTileById(tileId);
      if (!tile) return false;
      const config = _getDynamicSelector("tile_retry_button");
      if (!config || !Array.isArray(config.selectors) || config.selectors.length === 0) {
        console.warn('[Flow:tile_retry] Config missing/empty \u2014 skip retry. \u0110\u1EE3i server config sync ho\u1EB7c admin seed key "tile_retry_button".');
        return false;
      }
      const selectors = config.selectors;
      const iconText = config.icon_text || null;
      const buttonTextList = Array.isArray(config.button_text) ? config.button_text : [];
      let candidates = [];
      for (const sel of selectors) {
        try {
          const found = tile.querySelectorAll(sel);
          candidates.push(...found);
        } catch (e) {
        }
      }
      if (candidates.length === 0) {
        console.warn("[Flow:tile_retry] No button candidates matched server selectors:", selectors);
        return false;
      }
      let retryBtn = null;
      for (const btn of candidates) {
        if (iconText) {
          const icon = btn.querySelector("i, span, [data-icon]");
          if (icon && icon.textContent.trim() === iconText) {
            retryBtn = btn;
            break;
          }
        }
        if (buttonTextList.length > 0) {
          const btnText = (btn.textContent || "").trim();
          if (btnText && buttonTextList.some((label) => btnText.includes(label))) {
            retryBtn = btn;
            break;
          }
        }
      }
      if (!retryBtn) return false;
      const propsKey = Object.keys(retryBtn).find((k) => k.startsWith("__reactProps$"));
      if (propsKey && retryBtn[propsKey] && typeof retryBtn[propsKey].onClick === "function") {
        try {
          retryBtn[propsKey].onClick({
            preventDefault: function() {
            },
            stopPropagation: function() {
            },
            nativeEvent: new MouseEvent("click"),
            type: "click",
            target: retryBtn,
            currentTarget: retryBtn
          });
          return true;
        } catch (e) {
          console.warn("[TobyFlow] React onClick retry failed:", e.message);
        }
      }
      simulateClick(retryBtn);
      return true;
    }, clickUploadRetryButton = function(tileId) {
      const tile = _getTileById(tileId);
      if (!tile) return false;
      const config = _getDynamicSelector("tile_retry_button");
      if (!config || !Array.isArray(config.selectors) || config.selectors.length === 0) {
        console.warn('[Flow:upload_retry] Config missing/empty \u2014 skip retry. Check key "tile_retry_button" trong admin.');
        return false;
      }
      const selectors = config.selectors;
      const iconText = config.icon_text || null;
      const buttonTextList = Array.isArray(config.button_text) ? config.button_text : [];
      let candidates = [];
      for (const sel of selectors) {
        try {
          const found = tile.querySelectorAll(sel);
          candidates.push(...found);
        } catch (e) {
        }
      }
      if (candidates.length === 0) {
        console.warn("[Flow:upload_retry] No button candidates matched server selectors:", selectors);
        return false;
      }
      let retryBtn = null;
      for (const btn of candidates) {
        if (iconText) {
          const icon = btn.querySelector("i, span, [data-icon]");
          if (icon && icon.textContent.trim() === iconText) {
            retryBtn = btn;
            break;
          }
        }
        if (buttonTextList.length > 0) {
          const btnText = (btn.textContent || "").trim();
          if (btnText && buttonTextList.some((label) => btnText.includes(label))) {
            retryBtn = btn;
            break;
          }
        }
      }
      if (!retryBtn) {
        console.warn("[Flow:upload_retry] No button matched icon_text/button_text criteria");
        return false;
      }
      const propsKey = Object.keys(retryBtn).find((k) => k.startsWith("__reactProps$"));
      if (propsKey && retryBtn[propsKey] && typeof retryBtn[propsKey].onClick === "function") {
        try {
          retryBtn[propsKey].onClick({
            preventDefault: function() {
            },
            stopPropagation: function() {
            },
            nativeEvent: new MouseEvent("click"),
            type: "click",
            target: retryBtn,
            currentTarget: retryBtn
          });
          console.log("[Flow:upload_retry] React onClick triggered for tile:", tileId);
          return true;
        } catch (e) {
          console.warn("[Flow:upload_retry] React onClick failed:", e.message);
        }
      }
      simulateClick(retryBtn);
      console.log("[Flow:upload_retry] Native click triggered for tile:", tileId);
      return true;
    }, detectTileStatus = function(tileEl) {
      if (!tileEl) return "processing";
      var _statusTileId = tileEl.dataset?.tileId;
      if (_statusTileId) {
        var _cached = _statusCache.get(_statusTileId);
        if (_cached && Date.now() - _cached.ts < 1500) return _cached.status;
      }
      const media = _q("tile_video", tileEl) || tileEl.querySelector("img");
      if (media && media.src && !media.src.startsWith("data:")) {
        const mediaSrc = media.src || "";
        const rawSrc = media.getAttribute("src") || "";
        const isPlaceholder = mediaSrc.includes("media.html") || mediaSrc.endsWith(".html") || rawSrc === "media.html" || rawSrc.endsWith(".html") || !mediaSrc.startsWith("http://") && !mediaSrc.startsWith("https://") && !mediaSrc.startsWith("blob:");
        if (!isPlaceholder) {
          if (_statusTileId) _statusCache.set(_statusTileId, { status: "success", ts: Date.now() });
          return "success";
        }
      }
      const progressEl = Array.from(tileEl.querySelectorAll("div")).find((d) => {
        if (d.children.length > 2) return false;
        return /^\d+%$/.test(d.textContent.trim());
      });
      if (progressEl) {
        if (_statusTileId) _statusCache.set(_statusTileId, { status: "processing", ts: Date.now() });
        return "processing";
      }
      const _isElVisible = (el) => {
        try {
          const c = window.getComputedStyle(el);
          if (c.opacity === "0" || c.visibility === "hidden" || c.display === "none") return false;
        } catch (e) {
        }
        let p = el.parentElement;
        while (p && p !== tileEl) {
          if (p.style && p.style.opacity === "0") return false;
          try {
            const c = window.getComputedStyle(p);
            if (c.opacity === "0" || c.visibility === "hidden" || c.display === "none") return false;
          } catch (e) {
          }
          p = p.parentElement;
        }
        return true;
      };
      const genIcon = Array.from(tileEl.querySelectorAll("i")).find((el) => el.textContent.trim() === "play_circle");
      if (genIcon && _isElVisible(genIcon)) {
        return "processing";
      }
      const warningConfig = _getDynamicSelector("warning_icon");
      let warningText = warningConfig?.text_match;
      if (!warningText) {
        console.debug("[Tier3] warning detection: warning_icon.text_match cache miss");
        warningText = "";
      }
      let warningIcons = [];
      if (Array.isArray(warningConfig?.selectors) && warningConfig.selectors.length > 0) {
        for (const sel of warningConfig.selectors) {
          try {
            const found = tileEl.querySelectorAll(sel);
            if (found.length > 0) {
              warningIcons = Array.from(found);
              break;
            }
          } catch (e) {
          }
        }
      }
      for (const icon of warningIcons) {
        if (icon.textContent.trim() !== warningText) continue;
        let isHidden = false;
        try {
          const iconComputed = window.getComputedStyle(icon);
          if (iconComputed.opacity === "0" || iconComputed.visibility === "hidden" || iconComputed.display === "none") {
            isHidden = true;
          }
        } catch (e) {
        }
        if (!isHidden) {
          let parent = icon.parentElement;
          while (parent && parent !== tileEl) {
            if (parent.style && parent.style.opacity === "0") {
              isHidden = true;
              break;
            }
            try {
              const computed = window.getComputedStyle(parent);
              if (computed.opacity === "0" || computed.visibility === "hidden" || computed.display === "none") {
                isHidden = true;
                break;
              }
            } catch (e) {
            }
            parent = parent.parentElement;
          }
        }
        if (!isHidden) {
          return "failed";
        }
      }
      return "processing";
    }, detectMediaType = function(tile) {
      if (!tile) return "image";
      const video = _q("tile_video", tile);
      if (video) return "video";
      const img = tile.querySelector("img");
      if (img?.alt?.toLowerCase().includes("video")) return "video";
      if (Array.from(tile.querySelectorAll("i")).some((el) => el.textContent.trim() === "play_circle")) return "video";
      return "image";
    }, extractTileProgress = function(tileEl) {
      if (!tileEl) return null;
      var els = tileEl.querySelectorAll("span, div, p");
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if (el.children.length > 2) continue;
        var text = el.textContent.trim();
        if (/^\d{1,3}%$/.test(text)) {
          return parseInt(text, 10);
        }
      }
      return null;
    }, isHumanizedEnabled = function() {
      return window._afSettings?.humanizedMode || false;
    }, getHumanizedSpeed = function() {
      return window._afSettings?.humanizedSpeed || 0.5;
    }, getHumanizedDelay = function(baseMs) {
      const speed = getHumanizedSpeed();
      const adjusted = baseMs / speed;
      const jitter = adjusted * 0.3;
      return adjusted + (Math.random() * 2 - 1) * jitter;
    }, injectSlateBridge = function() {
    }, _slateBridgeCall = function(action, detail) {
      return new Promise((resolve) => {
        const requestId = Math.random().toString(36).substr(2, 9);
        console.log("[TobyFlow] Bridge call:", action, "rid:", requestId);
        let resolved = false;
        const handler = (e) => {
          if (e.source !== window) return;
          if (e.data && e.data.source === "flow-auto-slate-result" && e.data.requestId === requestId) {
            resolved = true;
            window.removeEventListener("message", handler);
            console.log("[TobyFlow] Bridge response:", action, e.data.success, e.data.error || "");
            resolve({ success: e.data.success, error: e.data.error });
          }
        };
        window.addEventListener("message", handler);
        window.postMessage({
          source: "flow-auto-slate",
          action,
          requestId,
          slateSelector: _getSlateEditorSelectorString(),
          ...detail
        }, window.location.origin);
        setTimeout(() => {
          if (!resolved) {
            window.removeEventListener("message", handler);
            console.warn("[TobyFlow] Bridge TIMEOUT:", action, requestId);
            resolve({ success: false, error: "Bridge timeout" });
          }
        }, 3e3);
      });
    }, readCurrentSettings = function() {
      const submitBtn = getSubmitButton();
      const settingsBtn = getSettingsButton(submitBtn);
      if (!settingsBtn) return null;
      let ratioIcon = null;
      const icons = _findIconsInElement(settingsBtn);
      const settingsIconPrefix = _getDynamicSelector("settings_button")?.icon_text;
      if (settingsIconPrefix) {
        for (const icon of icons) {
          const t = icon.textContent.trim();
          if (t.startsWith(settingsIconPrefix)) {
            ratioIcon = t;
            break;
          }
        }
      }
      let quantity = null;
      for (const node of settingsBtn.childNodes) {
        if (node.nodeType !== Node.TEXT_NODE) continue;
        const t = (node.textContent || "").trim();
        if (!t) continue;
        const m = t.match(/^(\d)x$|^x(\d)$/);
        if (m) {
          quantity = parseInt(m[1] || m[2]);
          break;
        }
      }
      let model = "";
      for (const node of settingsBtn.childNodes) {
        if (node.nodeType !== Node.TEXT_NODE) continue;
        const t = (node.textContent || "").trim();
        if (!t) continue;
        if (/^\d?x\d?$/.test(t)) continue;
        model = t.replace(/^[\u{1F000}-\u{1FFFF}]\s*/u, "").trim();
        break;
      }
      const rawText = settingsBtn.textContent.trim();
      if (!model && !ratioIcon && quantity === null) return null;
      return { model, ratioIcon, quantity, rawText };
    }, ratioToIconName = function(ratio) {
      const r = String(ratio).toLowerCase().trim();
      if (r.includes("16:9") || r === "ngang" || r === "widescreen" || r === "16_9") return "crop_16_9";
      if (r.includes("4:3") || r === "4_3" || r === "ngang 4:3" || r === "landscape") return "crop_landscape";
      if (r.includes("1:1") || r === "vu\xF4ng" || r === "square") return "crop_square";
      if (r.includes("3:4") || r === "3_4" || r === "d\u1ECDc 3:4" || r === "portrait") return "crop_portrait";
      if (r.includes("9:16") || r === "d\u1ECDc" || r === "story" || r === "9_16") return "crop_9_16";
      return null;
    }, simulateClick = function(element) {
      if (!element || !(element instanceof Element)) {
        console.warn("[Flow] simulateClick: invalid element type", element);
        return;
      }
      const rect = element.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) {
        console.warn("[Flow] simulateClick: element zero-size (hidden/detached), skip", element);
        return;
      }
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      element.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true, button: 0, clientX: x, clientY: y, pointerType: "mouse" }));
      element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, button: 0, clientX: x, clientY: y }));
      element.dispatchEvent(new PointerEvent("pointerup", { bubbles: true, cancelable: true, button: 0, clientX: x, clientY: y, pointerType: "mouse" }));
      element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, button: 0, clientX: x, clientY: y }));
      element.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, button: 0, clientX: x, clientY: y }));
    }, simulateContextMenu = function(element) {
      if (!element) return;
      const rect = element.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      element.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true, button: 2, clientX: x, clientY: y, pointerType: "mouse" }));
      element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, button: 2, clientX: x, clientY: y }));
      element.dispatchEvent(new MouseEvent("contextmenu", { bubbles: true, cancelable: true, button: 2, buttons: 2, clientX: x, clientY: y }));
      element.dispatchEvent(new PointerEvent("pointerup", { bubbles: true, cancelable: true, button: 2, clientX: x, clientY: y, pointerType: "mouse" }));
      element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, button: 2, clientX: x, clientY: y }));
    }, getExponentialBackoffMs = function(retryIdx, retrySettings) {
      const s = retrySettings || {};
      const baseSec = parseInt(s.flowBackoffBaseSec ?? 30, 10);
      const maxSec = parseInt(s.flowBackoffMaxSec ?? 300, 10);
      const jitterPct = Math.max(0, Math.min(50, parseInt(s.flowBackoffJitterPercent ?? 20, 10))) / 100;
      const baseMs = baseSec * 1e3 * Math.pow(2, Math.max(0, retryIdx));
      const cappedMs = Math.min(baseMs, maxSec * 1e3);
      const jitter = cappedMs * jitterPct * (Math.random() * 2 - 1);
      return Math.round(cappedMs + jitter);
    }, scanGalleryTiles = function() {
      const tileIds = getUniqueTileIds();
      const results = [];
      for (const tileId of tileIds) {
        const tile = _getTileById(tileId);
        if (!tile) continue;
        const img = tile.querySelector("img");
        const video = _q("tile_video", tile);
        let mediaType = "unknown";
        let mediaSrc = "";
        let thumbnail = "";
        const isVideoByAlt = img?.alt?.toLowerCase().includes("video");
        if (video) {
          mediaType = "video";
          mediaSrc = video.src || video.querySelector("source")?.src || "";
          thumbnail = video.poster || "";
          if (!thumbnail && img && img.src && !img.src.startsWith("data:") && !img.src.includes("chrome-extension")) {
            thumbnail = img.src;
          }
          if (!thumbnail) thumbnail = mediaSrc;
        } else if (isVideoByAlt && img && img.src && !img.src.startsWith("data:") && !img.src.includes("chrome-extension")) {
          mediaType = "video";
          mediaSrc = img.src;
          thumbnail = img.src;
        } else if (img && img.src && !img.src.startsWith("data:") && !img.src.includes("chrome-extension")) {
          mediaType = "image";
          mediaSrc = img.src;
          thumbnail = img.src;
        }
        const status = detectTileStatus(tile);
        const file_name = extractFileName(tile) || null;
        const flowInfo = extractFlowFileInfo(tile);
        results.push({ tileId, mediaType, mediaSrc, status, thumbnail, file_name, ...flowInfo && { file_id: flowInfo.file_id, project_id: flowInfo.project_id } });
      }
      return results;
    }, _checkFlowCreditLimit = function() {
      const cfg = _getDynamicSelector("flow_credit_limit_alert");
      if (!cfg) {
        console.debug("[FlowLimit] flow_credit_limit_alert config missing \u2014 skip check");
        return false;
      }
      const selectors = cfg.selectors?.length ? cfg.selectors : [];
      if (!selectors.length) return false;
      for (const sel of selectors) {
        try {
          const el = document.querySelector(sel);
          if (el) {
            console.warn(`[FlowLimit] \u26A0 Credit limit alert detected via selector "${sel}"`);
            return true;
          }
        } catch (_) {
        }
      }
      return false;
    }, _findFlowAgentButton = function() {
      const cfg = _getDynamicSelector("flow_agent_toggle_button");
      if (!cfg) {
        console.log("[FlowAgent] \u26A0 config flow_agent_toggle_button MISSING \u2014 backend c\u1EA7n ch\u1EA1y migration 2026_07_25_100003");
        return null;
      }
      const selectors = cfg.selectors?.length ? cfg.selectors : [];
      const textsMatch = cfg.button_text?.length ? cfg.button_text : [];
      if (!selectors.length || !textsMatch.length) return null;
      for (const sel of selectors) {
        try {
          const candidates = document.querySelectorAll(sel);
          for (const btn of candidates) {
            const icon = _findIconInElement(btn);
            const text = _stripIconFromButtonText(btn, icon);
            if (!text) continue;
            if (textsMatch.some((t) => text === t)) {
              return btn;
            }
          }
        } catch (_) {
        }
      }
      return null;
    }, _isFlowAgentModeOn = function() {
      const btn = _findFlowAgentButton();
      if (!btn) return { found: false, on: false };
      const cfg = _getDynamicSelector("flow_agent_toggle_button");
      const onValue = cfg?.aria_pressed_on || "true";
      const isOn = (btn.getAttribute("aria-pressed") || "").trim() === onValue;
      return { found: true, on: isOn };
    }, _findFlowAgentInstructionDoneButton = function() {
      const cfg = _getDynamicSelector("flow_agent_instruction_done_button");
      if (!cfg) {
        console.log("[FlowAgentInstruction] \u26A0 config flow_agent_instruction_done_button MISSING \u2014 backend c\u1EA7n ch\u1EA1y migration 2026_07_25_100022");
        return null;
      }
      const buttonTexts = cfg.button_text?.length ? cfg.button_text : [];
      const panelLabelTexts = cfg.panel_label_text?.length ? cfg.panel_label_text : [];
      const walkDepth = typeof cfg.anchor_walk_depth === "number" ? cfg.anchor_walk_depth : 6;
      if (!buttonTexts.length || !panelLabelTexts.length) return null;
      let panelLabelEl = null;
      try {
        const allSpans = document.querySelectorAll("span");
        for (const sp of allSpans) {
          const text = (sp.textContent || "").trim();
          if (panelLabelTexts.some((t) => text === t)) {
            panelLabelEl = sp;
            break;
          }
        }
      } catch (_) {
      }
      if (!panelLabelEl) return null;
      let container = panelLabelEl;
      for (let depth = 0; depth < walkDepth && container; depth++) {
        try {
          const buttons = container.querySelectorAll("button");
          for (const btn of buttons) {
            const icon = _findIconInElement(btn);
            const text = _stripIconFromButtonText(btn, icon);
            if (buttonTexts.some((t) => text === t)) {
              return btn;
            }
          }
        } catch (_) {
        }
        container = container.parentElement;
      }
      return null;
    }, _isFlowAgentInstructionDialogOpen = function() {
      const btn = _findFlowAgentInstructionDoneButton();
      return { found: !!btn, open: !!btn };
    }, _findFlowChatAgentCloseButton = function() {
      const cfg = _getDynamicSelector("flow_chat_agent_close_button");
      if (!cfg) {
        console.log("[FlowChatAgent] \u26A0 config flow_chat_agent_close_button MISSING \u2014 backend c\u1EA7n ch\u1EA1y migration 2026_07_25_100021");
        return null;
      }
      const selectors = cfg.selectors?.length ? cfg.selectors : [];
      const closeIconText = cfg.icon_text || "close";
      const closeTexts = cfg.button_text?.length ? cfg.button_text : [];
      const siblingIconText = cfg.sibling_icon_text || "edit_square";
      const siblingTexts = cfg.sibling_button_text?.length ? cfg.sibling_button_text : [];
      if (!selectors.length || !closeTexts.length || !siblingTexts.length) return null;
      const verbose = !!_tobyVerboseFlowDebug;
      let stats = { totalBtns: 0, iconCloseMatched: 0, textMatched: 0, siblingFailed: 0, configCfg: cfg };
      for (const sel of selectors) {
        try {
          const candidates = document.querySelectorAll(sel);
          stats.totalBtns += candidates.length;
          for (const btn of candidates) {
            const icon = _findIconInElement(btn);
            if (!icon || (icon.textContent || "").trim() !== closeIconText) continue;
            stats.iconCloseMatched++;
            const text = _stripIconFromButtonText(btn, icon);
            if (!closeTexts.some((t) => text === t)) {
              if (verbose) console.log(`[FlowChatAgent:debug] icon=close but text mismatch: ${JSON.stringify(text)} \u2209 ${JSON.stringify(closeTexts)}`);
              continue;
            }
            stats.textMatched++;
            const parent = btn.parentElement;
            if (!parent) continue;
            const siblings = parent.querySelectorAll("button");
            let hasSessionSibling = false;
            for (const sib of siblings) {
              if (sib === btn) continue;
              const sibIcon = _findIconInElement(sib);
              if (!sibIcon || (sibIcon.textContent || "").trim() !== siblingIconText) continue;
              const sibText = _stripIconFromButtonText(sib, sibIcon);
              if (siblingTexts.some((t) => sibText === t)) {
                hasSessionSibling = true;
                break;
              }
            }
            if (!hasSessionSibling) {
              stats.siblingFailed++;
              if (verbose) console.log(`[FlowChatAgent:debug] Found close+text match but NO sibling Phi\xEAn m\u1EDBi. Parent has ${siblings.length} button(s).`, btn);
              continue;
            }
            return btn;
          }
        } catch (_) {
        }
      }
      if (verbose) {
        console.log(`[FlowChatAgent:debug] No match \u2014 stats:`, stats);
      }
      return null;
    }, _stripIconFromButtonText = function(btn, icon) {
      const full = (btn.textContent || "").trim();
      if (!icon) return full;
      const iconText = (icon.textContent || "").trim();
      if (!iconText) return full;
      if (full.startsWith(iconText)) return full.slice(iconText.length).trim();
      if (full.endsWith(iconText)) return full.slice(0, -iconText.length).trim();
      return full.replace(iconText, "").trim();
    }, _isFlowChatAgentPanelOpen = function() {
      const btn = _findFlowChatAgentCloseButton();
      return { found: !!btn, open: !!btn };
    }, _showZoomNotice = function(textKey, factor) {
      try {
        const inv = factor && factor > 0 ? 1 / factor : 1;
        let notice = document.getElementById("tobyflow-zoom-notice");
        if (!notice) {
          notice = document.createElement("div");
          notice.id = "tobyflow-zoom-notice";
          notice.style.cssText = 'position:fixed;top:26px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#1fbd53;color:#fff;padding:10px 16px;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,0.35);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;max-width:80vw;pointer-events:none;';
          document.body.appendChild(notice);
        }
        notice.innerHTML = _ZOOM_NOTICE_SVG + "<span>" + _getTrackerT(textKey) + "</span>";
        notice.style.zoom = String(inv);
        notice.style.display = "flex";
      } catch (_) {
      }
    }, _hideZoomNotice = function() {
      try {
        const n = document.getElementById("tobyflow-zoom-notice");
        if (n) n.remove();
      } catch (_) {
      }
    }, _applyZoomUx = function(factor) {
      try {
        const inv = factor && factor > 0 ? 1 / factor : 1;
        const tr = document.getElementById("tobyflow-flow-tracker");
        if (tr) {
          tr.style.transform = "";
          tr.style.transformOrigin = "";
          tr.style.zoom = String(inv);
        }
        _showZoomNotice("zoomedForFarRef", factor);
      } catch (_) {
      }
    }, _clearZoomUx = function() {
      try {
        const tr = document.getElementById("tobyflow-flow-tracker");
        if (tr) {
          tr.style.zoom = "";
          tr.style.transform = "";
          tr.style.transformOrigin = "";
        }
        _hideZoomNotice();
      } catch (_) {
      }
    }, injectOverlayButtons = function() {
      const tileSelector = _getTileSelectorString();
      const tiles = document.querySelectorAll(tileSelector);
      tiles.forEach((tile) => {
        if (tile.dataset.overlayInjected === "1") return;
        if (tile.querySelector(":scope > .flow-auto-overlay-btn")) return;
        tile.dataset.overlayInjected = "1";
        const currentPos = window.getComputedStyle(tile).position;
        if (currentPos === "static") {
          tile.style.position = "relative";
        }
        const btn = document.createElement("div");
        btn.className = "flow-auto-overlay-btn";
        btn.style.cssText = `
            position: absolute;
            bottom: 8px;
            right: 8px;
            width: 28px;
            height: 28px;
            background: rgba(255, 255, 255, 0.7);
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 0;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            background: rgba(255,255,255,0.85);
            transition: background 0.2s, transform 0.1s;
        `;
        btn.innerHTML = "+";
        btn.title = "Th\xEAm \u1EA3nh n\xE0y v\xE0o Tab Gen";
        btn.addEventListener("mouseenter", () => {
          btn.style.background = "rgba(255, 255, 255, 0.95)";
          btn.style.transform = "scale(1.05)";
        });
        btn.addEventListener("mouseleave", () => {
          btn.style.background = "rgba(255, 255, 255, 0.7)";
          btn.style.transform = "scale(1)";
        });
        btn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          const tileId = tile.getAttribute("data-tile-id");
          if (!tileId) return;
          const fileName = extractFileName(tile);
          const thumbnail = extractThumbnailUrl(tile);
          try {
            if (!chrome.runtime?.id) {
              console.warn("[TobyFlow] Extension context invalidated, reloading page...");
              location.reload();
              return;
            }
            chrome.runtime.sendMessage({
              action: "addImageToGenTab",
              tileId,
              fileName,
              thumbnail
            }, (response) => {
              if (chrome.runtime.lastError) {
                const errMsg = chrome.runtime.lastError.message || "";
                if (errMsg.includes("Extension context invalidated") || errMsg.includes("Receiving end does not exist")) {
                  console.warn("[TobyFlow] Extension reloaded, reloading page...");
                  location.reload();
                } else {
                  sendLog(`Kh\xF4ng th\u1EC3 g\u1EEDi \u1EA3nh \u0111\u1EBFn GenTab: ${errMsg}`, "warn");
                }
                return;
              }
              if (response?.success) {
                if (response.alreadyExists) {
                  sendLog(`ID: ${tileId.substring(0, 20)}... \u0111\xE3 c\xF3 trong danh s\xE1ch`, "warn");
                  btn.innerHTML = "...";
                  btn.style.color = "#f9ab00";
                  btn.style.fontSize = "10px";
                  setTimeout(() => {
                    btn.innerHTML = "+";
                    btn.style.color = "#333";
                    btn.style.fontSize = "18px";
                  }, 1e3);
                } else if (response.queued) {
                  sendLog(`\u1EA2nh \u0111\xE3 \u0111\u01B0\u1EE3c \u0111\xE1nh d\u1EA5u, m\u1EDF sidebar \u0111\u1EC3 th\xEAm v\xE0o Tab 1`, "info");
                  btn.innerHTML = "\u25CB";
                  btn.style.color = "#4285f4";
                  setTimeout(() => {
                    btn.innerHTML = "+";
                    btn.style.color = "#333";
                  }, 1500);
                } else {
                  sendLog(`\u0110\xE3 th\xEAm \u1EA3nh v\xE0o Tab 1: ${tileId.substring(0, 20)}...`, "success");
                  btn.innerHTML = "\u2713";
                  btn.style.color = "#0f9d58";
                  setTimeout(() => {
                    btn.innerHTML = "+";
                    btn.style.color = "#333";
                  }, 1e3);
                }
              }
            });
          } catch (err) {
            const errMsg = err.message || "";
            if (errMsg.includes("Extension context invalidated")) {
              console.warn("[TobyFlow] Extension reloaded, reloading page...");
              location.reload();
            } else {
              console.error("[TobyFlow] addImageToGenTab error:", err);
            }
          }
        });
        tile.appendChild(btn);
      });
    }, _setupTileObserver = function() {
      if (_tileObserver) _tileObserver.disconnect();
      const firstTile = document.querySelector(_getTileSelectorString());
      const tileContainer = firstTile ? firstTile.closest('[class*="grid"], [class*="Gallery"], [role="list"]') || firstTile.parentElement : null;
      const target = tileContainer || document.body;
      _tileObserver = new MutationObserver(debounce(injectOverlayButtons, 500));
      _tileObserver.observe(target, { childList: true, subtree: true });
      if (!tileContainer) {
        setTimeout(() => _setupTileObserver(), 3e3);
      }
    }, setupFlowSpaNavigateHookDeferred = function() {
      let _lastUrl = location.href;
      function _notifyFlowNavigate() {
        try {
          if (location.href === _lastUrl) return;
          _lastUrl = location.href;
          const m = location.href.match(/\/project\/([a-f0-9-]+)/);
          const projectId = m ? m[1] : null;
          const sendResult = chrome.runtime.sendMessage({
            action: "projectContext",
            projectId,
            projectName: null,
            documentTitle: document.title || null,
            fromSPANavigate: true
          });
          if (sendResult && typeof sendResult.catch === "function") {
            sendResult.catch(() => {
            });
          }
        } catch (_) {
        }
      }
      try {
        const _origPushState = history.pushState;
        const _origReplaceState = history.replaceState;
        history.pushState = function() {
          _origPushState.apply(this, arguments);
          try {
            setTimeout(_notifyFlowNavigate, 50);
          } catch (_) {
          }
        };
        history.replaceState = function() {
          _origReplaceState.apply(this, arguments);
          try {
            setTimeout(_notifyFlowNavigate, 50);
          } catch (_) {
          }
        };
        window.addEventListener("popstate", () => {
          try {
            setTimeout(_notifyFlowNavigate, 50);
          } catch (_) {
          }
        });
      } catch (_) {
      }
    }, setupFlowHomepageObserver = function() {
      if (location.pathname.match(/\/project\/[a-f0-9-]+/)) return;
      let _lastCount = 0;
      let _debounceTimer = null;
      function _notifyHomepageCountChange() {
        const count = _qaProjectLinks().length;
        if (count === _lastCount) return;
        _lastCount = count;
        try {
          const sendResult = chrome.runtime.sendMessage({
            action: "flowHomepageProjectsChanged",
            count
          });
          if (sendResult && typeof sendResult.catch === "function") {
            sendResult.catch(() => {
            });
          }
        } catch (_) {
        }
      }
      const tryAttach = () => {
        const container = document.querySelector('[data-testid="virtuoso-item-list"]') || document.querySelector('[data-testid="virtuoso-scroller"]') || document.body;
        if (!container) return false;
        try {
          const observer = new MutationObserver(() => {
            clearTimeout(_debounceTimer);
            _debounceTimer = setTimeout(_notifyHomepageCountChange, 1e3);
          });
          observer.observe(container, { childList: true, subtree: true });
          _notifyHomepageCountChange();
          return true;
        } catch (_) {
          return false;
        }
      };
      let attempts = 0;
      const tryInterval = setInterval(() => {
        attempts++;
        if (tryAttach() || attempts >= 20) {
          clearInterval(tryInterval);
        }
      }, 500);
    };
    _getFlowLocaleStrings2 = _getFlowLocaleStrings, _getFlowLocaleStringsWithFallback2 = _getFlowLocaleStringsWithFallback, _isGroupViewTabLabel2 = _isGroupViewTabLabel, _isNonViewSettingsControlLabel2 = _isNonViewSettingsControlLabel, _isLikelyGridViewLabel2 = _isLikelyGridViewLabel, _queryInputsByAriaLabels2 = _queryInputsByAriaLabels, _ariaLabelMatches2 = _ariaLabelMatches, _textIncludesAny2 = _textIncludesAny, _getTileSelector2 = _getTileSelector, _getTileSelectorString2 = _getTileSelectorString, _getSlateEditorSelectorString2 = _getSlateEditorSelectorString, _queryAllSlateEditors2 = _queryAllSlateEditors, _ensureSelectorsForExecution2 = _ensureSelectorsForExecution, _getMediaUrlPattern2 = _getMediaUrlPattern, _getCachedTiles2 = _getCachedTiles, _invalidateTileCache2 = _invalidateTileCache, _getTileById2 = _getTileById, _loadRadixTriggerPattern2 = _loadRadixTriggerPattern, _buildRadixTriggerSelector2 = _buildRadixTriggerSelector, _shouldAllowFlowSelectorBootstrap2 = _shouldAllowFlowSelectorBootstrap, _storageTargetsLocalDev2 = _storageTargetsLocalDev, _applyFlowSelectorBootstrap2 = _applyFlowSelectorBootstrap, _tfInjectHintStyle2 = _tfInjectHintStyle, _tfAttachHint2 = _tfAttachHint, _tfDismissHint2 = _tfDismissHint, _tfBuildOpenButton2 = _tfBuildOpenButton, _tfFindBrandLink2 = _tfFindBrandLink, _tfWatchAnchor2 = _tfWatchAnchor, _tfContextValid2 = _tfContextValid, _injectTobyFlowOpenButton2 = _injectTobyFlowOpenButton, _runSelectorWaitLoop2 = _runSelectorWaitLoop, _showConfigErrorOverlay2 = _showConfigErrorOverlay, _showCloneDetectedOverlay2 = _showCloneDetectedOverlay, _hideCloneDetectedOverlay2 = _hideCloneDetectedOverlay, _getDynamicSelector2 = _getDynamicSelector, _selStr2 = _selStr, _q2 = _q, _qa2 = _qa, _queryWithFallback2 = _queryWithFallback, _findIconInElement2 = _findIconInElement, _findIconsInElement2 = _findIconsInElement, _getApiConfigValue2 = _getApiConfigValue, _detectFlowUploadError2 = _detectFlowUploadError, _clickUploadConsentModal2 = _clickUploadConsentModal, _getDownloadMenuLabel2 = _getDownloadMenuLabel, _getDownloadFallbackChain2 = _getDownloadFallbackChain, _getDownloadPixelWidth2 = _getDownloadPixelWidth, _getTrackerT2 = _getTrackerT, incrementDownloadCounter2 = incrementDownloadCounter, getDownloadCounter2 = getDownloadCounter, debounce2 = debounce, sleep2 = sleep, _setReactInputValue2 = _setReactInputValue, _findTabByIconText2 = _findTabByIconText, _closeFlowAdvancedMenu2 = _closeFlowAdvancedMenu, _extractCharOption2 = _extractCharOption, _incrementDailyStat2 = _incrementDailyStat, getInputTimeoutMs2 = getInputTimeoutMs, getClearEditorDelay2 = getClearEditorDelay, getSubmitDelay2 = getSubmitDelay, getAfterSubmitDelay2 = getAfterSubmitDelay, getSettingsStepDelay2 = getSettingsStepDelay, getDelayBetweenPromptsMs2 = getDelayBetweenPromptsMs, getRandomDelay2 = getRandomDelay, _isLogSelectorsEnabled2 = _isLogSelectorsEnabled, _logSelectorPick2 = _logSelectorPick, getEditor2 = getEditor, getSettingsButton2 = getSettingsButton, _getActiveSettingsPanel2 = _getActiveSettingsPanel, getSubmitButton2 = getSubmitButton, sendLog2 = sendLog, sendRetryStatus2 = sendRetryStatus, isAutoDownloadEnabled2 = isAutoDownloadEnabled, getDownloadSettings2 = getDownloadSettings, _toAscii2 = _toAscii, _buildFilename2 = _buildFilename, applyResolutionToUrl2 = applyResolutionToUrl, _waitForElement2 = _waitForElement, _waitForTileMediaReady2 = _waitForTileMediaReady, _closeContextMenu2 = _closeContextMenu, _releaseCtxMenuLock2 = _releaseCtxMenuLock, extractFileName2 = extractFileName, extractFileNameFromUrl2 = extractFileNameFromUrl, extractThumbnailUrl2 = extractThumbnailUrl, extractVideoUrl2 = extractVideoUrl, extractFlowFileInfo2 = extractFlowFileInfo, getCurrentProjectId2 = getCurrentProjectId, _isFlowProjectErrorState2 = _isFlowProjectErrorState, _isFlowMediaViewerOpen2 = _isFlowMediaViewerOpen, findTileByFileId2 = findTileByFileId, extractProjectName2 = extractProjectName, _qaProjectLinks2 = _qaProjectLinks, _getFlowGoogleLoginState2 = _getFlowGoogleLoginState, _collectFlowProjects2 = _collectFlowProjects, getUniqueTileIds2 = getUniqueTileIds, getExistingFileNames2 = getExistingFileNames, isTileComplete2 = isTileComplete, validateTileFile2 = validateTileFile, clickTileRetryButton2 = clickTileRetryButton, clickUploadRetryButton2 = clickUploadRetryButton, detectTileStatus2 = detectTileStatus, detectMediaType2 = detectMediaType, extractTileProgress2 = extractTileProgress, isHumanizedEnabled2 = isHumanizedEnabled, getHumanizedSpeed2 = getHumanizedSpeed, getHumanizedDelay2 = getHumanizedDelay, injectSlateBridge2 = injectSlateBridge, _slateBridgeCall2 = _slateBridgeCall, readCurrentSettings2 = readCurrentSettings, ratioToIconName2 = ratioToIconName, simulateClick2 = simulateClick, simulateContextMenu2 = simulateContextMenu, getExponentialBackoffMs2 = getExponentialBackoffMs, scanGalleryTiles2 = scanGalleryTiles, _checkFlowCreditLimit2 = _checkFlowCreditLimit, _findFlowAgentButton2 = _findFlowAgentButton, _isFlowAgentModeOn2 = _isFlowAgentModeOn, _findFlowAgentInstructionDoneButton2 = _findFlowAgentInstructionDoneButton, _isFlowAgentInstructionDialogOpen2 = _isFlowAgentInstructionDialogOpen, _findFlowChatAgentCloseButton2 = _findFlowChatAgentCloseButton, _stripIconFromButtonText2 = _stripIconFromButtonText, _isFlowChatAgentPanelOpen2 = _isFlowChatAgentPanelOpen, _showZoomNotice2 = _showZoomNotice, _hideZoomNotice2 = _hideZoomNotice, _applyZoomUx2 = _applyZoomUx, _clearZoomUx2 = _clearZoomUx, injectOverlayButtons2 = injectOverlayButtons, _setupTileObserver2 = _setupTileObserver, setupFlowSpaNavigateHookDeferred2 = setupFlowSpaNavigateHookDeferred, setupFlowHomepageObserver2 = setupFlowHomepageObserver;
    self.__tobyflowContentJsLoaded__ = true;
    isRunning = false;
    shouldStop = false;
    isPaused = false;
    failedPrompts = [];
    _tileCache = null;
    _tileCacheTime = 0;
    _TILE_CACHE_TTL = 250;
    _FLOW_LOCALE_FALLBACKS = {
      grid_view_tab: {
        aria_labels: ["Grid", "Grid view", "L\u01B0\u1EDBi", "Ch\u1EBF \u0111\u1ED9 l\u01B0\u1EDBi", "\u30B0\u30EA\u30C3\u30C9", "\uADF8\uB9AC\uB4DC"]
      },
      show_tile_details_setting: {
        text_match: [
          "Show tile details",
          "Show details",
          "tile details",
          "Hi\u1EC7n th\xF4ng tin chi ti\u1EBFt v\u1EC1 \xF4",
          "Hi\u1EC3n th\u1ECB chi ti\u1EBFt",
          "chi ti\u1EBFt v\u1EC1 \xF4"
        ]
      },
      toggle_state_button: {
        aria_labels_on: ["On", "B\u1EADt", "Turn on", "\u30AA\u30F3", "\uCF1C\uAE30"],
        aria_labels_off: ["Off", "T\u1EAFt", "Turn off", "\u30AA\u30D5", "\uB044\uAE30"]
      }
    };
    _tileSelectorCache = null;
    if (typeof window !== "undefined") {
      window._getTileSelectorString = _getTileSelectorString;
    }
    _SLATE_EDITOR_FALLBACK_SELECTORS = [
      'div[role="textbox"][aria-multiline="true"][data-slate-editor="true"][data-slate-node="value"][contenteditable="true"]',
      '[data-slate-editor="true"][data-slate-node="value"][contenteditable="true"]',
      '[data-slate-editor="true"][contenteditable="true"]'
    ];
    if (typeof window !== "undefined") {
      window._getSlateEditorSelectorString = _getSlateEditorSelectorString;
    }
    async function _getMediaUrlPatternAsync(timeoutMs = 5e3) {
      var pattern = _getMediaUrlPattern();
      if (pattern) return pattern;
      var startTime = Date.now();
      while (Date.now() - startTime < timeoutMs) {
        await sleep(200);
        var res = await new Promise((resolve) => chrome.storage.local.get(["toby_provider_api_configs"], resolve));
        if (res.toby_provider_api_configs?.data?.flow?.configs?.image_url_pattern?.url_substring) {
          _apiConfigsCacheLocal = res.toby_provider_api_configs;
          _apiConfigsCacheLocalTime = Date.now();
          return res.toby_provider_api_configs.data.flow.configs.image_url_pattern.url_substring;
        }
        try {
          chrome.runtime.sendMessage({ action: "getProviderApiConfigs", provider: "flow" }, function() {
            if (chrome.runtime.lastError) {
            }
          });
        } catch (_) {
        }
      }
      console.warn("[Tier3] _getMediaUrlPatternAsync timeout after " + timeoutMs + "ms");
      return null;
    }
    if (typeof window !== "undefined") {
      window._getMediaUrlPattern = _getMediaUrlPattern;
    }
    _fileNameCache = /* @__PURE__ */ new Map();
    _statusCache = /* @__PURE__ */ new Map();
    _selectorConfig = null;
    _selectorConfigTime = 0;
    _tobyVerboseFlowDebug = false;
    _SELECTOR_CACHE_TTL = 3e4;
    _coldStartWarnedKeys = /* @__PURE__ */ new Set();
    _radixTriggerPattern = null;
    _loadRadixTriggerPattern();
    try {
      chrome.storage.onChanged.addListener(function(changes, area) {
        if (area === "local" && changes.toby_provider_api_configs) {
          var next = changes.toby_provider_api_configs.newValue;
          var cfg = next?.data?.flow?.configs?.radix_trigger_button_pattern;
          if (typeof cfg === "string" && cfg.includes("{suffix}")) {
            _radixTriggerPattern = cfg;
          }
        }
      });
    } catch (_) {
    }
    _selectorConfigReady = false;
    _SELECTOR_WAIT_MAX_MS = 1e4;
    _FLOW_LOCAL_DEV_BOOTSTRAP = {
      flow: {
        selectors: {
          slate_editor: {
            selectors: [
              'div[role="textbox"][aria-multiline="true"][data-slate-editor="true"][data-slate-node="value"][contenteditable="true"]',
              '[data-slate-editor="true"][data-slate-node="value"][contenteditable="true"]'
            ]
          },
          tile_container: {
            selectors: ["[data-tile-id]", '[class*="tile"]', '[data-testid*="media"]'],
            attribute: "data-tile-id"
          },
          submit_button: {
            selectors: ['button[class*="sc-26b30722-5"]', "button"],
            icon_text: "arrow_forward"
          },
          icon_element: {
            selectors: ["i.google-symbols", "span.material-symbols-outlined", 'i[class*="symbol"]', "[data-icon]"]
          },
          // Settings menu tabs (Grid / Group) + toggles — server config hay miss → NO SELECTORS
          flow_tab_slider_trigger: {
            selectors: [
              'button[role="tab"]',
              '[role="tab"]',
              "button[data-state]",
              '[role="menuitem"][data-state]',
              "button[aria-pressed]"
            ]
          },
          show_tile_details_setting: {
            selectors: [
              '[role="menuitem"]',
              '[role="menuitemcheckbox"]',
              '[role="menuitemradio"]',
              "label",
              '[role="switch"]',
              'div[class*="menu"] > div',
              "[data-radix-collection-item]"
            ]
          },
          settings_button: {
            selectors: [
              'button[aria-haspopup="menu"]',
              'button[aria-label*="Settings"]',
              'button[aria-label*="C\xE0i \u0111\u1EB7t"]',
              'button[aria-label*="setting" i]'
            ],
            icon_text: "settings_2"
          },
          // Nút ⊕ upload / add media cạnh composer
          add_button: {
            selectors: [
              'button[aria-haspopup="dialog"]',
              'button[aria-label*="Upload"]',
              'button[aria-label*="Add"]',
              'button[aria-label*="Th\xEAm"]'
            ],
            icon_text: "add_2"
          },
          file_input: {
            selectors: [
              'input[type="file"][accept*="image"]',
              'input[type="file"]'
            ]
          },
          flow_agent_toggle_button: {
            selectors: ["button.btn-agent-toggle", "button[aria-pressed]"],
            button_text: ["T\xE1c nh\xE2n", "Agent", "\u30A8\u30FC\u30B8\u30A7\u30F3\u30C8"],
            aria_pressed_on: "true"
          },
          flow_agent_instruction_done_button: {
            selectors: ["button.btn-done"],
            button_text: ["Xong", "Done", "\u5B8C\u4E86"],
            panel_label_text: ["H\u01B0\u1EDBng d\u1EABn cho t\xE1c nh\xE2n", "Agent instructions", "\u30A8\u30FC\u30B8\u30A7\u30F3\u30C8\u306E\u624B\u9806"],
            anchor_walk_depth: 6
          },
          flow_chat_agent_close_button: {
            selectors: ['button[id$="-trigger-close"]']
          },
          project_link: {
            selectors: [
              'a[href*="/project/"]',
              'a[href*="/fx/"][href*="/project/"]'
            ]
          },
          project_name_input: {
            aria_labels: [
              "Editable text",
              "Ch\u1EC9nh s\u1EEDa v\u0103n b\u1EA3n",
              "\u30C6\u30AD\u30B9\u30C8\u3092\u7DE8\u96C6",
              "\u0E41\u0E01\u0E49\u0E44\u0E02\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21"
            ]
          }
        }
      }
    };
    _SELECTOR_WAIT_INTERVAL_MS = 200;
    _OVERLAY_I18N = {
      vi: { title: "M\u1EA5t k\u1EBFt n\u1ED1i server", desc: "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i t\u1EDBi m\xE1y ch\u1EE7 Toby. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i sau.", retry: "Th\u1EED l\u1EA1i" },
      en: { title: "Server Connection Lost", desc: "Unable to connect to Toby server. Please try again later.", retry: "Retry" },
      ja: { title: "\u30B5\u30FC\u30D0\u30FC\u63A5\u7D9A\u304C\u5207\u308C\u307E\u3057\u305F", desc: "Toby\u30B5\u30FC\u30D0\u30FC\u306B\u63A5\u7D9A\u3067\u304D\u307E\u305B\u3093\u3002\u5F8C\u3067\u3082\u3046\u4E00\u5EA6\u304A\u8A66\u3057\u304F\u3060\u3055\u3044\u3002", retry: "\u518D\u8A66\u884C" },
      th: { title: "\u0E02\u0E32\u0E14\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C", desc: "\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E01\u0E31\u0E1A\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C Toby \u0E01\u0E23\u0E38\u0E13\u0E32\u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07", retry: "\u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" }
    };
    _overlayLocale = "vi";
    chrome.storage.local.get(["af_locale", "af_settings"], function(r) {
      _overlayLocale = r.af_locale || r.af_settings && r.af_settings.language || "vi";
    });
    _TF_OPEN_LABEL = "Open TobyFlow";
    _TF_HINT_LABEL = "Click here to open TobyFlow";
    _tfHintSeen = true;
    chrome.storage.local.get(["tf_open_hint_seen"], function(r) {
      _tfHintSeen = r.tf_open_hint_seen === true;
      if (!_tfHintSeen) {
        var _b = document.getElementById("tobyflow-open-sidebar-btn");
        if (_b) _tfAttachHint(_b);
      }
    });
    _tfNavObserver = null;
    _tfInjectInterval = setInterval(_injectTobyFlowOpenButton, 2e3);
    _runSelectorWaitLoop();
    (function _initCloneDetectedListener() {
      try {
        setTimeout(function() {
          chrome.storage.local.get("tobyflow_extension_not_authorized", function(res) {
            if (res && res.tobyflow_extension_not_authorized) _showCloneDetectedOverlay();
          });
        }, 800);
        chrome.storage.onChanged.addListener(function(changes, area) {
          if (area !== "local") return;
          if (changes.tobyflow_extension_not_authorized) {
            if (changes.tobyflow_extension_not_authorized.newValue) _showCloneDetectedOverlay();
            else _hideCloneDetectedOverlay();
          }
        });
        if (chrome.runtime && chrome.runtime.onMessage) {
          chrome.runtime.onMessage.addListener(function(msg) {
            if (msg && msg.type === "EXTENSION_NOT_AUTHORIZED") _showCloneDetectedOverlay();
            else if (msg && msg.type === "EXTENSION_AUTHORIZED") _hideCloneDetectedOverlay();
          });
        }
        document.addEventListener("click", function(e) {
          if (e.target && e.target.closest && e.target.closest("#tobyflow-clone-detected-overlay")) {
            try {
              chrome.runtime.sendMessage({ type: "EXTENSION_AUTH_RETRY" });
            } catch (_) {
            }
          }
        }, true);
      } catch (_) {
      }
    })();
    _apiConfigsCacheLocal = null;
    _apiConfigsCacheLocalTime = 0;
    _API_CONFIGS_CACHE_TTL = 3e4;
    (function _preloadApiConfigs() {
      chrome.storage.local.get(["toby_provider_api_configs"], function(res) {
        if (res.toby_provider_api_configs?.data) {
          _apiConfigsCacheLocal = res.toby_provider_api_configs;
          _apiConfigsCacheLocalTime = Date.now();
          console.log(
            "[ApiConfigs:preload] \u2705 Loaded from storage, providers:",
            Object.keys(res.toby_provider_api_configs.data || {}).join(", ")
          );
        } else {
          console.warn("[ApiConfigs:preload] \u26A0\uFE0F Cache empty \u2014 _getApiConfigValue() s\u1EBD tr\u1EA3 null t\u1EDBi khi background fetch xong");
        }
      });
    })();
    async function _dropVideoToFlow(file) {
      const dt = new DataTransfer();
      dt.items.add(file);
      const dropTarget = _q("slate_editor") || document.querySelector("main") || document.body;
      const fire = (type) => {
        let e;
        try {
          e = new DragEvent(type, { bubbles: true, cancelable: true, composed: true, dataTransfer: dt });
        } catch (_) {
          e = new Event(type, { bubbles: true, cancelable: true });
        }
        try {
          if (!e.dataTransfer) Object.defineProperty(e, "dataTransfer", { value: dt });
        } catch (_) {
        }
        dropTarget.dispatchEvent(e);
      };
      try {
        fire("dragenter");
        fire("dragover");
        fire("drop");
        console.log(`[uploadFilesToFlow] video drop dispatched on <${(dropTarget.tagName || "body").toLowerCase()}> file="${file.name}"`);
      } catch (e) {
        console.warn("[uploadFilesToFlow] video drop dispatch error:", e?.message);
      }
      const cfg = _getDynamicSelector("video_upload_confirm");
      const texts = Array.isArray(cfg?.text_match) && cfg.text_match.length ? cfg.text_match : ["I agree, Do not show again", "I agree"];
      const lowered = texts.map((t) => t.toLowerCase());
      for (let i = 0; i < 24; i++) {
        await sleep(300);
        const dialog = document.querySelector('[role="dialog"]');
        if (!dialog) continue;
        const btns = Array.from(dialog.querySelectorAll("button"));
        let agree = null;
        for (const lt of lowered) {
          agree = btns.find((b) => (b.textContent || "").trim().toLowerCase().includes(lt));
          if (agree) break;
        }
        if (agree) {
          console.log(`[uploadFilesToFlow] video confirm: click "${(agree.textContent || "").trim()}"`);
          simulateClick(agree);
          return true;
        }
      }
      console.log("[uploadFilesToFlow] video confirm modal kh\xF4ng xu\u1EA5t hi\u1EC7n (c\xF3 th\u1EC3 \u0111\xE3 t\u1EAFt) \u2014 ti\u1EBFp t\u1EE5c ch\u1EDD tile");
      return true;
    }
    _trackerLocale = "vi";
    _trackerTranslations = {
      vi: {
        stopAll: "D\u1EEBng t\u1EA5t c\u1EA3",
        zoomedForFarRef: "\u0110\xE3 thu nh\u1ECF trang Flow v\xEC \u1EA3nh tham chi\u1EBFu n\u1EB1m \u1EDF xa",
        scanningRefImages: "\u0110ang qu\xE9t \u1EA3nh tham chi\u1EBFu tr\xEAn Flow...",
        done: "xong",
        retrying: "\u0110ang th\u1EED l\u1EA1i",
        paused: "T\u1EA1m d\u1EEBng",
        completed: "Xong",
        stopped: "\u0110\xE3 d\u1EEBng",
        errors: "l\u1ED7i",
        resume: "Ti\u1EBFp t\u1EE5c",
        pause: "T\u1EA1m d\u1EEBng",
        stop: "D\u1EEBng",
        running: "\u0111ang",
        idle: "ngh\u1EC9",
        sent: "\u0111\xE3 g\u1EEDi",
        failed: "l\u1ED7i",
        total: "t\u1ED5ng",
        genActive: "\u0111ang gen",
        flowWaiting: "ch\u1EDD Flow",
        flowSlow: "Flow ch\u1EADm \u2014 \u0111ang ch\u1EDD ph\u1EA3n h\u1ED3i",
        dlPending: "ch\u1EDD t\u1EA3i",
        dlActive: "\u0111ang t\u1EA3i",
        chunkDraining: "\u0110\u1EE3i xong chunk, s\u1EAFp reload Flow...",
        chunkReloading: "\u0110ang reload Flow page...",
        chunkResumed: "Chunk xong, ti\u1EBFp t\u1EE5c batch...",
        andMore: "v\xE0 {count} m\u1EE5c kh\xE1c",
        generating: "\u0110ang t\u1EA1o \u1EA3nh...",
        // State labels
        statePending: "Ch\u1EDD",
        stateSubmitting: "\u0110ang g\u1EEDi",
        stateSubmitted: "\u0110\xE3 g\u1EEDi",
        stateMonitoring: "Ch\u1EDD k\u1EBFt qu\u1EA3",
        stateRetry: "Th\u1EED l\u1EA1i",
        stateCompleted: "Xong",
        statePartialFail: "M\u1ED9t ph\u1EA7n l\u1ED7i",
        stateFailed: "L\u1ED7i",
        stateCancelled: "H\u1EE7y"
      },
      en: {
        stopAll: "Stop all",
        zoomedForFarRef: "Zoomed out Flow page to load far-away reference images",
        scanningRefImages: "Scanning reference images on Flow...",
        done: "done",
        retrying: "Retrying",
        paused: "Paused",
        completed: "Done",
        stopped: "Stopped",
        errors: "errors",
        resume: "Resume",
        pause: "Pause",
        stop: "Stop",
        running: "running",
        idle: "idle",
        sent: "sent",
        failed: "failed",
        total: "total",
        genActive: "generating",
        flowWaiting: "waiting Flow",
        flowSlow: "Flow slow \u2014 waiting response",
        dlPending: "pending",
        dlActive: "downloading",
        chunkDraining: "Finishing chunk, will reload Flow soon...",
        chunkReloading: "Reloading Flow page...",
        chunkResumed: "Chunk done, continuing batch...",
        andMore: "and {count} more",
        generating: "Generating...",
        statePending: "Pending",
        stateSubmitting: "Submitting",
        stateSubmitted: "Submitted",
        stateMonitoring: "Waiting",
        stateRetry: "Retry",
        stateCompleted: "Done",
        statePartialFail: "Partial fail",
        stateFailed: "Failed",
        stateCancelled: "Cancelled"
      },
      th: {
        stopAll: "\u0E2B\u0E22\u0E38\u0E14\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14",
        zoomedForFarRef: "\u0E22\u0E48\u0E2D\u0E2B\u0E19\u0E49\u0E32 Flow \u0E40\u0E1E\u0E23\u0E32\u0E30\u0E23\u0E39\u0E1B\u0E2D\u0E49\u0E32\u0E07\u0E2D\u0E34\u0E07\u0E2D\u0E22\u0E39\u0E48\u0E44\u0E01\u0E25",
        scanningRefImages: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E41\u0E01\u0E19\u0E23\u0E39\u0E1B\u0E2D\u0E49\u0E32\u0E07\u0E2D\u0E34\u0E07\u0E1A\u0E19 Flow...",
        done: "\u0E40\u0E2A\u0E23\u0E47\u0E08",
        retrying: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48",
        paused: "\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27",
        completed: "\u0E40\u0E2A\u0E23\u0E47\u0E08",
        stopped: "\u0E2B\u0E22\u0E38\u0E14\u0E41\u0E25\u0E49\u0E27",
        errors: "\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14",
        resume: "\u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D",
        pause: "\u0E2B\u0E22\u0E38\u0E14\u0E0A\u0E31\u0E48\u0E27\u0E04\u0E23\u0E32\u0E27",
        stop: "\u0E2B\u0E22\u0E38\u0E14",
        running: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E17\u0E33",
        idle: "\u0E27\u0E48\u0E32\u0E07",
        sent: "\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27",
        failed: "\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27",
        total: "\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14",
        genActive: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07",
        flowWaiting: "\u0E23\u0E2D Flow",
        flowSlow: "Flow \u0E0A\u0E49\u0E32 \u2014 \u0E23\u0E2D\u0E01\u0E32\u0E23\u0E15\u0E2D\u0E1A\u0E2A\u0E19\u0E2D\u0E07",
        dlPending: "\u0E23\u0E2D\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14",
        dlActive: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14",
        chunkDraining: "\u0E23\u0E2D\u0E40\u0E2A\u0E23\u0E47\u0E08 chunk, \u0E08\u0E30\u0E23\u0E35\u0E42\u0E2B\u0E25\u0E14 Flow \u0E40\u0E23\u0E47\u0E27\u0E46 \u0E19\u0E35\u0E49...",
        chunkReloading: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E23\u0E35\u0E42\u0E2B\u0E25\u0E14\u0E2B\u0E19\u0E49\u0E32 Flow...",
        chunkResumed: "Chunk \u0E40\u0E2A\u0E23\u0E47\u0E08\u0E41\u0E25\u0E49\u0E27 \u0E14\u0E33\u0E40\u0E19\u0E34\u0E19\u0E01\u0E32\u0E23\u0E15\u0E48\u0E2D...",
        andMore: "\u0E41\u0E25\u0E30 {count} \u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21",
        generating: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07...",
        statePending: "\u0E23\u0E2D",
        stateSubmitting: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E48\u0E07",
        stateSubmitted: "\u0E2A\u0E48\u0E07\u0E41\u0E25\u0E49\u0E27",
        stateMonitoring: "\u0E23\u0E2D\u0E1C\u0E25",
        stateRetry: "\u0E25\u0E2D\u0E07\u0E43\u0E2B\u0E21\u0E48",
        stateCompleted: "\u0E40\u0E2A\u0E23\u0E47\u0E08",
        statePartialFail: "\u0E40\u0E2A\u0E23\u0E47\u0E08\u0E1A\u0E32\u0E07\u0E2A\u0E48\u0E27\u0E19",
        stateFailed: "\u0E25\u0E49\u0E21\u0E40\u0E2B\u0E25\u0E27",
        stateCancelled: "\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01"
      },
      ja: {
        stopAll: "\u3059\u3079\u3066\u505C\u6B62",
        zoomedForFarRef: "\u53C2\u7167\u753B\u50CF\u304C\u9060\u3044\u305F\u3081 Flow \u30DA\u30FC\u30B8\u3092\u7E2E\u5C0F\u3057\u307E\u3057\u305F",
        scanningRefImages: "Flow \u3067\u53C2\u7167\u753B\u50CF\u3092\u30B9\u30AD\u30E3\u30F3\u4E2D...",
        done: "\u5B8C\u4E86",
        retrying: "\u30EA\u30C8\u30E9\u30A4\u4E2D",
        paused: "\u4E00\u6642\u505C\u6B62",
        completed: "\u5B8C\u4E86",
        stopped: "\u505C\u6B62",
        errors: "\u30A8\u30E9\u30FC",
        resume: "\u518D\u958B",
        pause: "\u4E00\u6642\u505C\u6B62",
        stop: "\u505C\u6B62",
        running: "\u5B9F\u884C\u4E2D",
        idle: "\u5F85\u6A5F",
        sent: "\u9001\u4FE1",
        failed: "\u5931\u6557",
        total: "\u5408\u8A08",
        genActive: "\u751F\u6210\u4E2D",
        flowWaiting: "Flow\u5F85\u6A5F",
        flowSlow: "Flow\u304C\u9045\u3044 \u2014 \u5FDC\u7B54\u5F85\u3061",
        dlPending: "DL\u5F85\u3061",
        dlActive: "DL\u4E2D",
        chunkDraining: "\u30C1\u30E3\u30F3\u30AF\u5B8C\u4E86\u5F85\u3061\u3001Flow\u518D\u8AAD\u307F\u8FBC\u307F...",
        chunkReloading: "Flow\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u4E2D...",
        chunkResumed: "\u30C1\u30E3\u30F3\u30AF\u5B8C\u4E86\u3001\u7D9A\u884C\u4E2D...",
        andMore: "\u3042\u3068{count}\u4EF6",
        generating: "\u751F\u6210\u4E2D...",
        statePending: "\u5F85\u6A5F",
        stateSubmitting: "\u9001\u4FE1\u4E2D",
        stateSubmitted: "\u9001\u4FE1\u6E08\u307F",
        stateMonitoring: "\u5F85\u6A5F\u4E2D",
        stateRetry: "\u30EA\u30C8\u30E9\u30A4",
        stateCompleted: "\u5B8C\u4E86",
        statePartialFail: "\u4E00\u90E8\u5931\u6557",
        stateFailed: "\u5931\u6557",
        stateCancelled: "\u30AD\u30E3\u30F3\u30BB\u30EB"
      }
    };
    (function() {
      try {
        chrome.storage.local.get(["af_locale"], function(result) {
          if (result.af_locale) {
            _trackerLocale = result.af_locale;
          }
        });
        chrome.storage.onChanged.addListener(function(changes, area) {
          if (area === "local" && changes.af_locale) {
            _trackerLocale = changes.af_locale.newValue || "vi";
            if (FloatingTracker._el && FloatingTracker._lastData) {
              FloatingTracker.update(FloatingTracker._lastData);
            }
          }
        });
      } catch (e) {
      }
    })();
    downloadCounter = 0;
    FloatingTracker = {
      _el: null,
      _hideTimer: null,
      _expandedJobs: /* @__PURE__ */ new Set(),
      _manuallyCollapsed: /* @__PURE__ */ new Set(),
      _tileProgressCache: {},
      _lastDataHash: null,
      _autoRefreshInterval: null,
      _AUTO_REFRESH_MS: 2e3,
      // Re-scan tile progress mỗi 2 giây khi đang running
      // Chunk Mode (2026-07-26): proactive reload status từ PromptQueue
      _chunkStatus: null,
      // { phase, chunkSize, completedChunks, remaining }
      _chunkResumedTimer: null,
      // auto-clear 'resumed' phase sau 3s
      // Owner colors
      _ownerColors: {
        prompts: "#3b82f6",
        task: "#f97316",
        workflow: "#a855f7",
        angles: "#ec4899",
        telegram: "#06b6d4"
      },
      // State badge config (dynamic labels from _getTrackerT)
      _getStateConfig: function() {
        return {
          PENDING: { label: _getTrackerT("statePending"), bg: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" },
          SUBMITTING: { label: _getTrackerT("stateSubmitting"), bg: "rgba(59,130,246,0.2)", color: "#60a5fa" },
          SUBMITTED: { label: _getTrackerT("stateSubmitted"), bg: "rgba(59,130,246,0.15)", color: "#93c5fd" },
          MONITORING: { label: _getTrackerT("stateMonitoring"), bg: "rgba(168,85,247,0.2)", color: "#c084fc" },
          RETRY_SUBMIT: { label: _getTrackerT("stateRetry"), bg: "rgba(249,115,22,0.2)", color: "#fb923c" },
          COMPLETED: { label: _getTrackerT("stateCompleted"), bg: "rgba(34,197,94,0.2)", color: "#4ade80" },
          PARTIAL_FAIL: { label: _getTrackerT("statePartialFail"), bg: "rgba(234,179,8,0.2)", color: "#facc15" },
          FAILED: { label: _getTrackerT("stateFailed"), bg: "rgba(239,68,68,0.2)", color: "#f87171" },
          CANCELLED: { label: _getTrackerT("stateCancelled"), bg: "rgba(107,114,128,0.2)", color: "#9ca3af" }
        };
      },
      _formatTime(ms) {
        if (!ms || ms < 0) return "00:00";
        var s = Math.floor(ms / 1e3);
        var m = Math.floor(s / 60);
        var sec = s % 60;
        return (m < 10 ? "0" : "") + m + ":" + (sec < 10 ? "0" : "") + sec;
      },
      _escHtml(str) {
        if (!str) return "";
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      },
      _create() {
        if (this._el && document.body.contains(this._el)) return;
        var existing = document.getElementById("tobyflow-flow-tracker");
        if (existing) existing.remove();
        this._el = null;
        var el = document.createElement("div");
        el.id = "tobyflow-flow-tracker";
        el.style.cssText = 'position:fixed;bottom:16px;right:16px;width:340px;background:rgba(18,18,22,0.95);border:1px solid rgba(255,255,255,0.1);border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.5);z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;font-size:13px;color:#fff;display:none;overflow:hidden;';
        var header = document.createElement("div");
        header.style.cssText = "display:flex;align-items:center;gap:6px;padding:8px 12px;background:#1fbd53;border-bottom:1px solid rgba(255,255,255,0.15);";
        header.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg><span style="flex:1;font-weight:600;font-size:12px;">Pipeline</span><span class="tobyflow-ft-counter" style="font-size:11px;opacity:0.7;font-variant-numeric:tabular-nums;"></span><span class="tobyflow-ft-elapsed" style="font-size:10px;opacity:0.5;font-variant-numeric:tabular-nums;"></span><button class="tobyflow-ft-stop-all" title="' + _getTrackerT("stopAll") + '" style="width:22px;height:22px;background:rgba(239,68,68,0.2);border:none;border-radius:5px;color:#ef4444;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="1"/></svg></button>';
        el.appendChild(header);
        var self2 = this;
        header.querySelector(".tobyflow-ft-stop-all").addEventListener("click", function() {
          self2._sendAction("pq:stopAll");
        });
        var progress = document.createElement("div");
        progress.style.cssText = "height:3px;background:rgba(255,255,255,0.08);overflow:hidden;";
        progress.innerHTML = '<div class="tobyflow-ft-progress-fill" style="height:100%;width:100%;background:linear-gradient(90deg,#3b82f6,#60a5fa,#a78bfa);transform:scaleX(0);transform-origin:left;transition:transform 0.3s ease-out;will-change:transform;"></div>';
        el.appendChild(progress);
        if (!document.getElementById("tobyflow-ft-animations")) {
          var style = document.createElement("style");
          style.id = "tobyflow-ft-animations";
          style.textContent = "@keyframes tobyflow-pulse{0%,100%{opacity:1}50%{opacity:0.6}}@keyframes tobyflow-progress-glow{0%,100%{opacity:0.5}50%{opacity:1}}.tobyflow-ft-progress-fill.active{animation:tobyflow-progress-glow 1.5s ease-in-out infinite}.tobyflow-ft-dot-pulse{animation:tobyflow-pulse 1.5s ease-in-out infinite}";
          document.head.appendChild(style);
        }
        var pipelineRow = document.createElement("div");
        pipelineRow.className = "tobyflow-ft-pipeline";
        pipelineRow.style.cssText = "display:none;padding:6px 12px;font-size:11px;color:rgba(255,255,255,0.7);border-bottom:1px solid rgba(255,255,255,0.06);font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
        el.appendChild(pipelineRow);
        var jobsWrap = document.createElement("div");
        jobsWrap.className = "tobyflow-ft-jobs";
        jobsWrap.style.cssText = "max-height:320px;overflow-y:auto;overflow-x:hidden;";
        el.appendChild(jobsWrap);
        document.body.appendChild(el);
        this._el = el;
        this._setupJobsDelegation(jobsWrap);
      },
      /**
       * Thiết lập event delegation trên container .tobyflow-ft-jobs.
       * Chỉ gọi 1 lần trong _create(), không gọi lại mỗi lần render.
       * Delegate click dựa vào data-action (stop/pause/resume) và data-job-toggle (expand/collapse).
       */
      _setupJobsDelegation(container) {
        var self2 = this;
        container.addEventListener("click", function(e) {
          var actionEl = e.target.closest("[data-action]");
          if (actionEl) {
            e.stopPropagation();
            var action = actionEl.getAttribute("data-action");
            var jobId = actionEl.getAttribute("data-job-id");
            if (action === "stop") self2._sendAction("pq:stopJob", { jobId });
            else if (action === "pause") self2._sendAction("pq:pauseJob", { jobId });
            else if (action === "resume") self2._sendAction("pq:resumeJob", { jobId });
            return;
          }
          var headerEl = e.target.closest("[data-job-toggle]");
          if (headerEl) {
            var toggleJobId = headerEl.getAttribute("data-job-toggle");
            if (self2._expandedJobs.has(toggleJobId)) {
              self2._expandedJobs.delete(toggleJobId);
              self2._manuallyCollapsed.add(toggleJobId);
            } else {
              self2._expandedJobs.add(toggleJobId);
              self2._manuallyCollapsed.delete(toggleJobId);
            }
            if (self2._lastData) self2._renderJobs(self2._lastData.jobs || []);
          }
        });
      },
      update(data) {
        this._create();
        if (!data) return;
        clearTimeout(this._hideTimer);
        var el = this._el;
        var completed = data.completed || 0;
        var total = data.total || 0;
        var isRunning2 = data.isRunning;
        var jobs = data.jobs || [];
        if (!isRunning2 || total === 0) {
          this._stopAutoRefresh();
          if (completed > 0) {
            el.style.display = "block";
            el.querySelector(".tobyflow-ft-counter").textContent = completed + "/" + total + " " + _getTrackerT("done");
            var progressFill = el.querySelector(".tobyflow-ft-progress-fill");
            progressFill.style.transform = "scaleX(1)";
            progressFill.classList.remove("active");
            el.querySelector(".tobyflow-ft-elapsed").textContent = "";
            var stopBtn = el.querySelector(".tobyflow-ft-stop-all");
            if (stopBtn) stopBtn.style.display = "none";
            var pRow = el.querySelector(".tobyflow-ft-pipeline");
            if (pRow) pRow.style.display = "none";
            el.querySelector(".tobyflow-ft-jobs").innerHTML = "";
            this._hideTimer = setTimeout(function() {
              FloatingTracker.hide();
            }, 3e3);
          } else {
            this.hide();
          }
          return;
        }
        el.style.display = "block";
        var stopBtn = el.querySelector(".tobyflow-ft-stop-all");
        if (stopBtn) stopBtn.style.display = "";
        var pct = total > 0 ? Math.round(completed / total * 100) : 0;
        var submitted = data.pipeline && data.pipeline.editor && data.pipeline.editor.processedCount || 0;
        if (submitted < completed) submitted = completed;
        var counterText;
        if (submitted > 0 && submitted < total) {
          counterText = completed + "/" + submitted + " \u2713 \u2022 " + total + " " + _getTrackerT("total");
        } else {
          counterText = completed + "/" + total;
        }
        el.querySelector(".tobyflow-ft-counter").textContent = counterText;
        var progressFill = el.querySelector(".tobyflow-ft-progress-fill");
        progressFill.style.transform = "scaleX(" + pct / 100 + ")";
        progressFill.classList.add("active");
        el.querySelector(".tobyflow-ft-elapsed").textContent = this._formatTime(data.elapsed);
        this._renderPipelineRow(data.pipeline);
        this._scanTileProgress(jobs);
        this._renderJobs(jobs);
        this._startAutoRefresh();
      },
      // Bắt đầu auto-refresh interval để re-scan tile progress (legacy mode)
      _startAutoRefresh() {
        if (this._autoRefreshInterval) return;
        var self2 = this;
        this._autoRefreshInterval = setInterval(function() {
          if (!self2._lastData || !self2._lastData.isRunning) {
            self2._stopAutoRefresh();
            return;
          }
          var jobs = self2._lastData.jobs || [];
          self2._scanTileProgress(jobs);
          self2._renderJobs(jobs);
        }, this._AUTO_REFRESH_MS);
      },
      // Dừng auto-refresh interval
      _stopAutoRefresh() {
        if (this._autoRefreshInterval) {
          clearInterval(this._autoRefreshInterval);
          this._autoRefreshInterval = null;
        }
      },
      // Đọc % tiến độ từ DOM tile cho items đang MONITORING
      _scanTileProgress(jobs) {
        var cache = {};
        if (!jobs) {
          this._tileProgressCache = cache;
          return;
        }
        try {
          var monitoringItems = [];
          var allPreTileIds = /* @__PURE__ */ new Set();
          var isLegacyMode = false;
          for (var i = 0; i < jobs.length; i++) {
            var j = jobs[i];
            if (j.id && typeof j.id === "string" && j.id.startsWith("_legacy_")) {
              isLegacyMode = true;
            }
            if (!j.items) continue;
            for (var k = 0; k < j.items.length; k++) {
              var it = j.items[k];
              if (it.state !== "MONITORING" || !it.preTileIds) continue;
              monitoringItems.push(it);
              for (var pi = 0; pi < it.preTileIds.length; pi++) {
                allPreTileIds.add(it.preTileIds[pi]);
              }
            }
          }
          var allTiles = _getCachedTiles();
          if (monitoringItems.length === 0 && isLegacyMode) {
            var maxProgress = null;
            for (var lt = 0; lt < allTiles.length; lt++) {
              var ltEl = allTiles[lt];
              var ltStatus = typeof detectTileStatus === "function" ? detectTileStatus(ltEl) : null;
              if (ltStatus !== "processing") continue;
              var ltPct = typeof extractTileProgress === "function" ? extractTileProgress(ltEl) : null;
              if (ltPct !== null && (maxProgress === null || ltPct > maxProgress)) {
                maxProgress = ltPct;
              }
            }
            if (maxProgress !== null) {
              cache._legacy = maxProgress;
            }
            this._tileProgressCache = cache;
            return;
          }
          if (monitoringItems.length === 0) {
            this._tileProgressCache = cache;
            return;
          }
          var tilesWithProgress = [];
          for (var t = 0; t < allTiles.length; t++) {
            var tileEl = allTiles[t];
            var tid = tileEl.getAttribute("data-tile-id");
            if (!tid || allPreTileIds.has(tid)) continue;
            var pct = typeof extractTileProgress === "function" ? extractTileProgress(tileEl) : null;
            if (pct !== null) {
              tilesWithProgress.push({ tileId: tid, progress: pct });
            }
          }
          if (tilesWithProgress.length === 0) {
            this._tileProgressCache = cache;
            return;
          }
          for (var mi = 0; mi < monitoringItems.length; mi++) {
            var mit = monitoringItems[mi];
            var preTileSet = new Set(mit.preTileIds);
            var bestProgress = null;
            for (var p = 0; p < tilesWithProgress.length; p++) {
              var pt = tilesWithProgress[p];
              if (preTileSet.has(pt.tileId)) continue;
              if (bestProgress === null || pt.progress > bestProgress) {
                bestProgress = pt.progress;
              }
            }
            if (bestProgress !== null) cache[mit.id] = bestProgress;
          }
        } catch (e) {
        }
        this._tileProgressCache = cache;
      },
      /**
       * Chunk Mode (2026-07-26): receive chunk_status update từ PromptQueue.
       * Phase logic:
       *   - draining/reloading: hiện banner persistent
       *   - resumed: hiện 3s rồi auto-clear (chunk OK)
       *   - cancelled: clear ngay (reload bị block/fail, không show banner)
       */
      setChunkStatus(data) {
        if (!data || !data.phase) return;
        if (this._chunkResumedTimer) {
          clearTimeout(this._chunkResumedTimer);
          this._chunkResumedTimer = null;
        }
        if (data.phase === "cancelled") {
          this._chunkStatus = null;
        } else {
          this._chunkStatus = data;
        }
        if (data.phase === "resumed") {
          var self2 = this;
          this._chunkResumedTimer = setTimeout(function() {
            self2._chunkStatus = null;
            if (self2._el && self2._lastData) self2.update(self2._lastData);
          }, 3e3);
        }
        if (this._el && this._lastData) {
          this.update(this._lastData);
        }
      },
      _renderPipelineRow(pipeline) {
        var row = this._el.querySelector(".tobyflow-ft-pipeline");
        if (!pipeline) {
          row.style.display = "none";
          return;
        }
        var sent = pipeline.editor && pipeline.editor.processedCount || 0;
        var tm = pipeline.tileMonitor || {};
        var active = tm.activeCount || 0;
        var claiming = tm.claimingCount;
        if (typeof claiming !== "number") claiming = active;
        var waiting = tm.waitingCount;
        if (typeof waiting !== "number") waiting = 0;
        var done = tm.completedCount || 0;
        var failed = tm.failedCount || 0;
        var stagnant = !!tm.stagnant;
        var dl = pipeline.download || {};
        var dlQueue = dl.queueLength || 0;
        var dlDone = dl.completedCount || 0;
        var dlState = dl.state || "idle";
        var hasDlActivity = dlQueue > 0 || dlDone > 0 || dlState === "downloading";
        var hasChunkStatus = !!(this._chunkStatus && this._chunkStatus.phase);
        if (sent === 0 && active === 0 && done === 0 && failed === 0 && !hasDlActivity && !hasChunkStatus) {
          row.style.display = "none";
          row.style.background = "";
          row.style.borderLeft = "";
          return;
        }
        var sep = '<span style="opacity:0.3;margin:0 5px;">\u2022</span>';
        var failedColor = failed > 0 ? "#f87171" : "rgba(255,255,255,0.35)";
        var waitColor = waiting > 0 ? "#fbbf24" : "rgba(255,255,255,0.35)";
        var claimColor = claiming > 0 ? "#c084fc" : "rgba(255,255,255,0.35)";
        var stagnantPrefix = stagnant ? '<span style="color:#fb923c;font-weight:600;margin-right:6px;" title="' + this._escHtml(_getTrackerT("flowSlow")) + '">\u26A0\uFE0F</span>' : "";
        var chunkBanner = "";
        if (this._chunkStatus && this._chunkStatus.phase) {
          var cs = this._chunkStatus;
          var chunkIcon, chunkLabel, chunkColor;
          if (cs.phase === "draining") {
            chunkIcon = "\u23F3";
            chunkLabel = _getTrackerT("chunkDraining");
            if (typeof cs.remaining === "number" && cs.remaining > 0) {
              chunkLabel = chunkLabel + " (" + cs.remaining + ")";
            }
            chunkColor = "#60a5fa";
          } else if (cs.phase === "reloading") {
            chunkIcon = "\u{1F504}";
            chunkLabel = _getTrackerT("chunkReloading");
            chunkColor = "#a78bfa";
          } else if (cs.phase === "resumed") {
            chunkIcon = "\u2713";
            chunkLabel = _getTrackerT("chunkResumed");
            if (typeof cs.completedChunks === "number" && cs.completedChunks > 0) {
              chunkLabel = "#" + cs.completedChunks + " \u2014 " + chunkLabel;
            }
            chunkColor = "#4ade80";
          } else {
            chunkIcon = "";
            chunkLabel = "";
            chunkColor = "rgba(255,255,255,0.5)";
          }
          if (chunkLabel) {
            chunkBanner = '<div style="color:' + chunkColor + ';font-size:11px;padding:2px 0;border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:4px;">' + chunkIcon + " " + this._escHtml(chunkLabel) + "</div>";
          }
        }
        var genLine = stagnantPrefix + '<span style="color:#93c5fd;">\u25B6 ' + sent + " " + this._escHtml(_getTrackerT("sent")) + "</span>" + sep + '<span style="color:' + claimColor + ';">\u26A1 ' + claiming + " " + this._escHtml(_getTrackerT("genActive")) + "</span>" + sep + '<span style="color:' + waitColor + ';">\u23F8 ' + waiting + " " + this._escHtml(_getTrackerT("flowWaiting")) + "</span>" + sep + '<span style="color:#4ade80;">\u2713 ' + done + " " + this._escHtml(_getTrackerT("done")) + "</span>" + sep + '<span style="color:' + failedColor + ';">\u2715 ' + failed + " " + this._escHtml(_getTrackerT("failed")) + "</span>";
        var html = chunkBanner + "<div>" + genLine + "</div>";
        if (hasDlActivity) {
          var dlIcon = dlState === "downloading" ? "\u{1F4E5}" : dlQueue > 0 ? "\u{1F4CB}" : "\u2713";
          var dlLabel = dlState === "downloading" ? _getTrackerT("dlActive") : dlQueue > 0 ? _getTrackerT("dlPending") : _getTrackerT("done");
          var dlPendingColor = dlQueue > 0 ? "#60a5fa" : "rgba(255,255,255,0.35)";
          var dlDoneColor = dlDone > 0 ? "#4ade80" : "rgba(255,255,255,0.35)";
          var dlLine = '<span style="color:' + dlPendingColor + ';">' + dlIcon + " " + dlQueue + " " + this._escHtml(dlLabel) + "</span>" + sep + '<span style="color:' + dlDoneColor + ';">\u2713 ' + dlDone + " " + this._escHtml(_getTrackerT("done")) + "</span>";
          html += '<div style="margin-top:3px;padding-top:3px;border-top:1px solid rgba(255,255,255,0.05);">' + dlLine + "</div>";
        }
        row.style.display = "block";
        if (stagnant) {
          row.style.background = "rgba(251,146,60,0.08)";
          row.style.borderLeft = "3px solid #fb923c";
        } else {
          row.style.background = "";
          row.style.borderLeft = "";
        }
        row.innerHTML = html;
      },
      _renderJobs(jobs) {
        var jobsEl = this._el.querySelector(".tobyflow-ft-jobs");
        if (!jobs || jobs.length === 0) {
          jobsEl.innerHTML = "";
          return;
        }
        var self2 = this;
        var now = Date.now();
        var html = "";
        for (var i = 0; i < jobs.length; i++) {
          var j = jobs[i];
          var color = self2._ownerColors[j.owner] || "#6b7280";
          var isDone = j.status === "completed" || j.status === "stopped";
          var isPaused2 = j.status === "paused";
          var isActive = j.status === "running" || isPaused2;
          var jobPct = j.total > 0 ? Math.round(j.completed / j.total * 100) : 0;
          var jobElapsed = j.startedAt ? self2._formatTime(now - j.startedAt) : "";
          if (isActive && !self2._manuallyCollapsed.has(j.id)) {
            self2._expandedJobs.add(j.id);
          } else if (isDone) {
            self2._expandedJobs.delete(j.id);
            self2._manuallyCollapsed.delete(j.id);
          }
          var isExpanded = self2._expandedJobs.has(j.id);
          var hasRetrying = isActive && j.items && j.items.some(function(it2) {
            return it2.state === "RETRY_SUBMIT";
          });
          var statusBadge = "";
          if (hasRetrying) {
            statusBadge = '<span style="font-size:9px;padding:1px 5px;border-radius:3px;background:rgba(249,115,22,0.2);color:#fb923c;">' + _getTrackerT("retrying") + "</span>";
          } else if (isPaused2) {
            statusBadge = '<span style="font-size:9px;padding:1px 5px;border-radius:3px;background:rgba(245,158,11,0.2);color:#fbbf24;">' + _getTrackerT("paused") + "</span>";
          } else if (isDone) {
            var doneColor = j.status === "completed" ? "#4ade80" : "#f87171";
            var doneBg = j.status === "completed" ? "rgba(34,197,94,0.2)" : "rgba(239,68,68,0.2)";
            var doneLabel = j.status === "completed" ? _getTrackerT("completed") : _getTrackerT("stopped");
            statusBadge = '<span style="font-size:9px;padding:1px 5px;border-radius:3px;background:' + doneBg + ";color:" + doneColor + ';">' + doneLabel + "</span>";
          }
          var failBadge = "";
          if (j.failed > 0) {
            failBadge = '<span style="font-size:9px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.2);color:#f87171;margin-left:2px;">' + j.failed + " " + _getTrackerT("errors") + "</span>";
          }
          var actions = "";
          if (isActive) {
            if (j.owner === "prompts") {
              if (isPaused2) {
                actions += '<button data-action="resume" data-job-id="' + j.id + '" title="' + _getTrackerT("resume") + '" style="width:20px;height:20px;background:rgba(34,197,94,0.2);border:none;border-radius:4px;color:#4ade80;cursor:pointer;display:flex;align-items:center;justify-content:center;"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><polygon points="8,6 18,12 8,18"/></svg></button>';
              } else {
                actions += '<button data-action="pause" data-job-id="' + j.id + '" title="' + _getTrackerT("pause") + '" style="width:20px;height:20px;background:rgba(255,255,255,0.08);border:none;border-radius:4px;color:rgba(255,255,255,0.6);cursor:pointer;display:flex;align-items:center;justify-content:center;"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="7" y="6" width="3" height="12" rx="1"/><rect x="14" y="6" width="3" height="12" rx="1"/></svg></button>';
              }
            }
            actions += '<button data-action="stop" data-job-id="' + j.id + '" title="' + _getTrackerT("stop") + '" style="width:20px;height:20px;background:rgba(239,68,68,0.15);border:none;border-radius:4px;color:#ef4444;cursor:pointer;display:flex;align-items:center;justify-content:center;"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="7" y="7" width="10" height="10" rx="1"/></svg></button>';
          }
          var jobOpacity = isDone ? "opacity:0.5;" : "";
          html += '<div style="padding:4px 12px;border-bottom:1px solid rgba(255,255,255,0.05);' + jobOpacity + '">';
          html += '<div class="tobyflow-ft-job-header" data-job-toggle="' + j.id + '" style="display:flex;align-items:center;gap:6px;cursor:pointer;padding:3px 0;">';
          html += '<span class="' + (isActive && !isPaused2 ? "tobyflow-ft-dot-pulse" : "") + '" style="width:8px;height:8px;border-radius:50%;background:' + color + ';flex-shrink:0;"></span>';
          html += '<span style="flex:1;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;">' + self2._escHtml(j.label || j.owner) + "</span>";
          html += statusBadge + failBadge;
          html += '<span style="font-size:10px;opacity:0.5;font-variant-numeric:tabular-nums;flex-shrink:0;">' + jobElapsed + "</span>";
          html += '<span style="font-size:10px;opacity:0.6;font-variant-numeric:tabular-nums;flex-shrink:0;">' + jobPct + "%</span>";
          html += '<div style="display:flex;gap:2px;flex-shrink:0;">' + actions + "</div>";
          html += '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;transition:transform 0.2s;' + (isExpanded ? "transform:rotate(180deg);" : "") + '"><polyline points="6 9 12 15 18 9"/></svg>';
          html += "</div>";
          html += '<div style="height:2px;background:rgba(255,255,255,0.08);border-radius:1px;margin:3px 0;overflow:hidden;">';
          html += '<div style="height:100%;width:100%;background:' + color + ";border-radius:1px;transform:scaleX(" + jobPct / 100 + ');transform-origin:left;transition:transform 0.3s ease-out;will-change:transform;"></div>';
          html += "</div>";
          if (isExpanded && j.items && j.items.length > 0) {
            html += '<div style="padding:0px;margin-left:4px;">';
            var displayItems = j.items.slice(-12);
            for (var k = 0; k < displayItems.length; k++) {
              var it = displayItems[k];
              var stateConfig = self2._getStateConfig();
              var sc = stateConfig[it.state] || stateConfig.PENDING;
              var promptShort = it.promptText ? it.promptText.length > 50 ? it.promptText.substring(0, 50) + "..." : it.promptText : "";
              var timeInfo = "";
              if (it.completedAt && it.submittedAt) {
                timeInfo = self2._formatTime(it.completedAt - it.submittedAt);
              } else if (it.submittedAt) {
                timeInfo = self2._formatTime(now - it.submittedAt);
              }
              var retryBadge = "";
              if (it.retryCount > 0) {
                retryBadge = '<span style="font-size:8px;padding:0 3px;border-radius:2px;background:rgba(249,115,22,0.2);color:#fb923c;">x' + it.retryCount + "</span>";
              }
              var tileProgress = it.state === "MONITORING" && self2._tileProgressCache[it.id] != null ? self2._tileProgressCache[it.id] : null;
              var itemBg = it.state === "SUBMITTING" || it.state === "MONITORING" ? "background:rgba(255,255,255,0.03);border-radius:4px;" : "";
              html += '<div style="display:flex;align-items:center;gap:5px;padding:4px 4px;font-size:11px;' + itemBg + '">';
              html += '<span style="color:rgba(255,255,255,0.4);font-size:10px;width:18px;flex-shrink:0;font-variant-numeric:tabular-nums;">#' + ((it.promptIndex || 0) + 1) + "</span>";
              html += '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:rgba(255,255,255,0.7);" title="' + self2._escHtml(it.promptText || "") + '">' + self2._escHtml(promptShort) + "</span>";
              html += retryBadge;
              if (timeInfo) {
                html += '<span style="font-size:9px;opacity:0.4;font-variant-numeric:tabular-nums;flex-shrink:0;">' + timeInfo + "</span>";
              }
              if (tileProgress !== null) {
                html += '<span style="font-size:9px;padding:1px 4px;border-radius:3px;background:rgba(168,85,247,0.25);color:#c084fc;flex-shrink:0;white-space:nowrap;font-variant-numeric:tabular-nums;">' + tileProgress + "%</span>";
              } else {
                html += '<span style="font-size:9px;padding:1px 4px;border-radius:3px;background:' + sc.bg + ";color:" + sc.color + ';flex-shrink:0;white-space:nowrap;">' + sc.label + "</span>";
              }
              html += "</div>";
            }
            if (j.items.length > 12) {
              html += '<div style="font-size:10px;opacity:0.4;padding:2px 4px;">... ' + _getTrackerT("andMore", { count: j.items.length - 12 }) + "</div>";
            }
            html += "</div>";
          } else if (isExpanded && j.id && typeof j.id === "string" && j.id.startsWith("_legacy_") && isActive) {
            var legacyProgress = self2._tileProgressCache._legacy;
            if (legacyProgress !== null && typeof legacyProgress === "number") {
              html += '<div style="padding:6px 4px;margin-left:4px;">';
              html += '<div style="display:flex;align-items:center;gap:8px;font-size:11px;background:rgba(255,255,255,0.03);border-radius:4px;padding:6px 8px;">';
              html += '<span style="color:rgba(255,255,255,0.5);">' + _getTrackerT("generating") + "</span>";
              html += '<span style="font-size:10px;padding:2px 6px;border-radius:3px;background:rgba(168,85,247,0.25);color:#c084fc;font-variant-numeric:tabular-nums;font-weight:500;">' + legacyProgress + "%</span>";
              html += "</div>";
              html += "</div>";
            }
          }
          html += "</div>";
        }
        jobsEl.innerHTML = html;
      },
      /**
       * Legacy mode: cập nhật FloatingTracker cho execution KHÔNG dùng Pipeline Queue
       * Chuyển đổi dữ liệu single-owner thành format multi-job tương thích update()
       */
      updateLegacy(data) {
        if (!data) return;
        this._legacyData = data;
        var isActive = data.status === "running" || data.status === "paused";
        this.update({
          isRunning: isActive,
          completed: data.current || 0,
          total: data.total || 0,
          elapsed: data.startedAt ? Date.now() - data.startedAt : 0,
          pipeline: null,
          jobs: [{
            id: "_legacy_" + (data.owner || "prompts"),
            owner: data.owner || "prompts",
            label: data.label || data.owner || "Auto Gen",
            status: data.status || "running",
            completed: data.current || 0,
            failed: data.failed || 0,
            total: data.total || 0,
            startedAt: data.startedAt,
            items: data.items || []
          }]
        });
      },
      _sendAction(action, data) {
        if (data && data.jobId && typeof data.jobId === "string" && data.jobId.startsWith("_legacy_")) {
          if (action === "pq:stopJob" || action === "pq:stopAll") {
            shouldStop = true;
            isPaused = false;
            if (this._legacyData) {
              this._legacyData.status = "stopped";
              this.updateLegacy(this._legacyData);
            }
            return;
          }
          if (action === "pq:pauseJob") {
            isPaused = true;
            if (this._legacyData) {
              this._legacyData.status = "paused";
              this.updateLegacy(this._legacyData);
            }
            return;
          }
          if (action === "pq:resumeJob") {
            isPaused = false;
            if (this._legacyData) {
              this._legacyData.status = "running";
              this.updateLegacy(this._legacyData);
            }
            return;
          }
        }
        if (action === "pq:stopAll" && isRunning) {
          shouldStop = true;
          isPaused = false;
        }
        chrome.runtime.sendMessage(Object.assign({ action }, data || {})).catch(function(err) {
          console.warn("[FloatingTracker] Action failed:", action, err.message);
        });
      },
      hide() {
        this._stopAutoRefresh();
        if (this._el) {
          this._el.style.display = "none";
        }
        this._lastData = null;
        this._legacyData = null;
        this._expandedJobs.clear();
        this._manuallyCollapsed.clear();
        this._tileProgressCache = {};
        this._chunkStatus = null;
        if (this._chunkResumedTimer) {
          clearTimeout(this._chunkResumedTimer);
          this._chunkResumedTimer = null;
        }
      }
    };
    _origUpdate = FloatingTracker.update;
    FloatingTracker.update = function(data) {
      this._lastData = data;
      _origUpdate.call(this, data);
      try {
        const _zs = window._tobyFlowZoomSession;
        if (_zs && _zs.active && this._el) {
          const inv = _zs.factor && _zs.factor > 0 ? 1 / _zs.factor : 1;
          if (this._el.style.zoom !== String(inv)) this._el.style.zoom = String(inv);
        }
      } catch (_) {
      }
    };
    ExecutionBlocker = {
      _el: null,
      _styleEl: null,
      _blocking: false,
      _timeoutId: null,
      _sanityIntervalId: null,
      _escapeCount: 0,
      _escapeTimer: null,
      _pipelineOwned: false,
      // Pipeline mode owns blocker - don't auto-hide via sanity check
      _MAX_BLOCK_TIME: 5 * 60 * 1e3,
      // 5 phút auto-timeout
      _SANITY_CHECK_INTERVAL: 30 * 1e3,
      // 30 giây check 1 lần
      // Block tất cả events ở capture phase (triệt để hơn pointer-events)
      _blockEvent(e) {
        if (!ExecutionBlocker._blocking) return;
        if (!e.isTrusted) return;
        if (e.target && e.target.closest && e.target.closest("#tobyflow-flow-tracker")) return;
        if (e.type === "keydown" && e.key === "Escape") {
          ExecutionBlocker._escapeCount++;
          clearTimeout(ExecutionBlocker._escapeTimer);
          ExecutionBlocker._escapeTimer = setTimeout(function() {
            ExecutionBlocker._escapeCount = 0;
          }, 2e3);
          if (ExecutionBlocker._escapeCount >= 3) {
            console.warn("[ExecutionBlocker] Force hide via Escape x3");
            ExecutionBlocker._escapeCount = 0;
            ExecutionBlocker.hide();
            if (typeof isRunning !== "undefined") isRunning = false;
            if (typeof isPaused !== "undefined") isPaused = false;
            if (typeof shouldStop !== "undefined") shouldStop = true;
            return;
          }
        }
        e.stopPropagation();
        e.stopImmediatePropagation();
        e.preventDefault();
      },
      _injectStyles() {
        if (this._styleEl) return;
        var style = document.createElement("style");
        style.id = "tobyflow-execution-blocker-styles";
        style.textContent = `
      @keyframes tobyflow-glow-pulse {
        0%, 100% { opacity: 0.4; }
        50% { opacity: 0.7; }
      }

      @keyframes tobyflow-glow-paused {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 0.5; }
      }

      #tobyflow-execution-blocker {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        pointer-events: all;
        cursor: not-allowed;
        background: transparent;
      }

      /* Glow border via pseudo-element (GPU layer v\u1EDBi will-change) */
      /* Multi-layer box-shadow simulate blur effect m\xE0 kh\xF4ng d\xF9ng filter:blur (nh\u1EB9 h\u01A1n) */
      #tobyflow-execution-blocker::before {
        content: '';
        position: absolute;
        inset: 0;
        border: 5px solid #cdff01;
        border-radius: 12px;
        box-shadow:
          inset 0 0 0 2px rgba(205,255,1,0.5),
          inset 0 0 8px rgba(205,255,1,0.3),
          0 0 8px rgba(205,255,1,0.4),
          0 0 20px rgba(205,255,1,0.25),
          0 0 40px rgba(205,255,1,0.15);
        animation: tobyflow-glow-pulse 1.8s ease-in-out infinite;
        will-change: opacity;
        pointer-events: none;
      }

      /* Paused state - slower animation, yellow tint */
      #tobyflow-execution-blocker.tobyflow-paused::before {
        border-color: #facc15;
        box-shadow:
          inset 0 0 0 2px rgba(250,204,21,0.45),
          inset 0 0 6px rgba(250,204,21,0.25),
          0 0 6px rgba(250,204,21,0.35),
          0 0 15px rgba(250,204,21,0.2),
          0 0 30px rgba(250,204,21,0.1);
        animation: tobyflow-glow-paused 3s ease-in-out infinite;
      }

      /* Force Flow context menus (Radix UI) unclickable when blocker active */
      body.tobyflow-execution-blocking [data-radix-popper-content-wrapper],
      body.tobyflow-execution-blocking [role="menu"][data-state="open"] {
        pointer-events: none !important;
      }
    `;
        document.head.appendChild(style);
        this._styleEl = style;
      },
      _attachBlockers() {
        if (this._blocking) return;
        this._blocking = true;
        var events = ["mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel", "touchstart", "touchend", "touchmove", "keydown", "keyup", "keypress"];
        events.forEach(function(evt) {
          document.addEventListener(evt, ExecutionBlocker._blockEvent, { capture: true, passive: false });
        });
        document.body.classList.add("tobyflow-execution-blocking");
      },
      _detachBlockers() {
        if (!this._blocking) return;
        this._blocking = false;
        var events = ["mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel", "touchstart", "touchend", "touchmove", "keydown", "keyup", "keypress"];
        events.forEach(function(evt) {
          document.removeEventListener(evt, ExecutionBlocker._blockEvent, { capture: true });
        });
        document.body.classList.remove("tobyflow-execution-blocking");
      },
      // Sanity check: nếu isRunning = false mà blocker vẫn hiện → hide
      // Skip auto-hide nếu Pipeline owns blocker (pq:showBlocker)
      _startSanityCheck() {
        var self2 = this;
        this._sanityIntervalId = setInterval(function() {
          if (self2._pipelineOwned) return;
          if (typeof isRunning !== "undefined" && !isRunning) {
            console.log("[ExecutionBlocker] Sanity check: isRunning=false, auto-hiding");
            self2.hide();
          }
        }, this._SANITY_CHECK_INTERVAL);
      },
      _stopSanityCheck() {
        if (this._sanityIntervalId) {
          clearInterval(this._sanityIntervalId);
          this._sanityIntervalId = null;
        }
      },
      // Auto-timeout: tự hide sau _MAX_BLOCK_TIME
      _startTimeout() {
        var self2 = this;
        this._timeoutId = setTimeout(function() {
          console.warn("[ExecutionBlocker] Auto-timeout after " + self2._MAX_BLOCK_TIME / 1e3 + "s, force hiding");
          self2.hide();
          if (typeof isRunning !== "undefined") isRunning = false;
          if (typeof isPaused !== "undefined") isPaused = false;
          if (typeof shouldStop !== "undefined") shouldStop = true;
        }, this._MAX_BLOCK_TIME);
      },
      _stopTimeout() {
        if (this._timeoutId) {
          clearTimeout(this._timeoutId);
          this._timeoutId = null;
        }
      },
      // Visibility change: nếu tab ẩn quá 2 phút, cleanup
      _onVisibilityChange() {
        if (document.hidden && ExecutionBlocker._blocking) {
          ExecutionBlocker._visibilityTimeoutId = setTimeout(function() {
            if (document.hidden && ExecutionBlocker._blocking) {
              console.warn("[ExecutionBlocker] Tab hidden too long, auto-hiding + resetting state");
              ExecutionBlocker.hide();
              if (typeof isRunning !== "undefined") isRunning = false;
              if (typeof isPaused !== "undefined") isPaused = false;
              if (typeof shouldStop !== "undefined") shouldStop = true;
            }
          }, 2 * 60 * 1e3);
        } else {
          if (ExecutionBlocker._visibilityTimeoutId) {
            clearTimeout(ExecutionBlocker._visibilityTimeoutId);
            ExecutionBlocker._visibilityTimeoutId = null;
          }
        }
      },
      show(options) {
        options = options || {};
        this._injectStyles();
        var wasBlocking = this._blocking;
        this._attachBlockers();
        if (!wasBlocking) {
          if (!this._pipelineOwned) {
            this._startTimeout();
          }
          this._startSanityCheck();
          document.removeEventListener("visibilitychange", this._onVisibilityChange);
          document.addEventListener("visibilitychange", this._onVisibilityChange);
        }
        if (this._el) {
          this._el.style.display = "block";
          return;
        }
        var el = document.createElement("div");
        el.id = "tobyflow-execution-blocker";
        document.body.appendChild(el);
        this._el = el;
      },
      // Pause state - chuyển màu vàng, animation chậm hơn
      setPaused(paused) {
        if (!this._el) return;
        if (paused) {
          this._el.classList.add("tobyflow-paused");
        } else {
          this._el.classList.remove("tobyflow-paused");
        }
      },
      // update() - simplified, chỉ sync paused state
      // Giữ method để callers không bị crash
      update(options) {
        if (typeof isPaused !== "undefined") {
          this.setPaused(isPaused);
        }
      },
      hide() {
        this._detachBlockers();
        this._stopTimeout();
        this._stopSanityCheck();
        this._escapeCount = 0;
        this._pipelineOwned = false;
        clearTimeout(this._escapeTimer);
        clearTimeout(this._visibilityTimeoutId);
        document.removeEventListener("visibilitychange", this._onVisibilityChange);
        if (this._el) {
          this._el.style.display = "none";
          this._el.classList.remove("tobyflow-paused");
        }
        try {
          _endZoomSession();
        } catch (_) {
        }
      },
      isVisible() {
        return this._el && this._el.style.display !== "none";
      }
    };
    async function _openFlowAdvancedMenu() {
      const cfg = _getDynamicSelector("composer_advanced_menu_button");
      const iconText = cfg?.icon_text || "add_2";
      const buttons = document.querySelectorAll("button");
      let target = null;
      for (const btn of buttons) {
        const icon = btn.querySelector('i.google-symbols, i[class*="symbol"]');
        if (!icon || icon.textContent?.trim() !== iconText) continue;
        const nearTextbox = btn.closest("form")?.querySelector('[role="textbox"], [contenteditable="true"]') || document.querySelector('[data-slate-editor="true"], [contenteditable="true"]')?.closest('form, [role="group"]')?.contains(btn);
        if (nearTextbox || btn.getAttribute("aria-haspopup") === "dialog") {
          target = btn;
          break;
        }
      }
      if (!target) {
        for (const btn of buttons) {
          const icon = btn.querySelector('i.google-symbols, i[class*="symbol"]');
          if (icon && icon.textContent?.trim() === iconText) {
            target = btn;
            break;
          }
        }
      }
      if (!target) {
        console.warn("[FlowVoice] composer_advanced_menu_button not found (icon_text=" + iconText + ")");
        return false;
      }
      target.click();
      const deadline = Date.now() + 3e3;
      while (Date.now() < deadline) {
        const dialog = document.querySelector('[role="dialog"][data-state="open"], [role="dialog"]');
        if (dialog && dialog.querySelector('[role="tab"]')) return true;
        await sleep(80);
      }
      return false;
    }
    async function _switchToVoicesTab() {
      const iconText = _getDynamicSelector("advanced_menu_voices_tab")?.icon_text || "voice_selection";
      const tab = _findTabByIconText(iconText);
      if (!tab) {
        console.warn("[FlowVoice] advanced_menu_voices_tab not found");
        return false;
      }
      tab.click();
      await sleep(200);
      const deadline = Date.now() + 2e3;
      while (Date.now() < deadline) {
        if (document.querySelector('[role="option"]')) return true;
        await sleep(80);
      }
      return false;
    }
    async function scrapeFlowVoices() {
      try {
        const opened = await _openFlowAdvancedMenu();
        if (!opened) {
          return { success: false, error: "Could not open advanced menu (composer button not found or menu did not open)" };
        }
        const tabOk = await _switchToVoicesTab();
        if (!tabOk) {
          _closeFlowAdvancedMenu();
          return { success: false, error: "Could not switch to Voices tab" };
        }
        const firstOption = document.querySelector('[role="option"]');
        let scrollContainer = null;
        const knownSizeEl = document.querySelector("[data-known-size]");
        if (knownSizeEl) {
          let el = knownSizeEl.parentElement;
          while (el && el !== document.body) {
            const style = window.getComputedStyle(el);
            if ((style.overflow === "auto" || style.overflow === "scroll" || style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
              scrollContainer = el;
              break;
            }
            el = el.parentElement;
          }
        }
        if (!scrollContainer && firstOption) {
          let el = firstOption.parentElement;
          while (el && el !== document.body) {
            const style = window.getComputedStyle(el);
            if ((style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
              scrollContainer = el;
              break;
            }
            el = el.parentElement;
          }
        }
        console.log(
          "[FlowVoice] scrollContainer:",
          scrollContainer?.tagName,
          scrollContainer?.className,
          "scrollHeight:",
          scrollContainer?.scrollHeight,
          "clientHeight:",
          scrollContainer?.clientHeight
        );
        const nameSelCfg = _getDynamicSelector("advanced_menu_voice_name_div");
        const descSelCfg = _getDynamicSelector("advanced_menu_voice_description_div");
        const nameSelectors = nameSelCfg?.selectors?.length ? nameSelCfg.selectors : ["div > div:first-child"];
        const descSelectors = descSelCfg?.selectors?.length ? descSelCfg.selectors : ["div > div:nth-child(2)"];
        console.log("[FlowVoice] Using nameSelectors:", nameSelectors, "descSelectors:", descSelectors);
        const collected = /* @__PURE__ */ new Map();
        let stableScrolls = 0;
        const maxScrolls = 50;
        for (let i = 0; i < maxScrolls; i++) {
          const sizeBefore = collected.size;
          const options = document.querySelectorAll('[role="option"]');
          let voiceOptionsCount = 0;
          for (const opt of options) {
            const icon = opt.querySelector('i.google-symbols, i[class*="symbol"]');
            if (!icon || icon.textContent?.trim() !== "voice_selection") continue;
            voiceOptionsCount++;
            let name = "";
            let desc = "";
            for (const sel of nameSelectors) {
              try {
                const v = opt.querySelector(sel)?.textContent?.trim();
                if (v && !v.includes("voice_selection") && v.length < 50) {
                  name = v;
                  break;
                }
              } catch (_) {
              }
            }
            for (const sel of descSelectors) {
              try {
                const v = opt.querySelector(sel)?.textContent?.trim();
                if (v && !v.includes("voice_selection")) {
                  desc = v;
                  break;
                }
              } catch (_) {
              }
            }
            if (!name) {
              const directChildren = Array.from(opt.children).filter((c) => c.tagName === "DIV");
              const iconContainer = directChildren.find((d) => d.contains(icon));
              const infoContainer = directChildren.find((d) => d !== iconContainer && d.textContent?.trim());
              if (infoContainer) {
                const leafDivs = Array.from(infoContainer.querySelectorAll("div")).filter((d) => !d.querySelector("div") && d.textContent?.trim());
                if (leafDivs.length > 0) {
                  name = leafDivs[0].textContent.trim();
                  desc = leafDivs[1]?.textContent?.trim() || "";
                } else {
                  name = infoContainer.textContent?.trim() || "";
                }
              }
            }
            if (name && !collected.has(name)) {
              collected.set(name, { name, description: desc || null });
            }
          }
          const sizeAfter = collected.size;
          console.log(`[FlowVoice] Iter ${i}: ${options.length} role=option, ${voiceOptionsCount} voice icons, collected ${sizeAfter} (delta ${sizeAfter - sizeBefore})`);
          if (sizeAfter === sizeBefore) {
            stableScrolls++;
            if (stableScrolls >= 5) {
              console.log(`[FlowVoice] Stable for 5 iterations, stopping scroll`);
              break;
            }
          } else {
            stableScrolls = 0;
          }
          try {
            if (scrollContainer && scrollContainer.scrollHeight > scrollContainer.clientHeight + scrollContainer.scrollTop) {
              scrollContainer.scrollTop += 300;
            } else if (options.length > 0) {
              options[options.length - 1].scrollIntoView({ block: "end", behavior: "instant" });
            }
          } catch (e) {
            console.warn("[FlowVoice] Scroll error:", e.message);
          }
          await sleep(300);
        }
        _closeFlowAdvancedMenu();
        const voices = Array.from(collected.values());
        console.log(`[FlowVoice] Scraped ${voices.length} voices:`, voices.map((v) => v.name).join(", "));
        return { success: true, voices };
      } catch (err) {
        console.error("[FlowVoice] scrapeFlowVoices error:", err);
        try {
          _closeFlowAdvancedMenu();
        } catch (_) {
        }
        return { success: false, error: err.message };
      }
    }
    async function _removeAllSelectedFlowVoices() {
      const MAX_ITER = 10;
      let totalRemoved = 0;
      const cfg = _getDynamicSelector("prompt_selected_voice_button");
      if (!cfg) {
        console.warn("[FlowVoice] prompt_selected_voice_button config missing \u2014 skip voice cleanup");
        return 0;
      }
      const selectors = cfg.selectors?.length ? cfg.selectors : [];
      const iconText = cfg.icon_text || null;
      if (!selectors.length || !iconText) {
        console.warn("[FlowVoice] prompt_selected_voice_button config incomplete (selectors/icon_text missing) \u2014 skip");
        return 0;
      }
      for (let i = 0; i < MAX_ITER; i++) {
        const candidates = [];
        for (const sel of selectors) {
          try {
            document.querySelectorAll(sel).forEach((btn) => {
              if (!candidates.includes(btn)) candidates.push(btn);
            });
          } catch (_) {
          }
        }
        const voiceButtons = candidates.filter((btn) => {
          const directChildren = Array.from(btn.children);
          return directChildren.some((child) => {
            if (child.tagName !== "I") return false;
            return child.textContent?.trim() === iconText;
          });
        });
        if (voiceButtons.length === 0) break;
        console.log(`[FlowVoice] _removeAllSelectedFlowVoices iter ${i}: ${voiceButtons.length} voice button(s) found`);
        try {
          voiceButtons[0].click();
          totalRemoved++;
        } catch (e) {
          console.warn("[FlowVoice] Click voice remove button failed:", e.message);
          break;
        }
        await sleep(200);
      }
      return totalRemoved;
    }
    async function selectFlowVoice(voicePayload) {
      if (!voicePayload?.search_value) {
        return { success: true, skipped: true };
      }
      try {
        console.log(`[FlowVoice] selectFlowVoice START \u2014 search_value="${voicePayload.search_value}"`);
        try {
          const editorEl = document.querySelector('[data-slate-editor="true"]');
          if (editorEl) {
            await clearEditor(editorEl);
            console.log("[FlowVoice] \u2713 Cleared editor text tr\u01B0\u1EDBc select voice");
          }
        } catch (e) {
          console.warn("[FlowVoice] clearEditor failed (non-blocking):", e.message);
        }
        const removedCount = await _removeAllSelectedFlowVoices();
        if (removedCount > 0) {
          console.log(`[FlowVoice] \u2713 Removed ${removedCount} pre-existing voice(s)`);
        }
        const opened = await _openFlowAdvancedMenu();
        if (!opened) {
          console.warn("[FlowVoice] Could not open advanced menu");
          return { success: false, error: "Could not open advanced menu" };
        }
        console.log("[FlowVoice] \u2713 Menu opened");
        const tabOk = await _switchToVoicesTab();
        if (!tabOk) {
          console.warn("[FlowVoice] Could not switch to Voices tab");
          _closeFlowAdvancedMenu();
          return { success: false, error: "Could not switch to Voices tab" };
        }
        console.log("[FlowVoice] \u2713 Switched to Voices tab");
        const nameSelCfg = _getDynamicSelector("advanced_menu_voice_name_div");
        const nameSelectors = nameSelCfg?.selectors?.length ? nameSelCfg.selectors : ["div > div:first-child"];
        const extractOptName = (opt) => {
          const icon = opt.querySelector('i.google-symbols, i[class*="symbol"]');
          if (!icon || icon.textContent?.trim() !== "voice_selection") return "";
          for (const sel of nameSelectors) {
            try {
              const v = opt.querySelector(sel)?.textContent?.trim();
              if (v && !v.includes("voice_selection") && v.length < 50) return v;
            } catch (_) {
            }
          }
          const directChildren = Array.from(opt.children).filter((c) => c.tagName === "DIV");
          const iconContainer = directChildren.find((d) => d.contains(icon));
          const infoContainer = directChildren.find((d) => d !== iconContainer && d.textContent?.trim());
          if (infoContainer) {
            const leafDivs = Array.from(infoContainer.querySelectorAll("div")).filter((d) => !d.querySelector("div") && d.textContent?.trim());
            if (leafDivs.length > 0) return leafDivs[0].textContent.trim();
          }
          return "";
        };
        const targetName = voicePayload.search_value;
        let target = null;
        let scrollContainer = null;
        const firstOpt = document.querySelector('[role="option"]');
        if (firstOpt) {
          let el = firstOpt.parentElement;
          while (el && el !== document.body) {
            const style = window.getComputedStyle(el);
            if ((style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
              scrollContainer = el;
              break;
            }
            el = el.parentElement;
          }
        }
        const maxScrolls = 30;
        for (let i = 0; i < maxScrolls; i++) {
          const options = document.querySelectorAll('[role="option"]');
          const visibleNames = [];
          for (const opt of options) {
            const name = extractOptName(opt);
            if (!name) continue;
            visibleNames.push(name);
            if (name === targetName) {
              target = opt;
              break;
            }
          }
          console.log(`[FlowVoice] Search iter ${i}: ${options.length} options, ${visibleNames.length} voice names: [${visibleNames.slice(0, 8).join(", ")}${visibleNames.length > 8 ? "..." : ""}], target found: ${!!target}`);
          if (target) break;
          try {
            if (scrollContainer && scrollContainer.scrollHeight > scrollContainer.clientHeight + scrollContainer.scrollTop) {
              scrollContainer.scrollTop += 300;
            } else if (options.length > 0) {
              options[options.length - 1].scrollIntoView({ block: "end", behavior: "instant" });
            } else {
              break;
            }
          } catch (e) {
            console.warn("[FlowVoice] Scroll error:", e.message);
            break;
          }
          await sleep(250);
        }
        if (!target) {
          console.warn(`[FlowVoice] Voice "${voicePayload.search_value}" not found in menu after scroll`);
          _closeFlowAdvancedMenu();
          return { success: false, error: "voice_not_found", name: voicePayload.search_value };
        }
        try {
          target.scrollIntoView({ block: "center", behavior: "instant" });
        } catch (_) {
        }
        await sleep(150);
        console.log(`[FlowVoice] \u2713 Clicking voice option: "${voicePayload.search_value}"`);
        target.click();
        await sleep(400);
        const applied = await _clickAddToPromptButton();
        if (applied) {
          await sleep(300);
          return { success: true, selected: voicePayload.search_value, strategy: "add_to_prompt_button" };
        }
        console.warn('[FlowVoice] "Add To Prompt" button not found \u2014 fallback double-click voice option');
        const reFindTarget = () => {
          const opts = document.querySelectorAll('[role="option"]');
          for (const opt of opts) {
            const name = extractOptName(opt);
            if (name === targetName) return opt;
          }
          return null;
        };
        let target2 = reFindTarget();
        if (!target2) {
          await sleep(200);
          target2 = reFindTarget();
        }
        if (target2) {
          try {
            target2.scrollIntoView({ block: "center", behavior: "instant" });
          } catch (_) {
          }
          await sleep(100);
          console.log(`[FlowVoice] Fallback: clicking voice option AGAIN (double-click) \u2014 "${voicePayload.search_value}"`);
          target2.click();
          await sleep(500);
          const menuOpen = !!document.querySelector('[role="dialog"][data-state="open"] [role="tab"]');
          if (!menuOpen) {
            console.log("[FlowVoice] \u2713 Fallback succeeded \u2014 menu closed after double-click");
            return { success: true, selected: voicePayload.search_value, strategy: "double_click_fallback" };
          }
          _closeFlowAdvancedMenu();
          console.warn("[FlowVoice] Fallback double-click did NOT close menu \u2014 voice may not be applied");
          return { success: false, error: "fallback_double_click_failed" };
        }
        _closeFlowAdvancedMenu();
        return { success: false, error: "add_to_prompt_button_not_found" };
      } catch (err) {
        console.error("[FlowVoice] selectFlowVoice error:", err);
        try {
          _closeFlowAdvancedMenu();
        } catch (_) {
        }
        return { success: false, error: err.message };
      }
    }
    async function _clickAddToPromptButton() {
      const cfg = _getDynamicSelector("advanced_menu_add_to_prompt_button");
      const buttonTexts = cfg?.button_text?.length ? cfg.button_text : ["Th\xEAm v\xE0o c\xE2u l\u1EC7nh", "Add To Prompt", "Add to prompt"];
      const deadline = Date.now() + 3e3;
      while (Date.now() < deadline) {
        const buttons = document.querySelectorAll("button");
        for (const btn of buttons) {
          const text = btn.textContent?.trim() || "";
          for (const target of buttonTexts) {
            if (text === target || text.startsWith(target)) {
              if (btn.disabled) continue;
              const rect = btn.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              console.log(`[FlowVoice] Clicking "Add To Prompt" button: text="${text}"`);
              btn.click();
              return true;
            }
          }
        }
        await sleep(150);
      }
      console.warn("[FlowVoice] _clickAddToPromptButton timeout \u2014 no matching button found");
      return false;
    }
    async function _switchToCharactersTab() {
      const iconText = _getDynamicSelector("advanced_menu_characters_tab")?.icon_text || "accessibility_new";
      const tab = _findTabByIconText(iconText);
      if (!tab) {
        console.warn("[FlowCharacter] advanced_menu_characters_tab not found");
        return false;
      }
      tab.click();
      await sleep(200);
      const deadline = Date.now() + 2e3;
      while (Date.now() < deadline) {
        if (document.querySelector('[role="option"]')) return true;
        await sleep(80);
      }
      return false;
    }
    async function scrapeFlowCharacters() {
      try {
        const opened = await _openFlowAdvancedMenu();
        if (!opened) {
          return { success: false, error: "Could not open advanced menu" };
        }
        const tabOk = await _switchToCharactersTab();
        if (!tabOk) {
          _closeFlowAdvancedMenu();
          return { success: false, error: "Could not switch to Characters tab" };
        }
        const firstOption = document.querySelector('[role="option"]');
        let scrollContainer = null;
        const knownSizeEl = document.querySelector("[data-known-size]");
        if (knownSizeEl) {
          let el = knownSizeEl.parentElement;
          while (el && el !== document.body) {
            const style = window.getComputedStyle(el);
            if ((style.overflow === "auto" || style.overflow === "scroll" || style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
              scrollContainer = el;
              break;
            }
            el = el.parentElement;
          }
        }
        if (!scrollContainer && firstOption) {
          let el = firstOption.parentElement;
          while (el && el !== document.body) {
            const style = window.getComputedStyle(el);
            if ((style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
              scrollContainer = el;
              break;
            }
            el = el.parentElement;
          }
        }
        const nameSelCfg = _getDynamicSelector("advanced_menu_character_name_div");
        const nameSelectors = nameSelCfg?.selectors?.length ? nameSelCfg.selectors : [":scope > div:nth-child(2)"];
        const collected = /* @__PURE__ */ new Map();
        let stableScrolls = 0;
        const maxScrolls = 50;
        for (let i = 0; i < maxScrolls; i++) {
          const sizeBefore = collected.size;
          const options = document.querySelectorAll('[role="option"]');
          for (const opt of options) {
            const info = _extractCharOption(opt, nameSelectors);
            if (info && !collected.has(info.name)) collected.set(info.name, info);
          }
          const sizeAfter = collected.size;
          console.log(`[FlowCharacter] Iter ${i}: ${options.length} option, collected ${sizeAfter} (delta ${sizeAfter - sizeBefore})`);
          if (sizeAfter === sizeBefore) {
            stableScrolls++;
            if (stableScrolls >= 5) break;
          } else {
            stableScrolls = 0;
          }
          try {
            if (scrollContainer && scrollContainer.scrollHeight > scrollContainer.clientHeight + scrollContainer.scrollTop) {
              scrollContainer.scrollTop += 300;
            } else if (options.length > 0) {
              options[options.length - 1].scrollIntoView({ block: "end", behavior: "instant" });
            }
          } catch (e) {
            console.warn("[FlowCharacter] Scroll error:", e.message);
          }
          await sleep(300);
        }
        _closeFlowAdvancedMenu();
        const characters = Array.from(collected.values());
        console.log(`[FlowCharacter] Scraped ${characters.length} characters:`, characters.map((c) => c.name).join(", "));
        return { success: true, characters };
      } catch (err) {
        console.error("[FlowCharacter] scrapeFlowCharacters error:", err);
        try {
          _closeFlowAdvancedMenu();
        } catch (_) {
        }
        return { success: false, error: err.message };
      }
    }
    async function _removeAllSelectedFlowCharacters() {
      const MAX_ITER = 10;
      let totalRemoved = 0;
      const cfg = _getDynamicSelector("prompt_selected_character_button");
      if (!cfg) {
        console.warn("[FlowCharacter] prompt_selected_character_button config missing \u2014 skip cleanup");
        return 0;
      }
      const selectors = cfg.selectors?.length ? cfg.selectors : [];
      const iconText = cfg.icon_text || null;
      if (!selectors.length || !iconText) {
        console.warn("[FlowCharacter] prompt_selected_character_button config incomplete \u2014 skip");
        return 0;
      }
      for (let i = 0; i < MAX_ITER; i++) {
        const candidates = [];
        for (const sel of selectors) {
          try {
            document.querySelectorAll(sel).forEach((btn) => {
              if (!candidates.includes(btn)) candidates.push(btn);
            });
          } catch (_) {
          }
        }
        const charButtons = candidates.filter((btn) => {
          const hasDirectIcon = Array.from(btn.children).some(
            (child) => child.tagName === "I" && child.textContent?.trim() === iconText
          );
          return hasDirectIcon && !!btn.querySelector("img");
        });
        if (charButtons.length === 0) break;
        try {
          charButtons[0].click();
          totalRemoved++;
        } catch (e) {
          console.warn("[FlowCharacter] Click character remove button failed:", e.message);
          break;
        }
        await sleep(200);
      }
      return totalRemoved;
    }
    async function selectFlowCharacter(characterPayload) {
      if (!characterPayload?.search_value) {
        return { success: true, skipped: true };
      }
      try {
        console.log(`[FlowCharacter] selectFlowCharacter START \u2014 search_value="${characterPayload.search_value}"`);
        const removedCount = await _removeAllSelectedFlowCharacters();
        if (removedCount > 0) console.log(`[FlowCharacter] \u2713 Removed ${removedCount} pre-existing character(s)`);
        const opened = await _openFlowAdvancedMenu();
        if (!opened) return { success: false, error: "Could not open advanced menu" };
        const tabOk = await _switchToCharactersTab();
        if (!tabOk) {
          _closeFlowAdvancedMenu();
          return { success: false, error: "Could not switch to Characters tab" };
        }
        const nameSelCfg = _getDynamicSelector("advanced_menu_character_name_div");
        const nameSelectors = nameSelCfg?.selectors?.length ? nameSelCfg.selectors : [":scope > div:nth-child(2)"];
        const extractName = (opt) => {
          const info = _extractCharOption(opt, nameSelectors);
          return info ? info.name : "";
        };
        const targetName = characterPayload.search_value;
        let target = null;
        let scrollContainer = null;
        const firstOpt = document.querySelector('[role="option"]');
        if (firstOpt) {
          let el = firstOpt.parentElement;
          while (el && el !== document.body) {
            const style = window.getComputedStyle(el);
            if ((style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight) {
              scrollContainer = el;
              break;
            }
            el = el.parentElement;
          }
        }
        const maxScrolls = 30;
        for (let i = 0; i < maxScrolls; i++) {
          const options = document.querySelectorAll('[role="option"]');
          for (const opt of options) {
            if (extractName(opt) === targetName) {
              target = opt;
              break;
            }
          }
          if (target) break;
          try {
            if (scrollContainer && scrollContainer.scrollHeight > scrollContainer.clientHeight + scrollContainer.scrollTop) {
              scrollContainer.scrollTop += 300;
            } else if (options.length > 0) {
              options[options.length - 1].scrollIntoView({ block: "end", behavior: "instant" });
            } else {
              break;
            }
          } catch (e) {
            console.warn("[FlowCharacter] Scroll error:", e.message);
            break;
          }
          await sleep(250);
        }
        if (!target) {
          console.warn(`[FlowCharacter] Character "${characterPayload.search_value}" not found after scroll`);
          _closeFlowAdvancedMenu();
          return { success: false, error: "character_not_found", name: characterPayload.search_value };
        }
        try {
          target.scrollIntoView({ block: "center", behavior: "instant" });
        } catch (_) {
        }
        await sleep(150);
        target.click();
        await sleep(400);
        const applied = await _clickAddToPromptButton();
        if (applied) {
          await sleep(300);
          return { success: true, selected: characterPayload.search_value, strategy: "add_to_prompt_button" };
        }
        console.warn('[FlowCharacter] "Add To Prompt" button not found \u2014 fallback double-click');
        const reFind = () => {
          const opts = document.querySelectorAll('[role="option"]');
          for (const opt of opts) {
            if (extractName(opt) === targetName) return opt;
          }
          return null;
        };
        let target2 = reFind();
        if (!target2) {
          await sleep(200);
          target2 = reFind();
        }
        if (target2) {
          try {
            target2.scrollIntoView({ block: "center", behavior: "instant" });
          } catch (_) {
          }
          await sleep(100);
          target2.click();
          await sleep(500);
          const menuOpen = !!document.querySelector('[role="dialog"][data-state="open"] [role="tab"]');
          if (!menuOpen) return { success: true, selected: characterPayload.search_value, strategy: "double_click_fallback" };
          _closeFlowAdvancedMenu();
          return { success: false, error: "fallback_double_click_failed" };
        }
        _closeFlowAdvancedMenu();
        return { success: false, error: "add_to_prompt_button_not_found" };
      } catch (err) {
        console.error("[FlowCharacter] selectFlowCharacter error:", err);
        try {
          _closeFlowAdvancedMenu();
        } catch (_) {
        }
        return { success: false, error: err.message };
      }
    }
    _statQueue = Promise.resolve();
    async function downloadTileMedia(tileId, promptText, taskName, fileName, resolution, flowFileId, index, videoResolution) {
      let res = resolution;
      if (!res) {
        const settings = await getDownloadSettings();
        res = settings.resolution;
      }
      if (!res || res === "original") res = "1k";
      if (flowFileId) {
        const tile = findTileByFileId(flowFileId);
        if (tile) tileId = tile.dataset.tileId;
      }
      if (videoResolution) {
        const tileEl = _getTileById(tileId);
        if (tileEl && _q("tile_video", tileEl)) {
          res = videoResolution;
        }
      }
      console.log(`[TobyFlow] downloadTileMedia: attempting Flow menu for ${tileId.substring(0, 20)}, res=${res}`);
      const menuSuccess = await downloadViaFlowMenu(tileId, res, fileName, promptText, taskName, index);
      if (menuSuccess) {
        console.log(`[TobyFlow] downloadTileMedia: Flow menu SUCCESS for ${tileId.substring(0, 20)}`);
        return true;
      }
      console.log(`[TobyFlow] downloadTileMedia: Flow menu FAILED for ${tileId.substring(0, 20)}, trying legacy fallback`);
      const legacySuccess = await _downloadTileMediaLegacy(tileId, promptText, taskName, fileName, res, index);
      if (legacySuccess) {
        console.log(`[TobyFlow] downloadTileMedia: Legacy fallback SUCCESS for ${tileId.substring(0, 20)}`);
        return true;
      }
      console.warn(`[TobyFlow] downloadTileMedia: BOTH methods FAILED for ${tileId.substring(0, 20)}`);
      return false;
    }
    async function _downloadTileMediaLegacy(tileId, promptText, taskName, fileName, resolution, index) {
      const MAX_RETRIES = 3;
      const RETRY_INTERVAL = 800;
      let tile = null;
      for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
        tile = _getTileById(tileId);
        if (tile) break;
        if (attempt < MAX_RETRIES - 1) {
          console.log(`[TobyFlow] _downloadTileMediaLegacy: tile not found, retry ${attempt + 1}/${MAX_RETRIES}...`);
          await sleep(RETRY_INTERVAL);
        }
      }
      if (!tile) {
        console.warn(`[TobyFlow] _downloadTileMediaLegacy: tile not found after ${MAX_RETRIES} retries: ${tileId.substring(0, 30)}`);
        return false;
      }
      if (fileName) {
        const currentFn = extractFileName(tile);
        if (currentFn && currentFn !== fileName) {
          console.warn(`[TobyFlow] _downloadTileMediaLegacy: cross-project collision`);
          sendLog(`Tile ${tileId.substring(0, 15)}... thu\u1ED9c project kh\xE1c, b\u1ECF qua.`, "warn");
          return false;
        }
      }
      const resLower = (resolution || "").toLowerCase();
      const isVideoRes = resLower === "720p" || resLower === "1080p" || resLower === "4k" && !!_q("tile_video", tile);
      const mediaTimeout = isVideoRes ? 15e3 : 1e4;
      const mediaEl = await _waitForTileMediaReady(tile, mediaTimeout, isVideoRes);
      if (!mediaEl) {
        console.warn(`[TobyFlow] _downloadTileMediaLegacy: tile media not ready after ${mediaTimeout / 1e3}s, tileId=${tileId.substring(0, 30)}`);
        return false;
      }
      try {
        const settings = await getDownloadSettings();
        const mediaSrc = applyResolutionToUrl(mediaEl.src, resolution || "1k");
        if (!mediaSrc || mediaSrc.includes("media.html") || mediaSrc.endsWith(".html") || !mediaSrc.startsWith("http://") && !mediaSrc.startsWith("https://") && !mediaSrc.startsWith("blob:")) {
          console.warn(`[TobyFlow] _downloadTileMediaLegacy: invalid/placeholder URL rejected: ${mediaSrc?.substring(0, 80)}`);
          return false;
        }
        const isVideo = mediaEl.tagName === "VIDEO";
        const ext = isVideo ? "mp4" : "png";
        const filename = _buildFilename({
          template: settings.template,
          project: settings.project,
          prompt: promptText,
          index,
          taskName,
          folder: settings.folder,
          ext
        });
        console.log(`[TobyFlow] _downloadTileMediaLegacy: downloading via chrome.downloads: ${mediaSrc.substring(0, 100)}...`);
        const response = await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            action: "chromeDownload",
            url: mediaSrc,
            filename
          }, (resp) => {
            if (chrome.runtime.lastError) {
              resolve({ success: false, error: chrome.runtime.lastError.message });
            } else {
              resolve(resp || { success: false, error: "No response" });
            }
          });
        });
        if (response.success) {
          incrementDownloadCounter();
          const resLabel = resolution ? ` [${resolution.toUpperCase()}]` : "";
          sendLog(`\u0110\xE3 t\u1EA3i${resLabel}: ${filename}`, "success");
          return true;
        } else {
          console.warn(`[TobyFlow] _downloadTileMediaLegacy: chrome.downloads failed: ${response.error}`);
          return false;
        }
      } catch (e) {
        console.warn(`[TobyFlow] _downloadTileMediaLegacy: exception: ${e.message}`);
        sendLog(`Kh\xF4ng th\u1EC3 t\u1EA3i file ${tileId}: ${e.message}`, "warn");
        return false;
      }
    }
    async function downloadViaFlowMenu(tileId, resolution, fileName, promptText, taskName, index) {
      const MAX_TILE_RETRIES = 5;
      const TILE_RETRY_INTERVAL = 1e3;
      let tile = null;
      for (let attempt = 0; attempt < MAX_TILE_RETRIES; attempt++) {
        tile = _getTileById(tileId);
        if (tile) break;
        if (attempt < MAX_TILE_RETRIES - 1) {
          console.log(`[TobyFlow] downloadViaFlowMenu: tile not found, retry ${attempt + 1}/${MAX_TILE_RETRIES} in ${TILE_RETRY_INTERVAL}ms...`);
          await sleep(TILE_RETRY_INTERVAL);
        }
      }
      if (!tile) {
        console.warn(`[TobyFlow] downloadViaFlowMenu: tile not found after ${MAX_TILE_RETRIES} retries: ${tileId.substring(0, 20)}`);
        return false;
      }
      if (fileName) {
        const currentFn = extractFileName(tile);
        if (currentFn && currentFn !== fileName) {
          console.warn(`[TobyFlow] downloadViaFlowMenu: cross-project collision`);
          sendLog(`Tile ${tileId.substring(0, 15)}... thu\u1ED9c project kh\xE1c, b\u1ECF qua.`, "warn");
          return false;
        }
      }
      const resLower = (resolution || "").toLowerCase();
      const videoEl = _q("tile_video", tile);
      const imgEl = tile?.querySelector("img");
      const isVideoByAlt = imgEl?.alt?.toLowerCase().includes("video");
      const isVideo = !!videoEl || isVideoByAlt || resLower === "720p" || resLower === "1080p";
      let resLabel = _getDownloadMenuLabel(resolution, isVideo);
      if (!resLabel) {
        console.debug("[Tier3] downloadViaFlowMenu: resLabel null (config miss), using raw resolution string");
        resLabel = (resolution || "").toString();
      }
      if (document.visibilityState === "hidden") {
        await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: "ensureFlowTabActive" }, () => resolve());
        });
        await sleep(300);
      }
      const mediaTimeout = isVideo ? 15e3 : 1e4;
      tile.scrollIntoView({ behavior: "instant", block: "center" });
      const readyMedia = await _waitForTileMediaReady(tile, mediaTimeout, isVideo);
      if (!readyMedia) {
        console.warn(`[TobyFlow] downloadViaFlowMenu: tile media not ready after ${mediaTimeout / 1e3}s, tileId=${tileId.substring(0, 20)}`);
        return false;
      }
      await _acquireCtxMenuLock();
      try {
        tile.scrollIntoView({ behavior: "instant", block: "center" });
        await sleep(100);
        const targetEl = readyMedia;
        const rect = targetEl.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        console.log(`[TobyFlow] downloadViaFlowMenu: right-click on ${targetEl.tagName} at (${Math.round(cx)}, ${Math.round(cy)}), rect: ${Math.round(rect.width)}x${Math.round(rect.height)}`);
        targetEl.dispatchEvent(new MouseEvent("contextmenu", {
          bubbles: true,
          cancelable: true,
          clientX: cx,
          clientY: cy,
          button: 2
        }));
        const _ctxSel = _selStr("context_menu");
        if (!_ctxSel) {
          console.debug("[Tier3] downloadViaFlowMenu: context_menu config miss");
          return false;
        }
        const contextMenu = await _waitForElement(_ctxSel, 3e3);
        if (!contextMenu) {
          console.warn("[TobyFlow] downloadViaFlowMenu: context menu not found");
          return false;
        }
        await sleep(50);
        const triggerConfig = _getDynamicSelector("download_menu_trigger");
        let triggerIconText = triggerConfig?.icon_text;
        let triggerButtonText = triggerConfig?.button_text?.length ? triggerConfig.button_text : [];
        if (!triggerIconText) {
          console.debug("[Tier3] downloadViaFlowMenu: download_menu_trigger.icon_text cache miss");
          triggerIconText = "";
        }
        if (!triggerButtonText.length) {
          console.debug("[Tier3] downloadViaFlowMenu: download_menu_trigger.button_text cache miss");
        }
        const _miSel = _selStr("menu_item");
        if (!_miSel) {
          console.debug("[Tier3] menu_item config miss");
          return false;
        }
        const menuItems = contextMenu.querySelectorAll(_miSel);
        let downloadItem = null;
        for (const item of menuItems) {
          const icon = item.querySelector("i");
          if (icon?.textContent?.trim() === triggerIconText && item.getAttribute("aria-haspopup") === "menu") {
            downloadItem = item;
            break;
          }
        }
        if (!downloadItem) {
          for (const item of menuItems) {
            const text = item.textContent?.trim() || "";
            if (_textIncludesAny(text, triggerButtonText) && item.getAttribute("aria-haspopup") === "menu") {
              downloadItem = item;
              break;
            }
          }
        }
        if (!downloadItem) {
          for (const item of menuItems) {
            if (item.querySelector("i")?.textContent?.trim() === triggerIconText) {
              downloadItem = item;
              break;
            }
          }
        }
        if (!downloadItem) {
          console.warn("[TobyFlow] downloadViaFlowMenu: download menu item not found");
          _closeContextMenu();
          return false;
        }
        const dlRect = downloadItem.getBoundingClientRect();
        const dlCx = dlRect.left + dlRect.width / 2;
        const dlCy = dlRect.top + dlRect.height / 2;
        const pointerOpts = { bubbles: true, cancelable: true, clientX: dlCx, clientY: dlCy, pointerId: 1, pointerType: "mouse", relatedTarget: contextMenu };
        const mouseOpts = { bubbles: true, cancelable: true, clientX: dlCx, clientY: dlCy, relatedTarget: contextMenu };
        const submenuConfig = _getDynamicSelector("download_submenu");
        const submenuAttribute = submenuConfig?.attribute || "aria-controls";
        const submenuSelectors = submenuConfig?.selectors?.length ? submenuConfig.selectors : [];
        if (!submenuSelectors.length) console.debug("[Tier3] downloadViaFlowMenu: download_submenu config miss");
        const findSubMenu = () => {
          const subMenuId = downloadItem.getAttribute(submenuAttribute);
          if (subMenuId) {
            const menu = document.getElementById(subMenuId);
            if (menu) return menu;
          }
          for (const sel of submenuSelectors) {
            try {
              const candidates = document.querySelectorAll(sel);
              for (const m of candidates) {
                if (m !== contextMenu) return m;
              }
            } catch (e) {
            }
          }
          return null;
        };
        downloadItem.dispatchEvent(new PointerEvent("pointerover", pointerOpts));
        downloadItem.dispatchEvent(new PointerEvent("pointerenter", pointerOpts));
        downloadItem.dispatchEvent(new PointerEvent("pointermove", pointerOpts));
        downloadItem.dispatchEvent(new PointerEvent("pointerdown", { ...pointerOpts, button: 0 }));
        downloadItem.dispatchEvent(new PointerEvent("pointerup", { ...pointerOpts, button: 0 }));
        downloadItem.dispatchEvent(new MouseEvent("mouseover", mouseOpts));
        downloadItem.dispatchEvent(new MouseEvent("mouseenter", mouseOpts));
        downloadItem.dispatchEvent(new MouseEvent("mousemove", mouseOpts));
        downloadItem.focus();
        let subMenu = null;
        for (let attempt = 0; attempt < 5 && !subMenu; attempt++) {
          await sleep(150);
          subMenu = findSubMenu();
          if (!subMenu && attempt === 1) {
            downloadItem.dispatchEvent(new PointerEvent("pointerenter", pointerOpts));
            downloadItem.dispatchEvent(new MouseEvent("mouseenter", mouseOpts));
          }
          if (!subMenu && attempt === 3) {
            downloadItem.focus();
            downloadItem.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowRight", bubbles: true }));
            await sleep(100);
            subMenu = findSubMenu();
          }
        }
        if (!subMenu) {
          downloadItem.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true, clientX: dlCx, clientY: dlCy }));
          downloadItem.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, clientX: dlCx, clientY: dlCy }));
          await sleep(300);
          subMenu = findSubMenu();
        }
        if (!subMenu) {
          console.warn("[TobyFlow] downloadViaFlowMenu: sub-menu not found after 5 attempts");
          _closeContextMenu();
          return false;
        }
        const subItemConfig = _getDynamicSelector("download_submenu_item");
        const subItemSelectors = subItemConfig?.selectors?.length ? subItemConfig.selectors : [];
        if (!subItemSelectors.length) console.debug("[Tier3] download_submenu_item config miss");
        let subItems = [];
        for (const sel of subItemSelectors) {
          try {
            const found = subMenu.querySelectorAll(sel);
            if (found && found.length > 0) {
              subItems = found;
              break;
            }
          } catch (e) {
          }
        }
        const fallbackChain = _getDownloadFallbackChain(isVideo);
        let startIdx = fallbackChain.indexOf(resLabel);
        if (startIdx < 0) startIdx = 0;
        let targetItem = null;
        let actualResLabel = resLabel;
        for (let fi = startIdx; fi < fallbackChain.length && !targetItem; fi++) {
          const tryLabel = fallbackChain[fi];
          for (const item of subItems) {
            const text = item.textContent?.trim() || "";
            if (text.startsWith(tryLabel)) {
              if (item.getAttribute("aria-disabled") === "true") {
                console.log(`[TobyFlow] downloadViaFlowMenu: ${tryLabel} is disabled (aria-disabled), trying lower resolution`);
                break;
              }
              targetItem = item;
              actualResLabel = tryLabel;
              break;
            }
          }
        }
        if (targetItem && actualResLabel !== resLabel) {
          sendLog(`${resLabel} kh\xF4ng kh\u1EA3 d\u1EE5ng, t\u1EA3i ${actualResLabel} thay th\u1EBF`, "warn");
        }
        if (!targetItem) {
          const availableItems = [...subItems].map((i) => i.textContent?.trim()).join(", ");
          console.warn(`[TobyFlow] downloadViaFlowMenu: ${resLabel} not found in sub-menu. Available: [${availableItems}]`);
          for (const item of subItems) {
            if (item.getAttribute("aria-disabled") !== "true") {
              targetItem = item;
              const firstWord = item.textContent?.trim().split(" ")[0] || "?";
              sendLog(`${resLabel} kh\xF4ng kh\u1EA3 d\u1EE5ng, t\u1EA3i ${firstWord} thay th\u1EBF`, "warn");
              break;
            }
          }
          if (!targetItem) {
            console.warn("[TobyFlow] downloadViaFlowMenu: no downloadable option found");
            _closeContextMenu();
            return false;
          }
        }
        const mediaForValidation = isVideo ? _q("tile_video", tile) : _q("tile_video", tile) || tile.querySelector("img");
        if (mediaForValidation) {
          const currentSrc = mediaForValidation.src || "";
          const rawSrc = mediaForValidation.getAttribute("src") || "";
          const isPlaceholder = currentSrc.includes("media.html") || currentSrc.endsWith(".html") || rawSrc === "media.html" || rawSrc.endsWith(".html") || !currentSrc.startsWith("http") && !currentSrc.startsWith("blob:") && !rawSrc.startsWith("/fx/");
          if (isPlaceholder) {
            console.warn("[TobyFlow] downloadViaFlowMenu: media URL is placeholder after menu opened, aborting download");
            _closeContextMenu();
            return false;
          }
        }
        const settings = await getDownloadSettings();
        const downloadFilename = _buildFilename({
          template: settings.template,
          project: settings.project,
          prompt: promptText,
          index,
          taskName,
          folder: settings.folder,
          ext: isVideo ? "mp4" : "png"
        });
        const lastSlash = downloadFilename.lastIndexOf("/");
        const downloadFolder = lastSlash >= 0 ? downloadFilename.substring(0, lastSlash) : settings.folder;
        const baseName = lastSlash >= 0 ? downloadFilename.substring(lastSlash + 1).replace(/\.[^.]+$/, "") : downloadFilename.replace(/\.[^.]+$/, "");
        const identifier = fileName || baseName || tileId;
        await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            action: "prepareDownloadRename",
            folder: downloadFolder,
            filename: baseName,
            identifier
          }, () => resolve());
        });
        targetItem.click();
        await sleep(50);
        incrementDownloadCounter();
        const actualRes = targetItem.textContent?.trim().split(" ")[0] || resLabel;
        sendLog(`\u0110\xE3 t\u1EA3i [${actualRes}]: ${downloadFolder}/${baseName}`, "success");
        return true;
      } catch (e) {
        console.error("[TobyFlow] downloadViaFlowMenu error:", e);
        _closeContextMenu();
        return false;
      } finally {
        _releaseCtxMenuLock();
      }
    }
    _ctxMenuLockQueue = _ctxMenuLockQueue || [];
    _ctxMenuLocked = _ctxMenuLocked || false;
    async function _acquireCtxMenuLock() {
      if (_ctxMenuLocked) {
        await new Promise((resolve) => _ctxMenuLockQueue.push(resolve));
      }
      _ctxMenuLocked = true;
      if (!ExecutionBlocker._blocking) {
        document.body.classList.add("tobyflow-execution-blocking");
      }
      _closeContextMenu();
      await sleep(50);
    }
    async function _waitExitMediaViewer(maxMs = 3e3) {
      for (let i = 0; i < Math.ceil(maxMs / 200); i++) {
        await sleep(200);
        if (!_isFlowMediaViewerOpen()) return true;
      }
      return false;
    }
    async function _exitFlowMediaViewer() {
      if (!_isFlowMediaViewerOpen()) return true;
      const projectId = getCurrentProjectId();
      const cleanPath = location.pathname.replace(/(\/project\/[a-f0-9-]+)\/edit\/[a-f0-9-]+.*$/, "$1");
      let backBtn = null;
      const buttons = document.querySelectorAll("button");
      for (const btn of buttons) {
        const icon = _findIconInElement(btn);
        if (icon && icon.textContent.trim() === "arrow_back") {
          backBtn = btn;
          break;
        }
      }
      if (backBtn) {
        const opts = { bubbles: true, cancelable: true, view: window, button: 0 };
        try {
          backBtn.dispatchEvent(new PointerEvent("pointerdown", opts));
        } catch (_) {
        }
        try {
          backBtn.dispatchEvent(new MouseEvent("mousedown", opts));
        } catch (_) {
        }
        try {
          backBtn.dispatchEvent(new PointerEvent("pointerup", opts));
        } catch (_) {
        }
        try {
          backBtn.dispatchEvent(new MouseEvent("mouseup", opts));
        } catch (_) {
        }
        try {
          backBtn.click();
        } catch (_) {
        }
        if (await _waitExitMediaViewer()) return true;
        console.warn("[exitMediaViewer] Tier 1 (n\xFAt back) fail \u2192 th\u1EED history.back()");
      }
      try {
        history.back();
        await _waitExitMediaViewer();
        if (!_isFlowMediaViewerOpen() && getCurrentProjectId() === projectId && location.pathname.includes("/project/")) {
          return true;
        }
      } catch (_) {
      }
      if (cleanPath !== location.pathname) {
        console.warn("[exitMediaViewer] Tier 1+2 fail \u2192 reload URL project s\u1EA1ch:", cleanPath);
        location.href = location.origin + cleanPath + location.search;
      }
      return !_isFlowMediaViewerOpen();
    }
    let _autoScrollInFlight = false;
    async function _autoScrollLoadProjects() {
      if (_autoScrollInFlight) return;
      _autoScrollInFlight = true;
      try {
        await _autoScrollLoadProjectsInner();
      } finally {
        _autoScrollInFlight = false;
      }
    }
    async function _autoScrollLoadProjectsInner() {
      const sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
      let scroller = null;
      const firstLink = _qaProjectLinks()[0];
      if (firstLink) {
        let p = firstLink.parentElement;
        for (let i = 0; i < 12 && p && p !== document.body; i++) {
          const oy = getComputedStyle(p).overflowY;
          if ((oy === "auto" || oy === "scroll") && p.scrollHeight > p.clientHeight + 4) {
            scroller = p;
            break;
          }
          p = p.parentElement;
        }
      }
      if (!scroller) {
        scroller = document.querySelector('[data-testid="virtuoso-scroller"]') || document.querySelector('[data-testid="virtuoso-item-list"]')?.parentElement || null;
      }
      const useWindow = !scroller;
      const se = document.scrollingElement || document.documentElement;
      const getTop = () => useWindow ? window.scrollY || se.scrollTop || 0 : scroller.scrollTop;
      const getMax = () => useWindow ? se.scrollHeight - window.innerHeight : scroller.scrollHeight - scroller.clientHeight;
      const scrollTo = (y) => useWindow ? window.scrollTo(0, y) : scroller.scrollTop = y;
      const originalTop = getTop();
      const MAX_STEPS = 20;
      let lastCount = _qaProjectLinks().length;
      let stable = 0;
      for (let step = 0; step < MAX_STEPS; step++) {
        const beforeTop = getTop();
        scrollTo(getMax() + 1e3);
        await sleep3(400);
        const count = _qaProjectLinks().length;
        const grew = count > lastCount;
        const moved = getTop() > beforeTop + 2;
        lastCount = count;
        if (!grew && !moved) {
          if (++stable >= 2) break;
        } else {
          stable = 0;
        }
      }
      scrollTo(originalTop);
      await sleep3(120);
    }
    _retryingTiles = /* @__PURE__ */ new Set();
    _clickedRetryTileIds = /* @__PURE__ */ new Set();
    _retryMutex = null;
    async function _acquireRetryMutex() {
      const maxWait = 12e4;
      const startWait = Date.now();
      while (_retryMutex) {
        if (Date.now() - startWait > maxWait) {
          console.warn("[TobyFlow] Retry mutex stuck > 120s, force release");
          _retryMutex = null;
          break;
        }
        await _retryMutex;
      }
      let release;
      _retryMutex = new Promise((r) => {
        release = r;
      });
      return () => {
        release();
        _retryMutex = null;
      };
    }
    async function retryFailedTilesViaButton(failedTileIds, timeoutMs = 12e4, excludeTileIds = null) {
      const succeeded = [];
      const stillFailed = [];
      let clickedCount = 0;
      let skippedAlreadyClicked = 0;
      const toRetry = failedTileIds.filter((tid) => !_retryingTiles.has(tid) && !_clickedRetryTileIds.has(tid));
      const alreadyClicked = failedTileIds.filter((tid) => _clickedRetryTileIds.has(tid));
      skippedAlreadyClicked = alreadyClicked.length;
      if (alreadyClicked.length > 0) {
        console.log(`[TobyFlow] ${alreadyClicked.length} tile \u0111\xE3 click retry tr\u01B0\u1EDBc \u0111\xF3 (skip \u0111\u1EC3 tr\xE1nh t\u1EA1o d\u01B0):`, alreadyClicked.map((t) => t.substring(0, 12)));
      }
      if (toRetry.length === 0) {
        console.log("[TobyFlow] T\u1EA5t c\u1EA3 tiles \u0111\xE3 \u0111ang \u0111\u01B0\u1EE3c retry ho\u1EB7c \u0111\xE3 click retry, skip");
        return {
          succeeded: [],
          stillFailed: failedTileIds.filter((tid) => !_clickedRetryTileIds.has(tid)),
          clickedCount: 0,
          skippedAlreadyClicked
        };
      }
      toRetry.forEach((tid) => _retryingTiles.add(tid));
      const excludeSet = excludeTileIds?.length > 0 ? new Set(excludeTileIds) : null;
      const releaseMutex = await _acquireRetryMutex();
      try {
        for (const tileId of toRetry) {
          if (shouldStop) {
            stillFailed.push(tileId);
            continue;
          }
          const currentTile = _getTileById(tileId);
          const currentStatus = detectTileStatus(currentTile);
          if (currentStatus === "success") {
            console.log(`[TobyFlow] Retry skipped: tile ${tileId.substring(0, 12)}... \u0111\xE3 success (transient 'failed' state)`);
            succeeded.push(tileId);
            continue;
          }
          if (currentStatus === "processing") {
            console.log(`[TobyFlow] Retry skipped: tile ${tileId.substring(0, 12)}... \u0111ang processing`);
            continue;
          }
          const preTileIds = getUniqueTileIds(true);
          const preFileNames = getExistingFileNames();
          const clicked = clickTileRetryButton(tileId);
          if (!clicked) {
            console.warn("[TobyFlow] Retry button not found for tile:", tileId);
            stillFailed.push(tileId);
            continue;
          }
          _clickedRetryTileIds.add(tileId);
          clickedCount++;
          sendLog(`[Retry L1] Click n\xFAt retry tile...`, "info");
          const retryTimeout = Math.max(timeoutMs, 18e4);
          const result = await waitForNewTiles(preTileIds, retryTimeout, preFileNames);
          let newTiles = result?.tiles || [];
          if (excludeSet && newTiles.length > 0) {
            newTiles = newTiles.filter((tid) => !excludeSet.has(tid));
          }
          if (newTiles.length > 1) {
            console.log(`[TobyFlow] Retry single tile got ${newTiles.length} tiles, taking oldest`);
            newTiles = newTiles.slice(-1);
          }
          if (newTiles.length > 0) {
            const newTileId = newTiles[0];
            const tile = _getTileById(newTileId);
            const status = detectTileStatus(tile);
            if (status === "failed") {
              stillFailed.push(newTileId);
              console.log(`[TobyFlow] Retry tile ${tileId.substring(0, 12)}... \u2192 new tile ${newTileId.substring(0, 12)}... FAILED`);
            } else if (status === "success") {
              succeeded.push(newTileId);
              console.log(`[TobyFlow] Retry tile ${tileId.substring(0, 12)}... \u2192 new tile ${newTileId.substring(0, 12)}... SUCCESS`);
            } else {
              stillFailed.push(newTileId);
              console.log(`[TobyFlow] Retry tile ${tileId.substring(0, 12)}... \u2192 new tile ${newTileId.substring(0, 12)}... unexpected PROCESSING status, treat as failed`);
            }
          } else {
            console.log(`[TobyFlow] Retry tile ${tileId.substring(0, 12)}... \u2192 c\u1EA3 2 phase timeout (~120s), skip \u0111\u1EC3 tr\xE1nh t\u1EA1o d\u01B0`);
          }
          if (toRetry.indexOf(tileId) < toRetry.length - 1) {
            await sleep(300);
          }
        }
        const uniqueSucceeded = [...new Set(succeeded)];
        const uniqueFailed = [...new Set(stillFailed)];
        return {
          succeeded: uniqueSucceeded,
          stillFailed: uniqueFailed,
          clickedCount,
          // Số button retry đã thực sự click trong call này
          skippedAlreadyClicked
          // Số tile skip vì đã click trước đó
        };
      } finally {
        toRetry.forEach((tid) => _retryingTiles.delete(tid));
        releaseMutex();
      }
    }
    async function waitForNewTiles(preTileIds, timeoutMs = 12e4, preFileNames = null, maxQuantity = 0) {
      const startTime = Date.now();
      const MIN_FAIL_DETECT_MS = 15e3;
      const LAZY_LOAD_GRACE_MS = 15e3;
      const preTileSet = new Set(preTileIds);
      const knownFileNames = preFileNames || /* @__PURE__ */ new Set();
      const urlPattern = await _getMediaUrlPatternAsync(5e3);
      if (!urlPattern) {
        console.error("[waitForNewTiles] \u274C image_url_pattern config not loaded after 5s \u2014 cannot extract file_name, monitor will fail");
        sendLog("\u26A0\uFE0F Config ch\u01B0a s\u1EB5n s\xE0ng, vui l\xF2ng th\u1EED l\u1EA1i", "warn");
      } else {
        console.log("[waitForNewTiles] \u2705 image_url_pattern ready: " + urlPattern);
      }
      let confirmedNewTiles = null;
      let firstNewDetectedAt = 0;
      let pendingCheck = false;
      const tileContainer = document.querySelector(_getTileSelectorString())?.parentElement || document.body;
      const observer = new MutationObserver(() => {
        pendingCheck = true;
      });
      observer.observe(tileContainer, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class", "src", "data-tile-id"]
      });
      const cleanup = () => {
        observer.disconnect();
      };
      try {
        while (Date.now() - startTime < timeoutMs) {
          if (shouldStop) {
            cleanup();
            return { tiles: [], failed: false };
          }
          if (pendingCheck) {
            pendingCheck = false;
            await sleep(200);
          } else {
            await sleep(5e3);
          }
          const currentTiles = getUniqueTileIds(true);
          let newTiles = currentTiles.filter((id) => !preTileSet.has(id));
          if (newTiles.length > 0) {
            if (knownFileNames.size > 0) {
              newTiles = newTiles.filter((tid) => {
                const tile = _getTileById(tid);
                const fn = extractFileName(tile);
                return !fn || !knownFileNames.has(fn);
              });
              if (newTiles.length === 0) continue;
            }
            if (confirmedNewTiles === null) {
              if (!firstNewDetectedAt) firstNewDetectedAt = Date.now();
              const processingTiles = newTiles.filter((tid) => {
                const tile = _getTileById(tid);
                return detectTileStatus(tile) !== "success";
              });
              const fastCompletedTiles = newTiles.filter((tid) => {
                if (processingTiles.includes(tid)) return false;
                const tile = _getTileById(tid);
                const fn = extractFileName(tile);
                return fn && knownFileNames.size > 0 && !knownFileNames.has(fn);
              });
              if (processingTiles.length > 0 || fastCompletedTiles.length > 0) {
                confirmedNewTiles = /* @__PURE__ */ new Set([...processingTiles, ...fastCompletedTiles]);
              } else if (Date.now() - firstNewDetectedAt > LAZY_LOAD_GRACE_MS) {
                confirmedNewTiles = new Set(newTiles);
              } else {
                continue;
              }
            } else {
              for (const tid of newTiles) {
                if (confirmedNewTiles.has(tid)) continue;
                const tile = _getTileById(tid);
                if (detectTileStatus(tile) !== "success") {
                  confirmedNewTiles.add(tid);
                } else {
                  const fn = extractFileName(tile);
                  if (fn && knownFileNames.size > 0 && !knownFileNames.has(fn)) {
                    confirmedNewTiles.add(tid);
                  }
                }
              }
            }
            newTiles = newTiles.filter((id) => confirmedNewTiles.has(id));
            if (newTiles.length === 0) continue;
            if (maxQuantity > 0 && newTiles.length > maxQuantity) {
              newTiles = newTiles.slice(-maxQuantity);
            }
            const elapsed = Date.now() - startTime;
            let allDone = true;
            let anyFailed = false;
            for (const tid of newTiles) {
              const tile = _getTileById(tid);
              const status = detectTileStatus(tile);
              if (status === "failed" && elapsed >= MIN_FAIL_DETECT_MS) {
                anyFailed = true;
                continue;
              }
              if (status === "processing" || status === "failed" && elapsed < MIN_FAIL_DETECT_MS) {
                allDone = false;
                break;
              }
              const fileName = extractFileName(tile);
              if (!fileName && status === "success") {
                allDone = false;
                break;
              }
            }
            if (anyFailed && allDone) {
              cleanup();
              return { tiles: newTiles, failed: true };
            }
            if (!anyFailed && allDone) {
              const thumbnails = {};
              for (const tid of newTiles) {
                const tile = _getTileById(tid);
                if (!tile) continue;
                const img = tile.querySelector("img");
                let video = _q("tile_video", tile);
                const isVideoTileHint = img?.alt?.toLowerCase().includes("video");
                if (!video && isVideoTileHint) {
                  const pollVideoStart = Date.now();
                  const POLL_VIDEO_TIMEOUT = 1e4;
                  const POLL_VIDEO_INTERVAL = 500;
                  while (!video && Date.now() - pollVideoStart < POLL_VIDEO_TIMEOUT) {
                    await sleep(POLL_VIDEO_INTERVAL);
                    video = _q("tile_video", tile);
                  }
                  if (video) {
                    sendLog("[waitForNewTiles] \u0110\xE3 ph\xE1t hi\u1EC7n <video> sau " + (Date.now() - pollVideoStart) + "ms delay", "info");
                  } else {
                    sendLog("[waitForNewTiles] Video element kh\xF4ng xu\u1EA5t hi\u1EC7n sau " + POLL_VIDEO_TIMEOUT + "ms, fallback img-based video detection", "warn");
                  }
                }
                const fileName = extractFileName(tile);
                const flowInfo = extractFlowFileInfo(tile);
                if (video) {
                  let videoUrl = video.src || video.currentSrc || "";
                  if (!videoUrl || videoUrl.length < 10) {
                    const pollSrcStart = Date.now();
                    const POLL_SRC_TIMEOUT = 3e3;
                    const POLL_SRC_INTERVAL = 200;
                    while ((!videoUrl || videoUrl.length < 10) && Date.now() - pollSrcStart < POLL_SRC_TIMEOUT) {
                      await sleep(POLL_SRC_INTERVAL);
                      videoUrl = video.src || video.currentSrc || "";
                    }
                    if (videoUrl && videoUrl.length > 10) {
                      sendLog("[waitForNewTiles] Video src loaded sau " + (Date.now() - pollSrcStart) + "ms: " + videoUrl.substring(0, 60), "info");
                    }
                  }
                  if (videoUrl && !videoUrl.startsWith("http")) {
                    try {
                      videoUrl = new URL(videoUrl, window.location.origin).href;
                    } catch (e) {
                      console.warn("[waitForNewTiles] Cannot resolve video URL:", videoUrl);
                    }
                  }
                  let vThumb = video.poster || "";
                  if (!vThumb && img?.src && !img.src.includes("chrome-extension")) vThumb = img.src;
                  if (!vThumb && videoUrl) vThumb = videoUrl;
                  thumbnails[tid] = {
                    thumbnail: vThumb,
                    type: "video",
                    video_url: videoUrl,
                    // Actual video URL để backend download + gửi qua Telegram
                    ...fileName && { file_name: fileName },
                    ...flowInfo && { file_id: flowInfo.file_id, project_id: flowInfo.project_id }
                  };
                } else if (img?.src && !img.src.includes("chrome-extension")) {
                  const isVideoByAlt = img.alt?.toLowerCase().includes("video");
                  if (isVideoByAlt) {
                    thumbnails[tid] = {
                      thumbnail: img.src,
                      type: "video",
                      video_url: img.src,
                      // Fallback: dùng thumbnail URL — backend có thể retry lấy video
                      ...fileName && { file_name: fileName },
                      ...flowInfo && { file_id: flowInfo.file_id, project_id: flowInfo.project_id }
                    };
                    sendLog("[waitForNewTiles] Video tile detected via alt attribute, no <video> element \u2014 using img fallback", "warn");
                  } else {
                    thumbnails[tid] = { thumbnail: img.src, type: "image", ...fileName && { file_name: fileName }, ...flowInfo && { file_id: flowInfo.file_id, project_id: flowInfo.project_id } };
                  }
                }
              }
              cleanup();
              return { tiles: newTiles, failed: false, thumbnails };
            }
          }
        }
        cleanup();
        return { tiles: [], failed: false };
      } catch (err) {
        cleanup();
        throw err;
      }
    }
    async function waitAndDownloadNewTiles(preTileIds, promptText, timeoutMs = 12e4) {
      const startTime = Date.now();
      const MIN_FAIL_DETECT_MS = 15e3;
      while (Date.now() - startTime < timeoutMs) {
        await sleep(2e3);
        const currentTiles = getUniqueTileIds(true);
        const newTiles = currentTiles.filter((id) => !preTileIds.includes(id));
        if (newTiles.length > 0) {
          const elapsed = Date.now() - startTime;
          let allDone = true;
          let anyFailed = false;
          for (const tid of newTiles) {
            const tile = _getTileById(tid);
            const status = detectTileStatus(tile);
            if (status === "failed" && elapsed >= MIN_FAIL_DETECT_MS) {
              anyFailed = true;
            }
            if (status === "processing" || status === "failed" && elapsed < MIN_FAIL_DETECT_MS) {
              allDone = false;
              break;
            }
          }
          if (anyFailed) {
            sendLog("\u274C Google Flow b\xE1o l\u1ED7i - t\u1EA1o \u1EA3nh th\u1EA5t b\u1EA1i", "error");
            return [];
          }
          if (allDone) {
            for (const tid of newTiles) {
              await downloadTileMedia(tid, promptText);
              await sleep(150);
            }
            return newTiles;
          }
        }
      }
      sendLog("\u26A0\uFE0F Timeout ch\u1EDD k\u1EBFt qu\u1EA3 \u0111\u1EC3 t\u1EA3i", "warn");
      return [];
    }
    async function notifyCompletion(title, body) {
      const settings = await new Promise((resolve) => {
        chrome.storage.local.get(["af_settings"], (res) => resolve(res.af_settings || {}));
      });
      if (settings.notifyOnComplete !== false) {
        if (Notification.permission === "granted") {
          new Notification(title, { body });
        } else if (Notification.permission !== "denied") {
          const perm = await Notification.requestPermission();
          if (perm === "granted") {
            new Notification(title, { body });
          }
        }
      }
      if (settings.notifySound) {
        try {
          const ctx = new AudioContext();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.frequency.setValueAtTime(800, ctx.currentTime);
          osc.frequency.setValueAtTime(600, ctx.currentTime + 0.1);
          osc.frequency.setValueAtTime(900, ctx.currentTime + 0.2);
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
          osc.start(ctx.currentTime);
          osc.stop(ctx.currentTime + 0.4);
        } catch (e) {
        }
      }
    }
    window._afSettings = {
      humanizedMode: false,
      humanizedSpeed: 0.5,
      // User-controlled timing (kept in af_settings) — bootstrap initial trước khi storage load
      inputTimeout: 1200,
      randomDelayMin: 3,
      randomDelayMax: 10
    };
    window._afExecConfig = {
      workflow: { max_retries: 2, timeout_sec: 180 },
      timing: { delay_between_prompts_sec: 5 },
      flow_recovery: {
        backoff_base_sec: 30,
        backoff_max_sec: 300,
        backoff_jitter_percent: 20,
        auto_recovery_enabled: true,
        consecutive_fail_threshold: 2
      }
    };
    (function loadAfSettings() {
      chrome.storage.local.get(["af_settings", "af_execution_config"], (result) => {
        const s = result.af_settings || {};
        window._afSettings = {
          ...window._afSettings,
          humanizedMode: s.humanizedMode || false,
          humanizedSpeed: parseFloat(s.humanizedSpeed) || 0.5,
          inputTimeout: parseInt(s.inputTimeout) || 1200,
          randomDelayMin: parseInt(s.randomDelayMin) || 3,
          randomDelayMax: parseInt(s.randomDelayMax) || 10
        };
        const ec = result.af_execution_config;
        if (ec) {
          window._afExecConfig = {
            workflow: ec.workflow || window._afExecConfig.workflow,
            timing: ec.timing || window._afExecConfig.timing,
            flow_recovery: ec.flow_recovery || window._afExecConfig.flow_recovery
          };
        }
      });
    })();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.af_settings) {
        const s = changes.af_settings.newValue || {};
        window._afSettings = {
          ...window._afSettings,
          humanizedMode: s.humanizedMode || false,
          humanizedSpeed: parseFloat(s.humanizedSpeed) || 0.5,
          inputTimeout: parseInt(s.inputTimeout) || 1200,
          randomDelayMin: parseInt(s.randomDelayMin) || 3,
          randomDelayMax: parseInt(s.randomDelayMax) || 10
        };
      }
      if (changes.af_execution_config) {
        const ec = changes.af_execution_config.newValue;
        if (ec) {
          window._afExecConfig = {
            workflow: ec.workflow || window._afExecConfig.workflow,
            timing: ec.timing || window._afExecConfig.timing,
            flow_recovery: ec.flow_recovery || window._afExecConfig.flow_recovery
          };
        }
      }
    });
    async function refreshFlowSession(trigger) {
      trigger = trigger || "unknown";
      const startedAt = Date.now();
      try {
        if (document.visibilityState === "hidden") {
          await new Promise((r) => chrome.runtime.sendMessage({ action: "ensureFlowTabActive" }, () => r()));
          await sleep(300);
        }
        const result = await _slateBridgeCall("refreshSession", {});
        const durationMs = Date.now() - startedAt;
        if (result?.success) {
          console.log("[TobyFlow][FAR-1] Refresh OK", { trigger, durationMs });
          try {
            _incrementDailyStat("flow_refresh_success");
          } catch (e) {
          }
          return true;
        }
        console.warn("[TobyFlow][FAR-1] Refresh FAIL", { trigger, durationMs, error: result?.error || "unknown" });
        try {
          _incrementDailyStat("flow_refresh_fail");
        } catch (e) {
        }
        return false;
      } catch (e) {
        const durationMs = Date.now() - startedAt;
        console.warn("[TobyFlow][FAR-1] Refresh exception", { trigger, durationMs, error: e.message });
        try {
          _incrementDailyStat("flow_refresh_fail");
        } catch (e2) {
        }
        return false;
      }
    }
    async function clearEditor(editor) {
      injectSlateBridge();
      const result = await _slateBridgeCall("clear", {});
      if (result.success) {
        console.log("[TobyFlow] clearEditor: Slate bridge OK (1 trong 3 inner tier work)");
        await sleep(200);
        return;
      }
      console.warn("[TobyFlow] clearEditor: \u274C Slate bridge failed (c\u1EA3 3 inner tier):", result.error);
      console.warn("[TobyFlow] clearEditor: \u26A0\uFE0F Aborting \u2014 no DOM fallback (tr\xE1nh crash Flow page)");
    }
    async function insertText(editor, text) {
      injectSlateBridge();
      await sleep(100 + Math.random() * 200);
      editor = getEditor() || editor;
      if (isHumanizedEnabled()) {
        const chunks = text.match(/\S+\s*/g) || [text];
        for (let ci = 0; ci < chunks.length; ci++) {
          if (shouldStop) break;
          await _insertTextSingle(chunks[ci]);
          if (ci < chunks.length - 1) {
            await sleep(getHumanizedDelay(120));
          }
        }
      } else {
        await _insertTextSingle(text);
      }
      await sleep(200 + Math.random() * 300);
    }
    async function _insertTextSingle(text) {
      let editor = getEditor();
      function isDomUpdated() {
        const el = getEditor();
        if (!el) return false;
        const hasPlaceholder = !!el.querySelector("[data-slate-placeholder]");
        const domText = el.textContent?.trim() || "";
        return !hasPlaceholder && domText.length > 0;
      }
      function isTextAlreadyInserted() {
        const el = getEditor();
        if (!el) return false;
        const domText = el.textContent?.trim() || "";
        const normalizedDom = domText.replace(/\s+/g, " ").trim();
        const normalizedTarget = text.replace(/\s+/g, " ").trim();
        if (normalizedTarget.length > 20) {
          const matchRatio = normalizedDom.length > 0 ? Math.min(normalizedDom.length, normalizedTarget.length) / normalizedTarget.length : 0;
          return matchRatio > 0.8;
        }
        return normalizedDom === normalizedTarget;
      }
      const result = await _slateBridgeCall("insert", { text });
      if (result.success) {
        console.log("[TobyFlow] insertText: Slate bridge returned success (1 trong 3 inner tier work)");
        const maxWaitDom = 2e3;
        const pollInterval = 200;
        let waited = 0;
        while (waited < maxWaitDom) {
          await sleep(pollInterval);
          waited += pollInterval;
          if (isDomUpdated()) {
            console.log("[TobyFlow] insertText: DOM verified OK after", waited, "ms");
            return;
          }
          if (isTextAlreadyInserted()) {
            console.log("[TobyFlow] insertText: Text already in editor after", waited, "ms");
            return;
          }
        }
        console.log("[TobyFlow] insertText: Slate bridge success BUT DOM not updated after 2s");
        console.log("[TobyFlow] insertText: Skipping DOM fallbacks to avoid Slate state corruption");
        return;
      }
      console.warn("[TobyFlow] insertText: \u274C Slate bridge failed (c\u1EA3 3 inner tier):", result.error);
      console.warn("[TobyFlow] insertText: \u26A0\uFE0F Aborting \u2014 no DOM fallback (tr\xE1nh crash Flow page)");
    }
    async function removeExistingRefImages() {
      console.log("[removeExistingRefImages] called \u2014 clear ALL chips (ref + character + voice)");
      const editor = getEditor();
      if (!editor) {
        console.log("[removeExistingRefImages] EARLY RETURN \u2014 no editor found");
        return 0;
      }
      let promptContainer = null;
      let probe = editor.parentElement;
      let probeLevel = 0;
      for (let i = 0; i < 6 && probe; i++) {
        const iconsInProbe = _findIconsInElement(probe);
        const hasCancel = iconsInProbe.some((ic) => ic.textContent.trim() === "cancel");
        if (hasCancel) {
          promptContainer = probe;
          probeLevel = i + 1;
          break;
        }
        probe = probe.parentElement;
      }
      if (!promptContainer) {
        promptContainer = editor.parentElement?.parentElement?.parentElement;
        console.log("[removeExistingRefImages] walk-up kh\xF4ng t\xECm cancel icon, fallback 3-level parent");
      } else {
        console.log(`[removeExistingRefImages] container found via walk-up level ${probeLevel} (c\xF3 cancel icon)`);
      }
      if (!promptContainer) {
        console.log("[removeExistingRefImages] EARLY RETURN \u2014 no promptContainer");
        return 0;
      }
      let removed = 0;
      const MAX_CHIPS = 15;
      for (let i = 0; i < MAX_CHIPS; i++) {
        const cancelIcon = _findIconsInElement(promptContainer).find((ic) => ic.textContent.trim() === "cancel");
        if (!cancelIcon) break;
        const cancelBtn = cancelIcon.closest("button") || cancelIcon.parentElement;
        if (!cancelBtn) break;
        simulateClick(cancelBtn);
        removed++;
        await sleep(200);
      }
      const stillHasCancel = _findIconsInElement(promptContainer).some((ic) => ic.textContent.trim() === "cancel");
      if (stillHasCancel) {
        const clearBtn = _findIconsInElement(promptContainer).find((ic) => ic.textContent.trim() === "close")?.closest("button");
        if (clearBtn) {
          console.log('[removeExistingRefImages] c\xF2n chip sau loop \u2192 fallback click "Xo\xE1 c\xE2u l\u1EC7nh" (clear-all)');
          simulateClick(clearBtn);
          removed++;
          await sleep(300);
        }
      }
      if (removed > 0) {
        sendLog(`\u0110\xE3 xo\xE1 ${removed} th\xE0nh ph\u1EA7n c\u0169 trong c\xE2u l\u1EC7nh`, "info");
      } else {
        console.log(`[removeExistingRefImages] DONE \u2014 removed=0 (c\xE2u l\u1EC7nh \u0111\xE3 tr\u1ED1ng)`);
      }
      return removed;
    }
    async function applySettings(genType, aspectRatio, modelName, isFrames = false, quantity = 1, flowVideoDuration = null) {
      console.log(`[applySettings] CALLED with: genType="${genType}", aspectRatio="${aspectRatio}", modelName="${modelName}", isFrames=${isFrames} (typeof ${typeof isFrames}), quantity=${quantity}, flowVideoDuration=${flowVideoDuration}`);
      sendLog(`\u2699\uFE0F \u0110ang thi\u1EBFt l\u1EADp c\u1EA5u h\xECnh: ${genType}, ${aspectRatio}, ${modelName}, isFrames=${isFrames}, x${quantity}${flowVideoDuration ? ", " + flowVideoDuration : ""}`);
      const PRESUBMIT_COOLDOWN_MS = 5e3;
      const _presubmitLastRun = window._tobyAgentChainLastRunAt || 0;
      const _presubmitSince = Date.now() - _presubmitLastRun;
      const _skipPresubmitGuard = _presubmitSince < PRESUBMIT_COOLDOWN_MS;
      let _anyAgentActioned = false;
      if (_skipPresubmitGuard) {
        console.log(`[applySettings] Pre-submit guard SKIPPED (chain ran ${Math.round(_presubmitSince / 1e3)}s ago)`);
      } else {
        try {
          const d = _isFlowAgentInstructionDialogOpen();
          const p = _isFlowChatAgentPanelOpen();
          const a = _isFlowAgentModeOn();
          console.log("[applySettings] Pre-submit guard state:", {
            instructionDialog: d.open ? "OPEN" : d.found ? "closed" : "NO-BUTTON-ON-DOM",
            chatPanel: p.open ? "OPEN" : p.found ? "closed" : "NO-BUTTON-ON-DOM",
            agentToggle: a.on ? "ON" : a.found ? "OFF" : "NO-BUTTON-ON-DOM"
          });
        } catch (e) {
          console.warn("[applySettings] State probe failed:", e.message);
        }
        try {
          const dialogState = _isFlowAgentInstructionDialogOpen();
          if (dialogState.found && dialogState.open) {
            const openMsg = window.I18n?.t?.("flow.agentInstructionDialogOpenTitle") || 'Dialog "H\u01B0\u1EDBng d\u1EABn cho t\xE1c nh\xE2n" \u0111ang m\u1EDF \u2014 t\u1EF1 \u0111\u1ED9ng click "Xong" tr\u01B0\u1EDBc khi gen';
            sendLog("\u26A0 " + openMsg, "warn");
            const r = await _ensureFlowAgentInstructionDone();
            if (r.success) {
              const okMsg = window.I18n?.t?.("flow.agentInstructionAutoDone") || "\u0110\xE3 \u0111\xF3ng dialog h\u01B0\u1EDBng d\u1EABn agent";
              sendLog("\u2713 " + okMsg, "info");
              if (r.wasOpen) _anyAgentActioned = true;
            } else {
              const failMsg = window.I18n?.t?.("flow.agentInstructionDoneFailed") || "KH\xD4NG \u0111\xF3ng \u0111\u01B0\u1EE3c dialog h\u01B0\u1EDBng d\u1EABn \u2014 gen c\xF3 th\u1EC3 fail";
              sendLog("\u2717 " + failMsg, "error");
            }
          }
        } catch (e) {
          console.warn("[applySettings] _ensureFlowAgentInstructionDone failed:", e.message);
        }
        let _chatPanelActioned = false;
        try {
          const panelState = _isFlowChatAgentPanelOpen();
          if (panelState.found && panelState.open) {
            const openMsg = window.I18n?.t?.("flow.chatAgentPanelOpenTitle") || "Chat agent panel \u0111ang m\u1EDF \u2014 t\u1EF1 \u0111\u1ED9ng \u0111\xF3ng tr\u01B0\u1EDBc khi gen";
            sendLog("\u26A0 " + openMsg, "warn");
            const r = await _ensureFlowChatAgentClosed();
            if (r.success) {
              const okMsg = window.I18n?.t?.("flow.chatAgentAutoClosed") || "\u0110\xE3 \u0111\xF3ng panel chat agent";
              sendLog("\u2713 " + okMsg, "info");
              if (r.wasOpen) {
                _anyAgentActioned = true;
                _chatPanelActioned = true;
              }
            } else {
              const failMsg = window.I18n?.t?.("flow.chatAgentCloseFailed") || "KH\xD4NG \u0111\xF3ng \u0111\u01B0\u1EE3c panel chat agent \u2014 gen c\xF3 th\u1EC3 fail";
              sendLog("\u2717 " + failMsg, "error");
            }
          }
        } catch (e) {
          console.warn("[applySettings] _ensureFlowChatAgentClosed failed:", e.message);
        }
        if (_chatPanelActioned) {
          await sleep(800);
          try {
            const reVerify = _isFlowChatAgentPanelOpen();
            if (reVerify.found && reVerify.open) {
              sendLog("\u26A0 Panel re-render sau close \u2014 \u0111\xF3ng l\u1EA1i tr\u01B0\u1EDBc khi t\u1EAFt Agent", "warn");
              await _ensureFlowChatAgentClosed();
              await sleep(500);
            }
          } catch (_) {
          }
        }
        try {
          const agentState = _isFlowAgentModeOn();
          if (agentState.found && agentState.on) {
            const onMsg = window.I18n?.t?.("flow.agentModeOnTitle") || "Agent mode \u0111ang ON \u2014 t\u1EF1 \u0111\u1ED9ng t\u1EAFt tr\u01B0\u1EDBc khi gen";
            sendLog("\u26A0 " + onMsg, "warn");
            const r = await _ensureFlowAgentModeOff();
            if (r.success) {
              const okMsg = window.I18n?.t?.("flow.agentModeAutoDisabled") || "\u0110\xE3 t\u1EAFt Agent mode";
              sendLog("\u2713 " + okMsg, "info");
              if (r.wasOn) _anyAgentActioned = true;
            } else {
              const failMsg = window.I18n?.t?.("flow.agentModeDisableFailed") || "KH\xD4NG t\u1EAFt \u0111\u01B0\u1EE3c Agent mode \u2014 gen c\xF3 th\u1EC3 fail";
              sendLog("\u2717 " + failMsg, "error");
            }
          }
        } catch (e) {
          console.warn("[applySettings] _ensureFlowAgentModeOff failed:", e.message);
        }
        if (_anyAgentActioned) {
          sendLog("\u23F3 \u0110\u1EE3i editor Flow re-render sau khi \u0111\xF3ng agent UI...", "info");
          const editorReady = await _waitForFlowEditorReady(5e3);
          if (editorReady) {
            sendLog("\u2713 Editor Flow ready (sau " + editorReady + "ms)", "info");
          } else {
            sendLog("\u26A0 Editor Flow ch\u01B0a ready sau 5s \u2014 v\u1EABn ti\u1EBFp t\u1EE5c (c\xF3 th\u1EC3 fail)", "warn");
          }
        }
        window._tobyAgentChainLastRunAt = Date.now();
      }
      const current = readCurrentSettings();
      let needModel = true;
      let needRatio = true;
      let needQuantity = true;
      const isVideoMode = genType.toLowerCase() === "video";
      if (!isVideoMode && !modelName) {
        needModel = false;
      }
      if (current) {
        let targetModel = modelName;
        console.log(`[applySettings] current.model="${current.model}", targetModel="${targetModel}"`);
        let modelMatches = false;
        if (isVideoMode) {
          if (current.model && targetModel) {
            const currentLower = current.model.toLowerCase();
            const targetLower = targetModel.toLowerCase();
            modelMatches = currentLower.includes(targetLower) || targetLower.includes(currentLower);
            console.log(`[applySettings] Video mode: comparing "${currentLower}" with "${targetLower}" \u2192 match=${modelMatches}`);
          }
        } else if (current.model && targetModel) {
          const currentLower = current.model.toLowerCase();
          const targetLower = targetModel.toLowerCase();
          modelMatches = currentLower.includes(targetLower);
        }
        if (modelMatches) {
          needModel = false;
          console.log(`[applySettings] Skipping model change - already ${targetModel}`);
        }
        const targetRatioIcon = ratioToIconName(aspectRatio);
        if (targetRatioIcon && current.ratioIcon === targetRatioIcon) {
          needRatio = false;
        }
        if (current.quantity === quantity) {
          needQuantity = false;
        }
        if (!needModel && !needRatio && !needQuantity) {
          sendLog("\u2699\uFE0F Model/Ratio/Quantity \u0111\xE3 \u0111\xFAng, ch\u1EC9 verify genType", "info");
        }
        const changes = [];
        if (needModel) changes.push("model");
        if (needRatio) changes.push("ratio");
        if (needQuantity) changes.push("quantity");
        sendLog(`\u2699\uFE0F C\u1EA7n thay \u0111\u1ED5i: ${changes.join(", ")}`, "info");
      }
      const submitBtn = getSubmitButton();
      if (!submitBtn) {
        sendLog("\u274C Kh\xF4ng t\xECm th\u1EA5y n\xFAt Submit \u0111\u1EC3 m\u1EDF Settings.", "error");
        return;
      }
      const settingsBtn = getSettingsButton(submitBtn);
      if (!settingsBtn) {
        sendLog("\u274C Kh\xF4ng t\xECm th\u1EA5y n\xFAt Settings.", "error");
        return;
      }
      const _existingPanel = _getActiveSettingsPanel();
      const _spmSel = _selStr("settings_panel_marker");
      const _panelAlreadyOpen = _existingPanel !== document && !!_spmSel && !!_existingPanel.querySelector(_spmSel);
      if (_panelAlreadyOpen) {
        console.log("[applySettings] Settings panel \u0111\xE3 m\u1EDF \u2014 skip click settings button");
        sendLog("\u2699\uFE0F Settings panel \u0111\xE3 m\u1EDF s\u1EB5n \u2014 skip toggle", "info");
      } else {
        simulateClick(settingsBtn);
        await sleep(getSettingsStepDelay());
      }
      const _findByIdSuffix = (scope, suffix) => {
        return scope.querySelector(_buildRadixTriggerSelector(suffix));
      };
      const settingsPanel = _getActiveSettingsPanel();
      console.log(`[applySettings] settings panel: ${settingsPanel === document ? "document (no popup yet)" : "popup"}`);
      let typeClicked = false;
      const typeSuffix = genType.toLowerCase() === "video" ? "VIDEO" : "IMAGE";
      const typeKey = genType.toLowerCase() === "video" ? "mode_tab_video" : "mode_tab_image";
      let typeBtn = null;
      const _typeDynCfg = _getDynamicSelector(typeKey);
      const _typeIsDynamic = _typeDynCfg?.selectors?.length > 0;
      const _typeTrySelectors = _typeIsDynamic ? _typeDynCfg.selectors : [];
      if (!_typeIsDynamic) {
        console.debug(`[Tier3] applySettings type: ${typeKey} config miss, fallback _findByIdSuffix`);
      }
      for (const sel of _typeTrySelectors) {
        try {
          typeBtn = settingsPanel.querySelector(sel);
          if (!typeBtn && settingsPanel !== document) typeBtn = document.querySelector(sel);
          if (typeBtn) {
            console.log(`[applySettings] Found type button via ${_typeIsDynamic ? "\u{1F310} DYNAMIC" : "\u{1F4E6} DEFAULT"} selector: ${sel}`);
            break;
          }
        } catch (_) {
        }
      }
      if (!typeBtn) {
        typeBtn = _findByIdSuffix(settingsPanel, typeSuffix);
        if (!typeBtn && settingsPanel !== document) typeBtn = _findByIdSuffix(document, typeSuffix);
      }
      if (typeBtn) {
        console.log(`[applySettings] Found type button via ID suffix: -trigger-${typeSuffix}, aria-selected=${typeBtn.getAttribute("aria-selected")}`);
        simulateClick(typeBtn);
        await sleep(getSettingsStepDelay());
        typeClicked = true;
        sendLog(`\u2713 Type clicked via ID suffix: -trigger-${typeSuffix}`, "info");
      } else {
        console.log(`[applySettings] Type button NOT found via ID suffix: -trigger-${typeSuffix}`);
      }
      if (!typeClicked) {
        console.log(`[applySettings] Trying Strategy 2: text matching for genType="${genType}"`);
        const tabSelector = _selStr("tab_button_generic");
        if (!tabSelector) console.debug("[Tier3] tab_button_generic config miss");
        let allTabs = tabSelector ? settingsPanel.querySelectorAll(tabSelector) : [];
        if (allTabs.length === 0 && settingsPanel !== document && tabSelector) {
          allTabs = document.querySelectorAll(tabSelector);
        }
        console.log(`[applySettings] Found ${allTabs.length} tabs to search`);
        for (let t of allTabs) {
          let textLower = t.textContent.trim().toLowerCase();
          let targetLower = genType.toLowerCase();
          if (textLower === targetLower || targetLower === "video" && textLower.includes("video") || targetLower === "image" && (textLower.includes("\u1EA3nh") || textLower.includes("image") || textLower.includes("h\xECnh"))) {
            console.log(`[applySettings] Found type tab by text: "${textLower}", aria-selected=${t.getAttribute("aria-selected")}`);
            simulateClick(t);
            await sleep(getSettingsStepDelay());
            typeClicked = true;
            sendLog(`\u2713 Type clicked via text: ${textLower}`, "info");
            break;
          }
        }
        if (!typeClicked) {
          console.log(`[applySettings] WARNING: Could not find type tab for genType="${genType}"`);
          sendLog(`\u26A0\uFE0F Kh\xF4ng t\xECm th\u1EA5y tab ${genType}`, "warn");
        }
      }
      if (needRatio) {
        const targetRatioIcon = ratioToIconName(aspectRatio);
        const _ratioToIdSuffix = (ratio) => {
          const r = String(ratio).trim().toLowerCase();
          if (r === "d\u1ECDc" || r === "9:16" || r === "story") return "PORTRAIT";
          if (r === "ngang" || r === "16:9" || r === "widescreen") return "LANDSCAPE";
          if (r === "vu\xF4ng" || r === "1:1" || r === "square") return "SQUARE";
          if (r === "4:3" || r === "landscape") return "LANDSCAPE_4_3";
          if (r === "3:4" || r === "portrait") return "PORTRAIT_3_4";
          return null;
        };
        const activeMenu = _getActiveSettingsPanel();
        let ratioClicked = false;
        const ratioSuffix = _ratioToIdSuffix(aspectRatio);
        if (ratioSuffix) {
          const ratioBtn = _findByIdSuffix(activeMenu, ratioSuffix);
          if (ratioBtn) {
            simulateClick(ratioBtn);
            await sleep(getSettingsStepDelay());
            ratioClicked = true;
            sendLog(`\u2713 Ratio clicked via ID suffix: -trigger-${ratioSuffix}`, "info");
          }
        }
        if (!ratioClicked && targetRatioIcon) {
          const iconButtons = activeMenu.querySelectorAll("button");
          for (const btn of iconButtons) {
            const icon = _findIconInElement(btn);
            if (icon && icon.textContent.trim() === targetRatioIcon) {
              simulateClick(btn);
              await sleep(getSettingsStepDelay());
              ratioClicked = true;
              sendLog(`\u2713 Ratio clicked via icon: ${targetRatioIcon}`, "info");
              break;
            }
          }
        }
        if (!ratioClicked && targetRatioIcon) {
          const allButtons = activeMenu.querySelectorAll("button");
          for (const btn of allButtons) {
            const btnText = btn.textContent.trim().toLowerCase();
            if (btnText.includes(targetRatioIcon)) {
              simulateClick(btn);
              await sleep(getSettingsStepDelay());
              ratioClicked = true;
              sendLog(`\u2713 Ratio clicked via text: ${targetRatioIcon}`, "info");
              break;
            }
          }
        }
        if (!ratioClicked) {
          const tabSelector = _selStr("tab_button_generic");
          if (!tabSelector) console.debug("[Tier3] tab_button_generic config miss");
          const updatedTabs = tabSelector ? activeMenu.querySelectorAll(tabSelector) : [];
          for (let t of updatedTabs) {
            let textLower = t.textContent.trim().toLowerCase();
            let ratioLower = String(aspectRatio).trim().toLowerCase();
            if (textLower.includes(ratioLower) || targetRatioIcon && textLower.includes(targetRatioIcon) || ratioLower === "ngang" && (textLower.includes("landscape") || textLower.includes("16_9") || textLower.includes("16:9")) || ratioLower === "d\u1ECDc" && (textLower.includes("portrait") || textLower.includes("9_16") || textLower.includes("9:16"))) {
              simulateClick(t);
              await sleep(getSettingsStepDelay());
              sendLog(`\u2713 Ratio clicked via tab: ${textLower}`, "info");
              break;
            }
          }
        }
      }
      if (needQuantity && quantity >= 1 && quantity <= 4) {
        let quantityClicked = false;
        const quantityBtn = _findByIdSuffix(document, String(quantity));
        if (quantityBtn) {
          simulateClick(quantityBtn);
          await sleep(getSettingsStepDelay());
          quantityClicked = true;
          sendLog(`\u2713 Quantity clicked via ID suffix: -trigger-${quantity}`, "info");
        }
        if (!quantityClicked) {
          const tabSelector = _selStr("tab_button_generic");
          if (!tabSelector) console.debug("[Tier3] tab_button_generic config miss");
          const quantityTabs = tabSelector ? document.querySelectorAll(tabSelector) : [];
          for (let t of quantityTabs) {
            let text = t.textContent.trim();
            if (text === `x${quantity}`) {
              simulateClick(t);
              await sleep(getSettingsStepDelay());
              break;
            }
          }
        }
      }
      let targetModelName = modelName;
      const videoInputType = isVideoMode ? isFrames ? "Frames" : "Ingredients" : null;
      const actualVideoModel = isVideoMode ? modelName : null;
      if (isVideoMode) {
        targetModelName = videoInputType;
        console.log(`[applySettings] Video mode: inputType=${videoInputType}, actualModel=${actualVideoModel}`);
      }
      console.log(`[applySettings] needModel=${needModel}, isVideoMode=${isVideoMode}, isFrames=${isFrames}, targetModelName="${targetModelName}", actualVideoModel="${actualVideoModel}"`);
      if (isVideoMode && needModel) {
        const activeMenu = _getActiveSettingsPanel();
        let videoModeClicked = false;
        const _framesConfig = _getDynamicSelector("video_mode_frames");
        const _ingredientsConfig = _getDynamicSelector("video_mode_ingredients");
        const _framesTextMatch = _framesConfig?.text_match || [];
        const _ingredientsTextMatch = _ingredientsConfig?.text_match || [];
        const _targetLower = targetModelName.toLowerCase();
        const isFramesTarget = _framesTextMatch.some((t) => _targetLower.includes(t.toLowerCase()));
        const searchTerms = isFramesTarget ? _framesTextMatch : _ingredientsTextMatch;
        const ariaControlsMatch = isFramesTarget ? "VIDEO_FRAMES" : "VIDEO_REFERENCES";
        const videoModeSuffix = isFramesTarget ? "VIDEO_FRAMES" : "VIDEO_REFERENCES";
        console.log(`[applySettings] Video mode: looking for ${targetModelName} with ID suffix: -trigger-${videoModeSuffix}`);
        const _vmKey = isFramesTarget ? "video_mode_frames" : "video_mode_ingredients";
        const _vmDefaults = [_buildRadixTriggerSelector(videoModeSuffix), `button[role="tab"][aria-controls*="${ariaControlsMatch}"]`];
        const _vmDynCfg = _getDynamicSelector(_vmKey);
        const _vmIsDynamic = _vmDynCfg?.selectors?.length > 0;
        const _vmTrySelectors = _vmIsDynamic ? _vmDynCfg.selectors : _vmDefaults;
        let videoModeBtn = null;
        for (const sel of _vmTrySelectors) {
          try {
            videoModeBtn = activeMenu.querySelector(sel);
            if (videoModeBtn) {
              console.log(`[applySettings] Video mode: found via ${_vmIsDynamic ? "\u{1F310} DYNAMIC" : "\u{1F4E6} DEFAULT"} selector: ${sel}`);
              break;
            }
          } catch (_) {
          }
        }
        if (!videoModeBtn) {
          videoModeBtn = _findByIdSuffix(activeMenu, videoModeSuffix);
        }
        if (videoModeBtn) {
          console.log(`[applySettings] Video mode: clicking via ID suffix -trigger-${videoModeSuffix}`);
          simulateClick(videoModeBtn);
          await sleep(getSettingsStepDelay());
          videoModeClicked = true;
          sendLog(`\u2713 Video mode: ch\u1ECDn ${targetModelName} (${_vmIsDynamic ? "dynamic" : "default"})`, "info");
        }
        const tabSelector = _selStr("tab_button_generic");
        if (!tabSelector) console.debug("[Tier3] tab_button_generic config miss");
        if (!videoModeClicked) {
          const tabs = tabSelector ? activeMenu.querySelectorAll(tabSelector) : [];
          for (const tab of tabs) {
            const ariaControls = tab.getAttribute("aria-controls") || "";
            if (ariaControls.includes(ariaControlsMatch)) {
              console.log(`[applySettings] Video mode: clicking tab via aria-controls="${ariaControls}"`);
              simulateClick(tab);
              await sleep(getSettingsStepDelay());
              videoModeClicked = true;
              sendLog(`\u2713 Video mode: ch\u1ECDn ${targetModelName} (aria)`, "info");
              break;
            }
          }
        }
        if (!videoModeClicked) {
          const tabs = activeMenu.querySelectorAll(tabSelector);
          console.log(`[applySettings] Video mode Strategy 3: searching ${tabs.length} tabs by text`);
          for (const tab of tabs) {
            const tabText = tab.textContent.trim().toLowerCase();
            for (const term of searchTerms) {
              if (tabText === term || tabText.includes(term)) {
                console.log(`[applySettings] Video mode: clicking tab "${tabText}" for ${targetModelName}`);
                simulateClick(tab);
                await sleep(getSettingsStepDelay());
                videoModeClicked = true;
                sendLog(`\u2713 Video mode: ch\u1ECDn ${targetModelName} (tab)`, "info");
                break;
              }
            }
            if (videoModeClicked) break;
          }
        }
        if (!videoModeClicked) {
          const allButtons = activeMenu.querySelectorAll("button");
          console.log(`[applySettings] Video mode Strategy 4: searching ${allButtons.length} buttons`);
          for (const btn of allButtons) {
            const btnText = btn.textContent.trim().toLowerCase();
            for (const term of searchTerms) {
              if (btnText === term || btnText.includes(term)) {
                console.log(`[applySettings] Video mode: clicking button "${btnText}" for ${targetModelName}`);
                simulateClick(btn);
                await sleep(getSettingsStepDelay());
                videoModeClicked = true;
                sendLog(`\u2713 Video mode: ch\u1ECDn ${targetModelName} (button)`, "info");
                break;
              }
            }
            if (videoModeClicked) break;
          }
        }
        if (videoModeClicked) {
          if (actualVideoModel) {
            await sleep(getSettingsStepDelay());
            targetModelName = actualVideoModel;
            needModel = true;
            console.log(`[applySettings] Video input type selected, now selecting video model: ${actualVideoModel}`);
          } else {
            needModel = false;
          }
        } else {
          console.log(`[applySettings] Video mode: "${targetModelName}" input type not found, will try dropdown fallback`);
        }
      }
      if (needModel) {
        const menuSelector = '[role="menu"]';
        const _mpc = _getDynamicSelector("model_picker_button");
        const modelBtnSelector = _mpc?.selectors?.[0];
        if (!modelBtnSelector) console.debug("[Tier3] model_picker_button miss");
        const modelItemsSelector = 'button, [role="menuitem"], [role="menuitemradio"]';
        const activeSettingsPanel = _getActiveSettingsPanel();
        let modelBtn = null;
        if (modelBtnSelector) {
          modelBtn = activeSettingsPanel.querySelector(modelBtnSelector);
          if (modelBtn) {
            console.log(`[applySettings] Found model button in settings panel scope`);
          } else {
            const menus = document.querySelectorAll(menuSelector);
            console.log(`[applySettings] Found ${menus.length} menus for model button fallback`);
            if (menus.length > 0) {
              const activeMenu = menus[menus.length - 1];
              modelBtn = activeMenu.querySelector(modelBtnSelector);
              if (modelBtn) {
                console.log(`[applySettings] Found model button in menu scope`);
              }
            }
          }
        }
        if (modelBtn) {
          console.log(`[applySettings] Clicking model button to open dropdown`);
          simulateClick(modelBtn);
          await sleep(getSettingsStepDelay());
          const allMenus2 = document.querySelectorAll(menuSelector);
          console.log(`[applySettings] After click, found ${allMenus2.length} menus`);
          if (allMenus2.length > 0) {
            const dropdown = allMenus2[allMenus2.length - 1];
            const items = dropdown.querySelectorAll(modelItemsSelector);
            const availableItems = Array.from(items).map((i) => i.textContent.trim().toLowerCase());
            console.log(`[applySettings] Model dropdown items: [${availableItems.join(", ")}], looking for: "${targetModelName}" (targetText="${String(targetModelName).toLowerCase().trim()}")`);
            console.log(`[applySettings] isFrames parameter received: ${isFrames}, typeof: ${typeof isFrames}`);
            const _framesMatch = _getDynamicSelector("video_mode_frames")?.text_match || [];
            const _ingredientsMatch = _getDynamicSelector("video_mode_ingredients")?.text_match || [];
            const _exactMatchNames = [..._framesMatch, ..._ingredientsMatch].map((t) => t.toLowerCase());
            for (let item of items) {
              const domText = item.textContent.toLowerCase().trim();
              const targetText = String(targetModelName).toLowerCase().trim();
              const _needsExactMatch = _exactMatchNames.includes(targetText);
              if (domText === targetText || domText.includes(targetText) && !_needsExactMatch) {
                console.log(`[applySettings] Clicking model item: domText="${domText}", targetText="${targetText}"`);
                simulateClick(item);
                await sleep(getSettingsStepDelay());
                break;
              } else if (domText.includes(targetText)) {
                if (targetText.includes("veo") && domText.includes("veo") && (targetText.includes("fast") && !domText.includes("fast") || targetText.includes("quality") && !domText.includes("quality"))) {
                  continue;
                }
                console.log(`[applySettings] Clicking model item (partial): domText="${domText}", targetText="${targetText}"`);
                simulateClick(item);
                await sleep(getSettingsStepDelay());
                break;
              }
            }
          }
        } else {
          console.log(`[applySettings] Model button not found, skipping model selection`);
        }
      }
      console.log(`[applySettings] Video duration check: isVideoMode=${isVideoMode}, flowVideoDuration="${flowVideoDuration}" (type: ${typeof flowVideoDuration})`);
      if (isVideoMode && flowVideoDuration) {
        const _durCfg = _getDynamicSelector("video_duration_tab");
        const _durSelectors = _durCfg?.selectors || [];
        const _durTextMatch = _durCfg?.text_match || ["4s", "6s", "8s", "10s"];
        const durationNum = parseInt(flowVideoDuration);
        const tryClickDuration = () => {
          const activeMenu = _getActiveSettingsPanel();
          if (!activeMenu) return false;
          if (_durSelectors.length > 0 && _durTextMatch.includes(flowVideoDuration)) {
            for (const sel of _durSelectors) {
              try {
                for (const tab of activeMenu.querySelectorAll(sel)) {
                  if ((tab.textContent || "").trim() !== flowVideoDuration) continue;
                  if (tab.getAttribute("aria-selected") === "true" || tab.getAttribute("data-state") === "active") return true;
                  simulateClick(tab);
                  sendLog(`\u2713 Duration: ${flowVideoDuration}`, "info");
                  return true;
                }
              } catch (_) {
              }
            }
          }
          if (!isNaN(durationNum)) {
            const btn = activeMenu.querySelector(`button[id$="-trigger-${durationNum}"]`);
            if (btn) {
              if (btn.getAttribute("aria-selected") !== "true" && btn.getAttribute("data-state") !== "active") {
                simulateClick(btn);
                sendLog(`\u2713 Duration: ${flowVideoDuration} (ID suffix)`, "info");
              }
              return true;
            }
          }
          return false;
        };
        let durationClicked = false;
        for (let attempt = 0; attempt < 4 && !durationClicked; attempt++) {
          if (attempt > 0) await sleep(400);
          durationClicked = tryClickDuration();
        }
        if (durationClicked) await sleep(getSettingsStepDelay());
        if (!durationClicked) {
          const menu = _getActiveSettingsPanel() || document;
          const avail = [];
          menu.querySelectorAll('button[role="tab"], button[id*="-trigger-"]').forEach((b) => {
            const t = (b.textContent || "").trim();
            if (/^\d+\s*s$/.test(t) || /-trigger-\d+$/.test(b.id || "")) avail.push(t || b.id);
          });
          console.log(`[applySettings] Duration ${flowVideoDuration} not found. Available: [${avail.join(", ")}]`);
          sendLog(`\u26A0\uFE0F Duration ${flowVideoDuration} kh\xF4ng c\xF3 trong panel (Flow h\u1ED7 tr\u1EE3: ${avail.filter(Boolean).join(", ") || "N/A"})`, "warn");
        }
      }
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      simulateClick(document.body);
    }
    async function addFileToPrompt(fileId, fileName, flowFileId) {
      if (document.visibilityState === "hidden") {
        await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: "ensureFlowTabActive" }, () => resolve());
        });
        await sleep(300);
      }
      if (flowFileId) {
        const tile = findTileByFileId(flowFileId);
        if (tile) {
          fileId = tile.dataset.tileId;
        }
      }
      let els = document.querySelectorAll(`div[data-tile-id="${fileId}"]`);
      if (els.length > 0 && fileName) {
        const tile = els[els.length - 1];
        const currentFn = extractFileName(tile);
        if (currentFn && currentFn !== fileName) {
          console.log(`[TobyFlow] addFileToPrompt: tile_id ${fileId.substring(0, 20)}... exists but file_name mismatch (${currentFn.substring(0, 15)}... vs ${fileName.substring(0, 15)}...) \u2192 cross-project collision, finding by file_name`);
          els = [];
        }
      }
      if (els.length === 0 && fileName) {
        const allTiles = document.querySelectorAll(_getTileSelectorString());
        for (const tile of allTiles) {
          const fn = extractFileName(tile);
          if (fn === fileName) {
            const newId = tile.dataset.tileId;
            console.log(`[TobyFlow] addFileToPrompt: resolved ${fileId.substring(0, 20)}... \u2192 ${newId.substring(0, 20)}... via file_name`);
            fileId = newId;
            els = document.querySelectorAll(`div[data-tile-id="${fileId}"]`);
            break;
          }
        }
      }
      if (els.length === 0 && typeof ensureFlowTilesLoaded === "function") {
        console.log(`[TobyFlow] addFileToPrompt: tile ch\u01B0a th\u1EA5y (id=${fileId.substring(0, 20)}...) \u2192 ensureFlowTilesLoaded + retry`);
        try {
          await ensureFlowTilesLoaded(false, fileName ? [fileName] : []);
        } catch (_) {
        }
        els = document.querySelectorAll(`div[data-tile-id="${fileId}"]`);
        if (els.length === 0 && fileName) {
          const allTilesRetry = document.querySelectorAll(_getTileSelectorString());
          for (const tile of allTilesRetry) {
            if (extractFileName(tile) === fileName) {
              const newId = tile.dataset.tileId;
              console.log(`[TobyFlow] addFileToPrompt: post-load resolved ${fileId.substring(0, 20)}... \u2192 ${newId.substring(0, 20)}... via file_name`);
              fileId = newId;
              els = document.querySelectorAll(`div[data-tile-id="${fileId}"]`);
              break;
            }
          }
        }
      }
      if (els.length === 0) {
        sendLog(`\u26A0\uFE0F Kh\xF4ng t\xECm th\u1EA5y file c\xF3 ID: ${fileId} tr\xEAn m\xE0n h\xECnh.`, "warn");
        return false;
      }
      const el = els[els.length - 1];
      await _acquireCtxMenuLock();
      try {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(getInputTimeoutMs());
        const targetEl = el.querySelector("img") || el.querySelector("a") || el;
        simulateContextMenu(targetEl);
        await sleep(getInputTimeoutMs());
        const _cmSel = _selStr("context_menu");
        const ctxMenu = _cmSel ? document.querySelector(_cmSel) : null;
        if (!_cmSel) console.debug("[Tier3] context_menu config miss");
        if (!ctxMenu) {
          _closeContextMenu();
          sendLog(`\u26A0\uFE0F L\u1ED7i: Context menu kh\xF4ng m\u1EDF \u0111\u01B0\u1EE3c cho file ${fileId}`, "warn");
          return false;
        }
        const menuItems = _qa("menu_item", ctxMenu);
        let clicked = false;
        const addToPromptLabels = _getFlowLocaleStrings("add_to_prompt_menu_item", "text_match");
        for (const item of menuItems) {
          const text = item.textContent?.trim() || "";
          if (_textIncludesAny(text, addToPromptLabels)) {
            simulateClick(item);
            clicked = true;
            break;
          }
        }
        if (!clicked) {
          for (const item of menuItems) {
            const icon = _findIconInElement(item);
            if (icon && icon.textContent?.trim() === "add") {
              simulateClick(item);
              clicked = true;
              break;
            }
          }
        }
        if (clicked) {
          await sleep(100);
          _closeContextMenu();
        }
        if (!clicked) {
          _closeContextMenu();
          sendLog(`\u26A0\uFE0F L\u1ED7i: Kh\xF4ng t\xECm th\u1EA5y menu "Add to prompt" \u1EDF file ${fileId}`, "warn");
        }
        await sleep(getInputTimeoutMs());
        return clicked;
      } finally {
        _releaseCtxMenuLock();
      }
    }
    _cachedInputTimeoutMs = 1200;
    _cachedDelayBetweenMs = 5e3;
    async function runAutoPrompt(payload) {
      let { prompts, delayBetweenMs, inputTimeoutMs, fileIds, fileNameMap, genType, aspectRatio, modelName, frameFileIds, refPerPrompt, noTileWait, quantity, autoDownload, downloadResolution, videoDownloadResolution, flowVideoDuration, refImageMode, mentionData, taskName } = payload;
      fileNameMap = fileNameMap || {};
      quantity = quantity || 1;
      refPerPrompt = refPerPrompt || false;
      noTileWait = noTileWait || false;
      autoDownload = autoDownload ?? false;
      downloadResolution = downloadResolution || "1k";
      videoDownloadResolution = videoDownloadResolution || "720p";
      refImageMode = refImageMode || "all";
      mentionData = mentionData || null;
      _cachedInputTimeoutMs = inputTimeoutMs || 1200;
      _cachedDelayBetweenMs = delayBetweenMs || 5e3;
      if (isRunning) {
        console.warn("[runAutoPrompt] Blocked: isRunning=true, ExecutionBlocker.isVisible=" + ExecutionBlocker.isVisible());
        return { blocked: true, reason: "already_running" };
      }
      _ensureSelectorsForExecution("runAutoPrompt");
      try {
        injectSlateBridge();
      } catch (_) {
      }
      isRunning = true;
      shouldStop = false;
      isPaused = false;
      failedPrompts = [];
      _clickedRetryTileIds.clear();
      _retryingTiles.clear();
      const DELAY_BEFORE_SUBMIT = getSubmitDelay();
      const _startedAt = Date.now();
      FloatingTracker.updateLegacy({
        owner: payload._owner || "prompts",
        label: payload._label || "Auto Gen",
        status: "running",
        current: 0,
        total: prompts.length,
        failed: 0,
        startedAt: _startedAt
      });
      ExecutionBlocker.show({
        title: "\u0110ang chu\u1EA9n b\u1ECB...",
        subtitle: "Extension \u0111ang thao t\xE1c, vui l\xF2ng ch\u1EDD",
        current: 0,
        total: prompts.length,
        promptText: "Chu\u1EA9n b\u1ECB upload \u1EA3nh tham chi\u1EBFu...",
        owner: payload._owner || "prompts",
        indeterminate: true
      });
      if (fileIds && fileIds.some((id) => id.startsWith("upload_"))) {
        const idsStr = fileIds.join(", ");
        if (typeof window.uploadPendingFiles === "function") {
          const uploaded = await window.uploadPendingFiles(idsStr);
          fileIds = uploaded.split(",").map((s) => s.trim()).filter(Boolean);
          const fileIdsInput = document.getElementById("fileIdsInput");
          if (fileIdsInput) {
            fileIdsInput.value = fileIds.join(", ");
            if (typeof window.renderFileIdThumbnails === "function") window.renderFileIdThumbnails();
          }
        }
      }
      if (frameFileIds) {
        if (Array.isArray(frameFileIds)) {
          for (let fi = 0; fi < frameFileIds.length; fi++) {
            const fp = frameFileIds[fi];
            if (!fp) continue;
            if (fp.frame1?.startsWith("upload_") && typeof window.uploadPendingFiles === "function") {
              fp.frame1 = (await window.uploadPendingFiles(fp.frame1)).trim();
            }
            if (fp.frame2?.startsWith("upload_") && typeof window.uploadPendingFiles === "function") {
              fp.frame2 = (await window.uploadPendingFiles(fp.frame2)).trim();
            }
          }
        } else {
          if (frameFileIds.frame1?.startsWith("upload_") && typeof window.uploadPendingFiles === "function") {
            frameFileIds.frame1 = (await window.uploadPendingFiles(frameFileIds.frame1)).trim();
          }
          if (frameFileIds.frame2?.startsWith("upload_") && typeof window.uploadPendingFiles === "function") {
            frameFileIds.frame2 = (await window.uploadPendingFiles(frameFileIds.frame2)).trim();
          }
        }
      }
      if (fileIds && fileIds.length > 0 && typeof window.reuploadMissingFiles === "function") {
        const idsStr = fileIds.join(", ");
        const thumbCache = window.GenTab?.thumbnailCache || {};
        const fnCache = window.GenTab?.fileNameCache || {};
        const updated = await window.reuploadMissingFiles(idsStr, thumbCache, null, fnCache);
        if (updated !== idsStr) {
          fileIds = updated.split(",").map((s) => s.trim()).filter(Boolean);
          const fileIdsInput = document.getElementById("fileIdsInput");
          if (fileIdsInput) {
            fileIdsInput.value = fileIds.join(", ");
            if (typeof window.renderFileIdThumbnails === "function") window.renderFileIdThumbnails();
          }
        }
      }
      const wfCfg = window._afExecConfig?.workflow || {};
      const farCfg = window._afExecConfig?.flow_recovery || {};
      let retrySettings = {
        maxRetries: parseInt(wfCfg.max_retries ?? 2, 10),
        tileTimeout: parseInt(wfCfg.timeout_sec ?? 180, 10) * 1e3,
        // Phase FAR-5: Exponential backoff — server-controlled
        flowBackoffBaseSec: parseInt(farCfg.backoff_base_sec ?? 30, 10),
        flowBackoffMaxSec: parseInt(farCfg.backoff_max_sec ?? 300, 10),
        flowBackoffJitterPercent: parseInt(farCfg.backoff_jitter_percent ?? 20, 10),
        // Phase FAR-2: Consecutive fail recovery — server-controlled
        flowAutoRecoveryEnabled: farCfg.auto_recovery_enabled !== false,
        flowConsecutiveFailThreshold: parseInt(farCfg.consecutive_fail_threshold ?? 2, 10)
      };
      try {
        const stored = await new Promise((r) => chrome.storage.local.get(["af_entitlements"], r));
        const entitlements = stored.af_entitlements?.entitlements || {};
        const retryFeature = entitlements.retry_on_fail;
        const canUseRetry = retryFeature?.value === "1" || retryFeature?.value === 1;
        if (!canUseRetry) {
          retrySettings.maxRetries = 0;
        }
      } catch (e) {
      }
      const humanized = isHumanizedEnabled();
      if (humanized) {
        sendLog("Humanized mode: b\u1EADt - g\xF5 k\xFD t\u1EF1 v\xE0 delay ng\u1EABu nhi\xEAn", "info");
      }
      sendLog(`\u{1F680} B\u1EAFt \u0111\u1EA7u ch\u1EA1y ${prompts.length} prompt(s)...`);
      if (refPerPrompt) {
        sendLog(`Ch\u1EBF \u0111\u1ED9 m\u1ED7i prompt 1 \u1EA3nh: ${fileIds.length} \u1EA3nh cho ${prompts.length} prompt`, "info");
      }
      try {
        let actioned = false;
        const r1 = await _ensureFlowAgentInstructionDone();
        if (r1.wasOpen && r1.success) {
          sendLog("\u2713 \u0110\xE3 \u0111\xF3ng dialog h\u01B0\u1EDBng d\u1EABn agent", "info");
          actioned = true;
        }
        const r2 = await _ensureFlowChatAgentClosed();
        if (r2.wasOpen && r2.success) {
          sendLog("\u2713 \u0110\xE3 \u0111\xF3ng panel chat agent", "info");
          actioned = true;
          await sleep(1500);
        }
        const r3 = await _ensureFlowAgentModeOff();
        if (r3.wasOn && r3.success) {
          sendLog("\u2713 \u0110\xE3 t\u1EAFt Agent mode", "info");
          actioned = true;
        }
        if (actioned) {
          const editorReadyMs = await _waitForFlowEditorReady(5e3);
          sendLog(editorReadyMs ? `\u2713 Editor Flow ready (${editorReadyMs}ms)` : "\u26A0 Editor ch\u01B0a ready sau 5s", editorReadyMs ? "info" : "warn");
          window._tobyAgentChainLastRunAt = Date.now();
        }
      } catch (e) {
        console.warn("[runAutoPrompt] prepareFlowForGen guard failed (non-blocking):", e.message);
      }
      if (payload.voice && payload.voice.search_value) {
        try {
          const r = await selectFlowVoice(payload.voice);
          if (r?.success && r.selected) {
            sendLog(`\u0110\xE3 ch\u1ECDn voice: ${r.selected}`, "info");
          } else if (r?.error === "voice_not_found") {
            sendLog(`Voice "${payload.voice.search_value}" kh\xF4ng c\xF3 trong menu Flow \u2014 submit kh\xF4ng voice`, "warning");
          }
        } catch (e) {
          sendLog(`L\u1ED7i ch\u1ECDn voice (non-blocking): ${e.message}`, "warning");
        }
      }
      let completedCount = 0;
      let failedCount = 0;
      const allResultTileIds = [];
      let lastPreTileIds = [];
      let lastPreFileNames = null;
      const initialPreTileIds = noTileWait ? getUniqueTileIds(true) : [];
      const initialPreFileNames = noTileWait ? getExistingFileNames() : null;
      let _consecutiveFailures = 0;
      let _lastSilentRefreshAt = 0;
      const SILENT_REFRESH_COOLDOWN_MS = 6e4;
      for (let i = 0; i < prompts.length; i++) {
        if (shouldStop) {
          sendLog("\u26A0\uFE0F \u0110\xE3 nh\u1EADn l\u1EC7nh d\u1EEBng qu\xE1 tr\xECnh.", "warn");
          break;
        }
        if (isPaused) {
          sendLog("\u23F8 \u0110\xE3 t\u1EA1m d\u1EEBng. Nh\u1EA5n Resume \u0111\u1EC3 ti\u1EBFp t\u1EE5c.", "warn");
          while (isPaused && !shouldStop) {
            await sleep(500);
          }
          if (shouldStop) {
            sendLog("\u26A0\uFE0F \u0110\xE3 nh\u1EADn l\u1EC7nh d\u1EEBng qu\xE1 tr\xECnh.", "warn");
            break;
          }
          sendLog("\u25B6 Ti\u1EBFp t\u1EE5c ch\u1EA1y...", "info");
        }
        const prompt = prompts[i];
        const currentPrompt = prompt;
        sendLog(`[${i + 1}/${prompts.length}] "${prompt.substring(0, 50)}..."`, "info");
        ExecutionBlocker.update({
          title: "\u0110ang t\u1EA1o \u1EA3nh...",
          subtitle: `X\u1EED l\xFD prompt ${i + 1}/${prompts.length}`,
          current: i,
          total: prompts.length,
          promptText: currentPrompt.length > 100 ? currentPrompt.substring(0, 100) + "..." : currentPrompt,
          indeterminate: false
        });
        let promptSuccess = false;
        _clickedRetryTileIds.clear();
        const totalAttempts = 1 + retrySettings.maxRetries;
        for (let attempt = 1; attempt <= totalAttempts; attempt++) {
          if (shouldStop) break;
          if (attempt > 1) {
            const retryIdx = attempt - 2;
            const backoffMs = getExponentialBackoffMs(retryIdx, retrySettings);
            sendLog(`[Backoff] \u0110\u1EE3i ${Math.round(backoffMs / 1e3)}s tr\u01B0\u1EDBc th\u1EED l\u1EA1i l\u1EA7n ${attempt - 1}/${retrySettings.maxRetries}`, "info");
            await sleep(backoffMs);
            if (shouldStop) break;
            sendLog(`Th\u1EED l\u1EA1i l\u1EA7n ${attempt - 1}/${retrySettings.maxRetries}...`, "warn");
            ExecutionBlocker.update({
              title: "\u0110ang th\u1EED l\u1EA1i...",
              subtitle: `L\u1EA7n ${attempt - 1}/${retrySettings.maxRetries} - Prompt ${i + 1}/${prompts.length}`,
              current: i,
              total: prompts.length,
              promptText: currentPrompt.length > 100 ? currentPrompt.substring(0, 100) + "..." : currentPrompt,
              indeterminate: false
            });
          }
          let editor = getEditor();
          if (!editor) {
            sendLog("\u274C Kh\xF4ng t\xECm th\u1EA5y \xF4 nh\u1EADp li\u1EC7u (Slate editor)!", "error");
            break;
          }
          if (shouldStop) break;
          await removeExistingRefImages();
          if (shouldStop) break;
          await clearEditor(editor);
          if (shouldStop) break;
          await sleep(humanized ? getHumanizedDelay(getClearEditorDelay()) : getClearEditorDelay());
          if (shouldStop) break;
          let currentFileIds = fileIds;
          if (refImageMode === "mention" && mentionData && mentionData[i]) {
            const promptMentionData = mentionData[i];
            if (promptMentionData.refImages && promptMentionData.refImages.length > 0) {
              currentFileIds = promptMentionData.refImages.filter((ref) => ref.file_id).map((ref) => ref.file_id);
            } else {
              currentFileIds = [];
            }
          } else if (refImageMode === "none") {
            currentFileIds = [];
          } else if (refImageMode === "sequential" || refPerPrompt) {
            currentFileIds = fileIds[i] ? [fileIds[i]] : [];
          }
          if (shouldStop) break;
          if (frameFileIds) {
            const currentFrames = Array.isArray(frameFileIds) ? frameFileIds[i] || null : frameFileIds;
            if (currentFrames) {
              if (currentFrames.frame1 && !shouldStop) {
                sendLog(Array.isArray(frameFileIds) ? `\u0110ang g\xE0i Frame Start (Prompt ${i + 1})...` : "\u0110ang g\xE0i Frame 1...", "info");
                await addFileToPrompt(currentFrames.frame1, fileNameMap[currentFrames.frame1]);
              }
              if (currentFrames.frame2 && !shouldStop) {
                sendLog(Array.isArray(frameFileIds) ? `\u0110ang g\xE0i Frame End (Prompt ${i + 1})...` : "\u0110ang g\xE0i Frame 2...", "info");
                await addFileToPrompt(currentFrames.frame2, fileNameMap[currentFrames.frame2]);
              }
            }
          } else if (currentFileIds && currentFileIds.length > 0 && !shouldStop) {
            const logMsg = refImageMode === "sequential" || refPerPrompt ? `\u0110ang g\xE0i \u1EA3nh tham chi\u1EBFu #${i + 1}...` : `\u0110ang g\xE0i ${currentFileIds.length} \u1EA3nh tham chi\u1EBFu...`;
            sendLog(logMsg, "info");
            for (const fid of currentFileIds) {
              if (shouldStop) break;
              await addFileToPrompt(fid, fileNameMap[fid]);
            }
          }
          if (shouldStop) break;
          try {
            if (genType && aspectRatio && modelName) {
              const isFramesMode = !!frameFileIds;
              await applySettings(genType, aspectRatio, modelName, isFramesMode, quantity, flowVideoDuration);
            }
          } catch (e) {
            sendLog(`L\u1ED7i thi\u1EBFt l\u1EADp c\u1EA5u h\xECnh AI (iter ${i + 1}): ${e.message}`, "error");
          }
          if (shouldStop) break;
          editor = getEditor();
          if (!editor) {
            sendLog("\u274C Kh\xF4ng t\xECm th\u1EA5y \xF4 nh\u1EADp li\u1EC7u sau khi g\xE0i \u1EA3nh!", "error");
            break;
          }
          await insertText(editor, prompt);
          if (shouldStop) break;
          const delayBeforeSubmit = humanized ? getHumanizedDelay(DELAY_BEFORE_SUBMIT) : DELAY_BEFORE_SUBMIT;
          await sleep(delayBeforeSubmit);
          if (shouldStop) break;
          editor = getEditor() || editor;
          const hasPlaceholder = () => {
            const ed = getEditor();
            return ed && ed.querySelector("[data-slate-placeholder]") !== null;
          };
          if (hasPlaceholder()) {
            sendLog("\u26A0\uFE0F Slate placeholder v\u1EABn c\xF2n \u2192 model r\u1ED7ng, ch\u1EDD...", "warn");
            let waitSlate = 0;
            while (hasPlaceholder() && waitSlate < 2e3) {
              await sleep(200);
              waitSlate += 200;
            }
            if (hasPlaceholder()) {
              sendLog("\u26A0\uFE0F Retry insert text...", "warn");
              await _insertTextSingle(prompt);
              await sleep(500);
            }
          }
          if (_checkFlowCreditLimit()) {
            const msg = typeof window.I18n?.t === "function" ? window.I18n.t("flow.creditLimitHit") : null;
            const finalMsg = msg || "T\xE0i kho\u1EA3n Google Flow \u0111\xE3 h\u1EBFt credit \u2014 KH\xD4NG th\u1EC3 submit. \u0110\u1EE3i reset ho\u1EB7c upgrade Flow plan.";
            sendLog("\u274C " + finalMsg, "error");
            if (typeof window.showNotification === "function") {
              window.showNotification(finalMsg, "error", 1e4);
            }
            try {
              chrome.runtime.sendMessage({
                action: "reportFlowError",
                errorCode: "FLOW_CREDIT_LIMIT",
                message: finalMsg
              }).catch(() => {
              });
            } catch (_) {
            }
            break;
          }
          let submitBtn = getSubmitButton();
          if (!submitBtn) {
            sendLog("\u274C Kh\xF4ng t\xECm th\u1EA5y n\xFAt Submit (arrow_forward)!", "error");
            break;
          }
          let waitSubmit = 0;
          while (submitBtn.disabled && waitSubmit < 15e3) {
            await sleep(300);
            waitSubmit += 300;
            submitBtn = getSubmitButton() || submitBtn;
          }
          if (submitBtn.disabled) {
            sendLog("\u26A0\uFE0F N\xFAt Submit v\u1EABn disabled sau 15s, th\u1EED click...", "warn");
          }
          const allPreTileIds = getUniqueTileIds(true);
          const allPreFileNames = getExistingFileNames();
          lastPreTileIds = allPreTileIds;
          lastPreFileNames = allPreFileNames;
          const afterSubmitDelay = getAfterSubmitDelay();
          sendLog(`\u0110ang click Submit...`, "info");
          const iconSelectorForBridge = (_getDynamicSelector("icon_element")?.selectors || []).join(", ");
          const submitResult = await _slateBridgeCall("submit", { iconSelector: iconSelectorForBridge });
          if (!submitResult.success) {
            sendLog("\u26A0\uFE0F Bridge submit failed: " + submitResult.error + ", fallback simulateClick", "warn");
            simulateClick(submitBtn);
          }
          _incrementDailyStat("flow_prompt_total");
          await sleep(afterSubmitDelay);
          if (!submitResult.success) {
            const editorAfterSubmit = getEditor();
            const editorTextAfter = editorAfterSubmit?.textContent?.trim() || "";
            if (editorTextAfter.length > 10) {
              sendLog("\u26A0\uFE0F Editor ch\u01B0a b\u1ECB x\xF3a sau click, th\u1EED submit l\u1EA1i...", "warn");
              submitBtn = getSubmitButton() || submitBtn;
              submitBtn.click();
              await sleep(afterSubmitDelay);
            }
          }
          sendLog(`\u2705 \u0110\xE3 submit prompt #${i + 1}`, "success");
          FloatingTracker.updateLegacy({
            owner: payload._owner || "prompts",
            label: payload._label || "Auto Gen",
            status: isPaused ? "paused" : "running",
            current: i + 1,
            total: prompts.length,
            failed: failedCount,
            startedAt: _startedAt
          });
          ExecutionBlocker.update({
            title: isPaused ? "\u0110\xE3 t\u1EA1m d\u1EEBng" : "\u0110ang t\u1EA1o \u1EA3nh...",
            subtitle: isPaused ? "Nh\u1EA5n Ti\u1EBFp t\u1EE5c \u0111\u1EC3 ch\u1EA1y ti\u1EBFp" : "Ch\u1EDD k\u1EBFt qu\u1EA3 t\u1EEB Flow...",
            current: i + 1,
            total: prompts.length,
            promptText: currentPrompt.length > 100 ? currentPrompt.substring(0, 100) + "..." : currentPrompt,
            indeterminate: false
          });
          try {
            chrome.runtime.sendMessage({
              action: "promptProgress",
              current: i + 1,
              total: prompts.length
            });
          } catch (e) {
          }
          if (noTileWait) {
            sendLog("Song song: b\u1ECF qua ch\u1EDD tiles, ti\u1EBFp t\u1EE5c...", "info");
            completedCount++;
            promptSuccess = true;
          } else if (!shouldStop) {
            sendLog("Ch\u1EDD k\u1EBFt qu\u1EA3...", "info");
            ExecutionBlocker.update({
              title: "\u0110ang ch\u1EDD k\u1EBFt qu\u1EA3...",
              subtitle: `Flow \u0111ang x\u1EED l\xFD prompt ${i + 1}/${prompts.length}`,
              current: i,
              total: prompts.length,
              promptText: currentPrompt.length > 100 ? currentPrompt.substring(0, 100) + "..." : currentPrompt,
              indeterminate: true
            });
            const result = await waitForNewTiles(allPreTileIds, retrySettings.tileTimeout, allPreFileNames);
            if (result.failed) {
              sendLog("\u274C Google Flow b\xE1o l\u1ED7i - t\u1EA1o \u1EA3nh th\u1EA5t b\u1EA1i", "error");
              const failedTids = result.tiles.filter((tid) => {
                const tile = _getTileById(tid);
                return detectTileStatus(tile) === "failed";
              });
              const successTids = result.tiles.filter((tid) => !failedTids.includes(tid));
              const allTilesFailed = successTids.length === 0;
              if (successTids.length > 0) {
                allResultTileIds.push(...successTids);
                if (autoDownload) {
                  for (const tid of successTids) {
                    await downloadTileMedia(tid, prompt, taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                    await sleep(200);
                  }
                }
              }
              if (failedTids.length > 0 && retrySettings.maxRetries > 0) {
                let remainingFailed = failedTids;
                let promptSuccessCount = successTids.length;
                for (let btnRetry = 1; btnRetry <= retrySettings.maxRetries && remainingFailed.length > 0 && !shouldStop; btnRetry++) {
                  sendLog(`[Retry L1] Click "Th\u1EED l\u1EA1i" l\u1EA7n ${btnRetry}/${retrySettings.maxRetries} cho ${remainingFailed.length} tile fail...`, "warn");
                  sendRetryStatus(`Click Retry (${btnRetry}/${retrySettings.maxRetries})`);
                  const retryResult = await retryFailedTilesViaButton(remainingFailed, retrySettings.tileTimeout);
                  if (retryResult.succeeded.length > 0) {
                    allResultTileIds.push(...retryResult.succeeded);
                    promptSuccessCount += retryResult.succeeded.length;
                    sendLog(`[Retry L1] Th\xE0nh c\xF4ng: ${retryResult.succeeded.length} \u1EA3nh`, "success");
                    if (autoDownload) {
                      for (const tid of retryResult.succeeded) {
                        await downloadTileMedia(tid, prompt, taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                        await sleep(200);
                      }
                    }
                  }
                  remainingFailed = retryResult.stillFailed;
                }
                if (remainingFailed.length === 0 && promptSuccessCount > 0) {
                  completedCount++;
                  promptSuccess = true;
                }
                if (promptSuccessCount === 0 && !shouldStop) {
                  sendLog(`[Retry L2] T\u1EA5t c\u1EA3 ${failedTids.length} tile fail - \u0110ang g\u1EEDi l\u1EA1i prompt...`, "warn");
                  sendRetryStatus("G\u1EEDi l\u1EA1i Prompt");
                  await sleep(getDelayBetweenPromptsMs());
                  let fbEditor = getEditor();
                  if (fbEditor) {
                    await removeExistingRefImages();
                    await clearEditor(fbEditor);
                    await sleep(getClearEditorDelay());
                    if (currentFileIds && currentFileIds.length > 0) {
                      for (const fid of currentFileIds) await addFileToPrompt(fid, fileNameMap[fid]);
                    }
                    if (frameFileIds) {
                      const retryFrames = Array.isArray(frameFileIds) ? frameFileIds[i] || null : frameFileIds;
                      if (retryFrames) {
                        if (retryFrames.frame1) await addFileToPrompt(retryFrames.frame1, fileNameMap[retryFrames.frame1]);
                        if (retryFrames.frame2) await addFileToPrompt(retryFrames.frame2, fileNameMap[retryFrames.frame2]);
                      }
                    }
                    fbEditor = getEditor();
                    if (fbEditor) {
                      await insertText(fbEditor, prompt);
                      await sleep(getSubmitDelay());
                      const fbPreTileIds = getUniqueTileIds(true);
                      const fbPreFileNames = getExistingFileNames();
                      const fbSubmitResult = await _slateBridgeCall("submit", {});
                      if (!fbSubmitResult.success) {
                        let fbBtn = getSubmitButton();
                        if (fbBtn) {
                          let fbWait = 0;
                          while (fbBtn.disabled && fbWait < 1e4) {
                            await sleep(300);
                            fbWait += 300;
                            fbBtn = getSubmitButton() || fbBtn;
                          }
                          simulateClick(fbBtn);
                        }
                      }
                      await sleep(getAfterSubmitDelay());
                      const fbResult = await waitForNewTiles(fbPreTileIds, retrySettings.tileTimeout, fbPreFileNames);
                      if (fbResult.tiles.length > 0 && !fbResult.failed) {
                        allResultTileIds.push(...fbResult.tiles);
                        sendLog(`[Retry L2] G\u1EEDi l\u1EA1i th\xE0nh c\xF4ng: ${fbResult.tiles.length} \u1EA3nh`, "success");
                        if (autoDownload) {
                          for (const tid of fbResult.tiles) {
                            await downloadTileMedia(tid, prompt, taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                            await sleep(200);
                          }
                        }
                        completedCount++;
                        promptSuccess = true;
                      } else {
                        sendLog(`[Retry L2] G\u1EEDi l\u1EA1i c\u0169ng th\u1EA5t b\u1EA1i`, "error");
                      }
                    }
                  }
                }
                if (!promptSuccess && remainingFailed.length > 0 && !allStillFailed) {
                  sendLog(`[Retry L1] ${remainingFailed.length}/${failedTids.length} tile v\u1EABn fail sau click "Th\u1EED l\u1EA1i"`, "warn");
                }
              }
              const hasAnySuccess = successTids.length > 0 || allResultTileIds.length > 0;
              if (!promptSuccess && hasAnySuccess) {
                completedCount++;
                promptSuccess = true;
              }
              if (!promptSuccess) {
                failedCount++;
                _incrementDailyStat("flow_fail");
                failedPrompts.push({ index: i, prompt, error: "Google Flow error", timestamp: Date.now() });
              }
            } else if (result.tiles.length > 0) {
              sendLog(`\u2705 C\xF3 ${result.tiles.length} k\u1EBFt qu\u1EA3 m\u1EDBi`, "success");
              allResultTileIds.push(...result.tiles);
              if (autoDownload) {
                sendLog(`\u0110ang t\u1EA3i ${result.tiles.length} file [${downloadResolution.toUpperCase()}]...`, "info");
                for (const tid of result.tiles) {
                  await downloadTileMedia(tid, prompt, taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                  await sleep(200);
                }
              }
              completedCount++;
              promptSuccess = true;
            } else {
              sendLog("\u26A0\uFE0F Timeout - kh\xF4ng c\xF3 k\u1EBFt qu\u1EA3 m\u1EDBi", "warn");
              if (attempt < totalAttempts) {
                const retryDelay = getDelayBetweenPromptsMs();
                const waitSec = Math.round(retryDelay / 1e3);
                sendLog(`Ch\u1EDD ${waitSec}s tr\u01B0\u1EDBc khi th\u1EED l\u1EA1i...`, "warn");
                await sleep(retryDelay);
                continue;
              }
              failedCount++;
              _incrementDailyStat("flow_fail");
              failedPrompts.push({ index: i, prompt, error: "Timeout - no results", timestamp: Date.now() });
            }
          }
          break;
        }
        if (promptSuccess) {
          _consecutiveFailures = 0;
        } else {
          _consecutiveFailures++;
          const threshold = retrySettings.flowConsecutiveFailThreshold || 2;
          const recoveryEnabled = retrySettings.flowAutoRecoveryEnabled !== false;
          const now = Date.now();
          const cooldownPassed = now - _lastSilentRefreshAt > SILENT_REFRESH_COOLDOWN_MS;
          if (recoveryEnabled && _consecutiveFailures >= threshold && i < prompts.length - 1 && cooldownPassed && !shouldStop) {
            sendLog(`[Recovery] ${_consecutiveFailures} prompt fail li\xEAn ti\u1EBFp \u2014 th\u1EED silent refresh Flow session...`, "warn");
            sendRetryStatus("Refreshing Flow session");
            _lastSilentRefreshAt = now;
            const refreshed = await refreshFlowSession("recovery");
            if (refreshed) {
              _consecutiveFailures = 0;
              sendLog("[Recovery] Session refreshed th\xE0nh c\xF4ng, ti\u1EBFp t\u1EE5c queue", "success");
              await sleep(3e3);
            } else {
              sendLog("[Recovery] Silent refresh fail \u2014 ti\u1EBFp t\u1EE5c normal retry. B\u1EADt Pipeline Queue \u0111\u1EC3 d\xF9ng full reload-recovery flow.", "warn");
            }
          }
        }
        if (i < prompts.length - 1 && !shouldStop) {
          const actualDelay = humanized ? getHumanizedDelay(getRandomDelay()) : _cachedDelayBetweenMs;
          sendLog(`Ch\u1EDD ${(actualDelay / 1e3).toFixed(1)}s cho l\u01B0\u1EE3t t\u1EA1o ti\u1EBFp theo...`);
          await sleep(actualDelay);
        }
      }
      if (noTileWait && !shouldStop && completedCount > 0) {
        sendLog("Ch\u1EDD t\u1EA5t c\u1EA3 k\u1EBFt qu\u1EA3 ho\xE0n th\xE0nh...", "info");
        try {
          const allTilesResult = await waitForNewTiles(initialPreTileIds, retrySettings.tileTimeout, initialPreFileNames);
          if (allTilesResult.tiles.length > 0) {
            const refIdSet = new Set(fileIds || []);
            const pureNewTiles = allTilesResult.tiles.filter((id) => !refIdSet.has(id));
            await sleep(800);
            const successTiles = [];
            const failedTileIds = [];
            const skippedTiles = [];
            for (const tid of pureNewTiles) {
              const tile = _getTileById(tid);
              const status = detectTileStatus(tile);
              if (status === "failed") {
                failedTileIds.push(tid);
              } else if (status === "success" && tile) {
                successTiles.push(tid);
              } else {
                skippedTiles.push(tid);
              }
            }
            if (skippedTiles.length > 0) {
              sendLog(`\u26A0\uFE0F ${skippedTiles.length} tile ch\u01B0a ready (processing/missing) \u2014 b\u1ECF qua download`, "warn");
            }
            allResultTileIds.push(...successTiles);
            if (successTiles.length > 0 && autoDownload) {
              sendLog(`\u0110ang t\u1EA3i ${successTiles.length} file [${downloadResolution.toUpperCase()}]...`, "info");
              const successSet = new Set(successTiles);
              for (let ti = 0; ti < pureNewTiles.length; ti++) {
                const tid = pureNewTiles[ti];
                if (!successSet.has(tid)) continue;
                const promptIdx = Math.floor(ti / quantity);
                const promptForTile = prompts[promptIdx] || prompts[0] || "parallel-batch";
                await downloadTileMedia(tid, promptForTile, taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                await sleep(200);
              }
              sendLog(`\u0110\xE3 t\u1EA3i ${successTiles.length} file`, "success");
            }
            _clickedRetryTileIds.clear();
            if (failedTileIds.length > 0 && retrySettings.maxRetries > 0) {
              const failedPromptIndices = [];
              for (let ti = 0; ti < pureNewTiles.length; ti++) {
                if (failedTileIds.includes(pureNewTiles[ti])) {
                  const promptIdx = Math.floor(ti / quantity);
                  if (promptIdx < prompts.length && !failedPromptIndices.includes(promptIdx)) {
                    failedPromptIndices.push(promptIdx);
                  }
                }
              }
              sendLog(`${failedTileIds.length} \u1EA3nh th\u1EA5t b\u1EA1i (${failedPromptIndices.length} prompt), click "Th\u1EED l\u1EA1i"...`, "warn");
              let remainingFailed = [...failedTileIds];
              for (let btnRetry = 1; btnRetry <= retrySettings.maxRetries && remainingFailed.length > 0 && !shouldStop; btnRetry++) {
                sendLog(`Click "Th\u1EED l\u1EA1i" l\u1EA7n ${btnRetry} cho ${remainingFailed.length} tile...`, "warn");
                sendRetryStatus(`Click Retry (${btnRetry}/${retrySettings.maxRetries})`);
                const btnResult = await retryFailedTilesViaButton(remainingFailed, retrySettings.tileTimeout);
                if (btnResult.succeeded.length > 0) {
                  allResultTileIds.push(...btnResult.succeeded);
                  sendLog(`Retry button th\xE0nh c\xF4ng: ${btnResult.succeeded.length} \u1EA3nh`, "success");
                  for (const tid of btnResult.succeeded) {
                    await downloadTileMedia(tid, prompts[0] || "parallel-batch", taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                    await sleep(200);
                  }
                }
                remainingFailed = btnResult.stillFailed;
              }
              if (remainingFailed.length > 0 && !shouldStop) {
                const allFailedPromptIndices = [];
                for (let ti = 0; ti < pureNewTiles.length; ti++) {
                  if (remainingFailed.includes(pureNewTiles[ti])) {
                    const promptIdx = Math.floor(ti / quantity);
                    if (promptIdx < prompts.length && !allFailedPromptIndices.includes(promptIdx)) {
                      allFailedPromptIndices.push(promptIdx);
                    }
                  }
                }
                const fullyFailedPromptIndices = allFailedPromptIndices.filter((promptIdx) => {
                  const startTile = promptIdx * quantity;
                  const endTile = Math.min(startTile + quantity, pureNewTiles.length);
                  for (let ti = startTile; ti < endTile; ti++) {
                    if (!remainingFailed.includes(pureNewTiles[ti])) return false;
                  }
                  return true;
                });
                if (fullyFailedPromptIndices.length > 0) {
                  sendLog(`[Retry L2] ${fullyFailedPromptIndices.length} prompt t\u1EA5t c\u1EA3 tiles fail - \u0110ang g\u1EEDi l\u1EA1i...`, "warn");
                  sendRetryStatus("G\u1EEDi l\u1EA1i Prompt");
                  for (let ri = 0; ri < fullyFailedPromptIndices.length && !shouldStop; ri++) {
                    const promptIdx = fullyFailedPromptIndices[ri];
                    const retryPrompt = prompts[promptIdx];
                    sendLog(`[Retry L2] G\u1EEDi l\u1EA1i prompt ${ri + 1}/${fullyFailedPromptIndices.length}: "${retryPrompt.substring(0, 40)}..."`, "warn");
                    let editor = getEditor();
                    if (!editor) break;
                    await clearEditor(editor);
                    await sleep(getClearEditorDelay());
                    let retryFileIds = [];
                    if (refImageMode === "mention" && mentionData && mentionData[promptIdx]) {
                      const promptMentionData = mentionData[promptIdx];
                      if (promptMentionData.refImages && promptMentionData.refImages.length > 0) {
                        retryFileIds = promptMentionData.refImages.filter((ref) => ref.file_id).map((ref) => ref.file_id);
                      }
                    } else if (refImageMode === "none") {
                      retryFileIds = [];
                    } else if (refImageMode === "sequential" || refPerPrompt) {
                      retryFileIds = fileIds[promptIdx] ? [fileIds[promptIdx]] : [];
                    } else {
                      retryFileIds = fileIds || [];
                    }
                    if (retryFileIds.length > 0) {
                      for (const fid of retryFileIds) await addFileToPrompt(fid, fileNameMap[fid]);
                    }
                    editor = getEditor();
                    if (!editor) break;
                    await insertText(editor, retryPrompt);
                    await sleep(getSubmitDelay());
                    const retryPreTileIds = getUniqueTileIds(true);
                    const retryPreFileNames = getExistingFileNames();
                    const iconSelectorForRetryBridge = (_getDynamicSelector("icon_element")?.selectors || []).join(", ");
                    const submitResult = await _slateBridgeCall("submit", { iconSelector: iconSelectorForRetryBridge });
                    if (!submitResult.success) {
                      let submitBtn = getSubmitButton();
                      if (!submitBtn) break;
                      let waitMs = 0;
                      while (submitBtn.disabled && waitMs < 1e4) {
                        await sleep(300);
                        waitMs += 300;
                        submitBtn = getSubmitButton() || submitBtn;
                      }
                      simulateClick(submitBtn);
                    }
                    await sleep(getAfterSubmitDelay());
                    const retryResult = await waitForNewTiles(retryPreTileIds, retrySettings.tileTimeout, retryPreFileNames);
                    if (retryResult.tiles.length > 0) {
                      const retryNewTiles = retryResult.tiles.filter((id) => !refIdSet.has(id));
                      const retrySuccessTiles = retryNewTiles.filter((tid) => {
                        const tile = _getTileById(tid);
                        return detectTileStatus(tile) !== "failed";
                      });
                      if (retrySuccessTiles.length > 0) {
                        allResultTileIds.push(...retrySuccessTiles);
                        if (autoDownload) {
                          for (const tid of retrySuccessTiles) {
                            await downloadTileMedia(tid, retryPrompt, taskName || null, null, downloadResolution, null, null, videoDownloadResolution);
                            await sleep(200);
                          }
                        }
                        sendLog(`[Retry L2] G\u1EEDi l\u1EA1i th\xE0nh c\xF4ng: ${retrySuccessTiles.length}/${retryNewTiles.length} \u1EA3nh`, "success");
                      }
                      if (retrySuccessTiles.length < retryNewTiles.length) {
                        const fbFailCount = retryNewTiles.length - retrySuccessTiles.length;
                        sendLog(`[Retry L2] ${fbFailCount} tile v\u1EABn fail sau g\u1EEDi l\u1EA1i`, "warn");
                        if (retrySuccessTiles.length === 0) {
                          failedCount++;
                          _incrementDailyStat("flow_fail");
                          failedPrompts.push({ index: promptIdx, prompt: retryPrompt, error: "Retry failed", timestamp: Date.now() });
                        }
                      }
                    } else {
                      sendLog(`[Retry L2] G\u1EEDi l\u1EA1i th\u1EA5t b\u1EA1i: "${retryPrompt.substring(0, 40)}..."`, "error");
                      failedCount++;
                      _incrementDailyStat("flow_fail");
                      failedPrompts.push({ index: promptIdx, prompt: retryPrompt, error: "Retry failed", timestamp: Date.now() });
                    }
                    if (ri < fullyFailedPromptIndices.length - 1) await sleep(getDelayBetweenPromptsMs());
                  }
                }
                const partialFailPromptIndices = allFailedPromptIndices.filter((idx) => !fullyFailedPromptIndices.includes(idx));
                if (partialFailPromptIndices.length > 0) {
                  const partialFailCount = remainingFailed.filter((tid) => {
                    const ti = pureNewTiles.indexOf(tid);
                    const promptIdx = Math.floor(ti / quantity);
                    return partialFailPromptIndices.includes(promptIdx);
                  }).length;
                  sendLog(`${partialFailCount} tile fail (partial) \u2014 \u0111\xE3 t\u1EA3i ${successTiles.length} tile th\xE0nh c\xF4ng`, "warn");
                }
              }
            } else if (failedTileIds.length > 0) {
              const failedPromptSet = /* @__PURE__ */ new Set();
              for (let ti = 0; ti < pureNewTiles.length; ti++) {
                if (failedTileIds.includes(pureNewTiles[ti])) {
                  const promptIdx = Math.floor(ti / quantity);
                  if (promptIdx < prompts.length && !failedPromptSet.has(promptIdx)) {
                    failedPromptSet.add(promptIdx);
                    failedCount++;
                    _incrementDailyStat("flow_fail");
                    failedPrompts.push({ index: promptIdx, prompt: prompts[promptIdx], error: "Google Flow error", timestamp: Date.now() });
                  }
                }
              }
              sendLog(`${failedTileIds.length} \u1EA3nh th\u1EA5t b\u1EA1i (${failedPromptSet.size} prompt) - Retry b\u1ECB kh\xF3a`, "warn");
            }
          } else {
            sendLog("\u26A0\uFE0F Kh\xF4ng c\xF3 k\u1EBFt qu\u1EA3 m\u1EDBi \u0111\u1EC3 t\u1EA3i", "warn");
          }
        } catch (e) {
          sendLog("L\u1ED7i khi ch\u1EDD/t\u1EA3i k\u1EBFt qu\u1EA3: " + e.message, "error");
        }
      }
      if (!shouldStop) {
        if (failedCount > 0) {
          sendLog(`\u26A0\uFE0F Ho\xE0n t\u1EA5t: ${completedCount} th\xE0nh c\xF4ng, ${failedCount} th\u1EA5t b\u1EA1i`, "warn");
        } else {
          sendLog("\u{1F389} Ho\xE0n t\u1EA5t t\u1EA5t c\u1EA3 prompts!", "success");
        }
        notifyCompletion("Toby Flow", `Ho\xE0n t\u1EA5t: ${completedCount}/${prompts.length} prompts`);
      }
      isRunning = false;
      isPaused = false;
      ExecutionBlocker.hide();
      try {
        FloatingTracker.updateLegacy({
          owner: payload._owner || "prompts",
          label: payload._label || "Auto Gen",
          status: shouldStop ? "stopped" : "completed",
          current: completedCount,
          total: prompts.length,
          failed: failedCount,
          startedAt: _startedAt
        });
      } catch (e) {
        console.warn("[runAutoPrompt] FloatingTracker.updateLegacy error:", e.message);
      }
      try {
        chrome.runtime.sendMessage({
          action: "promptExecutionComplete",
          completedCount,
          failedCount,
          totalCount: prompts.length,
          failedPrompts: failedPrompts.length > 0 ? failedPrompts : []
        }).catch(() => {
        });
      } catch (e) {
      }
      return {
        success: true,
        completedCount,
        failedCount,
        totalCount: prompts.length,
        uploadedFileIds: fileIds,
        resultTileIds: allResultTileIds,
        // Parallel mode: trả về baseline tại thời điểm submit để caller tự gọi waitForNewTiles
        preTileIds: lastPreTileIds,
        // Convert Set → Array để serialize qua chrome message
        preFileNames: lastPreFileNames ? Array.from(lastPreFileNames) : null
      };
    }
    _FLOW_SETTINGS_KEY = "tobyflow_settings_applied_v2";
    _flowSettingsApplied = sessionStorage.getItem(_FLOW_SETTINGS_KEY) === "true";
    _flowSettingsLastAttemptAt = 0;
    _FLOW_SETTINGS_RETRY_COOLDOWN_MS = 3e4;
    try {
      sessionStorage.removeItem("tobyflow_settings_applied");
    } catch (_) {
    }
    let _flowAgentSkipLogged = false;
    async function _ensureFlowAgentModeOff() {
      const btn = _findFlowAgentButton();
      if (!btn) {
        if (!_flowAgentSkipLogged) {
          _flowAgentSkipLogged = true;
          console.debug("[FlowAgent] Agent toggle kh\xF4ng c\xF3 tr\xEAn trang Flow hi\u1EC7n t\u1EA1i \u2014 b\u1ECF qua (kh\xF4ng \u1EA3nh h\u01B0\u1EDFng gen)");
        }
        return { found: false, wasOn: false, success: true };
      }
      const cfg = _getDynamicSelector("flow_agent_toggle_button");
      const onValue = cfg?.aria_pressed_on || "true";
      const wasOn = (btn.getAttribute("aria-pressed") || "").trim() === onValue;
      if (!wasOn) {
        if (window._tobyVerboseFlowDebug) console.log("[FlowAgent] \u2713 Already OFF");
        return { found: true, wasOn: false, success: true };
      }
      console.log("[FlowAgent] \u{1F504} Agent mode ON \u2192 clicking toggle OFF...");
      try {
        simulateClick(btn);
      } catch (e) {
        console.warn("[FlowAgent] Click failed:", e.message);
        return { found: true, wasOn: true, success: false };
      }
      await sleep(400);
      const verifyBtn = _findFlowAgentButton();
      const stillOn = verifyBtn ? (verifyBtn.getAttribute("aria-pressed") || "").trim() === onValue : false;
      if (stillOn) {
        console.warn("[FlowAgent] \u26A0 Click KH\xD4NG turn off \u2014 button v\u1EABn aria-pressed=" + onValue);
        return { found: true, wasOn: true, success: false };
      }
      console.log("[FlowAgent] \u2713 Agent mode turned OFF successfully");
      return { found: true, wasOn: true, success: true };
    }
    async function _waitForFlowEditorReady(maxWaitMs = 5e3, pollIntervalMs = 200) {
      const startTime = Date.now();
      while (Date.now() - startTime < maxWaitMs) {
        try {
          const editor = typeof getEditor === "function" ? getEditor() : null;
          if (editor) {
            return Date.now() - startTime;
          }
        } catch (_) {
        }
        await sleep(pollIntervalMs);
      }
      return null;
    }
    async function _ensureFlowAgentInstructionDone() {
      const btn = _findFlowAgentInstructionDoneButton();
      if (!btn) {
        return { found: false, wasOpen: false, success: true };
      }
      console.log('[FlowAgentInstruction] \u{1F504} Instruction dialog detected \u2192 clicking "Xong"...');
      try {
        simulateClick(btn);
      } catch (e) {
        console.warn("[FlowAgentInstruction] simulateClick failed:", e.message);
      }
      await sleep(400);
      let verifyBtn = _findFlowAgentInstructionDoneButton();
      if (!verifyBtn) {
        console.log("[FlowAgentInstruction] \u2713 Instruction dialog closed (simulateClick)");
        return { found: true, wasOpen: true, success: true };
      }
      console.log("[FlowAgentInstruction] simulateClick ch\u01B0a work \u2192 fallback native click()");
      try {
        verifyBtn.click();
      } catch (e) {
        console.warn("[FlowAgentInstruction] native click failed:", e.message);
      }
      await sleep(400);
      verifyBtn = _findFlowAgentInstructionDoneButton();
      if (!verifyBtn) {
        console.log("[FlowAgentInstruction] \u2713 Instruction dialog closed (native click)");
        return { found: true, wasOpen: true, success: true };
      }
      console.warn("[FlowAgentInstruction] \u26A0 C\u1EA3 simulateClick + native click KH\xD4NG \u0111\xF3ng dialog");
      return { found: true, wasOpen: true, success: false };
    }
    async function _ensureFlowChatAgentClosed() {
      const btn = _findFlowChatAgentCloseButton();
      if (!btn) {
        return { found: false, wasOpen: false, success: true };
      }
      console.log("[FlowChatAgent] \u{1F504} Chat panel detected \u2192 clicking close...");
      console.log("[FlowChatAgent] Button matched (full outerHTML):", btn.outerHTML);
      console.log("[FlowChatAgent] Button parent class:", btn.parentElement?.className, "| grandparent:", btn.parentElement?.parentElement?.className);
      console.log("[FlowChatAgent] Button state: disabled=", btn.disabled, "| aria-disabled=", btn.getAttribute("aria-disabled"), "| pointer-events=", getComputedStyle(btn).pointerEvents);
      const verifyClosed = () => !_findFlowChatAgentCloseButton();
      try {
        btn.focus();
        btn.click();
      } catch (e) {
        console.warn("[FlowChatAgent] focus+click failed:", e.message);
      }
      await sleep(400);
      if (verifyClosed()) {
        console.log("[FlowChatAgent] \u2713 Chat panel closed (focus+click)");
        return { found: true, wasOpen: true, success: true };
      }
      let curBtn = _findFlowChatAgentCloseButton();
      if (!curBtn) return { found: true, wasOpen: true, success: true };
      console.log("[FlowChatAgent] focus+click ch\u01B0a work \u2192 try simulateClick");
      try {
        simulateClick(curBtn);
      } catch (e) {
        console.warn("[FlowChatAgent] simulateClick failed:", e.message);
      }
      await sleep(400);
      if (verifyClosed()) {
        console.log("[FlowChatAgent] \u2713 Chat panel closed (simulateClick)");
        return { found: true, wasOpen: true, success: true };
      }
      curBtn = _findFlowChatAgentCloseButton();
      if (!curBtn) return { found: true, wasOpen: true, success: true };
      const iconEl = _findIconInElement(curBtn);
      if (iconEl) {
        console.log("[FlowChatAgent] simulateClick ch\u01B0a work \u2192 try click on child icon");
        try {
          iconEl.click();
          simulateClick(iconEl);
        } catch (e) {
          console.warn("[FlowChatAgent] icon click failed:", e.message);
        }
        await sleep(400);
        if (verifyClosed()) {
          console.log("[FlowChatAgent] \u2713 Chat panel closed (icon click)");
          return { found: true, wasOpen: true, success: true };
        }
      }
      curBtn = _findFlowChatAgentCloseButton();
      if (!curBtn) return { found: true, wasOpen: true, success: true };
      console.log("[FlowChatAgent] icon click ch\u01B0a work \u2192 try MouseEvent with view+composed");
      try {
        const rect = curBtn.getBoundingClientRect();
        const evtInit = {
          bubbles: true,
          cancelable: true,
          composed: true,
          view: window,
          button: 0,
          clientX: rect.left + rect.width / 2,
          clientY: rect.top + rect.height / 2
        };
        curBtn.dispatchEvent(new MouseEvent("mousedown", evtInit));
        curBtn.dispatchEvent(new MouseEvent("mouseup", evtInit));
        curBtn.dispatchEvent(new MouseEvent("click", evtInit));
      } catch (e) {
        console.warn("[FlowChatAgent] MouseEvent dispatch failed:", e.message);
      }
      await sleep(400);
      if (verifyClosed()) {
        console.log("[FlowChatAgent] \u2713 Chat panel closed (MouseEvent+view)");
        return { found: true, wasOpen: true, success: true };
      }
      curBtn = _findFlowChatAgentCloseButton();
      if (!curBtn) return { found: true, wasOpen: true, success: true };
      console.log("[FlowChatAgent] MouseEvent ch\u01B0a work \u2192 try Escape key");
      try {
        const escEvt = () => new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true, composed: true });
        curBtn.dispatchEvent(escEvt());
        document.dispatchEvent(escEvt());
        document.body.dispatchEvent(escEvt());
      } catch (e) {
        console.warn("[FlowChatAgent] Escape dispatch failed:", e.message);
      }
      await sleep(400);
      if (verifyClosed()) {
        console.log("[FlowChatAgent] \u2713 Chat panel closed (Escape key)");
        return { found: true, wasOpen: true, success: true };
      }
      curBtn = _findFlowChatAgentCloseButton();
      if (!curBtn) return { found: true, wasOpen: true, success: true };
      const parent = curBtn.parentElement;
      if (parent) {
        console.log("[FlowChatAgent] Escape ch\u01B0a work \u2192 try click on parent wrapper");
        try {
          parent.click();
          simulateClick(parent);
        } catch (e) {
          console.warn("[FlowChatAgent] parent click failed:", e.message);
        }
        await sleep(400);
        if (verifyClosed()) {
          console.log("[FlowChatAgent] \u2713 Chat panel closed (parent click)");
          return { found: true, wasOpen: true, success: true };
        }
      }
      console.warn("[FlowChatAgent] \u26A0 T\u1EA5t c\u1EA3 6 click strategies KH\xD4NG \u0111\xF3ng panel \u2014 b\xE1o c\xE1o bug DOM");
      return { found: true, wasOpen: true, success: false };
    }
    async function ensureFlowSettingsApplied() {
      if (isRunning) {
        console.log("[TobyFlow] ensureFlowSettingsApplied: skipped (isRunning)");
        return;
      }
      try {
        const instructionResult = await _ensureFlowAgentInstructionDone();
        if (instructionResult.wasOpen && instructionResult.success) {
          console.log("[TobyFlow] \u2713 Agent instruction dialog closed (was open, now closed)");
        } else if (instructionResult.wasOpen && !instructionResult.success) {
          console.warn("[TobyFlow] \u26A0 Agent instruction Done click FAILED \u2014 dialog v\u1EABn m\u1EDF");
        } else if (instructionResult.found) {
          console.log("[TobyFlow] \u2713 Agent instruction dialog already closed");
        }
      } catch (e) {
        console.warn("[TobyFlow] _ensureFlowAgentInstructionDone failed (non-blocking):", e.message);
      }
      let _panelActioned = false;
      try {
        const panelResult = await _ensureFlowChatAgentClosed();
        if (panelResult.wasOpen && panelResult.success) {
          console.log("[TobyFlow] \u2713 Chat agent panel auto-closed");
          _panelActioned = true;
        } else if (panelResult.wasOpen && !panelResult.success) {
          console.warn("[TobyFlow] \u26A0 Chat agent panel close FAILED \u2014 panel v\u1EABn m\u1EDF");
        } else if (panelResult.found) {
          console.log("[TobyFlow] \u2713 Chat agent panel already closed");
        }
      } catch (e) {
        console.warn("[TobyFlow] _ensureFlowChatAgentClosed failed (non-blocking):", e.message);
      }
      if (_panelActioned) {
        await sleep(1500);
      }
      try {
        const agentResult = await _ensureFlowAgentModeOff();
        if (agentResult.wasOn && agentResult.success) {
          console.log("[TobyFlow] \u2713 Agent mode auto-disabled (was ON, now OFF)");
        } else if (agentResult.wasOn && !agentResult.success) {
          console.warn("[TobyFlow] \u26A0 Agent mode click toggle FAILED \u2014 v\u1EABn ON");
        } else if (agentResult.found) {
          console.log("[TobyFlow] \u2713 Agent mode already OFF");
        } else {
          console.log("[TobyFlow] Agent button not found (Flow ch\u01B0a rollout t\xEDnh n\u0103ng ho\u1EB7c page ch\u01B0a ready)");
        }
      } catch (e) {
        console.warn("[TobyFlow] _ensureFlowAgentModeOff failed (non-blocking):", e.message);
      }
      window._tobyAgentChainLastRunAt = Date.now();
      if (_flowSettingsApplied) {
        console.log("[TobyFlow] ensureFlowSettingsApplied: settings menu SKIPPED (already applied in this session)");
        return;
      }
      const now = Date.now();
      if (_flowSettingsLastAttemptAt && now - _flowSettingsLastAttemptAt < _FLOW_SETTINGS_RETRY_COOLDOWN_MS) {
        console.log("[TobyFlow] ensureFlowSettingsApplied: settings menu cooldown \u2014 skip retry");
        return;
      }
      _flowSettingsLastAttemptAt = now;
      let flowSettingsBtn = null;
      const allIcons = _findIconsInElement(document);
      for (const icon of allIcons) {
        if (icon.textContent.trim() === "settings_2") {
          flowSettingsBtn = icon.closest("button");
          break;
        }
      }
      if (!flowSettingsBtn) {
        console.log("[TobyFlow] ensureFlowSettingsApplied: settings_2 icon ch\u01B0a c\xF3 \u2014 Flow page ch\u01B0a ready, retry next call");
        return;
      }
      console.log("[TobyFlow] ensureFlowSettingsApplied: applying Grid view + show tile details (1-time)...");
      simulateClick(flowSettingsBtn);
      await sleep(500);
      const _collectTabTriggers = (scope) => {
        const root = scope || document;
        const fromCfg = _qa("flow_tab_slider_trigger", root);
        let list = fromCfg && fromCfg.length ? Array.from(fromCfg) : [];
        list = list.filter((el) => {
          const label = el.getAttribute("aria-label") || (el.textContent || "").trim();
          return !_isNonViewSettingsControlLabel(label);
        });
        if (list.length === 0) {
          root.querySelectorAll('button[role="tab"], [role="tab"]').forEach((el) => {
            const label = el.getAttribute("aria-label") || (el.textContent || "").trim();
            if (!_isNonViewSettingsControlLabel(label)) list.push(el);
          });
        }
        return list;
      };
      const _collectSettingRows = () => {
        const fromCfg = _qa("show_tile_details_setting");
        const list = fromCfg && fromCfg.length ? Array.from(fromCfg) : [];
        if (list.length === 0) {
          document.querySelectorAll('[role="menuitem"], [role="menuitemcheckbox"], [role="menuitemradio"], label, [data-radix-collection-item]').forEach((el) => list.push(el));
        }
        return list;
      };
      let tabTriggers = _collectTabTriggers();
      const gridLabels = _getFlowLocaleStringsWithFallback("grid_view_tab", "aria_labels");
      let gridClicked = false;
      for (const trigger of tabTriggers) {
        const label = trigger.getAttribute("aria-label") || trigger.textContent.trim();
        if (_ariaLabelMatches(label, gridLabels) && trigger.getAttribute("data-state") !== "active") {
          simulateClick(trigger);
          await sleep(600);
          gridClicked = true;
          break;
        }
      }
      if (!gridClicked && tabTriggers.length > 0) {
        for (const trigger of tabTriggers) {
          const label = trigger.getAttribute("aria-label") || trigger.textContent.trim();
          if (_isLikelyGridViewLabel(label) && trigger.getAttribute("data-state") !== "active") {
            console.log("[TobyFlow] ensureFlowSettingsApplied: grid heuristic click \u2192", label);
            simulateClick(trigger);
            await sleep(600);
            gridClicked = true;
            break;
          }
        }
      }
      if (!gridClicked && tabTriggers.length === 2) {
        for (const trigger of tabTriggers) {
          const label = trigger.getAttribute("aria-label") || trigger.textContent.trim();
          if (!_isGroupViewTabLabel(label) && !_isNonViewSettingsControlLabel(label) && trigger.getAttribute("data-state") !== "active") {
            console.log("[TobyFlow] ensureFlowSettingsApplied: 2-tab fallback click \u2192", label);
            simulateClick(trigger);
            await sleep(600);
            gridClicked = true;
            break;
          }
        }
      }
      let detailsClicked = false;
      const showDetailsLabels = _getFlowLocaleStringsWithFallback("show_tile_details_setting", "text_match");
      const toggleOnLabels = _getFlowLocaleStringsWithFallback("toggle_state_button", "aria_labels_on");
      const settingRows = _collectSettingRows();
      for (const row of settingRows) {
        const rowText = row.textContent || "";
        const rowMatch = showDetailsLabels.length > 0 ? _textIncludesAny(rowText, showDetailsLabels) : /chi tiết|detail/i.test(rowText);
        if (rowMatch) {
          let toggleBtns = _qa("flow_tab_slider_trigger", row);
          if (!toggleBtns || !toggleBtns.length) {
            toggleBtns = row.querySelectorAll('button[data-state], [role="switch"], button[aria-pressed], button');
          }
          for (const btn of toggleBtns) {
            const label = btn.getAttribute("aria-label") || btn.textContent.trim();
            const toggleMatch = toggleOnLabels.length > 0 ? _ariaLabelMatches(label, toggleOnLabels) : true;
            const state = btn.getAttribute("data-state") || btn.getAttribute("aria-pressed") || "";
            if (toggleMatch && state !== "active" && state !== "true" && state !== "checked") {
              simulateClick(btn);
              await sleep(600);
              detailsClicked = true;
              break;
            }
          }
          break;
        }
      }
      const verifyGridActive = () => {
        const triggers = _collectTabTriggers();
        for (const t of triggers) {
          const label = t.getAttribute("aria-label") || t.textContent.trim();
          if (_ariaLabelMatches(label, gridLabels) && t.getAttribute("data-state") === "active") {
            return true;
          }
        }
        let anyGroup = false;
        let anyActive = false;
        for (const t of triggers) {
          const label = t.getAttribute("aria-label") || t.textContent.trim();
          const active = t.getAttribute("data-state") === "active";
          if (active) anyActive = true;
          if (active && _isGroupViewTabLabel(label)) anyGroup = true;
        }
        if (triggers.length && anyActive && !anyGroup) return true;
        return false;
      };
      const verifyDetailsOn = () => {
        const rows = _collectSettingRows();
        for (const row of rows) {
          if (_textIncludesAny(row.textContent, showDetailsLabels) || /chi tiết|detail/i.test(row.textContent || "")) {
            let toggleBtns = _qa("flow_tab_slider_trigger", row);
            if (!toggleBtns || !toggleBtns.length) {
              toggleBtns = row.querySelectorAll('button[data-state], [role="switch"], button[aria-pressed]');
            }
            for (const btn of toggleBtns) {
              const label = btn.getAttribute("aria-label") || btn.textContent.trim();
              const state = btn.getAttribute("data-state") || btn.getAttribute("aria-checked") || btn.getAttribute("aria-pressed") || "";
              if ((_ariaLabelMatches(label, toggleOnLabels) || !label) && (state === "active" || state === "true" || state === "checked")) {
                return true;
              }
            }
            return false;
          }
        }
        return false;
      };
      const gridActive = verifyGridActive();
      const detailsOn = verifyDetailsOn();
      const detailsRowExists = _collectSettingRows().some((el) => /chi tiết|detail/i.test(el.textContent || "")) || [...document.querySelectorAll('[role="menu"] *, [role="dialog"] *')].some((el) => /chi tiết|detail/i.test(el.textContent || ""));
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      simulateClick(document.body);
      await sleep(300);
      const settingsOk = gridActive && (detailsOn || !detailsRowExists);
      if (settingsOk) {
        _flowSettingsApplied = true;
        sessionStorage.setItem(_FLOW_SETTINGS_KEY, "true");
        console.log(`[TobyFlow] ensureFlowSettingsApplied: DONE \u2713 (gridClicked=${gridClicked}, detailsClicked=${detailsClicked}, gridActive=${gridActive}, detailsOn=${detailsOn}, detailsRowExists=${detailsRowExists})`);
      } else {
        const softOk = !detailsRowExists || tabTriggers.length === 0 || !gridActive && !detailsOn && !detailsRowExists;
        if (softOk) {
          console.warn(`[TobyFlow] ensureFlowSettingsApplied: soft-OK (gridActive=${gridActive}, detailsOn=${detailsOn}, detailsRowExists=${detailsRowExists}, tabs=${tabTriggers.length}) \u2014 gen/upload v\u1EABn ch\u1EA1y`);
          _flowSettingsApplied = true;
          sessionStorage.setItem(_FLOW_SETTINGS_KEY, "true");
        } else {
          console.warn(`[TobyFlow] ensureFlowSettingsApplied: INCOMPLETE \u2014 gridActive=${gridActive}, detailsOn=${detailsOn} (gridClicked=${gridClicked}, detailsClicked=${detailsClicked}). Flag NOT set, retry sau ${_FLOW_SETTINGS_RETRY_COOLDOWN_MS / 1e3}s cooldown.`);
        }
      }
    }
    async function _getBrowserZoom() {
      try {
        return await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: "getBrowserZoom" }, (r) => {
            resolve(chrome.runtime.lastError || typeof r?.zoom !== "number" ? null : r.zoom);
          });
        });
      } catch (_) {
        return null;
      }
    }
    async function _setBrowserZoom(factor) {
      try {
        return await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: "setBrowserZoom", factor }, (r) => {
            resolve(chrome.runtime.lastError ? false : !!r?.ok);
          });
        });
      } catch (_) {
        return false;
      }
    }
    _ZOOM_NOTICE_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>';
    async function _ensureZoomSessionActive() {
      const s = window._tobyFlowZoomSession;
      if (!s || !s.armed || s.active) return;
      const o = await _getBrowserZoom();
      if (o != null) {
        await _setBrowserZoom(s.factor);
        s.mode = "browser";
        s.original = o;
        await new Promise((r) => {
          let done = false;
          const fin = () => {
            if (!done) {
              done = true;
              r();
            }
          };
          requestAnimationFrame(() => requestAnimationFrame(fin));
          setTimeout(fin, 150);
        });
      } else {
        s.originalCss = document.body.style.zoom || "1";
        document.body.style.zoom = String(s.factor);
        s.mode = "css";
      }
      s.active = true;
      _applyZoomUx(s.factor);
      console.log(`[TobyFlow] zoom session: zoom xu\u1ED1ng ${s.factor} (mode=${s.mode}) \u2014 gi\u1EEF su\u1ED1t batch`);
    }
    async function _endZoomSession() {
      const s = window._tobyFlowZoomSession;
      if (!s) return;
      window._tobyFlowZoomSession = null;
      _clearZoomUx();
      if (s.active) {
        if (s.mode === "browser") {
          const target = typeof s.original === "number" && s.original > 0 && s.original !== s.factor ? s.original : 1;
          await _setBrowserZoom(target);
          console.log(`[TobyFlow] zoom session: restore browser zoom \u2192 ${target}`);
        } else {
          document.body.style.zoom = s.originalCss && s.originalCss !== String(s.factor) ? s.originalCss : "1";
          console.log(`[TobyFlow] zoom session: restore CSS zoom \u2192 ${document.body.style.zoom}`);
        }
      }
    }
    async function ensureFlowTilesLoaded(force = false, targetFileNames = []) {
      if (!_selectorConfigReady) {
        console.log("[TobyFlow] ensureFlowTilesLoaded: config not ready, waiting...");
        for (let i = 0; i < 15; i++) {
          await sleep(200);
          if (_selectorConfigReady) break;
        }
        if (!_selectorConfigReady) {
          console.warn("[TobyFlow] ensureFlowTilesLoaded: timeout waiting for config");
          return;
        }
      }
      _tileSelectorCache = null;
      let selector = _getTileSelectorString();
      const rawTiles = document.querySelectorAll("[data-tile-id]");
      console.log(`[TobyFlow] ensureFlowTilesLoaded DEBUG: force=${force}, selector="${selector}", rawTiles=[data-tile-id]=${rawTiles.length}, URL=${location.href.substring(0, 80)}`);
      const tilesBeforeCount = selector ? document.querySelectorAll(selector).length : 0;
      const targets = Array.isArray(targetFileNames) ? targetFileNames.filter(Boolean) : [];
      const hasTargets = targets.length > 0;
      const foundTiles = {};
      let lastFoundEl = null;
      const _scan = () => {
        if (!hasTargets) return 0;
        const want = new Set(targets.filter((t) => !(t in foundTiles)));
        if (want.size === 0) return targets.length;
        const tiles = document.querySelectorAll(_getTileSelectorString());
        for (const tile of tiles) {
          const fn = extractFileName(tile);
          if (fn && want.has(fn)) {
            foundTiles[fn] = tile.dataset.tileId;
            lastFoundEl = tile;
            want.delete(fn);
            if (want.size === 0) break;
          }
        }
        return Object.keys(foundTiles).length;
      };
      if (hasTargets && _scan() === targets.length) {
        console.log(`[TobyFlow] ensureFlowTilesLoaded: t\u1EA5t c\u1EA3 ${targets.length} target \u0111\xE3 c\xF3 tr\xEAn DOM, skip`);
        return foundTiles;
      }
      if (!force && !hasTargets && tilesBeforeCount >= 50) {
        console.log(`[TobyFlow] ensureFlowTilesLoaded: skipping zoom (${tilesBeforeCount} tiles already loaded)`);
        return foundTiles;
      }
      const _inSession = !!(window._tobyFlowZoomSession && window._tobyFlowZoomSession.armed);
      const _bzOrig = _inSession ? null : await _getBrowserZoom();
      const _useBz = !_inSession && _bzOrig != null;
      const originalCssZoom = document.body.style.zoom || "1";
      const _applyZoom = async (f) => {
        if (_inSession) {
          await _ensureZoomSessionActive();
          return;
        }
        if (_useBz) await _setBrowserZoom(f);
        else document.body.style.zoom = String(f);
        if (hasTargets) _showZoomNotice("scanningRefImages", f);
      };
      const _restoreZoom = async () => {
        if (_inSession) return;
        if (_useBz) await _setBrowserZoom(_bzOrig);
        else document.body.style.zoom = originalCssZoom;
        if (hasTargets) _hideZoomNotice();
      };
      const _scCfg = _getDynamicSelector("flow_scroll_container");
      const _scClosestAttr = _scCfg?.closest_attribute || '[style*="overflow"]';
      const _getScroll = () => _q("flow_scroll_container")?.closest(_scClosestAttr) || document.documentElement;
      try {
        if (hasTargets) {
          const zoomSteps = [0.5, 0.33, 0.25];
          let done = false;
          let prevTotal = -1;
          for (let s = 0; s < zoomSteps.length && !done; s++) {
            await _applyZoom(zoomSteps[s]);
            await sleep(s === 0 ? 1200 : 800);
            const sc = _getScroll();
            const step = Math.max(Math.floor((window.innerHeight || 800) * 0.8), 500);
            const MAX_STEPS = 80;
            let stepCount = 0;
            for (let pos = 0; pos <= sc.scrollHeight + step && stepCount < MAX_STEPS; pos += step, stepCount++) {
              sc.scrollTop = pos;
              await sleep(300);
              if (_scan() === targets.length) {
                done = true;
                break;
              }
            }
            if (done) {
              const _zlbl = _inSession ? window._tobyFlowZoomSession?.factor ?? "session" : zoomSteps[s];
              console.log(`[TobyFlow] ensureFlowTilesLoaded: capture \u0111\u1EE7 ${targets.length} target \u1EDF zoom=${_zlbl}`);
              break;
            }
            sc.scrollTop = 0;
            await sleep(250);
            if (_scan() === targets.length) {
              done = true;
              break;
            }
            const curTotal = document.querySelectorAll(_getTileSelectorString()).length;
            if (s > 0 && curTotal <= prevTotal) {
              console.warn(`[TobyFlow] ensureFlowTilesLoaded: zoom=${zoomSteps[s]} kh\xF4ng render th\xEAm tile (${curTotal}) \u2192 d\u1EEBng s\u1EDBm`);
              break;
            }
            prevTotal = curTotal;
          }
          if (!done) console.warn(`[TobyFlow] ensureFlowTilesLoaded: ch\u1EC9 capture ${Object.keys(foundTiles).length}/${targets.length} target sau multi-pass`);
        } else {
          await _applyZoom(0.5);
          await sleep(1500);
          const sc = _getScroll();
          sc.scrollTop = sc.scrollHeight;
          await sleep(800);
          sc.scrollTop = 0;
          await sleep(500);
        }
      } finally {
        await _restoreZoom();
        await sleep(300);
        if (hasTargets && lastFoundEl && lastFoundEl.isConnected) {
          try {
            lastFoundEl.scrollIntoView({ block: "center" });
          } catch (_) {
          }
        }
      }
      const tilesAfterLoad = document.querySelectorAll(_getTileSelectorString()).length;
      console.log(`[TobyFlow] ensureFlowTilesLoaded: ${tilesBeforeCount} \u2192 ${tilesAfterLoad} tiles (after zoom${hasTargets ? `, captured=${Object.keys(foundTiles).length}/${targets.length}` : ""})`);
      return foundTiles;
    }
    async function _clickFlowNewProjectButton(iconText, textMatch, maxWaitMs = 2e4) {
      const DEFAULT_ICON = ["add_2", "add", "add_circle"];
      const DEFAULT_TEXT = ["D\u1EF1 \xE1n m\u1EDBi", "Du an moi", "New project", "Create new project", "T\u1EA1o d\u1EF1 \xE1n", "Tao du an"];
      const iconNames = new Set([...iconText?.length ? iconText : DEFAULT_ICON, ...DEFAULT_ICON].map((s) => String(s).trim()).filter(Boolean));
      const fold = (v) => String(v ?? "").replace(/\s+/g, " ").trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
      const textFolded = [.../* @__PURE__ */ new Set([...textMatch?.length ? textMatch : DEFAULT_TEXT, ...DEFAULT_TEXT])].map(fold).filter(Boolean);
      const hasLayout = (el) => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      };
      const robustClick = (el) => {
        const opts = { bubbles: true, cancelable: true, view: window, button: 0 };
        try {
          el.dispatchEvent(new PointerEvent("pointerdown", opts));
        } catch (_) {
        }
        try {
          el.dispatchEvent(new MouseEvent("mousedown", opts));
        } catch (_) {
        }
        try {
          el.dispatchEvent(new PointerEvent("pointerup", opts));
        } catch (_) {
        }
        try {
          el.dispatchEvent(new MouseEvent("mouseup", opts));
        } catch (_) {
        }
        try {
          el.dispatchEvent(new MouseEvent("click", opts));
        } catch (_) {
        }
        try {
          const k = Object.keys(el).find((x) => x.startsWith("__reactProps$"));
          if (k && typeof el[k]?.onClick === "function") {
            el[k].onClick({ preventDefault() {
            }, stopPropagation() {
            }, type: "click", target: el, currentTarget: el, button: 0 });
          }
        } catch (_) {
        }
        if (el instanceof HTMLElement) try {
          el.click();
        } catch (_) {
        }
      };
      const matches = (button) => {
        const icons = button.querySelectorAll('i.google-symbols, i[class*="google-symbols"]');
        let iconHit = false;
        for (const icon of icons) {
          if (iconNames.has(String(icon.textContent || "").trim())) {
            iconHit = true;
            break;
          }
        }
        const folded = fold(button.textContent);
        const textHit = textFolded.some((t) => folded.includes(t));
        return iconHit || textHit;
      };
      const tryOnce = () => {
        for (const overlay of document.querySelectorAll('[data-type="button-overlay"]')) {
          const button = overlay.closest("button");
          if (!button || !hasLayout(button) || !matches(button)) continue;
          robustClick(overlay);
          robustClick(button);
          return { clicked: true, method: "cs:button-overlay", text: String(button.textContent || "").trim() };
        }
        for (const button of document.querySelectorAll('button, [role="button"]')) {
          if (!hasLayout(button) || !matches(button)) continue;
          const overlay = button.querySelector('[data-type="button-overlay"]');
          if (overlay && hasLayout(overlay)) robustClick(overlay);
          robustClick(button);
          return { clicked: true, method: "cs:button", text: String(button.textContent || "").trim() };
        }
        return { clicked: false, error: "new_project_button not found" };
      };
      const started = Date.now();
      while (Date.now() - started < maxWaitMs) {
        const r = tryOnce();
        if (r.clicked) return r;
        await sleep(400);
      }
      return { clicked: false, error: "timeout" };
    }
    try {
      injectSlateBridge();
    } catch (e) {
      console.log("[TobyFlow] Bridge inject deferred:", e.message);
    }
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "ping") {
        sendResponse({ pong: true, loadedAt: self.__tobyflowContentJsLoaded__ });
        return false;
      }
      const handlers = {
        "runAutoPrompt": async () => {
          try {
            const n = message.payload?.prompts?.length ?? 0;
            console.log(`[runAutoPrompt] \u25B6 Received ${n} prompt(s) \u2014 filling editor...`);
            const result = await runAutoPrompt(message.payload);
            return result;
          } catch (err) {
            console.error("[runAutoPrompt] Unhandled error:", err);
            ExecutionBlocker.hide();
            isRunning = false;
            isPaused = false;
            return { success: false, error: err.message };
          }
        },
        "applySettings": async () => {
          console.log(`[content.js] applySettings message received:`, JSON.stringify({ genType: message.genType, ratio: message.ratio, model: message.model, isFrames: message.isFrames, quantity: message.quantity, flowVideoDuration: message.flowVideoDuration }));
          await applySettings(message.genType, message.ratio, message.model, message.isFrames, message.quantity, message.flowVideoDuration);
          return { success: true };
        },
        // 2026-06-02: prepareFlowForGen — đóng chat panel + Agent OFF + wait editor ready.
        // Gọi từ EditorExecutor TRƯỚC removeExistingRefImages/addRefImages để đảm bảo composer area
        // (editor + ref slots) đã render xong. Nếu add_ref trong khi panel/Agent UI vẫn mở → ref images
        // không add đúng chỗ.
        "prepareFlowForGen": async () => {
          console.log("[content.js] prepareFlowForGen: ensuring Flow editor ready (close panel + Agent OFF)...");
          let actioned = false;
          let exitedMediaViewer = false;
          try {
            if (_isFlowMediaViewerOpen()) {
              console.log("[prepareFlowForGen] Step 0: \u0111ang \u1EDF media viewer \u2192 quay l\u1EA1i editor project");
              exitedMediaViewer = await _exitFlowMediaViewer();
              actioned = true;
            }
          } catch (e) {
            console.warn("[prepareFlowForGen] Step 0 (media viewer) failed:", e.message);
          }
          try {
            const r = await _ensureFlowAgentInstructionDone();
            if (r.wasOpen && r.success) {
              console.log("[prepareFlowForGen] \u2713 Instruction dialog closed");
              actioned = true;
            }
          } catch (e) {
            console.warn("[prepareFlowForGen] Step 1 failed:", e.message);
          }
          try {
            const r = await _ensureFlowChatAgentClosed();
            if (r.wasOpen && r.success) {
              console.log("[prepareFlowForGen] \u2713 Chat panel closed");
              actioned = true;
              await sleep(1500);
            }
          } catch (e) {
            console.warn("[prepareFlowForGen] Step 2 failed:", e.message);
          }
          try {
            const r = await _ensureFlowAgentModeOff();
            if (r.wasOn && r.success) {
              console.log("[prepareFlowForGen] \u2713 Agent OFF");
              actioned = true;
            }
          } catch (e) {
            console.warn("[prepareFlowForGen] Step 3 failed:", e.message);
          }
          let editorReadyMs = 0;
          if (actioned) {
            editorReadyMs = await _waitForFlowEditorReady(5e3) || 0;
            if (editorReadyMs) {
              console.log(`[prepareFlowForGen] \u2713 Editor ready (${editorReadyMs}ms wait)`);
            } else {
              console.warn("[prepareFlowForGen] \u26A0 Editor not ready after 5s \u2014 gen may fail");
            }
          }
          window._tobyAgentChainLastRunAt = Date.now();
          return { success: true, actioned, editorReadyMs, exitedMediaViewer };
        },
        "getEditor": () => {
          const editor = getEditor();
          let hasSlateState = false;
          let debugInfo = {};
          if (editor) {
            try {
              const _slateSel = _getSlateEditorSelectorString();
              const isDisabled = editor.closest('[data-disabled="true"]') || _slateSel && editor.querySelector(_slateSel + '[contenteditable="false"]');
              const submitBtn = getSubmitButton();
              const btnExists = !!submitBtn;
              const slateEditor = _slateSel && editor.querySelector(_slateSel) || editor;
              const isEditable = slateEditor?.getAttribute("contenteditable") === "true" || editor.hasAttribute("data-slate-editor");
              hasSlateState = !isDisabled && btnExists && isEditable;
              debugInfo = { isDisabled: !!isDisabled, btnExists, isEditable };
            } catch (e) {
              hasSlateState = false;
              debugInfo = { error: e.message };
            }
          }
          return { exists: !!editor, hasSlateState };
        },
        "dismissBlockingModal": () => {
          let hadModal = false;
          const dialogs = _qa("flow_modal_dialog");
          for (const dialog of dialogs) {
            const acceptBtn = dialog.querySelector(
              'button:not([aria-label*="close" i]):not([aria-label*="cancel" i])'
            );
            const buttons = dialog.querySelectorAll("button");
            for (const btn of buttons) {
              const text = btn.textContent?.toLowerCase() || "";
              if (text.includes("accept") || text.includes("confirm") || text.includes("ok") || text.includes("\u0111\u1ED3ng \xFD") || text.includes("x\xE1c nh\u1EADn") || text.includes("continue") || text.includes("got it") || text.includes("agree") || text.includes("ti\u1EBFp t\u1EE5c")) {
                console.log("[dismissBlockingModal] Clicking accept button:", btn.textContent);
                btn.click();
                hadModal = true;
                break;
              }
            }
            if (hadModal) continue;
            const closeBtn = dialog.querySelector(
              'button[aria-label*="close" i], button[aria-label*="\u0111\xF3ng" i], [data-dismiss], [data-close]'
            );
            if (closeBtn) {
              console.log("[dismissBlockingModal] Clicking close button");
              closeBtn.click();
              hadModal = true;
              continue;
            }
            const backdrop = dialog.parentElement?.querySelector('[data-state="open"][data-overlay]');
            if (backdrop) {
              backdrop.click();
              hadModal = true;
            }
          }
          if (!hadModal) {
            const openModal = document.querySelector('[data-state="open"][role="dialog"]');
            if (openModal) {
              document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
              hadModal = true;
            }
          }
          return { hadModal };
        },
        "checkBlockingModal": () => {
          const hasModal = !!(document.querySelector('[role="dialog"][data-state="open"]') || document.querySelector('[role="alertdialog"][data-state="open"]') || document.querySelector('[role="dialog"]:not([data-state="closed"])'));
          return { hasModal };
        },
        "insertText": async () => {
          if (shouldStop) {
            console.log("[insertText] \u23F9 Aborted before start (shouldStop=true)");
            return { success: false, error: "ABORTED", message: "User stopped before insert" };
          }
          const text = message.text || message.prompt || "";
          console.log(
            "%c[insertText] Flow paste k\u1ECBch b\u1EA3n/prompt",
            "color:#cdff01;font-weight:bold",
            "len=",
            String(text).length,
            String(text).slice(0, 60)
          );
          if (!String(text).trim()) {
            return { success: false, error: "EMPTY_TEXT" };
          }
          const editor = getEditor();
          if (!editor) {
            console.warn("[insertText] getEditor() null");
            return { success: false, error: "NO_EDITOR" };
          }
          await insertText(editor, text);
          await sleep(200);
          let domLen = 0;
          try {
            const ed2 = getEditor();
            domLen = (ed2?.textContent || ed2?.innerText || "").trim().length;
          } catch (_) {
          }
          console.log("[insertText] after insert domLen=", domLen, "expected~", String(text).trim().length);
          if (domLen < Math.min(10, String(text).trim().length * 0.3)) {
            console.warn("[insertText] DOM text short \u2014 retry insertText once");
            await insertText(editor, text);
            await sleep(300);
            try {
              const ed3 = getEditor();
              domLen = (ed3?.textContent || ed3?.innerText || "").trim().length;
            } catch (_) {
            }
          }
          return { success: domLen > 0, domLen, expected: String(text).trim().length };
        },
        "clearEditor": async () => {
          if (shouldStop) {
            console.log("[clearEditor] \u23F9 Aborted before start (shouldStop=true)");
            return { success: false, error: "ABORTED", message: "User stopped before clear" };
          }
          const editor = getEditor();
          if (editor) await clearEditor(editor);
          return { success: true };
        },
        "clickSubmit": async () => {
          if (shouldStop) {
            console.log("[clickSubmit] \u23F9 Aborted before start (shouldStop=true)");
            return { success: false, error: "ABORTED", message: "User stopped before submit" };
          }
          let btn = getSubmitButton();
          const editor = getEditor();
          console.log("[clickSubmit] \u{1F680} Start. Button:", !!btn, "disabled:", btn?.disabled, "Editor:", !!editor);
          if (!btn) {
            console.warn("[clickSubmit] \u26A0\uFE0F submit_button DOM selector MISS \u2014 s\u1EBD fallback Slate Bridge (React internal). Admin ki\u1EC3m tra provider_configs.dom_selector.submit_button cho flow n\u1EBFu th\u1EA5y log n\xE0y nhi\u1EC1u.");
          }
          let waitMs = 0;
          while (btn?.disabled && waitMs < 5e3) {
            if (shouldStop) {
              console.log("[clickSubmit] \u23F9 Aborted while waiting button enable");
              return { success: false, error: "ABORTED", message: "User stopped while waiting button" };
            }
            await sleep(200);
            waitMs += 200;
            btn = getSubmitButton() || btn;
          }
          if (waitMs > 0) {
            console.log("[clickSubmit] Waited", waitMs, "ms for button enable, disabled:", btn?.disabled);
          }
          console.log("[clickSubmit] \u{1F3AF} Approach 1: Slate Bridge (React internal submit)");
          injectSlateBridge();
          try {
            const iconSelectorForClickBridge = (_getDynamicSelector("icon_element")?.selectors || []).join(", ");
            const result = await _slateBridgeCall("submit", { iconSelector: iconSelectorForClickBridge });
            console.log("[clickSubmit]    Bridge return:", result);
            if (result?.success) {
              console.log("[clickSubmit] \u{1F3C6} SUBMITTED via Slate Bridge \u2014 caller s\u1EBD verify gen-done qua waitForNewTiles");
              return { success: true, approach: "bridge" };
            }
            console.warn("[clickSubmit] \u26A0\uFE0F Bridge return success=false:", result?.error, "\u2192 fallback");
          } catch (e) {
            console.warn("[clickSubmit] \u26A0\uFE0F Bridge throw:", e.message, "\u2192 fallback");
          }
          btn = getSubmitButton();
          if (btn && !btn.disabled) {
            console.log("[clickSubmit] \u{1F3AF} Approach 2: simulateClick (bridge failed \u2192 fallback)");
            simulateClick(btn);
            return { success: true, approach: "simulateClick" };
          }
          console.log("[clickSubmit] \u23ED\uFE0F Approach 2 skipped \u2014 button disabled");
          if (editor) {
            console.log("[clickSubmit] \u{1F3AF} Approach 3: Enter key (bridge + simulateClick failed \u2192 fallback)");
            editor.focus();
            await sleep(100);
            editor.dispatchEvent(new KeyboardEvent("keydown", {
              key: "Enter",
              code: "Enter",
              keyCode: 13,
              bubbles: true,
              cancelable: true
            }));
            return { success: true, approach: "enterKey" };
          }
          btn = getSubmitButton();
          if (btn && !btn.disabled) {
            console.log("[clickSubmit] \u{1F3AF} Approach 4: Native btn.click() (last resort)");
            btn.click();
            return { success: true, approach: "nativeClick" };
          }
          console.warn("[clickSubmit] \u274C T\u1EA5t c\u1EA3 approaches \u0111\u1EC1u skip \u2014 kh\xF4ng c\xF3 button enabled / editor");
          return { success: false, error: "No usable element to trigger submit" };
        },
        "addFileToPrompt": async () => {
          await addFileToPrompt(message.fileId, message.fileName, message.flowFileId);
          return { success: true };
        },
        "getCurrentTileIds": () => {
          _invalidateTileCache();
          return { tileIds: getUniqueTileIds(true), fileNames: [...getExistingFileNames()] };
        },
        "waitForNewTiles": async () => {
          shouldStop = false;
          const preFileNames = message.preFileNames ? new Set(message.preFileNames) : message.captureFileNames ? getExistingFileNames() : null;
          console.log(`[content.js] waitForNewTiles received \u2014 preTileIds=${(message.preTileIds || []).length}, timeout=${message.timeout}, maxQty=${message.maxQuantity}`);
          const result = await waitForNewTiles(
            message.preTileIds || [],
            message.timeout || 12e4,
            preFileNames,
            message.maxQuantity || 0
          );
          console.log(`[content.js] waitForNewTiles done \u2014 result has ${result?.tiles?.length || 0} new tiles, failed=${result?.failed}`);
          return result;
        },
        "stopExecution": () => {
          shouldStop = true;
          isPaused = false;
          _clickedRetryTileIds.clear();
          if (FloatingTracker._legacyData) {
            FloatingTracker._legacyData.status = "stopped";
            FloatingTracker.updateLegacy(FloatingTracker._legacyData);
          }
          ExecutionBlocker.hide();
          return { success: true };
        },
        "resetStop": () => {
          shouldStop = false;
          return { success: true };
        },
        "pauseExecution": () => {
          isPaused = true;
          if (FloatingTracker._legacyData) {
            FloatingTracker._legacyData.status = "paused";
            FloatingTracker.updateLegacy(FloatingTracker._legacyData);
          }
          return { isPaused: true };
        },
        "resumeExecution": () => {
          isPaused = false;
          if (FloatingTracker._legacyData) {
            FloatingTracker._legacyData.status = "running";
            FloatingTracker.updateLegacy(FloatingTracker._legacyData);
          }
          return { isPaused: false };
        },
        "pq:clearRetryTracking": () => {
          _clickedRetryTileIds.clear();
          _retryingTiles.clear();
          return { success: true };
        },
        "getRunningState": () => {
          return { isRunning, shouldStop, isPaused };
        },
        // Sidepanel timeout / "Flow bận" oan: clear isRunning khi job CS treo sau race timeout.
        // shouldStop=true trước → loop runAutoPrompt đang chạy sẽ thoát; isRunning=false cho phép job mới.
        "forceResetRunning": () => {
          console.warn("[TobyFlow] forceResetRunning: was isRunning=", isRunning, "shouldStop=", shouldStop);
          shouldStop = true;
          isRunning = false;
          isPaused = false;
          try {
            ExecutionBlocker.hide();
          } catch (_) {
          }
          try {
            FloatingTracker.hide?.();
          } catch (_) {
          }
          setTimeout(() => {
            if (!isRunning) shouldStop = false;
          }, 50);
          return { success: true, reset: true };
        },
        "getFailedPrompts": () => {
          return { failedPrompts };
        },
        "clearFailedPrompts": () => {
          failedPrompts = [];
          return { success: true };
        },
        "getThumbnailsByIds": () => {
          const fileIds = message.fileIds || [];
          const results = {};
          for (const fileId of fileIds) {
            const tile = _getTileById(fileId);
            if (!tile) continue;
            const img = tile.querySelector("img");
            const video = _q("tile_video", tile);
            const fileName = extractFileName(tile);
            const flowInfo = extractFlowFileInfo(tile);
            const isVideoByAlt = img?.alt?.toLowerCase().includes("video");
            if (video) {
              const videoUrl = extractVideoUrl(tile);
              results[fileId] = {
                thumbnail: video.poster || video.src || "",
                type: "video",
                ...fileName && { file_name: fileName },
                ...flowInfo && { file_id: flowInfo.file_id },
                ...videoUrl && { video_url: videoUrl }
                // Include video_url for Telegram/download
              };
            } else if (isVideoByAlt && img?.src && !img.src.includes("chrome-extension")) {
              results[fileId] = {
                thumbnail: img.src,
                type: "video",
                video_url: img.src,
                // Fallback to img src
                ...fileName && { file_name: fileName },
                ...flowInfo && { file_id: flowInfo.file_id }
              };
            } else if (img?.src && !img.src.includes("chrome-extension")) {
              results[fileId] = { thumbnail: img.src, type: "image", ...fileName && { file_name: fileName }, ...flowInfo && { file_id: flowInfo.file_id } };
            }
          }
          return { results };
        },
        "correctStaleFileIds": async () => {
          const idToUrlMap = message.idToUrlMap || {};
          const fileNameMap = message.fileNameMap || {};
          const fileIdMap = message.fileIdMap || {};
          const oldIds = Object.keys(idToUrlMap);
          const fileNameOnlyIds = Object.keys(fileNameMap).filter((id) => !idToUrlMap[id]);
          const allIds = [.../* @__PURE__ */ new Set([...oldIds, ...fileNameOnlyIds])];
          if (allIds.length === 0) return { corrections: {} };
          function scanByFileName(idsToCheck) {
            const corrections2 = {};
            const fnMap = {};
            for (const id of idsToCheck) {
              if (fileNameMap[id]) fnMap[id] = fileNameMap[id];
            }
            if (Object.keys(fnMap).length === 0) return corrections2;
            const fnToTileId = /* @__PURE__ */ new Map();
            const allTiles = document.querySelectorAll(_getTileSelectorString());
            allTiles.forEach((tile) => {
              const tileId = tile.dataset.tileId;
              if (!tileId) return;
              const fn = extractFileName(tile);
              if (fn) fnToTileId.set(fn, tileId);
            });
            for (const oldId of idsToCheck) {
              const savedFn = fnMap[oldId];
              if (!savedFn) continue;
              const newId = fnToTileId.get(savedFn);
              if (newId && newId !== oldId) {
                corrections2[oldId] = newId;
              }
            }
            return corrections2;
          }
          function normalizeMediaUrl(url) {
            if (!url || typeof url !== "string") return "";
            const urlPat = _getMediaUrlPattern();
            if (urlPat && url.includes(urlPat)) {
              try {
                const urlObj = new URL(url, window.location.origin);
                const name = urlObj.searchParams.get("name");
                const input = urlObj.searchParams.get("input");
                if (name) return urlObj.pathname + "?name=" + name;
                if (input) {
                  try {
                    const parsed = JSON.parse(decodeURIComponent(input));
                    const json = parsed?.json || parsed?.["0"]?.json || parsed;
                    if (json?.name) return urlObj.pathname + "?name=" + json.name;
                  } catch (e) {
                  }
                }
              } catch (e) {
              }
            }
            return url.split("=")[0];
          }
          function scanByThumbnailUrl(idsToCheck) {
            const corrections2 = {};
            const crossProjectIds = [];
            const urlToTileData = /* @__PURE__ */ new Map();
            const allTiles = document.querySelectorAll(_getTileSelectorString());
            allTiles.forEach((tile) => {
              const tileId = tile.dataset.tileId;
              if (!tileId) return;
              const img = tile.querySelector("img");
              const video = _q("tile_video", tile);
              const src = img?.src || video?.poster || video?.src || "";
              if (src && !src.includes("chrome-extension") && !src.startsWith("data:")) {
                const normalized = normalizeMediaUrl(src);
                const tileFn = extractFileName(tile);
                urlToTileData.set(normalized, { tileId, file_name: tileFn });
              }
            });
            for (const oldId of idsToCheck) {
              const savedUrl = idToUrlMap[oldId];
              if (!savedUrl) continue;
              const normalizedSaved = normalizeMediaUrl(savedUrl);
              const tileData = urlToTileData.get(normalizedSaved);
              if (!tileData || tileData.tileId === oldId) continue;
              const newId = tileData.tileId;
              const savedFn = fileNameMap[oldId];
              const tileFn = tileData.file_name;
              if (savedFn && tileFn && savedFn !== tileFn) {
                console.warn(`[TobyFlow] [T\u1EA7ng 2] Cross-project collision detected: oldId=${oldId.substring(0, 20)}... savedFn=${savedFn.substring(0, 20)}... vs tileFn=${tileFn.substring(0, 20)}...`);
                crossProjectIds.push(oldId);
                continue;
              }
              if (savedFn && !tileFn) {
                console.warn(`[TobyFlow] [T\u1EA7ng 2] Skipping correction: savedFn=${savedFn.substring(0, 20)}... but tile has no file_name yet`);
                continue;
              }
              corrections2[oldId] = newId;
            }
            return { corrections: corrections2, crossProjectIds };
          }
          function validateTileIdWithFileName(tileId, savedFileName) {
            if (!savedFileName) return true;
            const tile = _getTileById(tileId);
            if (!tile) return false;
            const currentFileName = extractFileName(tile);
            if (!currentFileName) return true;
            return currentFileName === savedFileName;
          }
          if (!_selectorConfigReady) {
            console.log("[TobyFlow] correctStaleFileIds: config not ready, waiting...");
            for (let i = 0; i < 15; i++) {
              await sleep(200);
              if (_selectorConfigReady) break;
            }
          }
          _tileSelectorCache = null;
          let _selector = _getTileSelectorString();
          const _rawTiles = document.querySelectorAll("[data-tile-id]");
          console.log(`[TobyFlow] correctStaleFileIds DEBUG: selector="${_selector}", rawTiles=${_rawTiles.length}, URL=${location.href.substring(0, 60)}`);
          const totalTiles = _selector ? document.querySelectorAll(_selector).length : 0;
          const validIds = [];
          const needsCorrectionIds = [];
          for (const id of allIds) {
            const tile = _getTileById(id);
            if (tile) {
              const savedFn = fileNameMap[id];
              if (validateTileIdWithFileName(id, savedFn)) {
                validIds.push(id);
              } else {
                console.log(`[TobyFlow] Cross-project detected: tile_id ${id.substring(0, 20)}... exists but file_name mismatch`);
                needsCorrectionIds.push(id);
              }
            } else {
              needsCorrectionIds.push(id);
            }
          }
          console.log(`[TobyFlow] correctStaleFileIds: ${allIds.length} IDs check | ${validIds.length} valid | ${needsCorrectionIds.length} need correction | ${totalTiles} tiles tr\xEAn DOM`);
          if (needsCorrectionIds.length === 0) return { corrections: {} };
          let corrections = {};
          for (const oldId of needsCorrectionIds) {
            const savedFileId = fileIdMap[oldId];
            if (!savedFileId) continue;
            const tile = findTileByFileId(savedFileId);
            if (tile) {
              const newTileId = tile.dataset.tileId;
              if (newTileId && newTileId !== oldId) {
                corrections[oldId] = newTileId;
              }
            }
          }
          const tier0Count = Object.keys(corrections).length;
          if (tier0Count > 0) {
            console.log(`[TobyFlow] [T\u1EA7ng 0 file_id]: ${tier0Count}/${needsCorrectionIds.length} corrected`);
          }
          const afterTier0 = needsCorrectionIds.filter((id) => !corrections[id]);
          const fnCorrections = scanByFileName(afterTier0);
          const fnCount = Object.keys(fnCorrections).length;
          if (fnCount > 0) {
            Object.assign(corrections, fnCorrections);
            console.log(`[TobyFlow] [T\u1EA7ng 1 file_name]: ${fnCount}/${afterTier0.length} corrected`);
          }
          let uncorrected = needsCorrectionIds.filter((id) => !corrections[id]);
          let allCrossProjectIds = [];
          if (uncorrected.length > 0) {
            const urlResult = scanByThumbnailUrl(uncorrected);
            const urlCorrections = urlResult.corrections;
            const urlCrossProject = urlResult.crossProjectIds || [];
            const urlCount = Object.keys(urlCorrections).length;
            if (urlCount > 0) {
              Object.assign(corrections, urlCorrections);
              console.log(`[TobyFlow] [T\u1EA7ng 2 thumbnail_url]: ${urlCount}/${uncorrected.length} corrected`);
            }
            if (urlCrossProject.length > 0) {
              allCrossProjectIds.push(...urlCrossProject);
              console.log(`[TobyFlow] [T\u1EA7ng 2 cross-project]: ${urlCrossProject.length} detected`);
            }
            uncorrected = uncorrected.filter((id) => !corrections[id] && !urlCrossProject.includes(id));
          }
          if (uncorrected.length > 0 && !message.skipZoomScan) {
            console.log(`[TobyFlow] [T\u1EA7ng 3]: c\xF2n ${uncorrected.length} IDs ch\u01B0a match, g\u1ECDi ensureFlowTilesLoaded(targets)...`);
            const targetFns = [...new Set(uncorrected.map((id) => fileNameMap[id]).filter(Boolean))];
            const found = await ensureFlowTilesLoaded(false, targetFns) || {};
            for (const oldId of uncorrected) {
              const fn = fileNameMap[oldId];
              if (fn && found[fn] && found[fn] !== oldId) corrections[oldId] = found[fn];
            }
            const tilesAfterLoad = document.querySelectorAll(_getTileSelectorString()).length;
            console.log(`[TobyFlow] [T\u1EA7ng 3]: sau ensureFlowTilesLoaded: ${tilesAfterLoad} tiles, capture ${Object.keys(found).length}/${targetFns.length} target`);
            uncorrected = uncorrected.filter((id) => !corrections[id]);
            const retryFn = scanByFileName(uncorrected);
            Object.assign(corrections, retryFn);
            const stillMissing = uncorrected.filter((id) => !corrections[id] && !retryFn[id]);
            if (stillMissing.length > 0) {
              const retryUrlResult = scanByThumbnailUrl(stillMissing);
              Object.assign(corrections, retryUrlResult.corrections);
              if (retryUrlResult.crossProjectIds?.length > 0) {
                allCrossProjectIds.push(...retryUrlResult.crossProjectIds);
              }
            }
            const finalUncorrected = uncorrected.filter((id) => !corrections[id]);
            console.log(`[TobyFlow] [T\u1EA7ng 3] retry: ${uncorrected.length - finalUncorrected.length} th\xEAm | ${finalUncorrected.length} v\u1EABn missing`);
          }
          allCrossProjectIds = [...new Set(allCrossProjectIds)];
          console.log(`[TobyFlow] correctStaleFileIds K\u1EBET QU\u1EA2: ${Object.keys(corrections).length}/${needsCorrectionIds.length} corrected, ${allCrossProjectIds.length} cross-project`);
          for (const [oldId, newId] of Object.entries(corrections)) {
            console.log(`[TobyFlow]   ${oldId.substring(0, 30)}... \u2192 ${newId.substring(0, 30)}...`);
          }
          if (allCrossProjectIds.length > 0) {
            console.log(`[TobyFlow] Cross-project IDs:`, allCrossProjectIds.map((id) => id.substring(0, 25) + "..."));
          }
          return { corrections, crossProjectIds: allCrossProjectIds };
        },
        "findTileByFileName": () => {
          const fileName = message.fileName;
          if (!fileName) return { tileId: null };
          const tiles = document.querySelectorAll(_getTileSelectorString());
          for (const tile of tiles) {
            const fn = extractFileName(tile);
            if (fn === fileName) {
              return { tileId: tile.dataset.tileId };
            }
          }
          return { tileId: null };
        },
        "prepareFlowForScan": async () => {
          await ensureFlowTilesLoaded();
          const tileCount = document.querySelectorAll(_getTileSelectorString()).length;
          return { success: true, tileCount };
        },
        "applyFlowPageSettings": async () => {
          if (isRunning) {
            return { success: true, applied: _flowSettingsApplied, skipped: "isRunning" };
          }
          await ensureFlowSettingsApplied();
          return { success: true, applied: _flowSettingsApplied };
        },
        "scanFlowImages": async () => {
          if (!_selectorConfigReady) {
            console.log("[TobyFlow] scanFlowImages: config not ready, waiting...");
            for (let i = 0; i < 15; i++) {
              await sleep(200);
              if (_selectorConfigReady) break;
            }
            if (!_selectorConfigReady) {
              console.warn("[TobyFlow] scanFlowImages: timeout waiting for config");
              return { images: [], error: "selector_config_timeout" };
            }
          }
          _tileSelectorCache = null;
          const images = [];
          const seenIds = /* @__PURE__ */ new Set();
          const tileSelector = _getTileSelectorString();
          console.log(`[TobyFlow] scanFlowImages: selector="${tileSelector}", deep=${message.deep === true}`);
          const _scanCurrent = () => {
            const tiles = document.querySelectorAll(tileSelector || "[data-tile-id]");
            tiles.forEach((tile) => {
              const tileId = tile.dataset.tileId;
              if (!tileId || seenIds.has(tileId)) return;
              const img = tile.querySelector("img");
              const video = _q("tile_video", tile);
              const fileName = extractFileName(tile);
              const isVideoByAlt = img?.alt?.toLowerCase().includes("video");
              if (video) {
                seenIds.add(tileId);
                const flowInfoV = extractFlowFileInfo(tile);
                const videoSrc = video.src || video.querySelector("source")?.src || "";
                let vThumb = video.poster || "";
                if (!vThumb && img && img.src && !img.src.includes("chrome-extension")) vThumb = img.src;
                if (!vThumb) vThumb = videoSrc;
                images.push({ fileId: tileId, thumbnail: vThumb, source: "flow", type: "video", ...videoSrc && { video_url: videoSrc }, ...fileName && { file_name: fileName }, ...flowInfoV && { file_id: flowInfoV.file_id, project_id: flowInfoV.project_id } });
              } else if (isVideoByAlt && img && img.src && !img.src.includes("chrome-extension")) {
                seenIds.add(tileId);
                const flowInfoV = extractFlowFileInfo(tile);
                images.push({ fileId: tileId, thumbnail: img.src, source: "flow", type: "video", video_url: img.src, ...fileName && { file_name: fileName }, ...flowInfoV && { file_id: flowInfoV.file_id, project_id: flowInfoV.project_id } });
              } else if (img && img.src && !img.src.includes("chrome-extension")) {
                seenIds.add(tileId);
                const flowInfo = extractFlowFileInfo(tile);
                images.push({ fileId: tileId, thumbnail: img.src, source: "flow", type: "image", ...fileName && { file_name: fileName }, ...flowInfo && { file_id: flowInfo.file_id, project_id: flowInfo.project_id } });
              }
            });
          };
          _scanCurrent();
          if (message.deep === true) {
            const _inSession = !!(window._tobyFlowZoomSession && window._tobyFlowZoomSession.armed);
            const _bzOrig = _inSession ? null : await _getBrowserZoom();
            const _useBz = !_inSession && _bzOrig != null;
            const originalCssZoom = document.body.style.zoom || "1";
            const _scCfg = _getDynamicSelector("flow_scroll_container");
            const _scClosestAttr = _scCfg?.closest_attribute || '[style*="overflow"]';
            const sc = _q("flow_scroll_container")?.closest(_scClosestAttr) || document.documentElement;
            try {
              if (_inSession) await _ensureZoomSessionActive();
              else if (_useBz) await _setBrowserZoom(0.3);
              else document.body.style.zoom = "0.5";
              await sleep(800);
              const step = Math.max(Math.floor((window.innerHeight || 800) * 0.8), 500);
              const MAX_STEPS = 200;
              let stagnant = 0, prevCount = images.length;
              for (let pos = 0, n = 0; pos <= sc.scrollHeight + step && n < MAX_STEPS; pos += step, n++) {
                sc.scrollTop = pos;
                await sleep(250);
                _scanCurrent();
                if (images.length === prevCount) {
                  if (++stagnant >= 3) break;
                } else {
                  stagnant = 0;
                  prevCount = images.length;
                }
              }
              sc.scrollTop = 0;
            } finally {
              if (!_inSession) {
                if (_useBz) await _setBrowserZoom(_bzOrig);
                else document.body.style.zoom = originalCssZoom;
              }
              await sleep(200);
            }
            console.log(`[TobyFlow] scanFlowImages deep: t\xEDch lu\u1EF9 ${images.length} \u1EA3nh`);
          }
          if (images.length === 0) {
            console.log("[TobyFlow] scanFlowImages: fallback to tile_image scan");
            const allImgs = _qa("tile_image");
            allImgs.forEach((img, i) => {
              const src = img.src;
              if (!src || src.includes("chrome-extension") || img.naturalWidth < 50) return;
              const parentTile = img.closest(tileSelector || "[data-tile-id]");
              const fileId = parentTile?.dataset?.tileId;
              if (!fileId) {
                console.warn("[TobyFlow] scanFlowImages: skipping img without tile ID");
                return;
              }
              if (seenIds.has(fileId)) return;
              seenIds.add(fileId);
              images.push({ fileId, thumbnail: src, source: "flow", type: "image" });
            });
          }
          return { images };
        },
        "uploadFilesToFlow": async () => {
          const filesData = message.filesData || [];
          console.log("[uploadFilesToFlow] handler called with", filesData.length, "file(s), url:", window.location.href.substring(0, 80));
          if (filesData.length === 0) return { tileIds: [], orderedTileIds: [] };
          if (!/\/project\//i.test(location.href)) {
            console.warn(
              "[uploadFilesToFlow] NOT on /project/ \u2014 tile inject s\u1EBD fail. url=",
              location.href.slice(0, 120)
            );
          }
          let _uploadOwnedBlocker = false;
          const _uploadStartedAt = Date.now();
          try {
            if (!ExecutionBlocker._blocking) {
              ExecutionBlocker._pipelineOwned = true;
              ExecutionBlocker.show();
              _uploadOwnedBlocker = true;
            } else if (!ExecutionBlocker._pipelineOwned) {
              ExecutionBlocker._pipelineOwned = true;
              _uploadOwnedBlocker = true;
            }
            try {
              FloatingTracker.updateLegacy({
                status: "running",
                current: 0,
                total: filesData.length,
                owner: "bridge-upload",
                label: "Upload \u2192 Flow",
                startedAt: _uploadStartedAt,
                items: filesData.map((fd, i) => ({
                  text: (fd?.name || `file-${i + 1}`).slice(0, 40),
                  status: "running"
                }))
              });
            } catch (_) {
            }
          } catch (ebErr) {
            console.warn("[uploadFilesToFlow] show blocker failed:", ebErr?.message || ebErr);
          }
          const _endUploadUi = (delayMs = 2e3) => {
            if (!_uploadOwnedBlocker) return;
            _uploadOwnedBlocker = false;
            setTimeout(() => {
              try {
                ExecutionBlocker._pipelineOwned = false;
                ExecutionBlocker.hide();
              } catch (_) {
              }
              try {
                FloatingTracker.hide();
              } catch (_) {
              }
            }, delayMs);
          };
          const _findFlowFileInputs = () => {
            const sels = _getDynamicSelector("file_input")?.selectors || [
              'input[type="file"][accept*="image"]',
              'input[type="file"]'
            ];
            const out = [];
            const seen = /* @__PURE__ */ new Set();
            for (const s of sels) {
              try {
                document.querySelectorAll(s).forEach((el) => {
                  if (!seen.has(el)) {
                    seen.add(el);
                    out.push(el);
                  }
                });
              } catch (_) {
              }
            }
            if (out.length === 0) {
              document.querySelectorAll('input[type="file"]').forEach((el) => out.push(el));
            }
            return out;
          };
          const _clickFlowAddUploadButton = () => {
            const cfgIcon = _getDynamicSelector("add_button")?.icon_text;
            const buttons = document.querySelectorAll('button, [role="button"]');
            let best = null;
            let bestScore = -1;
            for (const btn of buttons) {
              const r = btn.getBoundingClientRect?.();
              if (!r || r.width < 8 || r.height < 8) continue;
              const fullTxt = (btn.textContent || "").replace(/\s+/g, " ").trim();
              const fullLow = fullTxt.toLowerCase();
              if (/dự án mới|new project|create project/i.test(fullLow) && r.top < 120) continue;
              if (/xem hình ảnh|xem các cảnh|view images|view scenes/i.test(fullLow)) continue;
              const icon = btn.querySelector('i.google-symbols, i[class*="symbol"], span.material-symbols-outlined');
              const iconTxt = (icon?.textContent || "").trim();
              const aria = (btn.getAttribute("aria-label") || "").toLowerCase();
              const popup = (btn.getAttribute("aria-haspopup") || "").toLowerCase();
              let score = 0;
              if (/thêm nội dung nghe nhìn|add (audio.?visual|media|content)|nội dung nghe nhìn/i.test(fullTxt + " " + aria)) {
                score += 100;
              }
              if (iconTxt === "add" && popup === "menu") score += 80;
              if (iconTxt === "drive_folder_upload") score += 70;
              if (iconTxt === "add_2" && (popup === "dialog" || /tạo|create/i.test(fullTxt))) score += 55;
              if (iconTxt === "add_photo_alternate" || iconTxt === "upload" || iconTxt === "perm_media") score += 50;
              if (cfgIcon && iconTxt === String(cfgIcon).trim()) score += 40;
              if (/upload|tải lên|thêm ảnh|add image|media|file|photo/i.test(aria + " " + fullLow)) score += 25;
              if (popup === "menu") score += 20;
              if (popup === "dialog") score += 10;
              if (r.top < 100 && iconTxt === "add") score += 30;
              if (r.top > (window.innerHeight || 800) * 0.7 && iconTxt === "add_2") score += 25;
              if (score > bestScore) {
                bestScore = score;
                best = btn;
              }
            }
            if (best && bestScore >= 40) {
              const iconTxt = (best.querySelector("i")?.textContent || "").trim();
              console.log(
                "[uploadFilesToFlow] click add/upload btn score=",
                bestScore,
                "icon=",
                iconTxt,
                "text=",
                (best.textContent || "").replace(/\s+/g, " ").trim().slice(0, 40)
              );
              try {
                simulateClick(best);
              } catch (_) {
                try {
                  best.click();
                } catch (__) {
                }
              }
              return true;
            }
            console.warn("[uploadFilesToFlow] add/upload button not found (score max=", bestScore, ")");
            return false;
          };
          const _clickUploadMenuItem = () => {
            const patterns = [
              /tải lên|upload|upload image|upload media|thêm ảnh|add image|from device|từ thiết bị|máy tính|computer|photo|hình ảnh|media file|nội dung nghe nhìn|tải.*lên|from computer|choose file/i
            ];
            const items = document.querySelectorAll(
              '[role="menuitem"], [role="option"], [data-radix-collection-item], button, [role="button"], li, div[class*="menu"] *'
            );
            for (const el of items) {
              const t = (el.textContent || "").replace(/\s+/g, " ").trim();
              if (!t || t.length > 100) continue;
              const r = el.getBoundingClientRect?.();
              if (!r || r.width < 8 || r.height < 8) continue;
              if (patterns.some((p) => p.test(t))) {
                console.log("[uploadFilesToFlow] click menu item:", t.slice(0, 50));
                try {
                  simulateClick(el);
                } catch (_) {
                  try {
                    el.click();
                  } catch (__) {
                  }
                }
                return true;
              }
            }
            for (const el of items) {
              const icon = (el.querySelector?.("i, .material-symbols-outlined")?.textContent || "").trim();
              if (["upload", "drive_folder_upload", "add_photo_alternate", "file_upload", "photo"].includes(icon)) {
                console.log("[uploadFilesToFlow] click menu icon:", icon);
                try {
                  simulateClick(el);
                } catch (_) {
                  try {
                    el.click();
                  } catch (__) {
                  }
                }
                return true;
              }
            }
            return false;
          };
          const _pasteImageToFlow = async (file) => {
            const editor = _q("slate_editor") || document.querySelector('[data-slate-editor="true"]') || document.querySelector('[contenteditable="true"]') || document.body;
            try {
              editor.focus?.();
            } catch (_) {
            }
            const dt = new DataTransfer();
            dt.items.add(file);
            try {
              const pasteEv = new ClipboardEvent("paste", {
                bubbles: true,
                cancelable: true,
                composed: true
              });
              Object.defineProperty(pasteEv, "clipboardData", { value: dt, configurable: true });
              const ok = editor.dispatchEvent(pasteEv);
              console.log("[uploadFilesToFlow] paste image event \u2192", (editor.tagName || "?").toLowerCase(), "defaultPrevented=", pasteEv.defaultPrevented, "ok=", ok);
            } catch (e) {
              console.warn("[uploadFilesToFlow] paste event fail:", e?.message);
            }
            try {
              const ie = new InputEvent("input", {
                bubbles: true,
                cancelable: true,
                inputType: "insertFromPaste",
                data: null
              });
              editor.dispatchEvent(ie);
            } catch (_) {
            }
            return true;
          };
          const _dropImageToFlow = async (file) => {
            const dt = new DataTransfer();
            dt.items.add(file);
            const targets = [
              _q("slate_editor"),
              document.querySelector('[data-slate-editor="true"]'),
              document.querySelector('[contenteditable="true"]'),
              document.querySelector('[class*="drop"], [class*="upload"], [data-dropzone]'),
              document.querySelector("main"),
              document.querySelector('[role="main"]'),
              document.body
            ].filter(Boolean);
            const seen = /* @__PURE__ */ new Set();
            const unique = [];
            for (const t of targets) {
              if (seen.has(t)) continue;
              seen.add(t);
              unique.push(t);
            }
            const fire = (type, dropTarget) => {
              let e;
              try {
                e = new DragEvent(type, { bubbles: true, cancelable: true, composed: true, dataTransfer: dt });
              } catch (_) {
                e = new Event(type, { bubbles: true, cancelable: true });
              }
              try {
                if (!e.dataTransfer) Object.defineProperty(e, "dataTransfer", { value: dt });
              } catch (_) {
              }
              dropTarget.dispatchEvent(e);
            };
            let ok = false;
            for (const dropTarget of unique) {
              try {
                fire("dragenter", dropTarget);
                fire("dragover", dropTarget);
                fire("drop", dropTarget);
                console.log(
                  `[uploadFilesToFlow] image drop on <${(dropTarget.tagName || "?").toLowerCase()}> class="${String(dropTarget.className || "").slice(0, 40)}" file="${file.name}"`
                );
                ok = true;
                break;
              } catch (e) {
                console.warn("[uploadFilesToFlow] image drop error:", e?.message);
              }
            }
            return ok;
          };
          const _setFilesOnInput = (input, dataTransfer) => {
            try {
              const nativeFilesSetter = Object.getOwnPropertyDescriptor(
                window.HTMLInputElement.prototype,
                "files"
              )?.set;
              if (nativeFilesSetter) {
                nativeFilesSetter.call(input, dataTransfer.files);
              } else {
                input.files = dataTransfer.files;
              }
            } catch (_) {
              try {
                input.files = dataTransfer.files;
              } catch (__) {
              }
            }
            try {
              input.dispatchEvent(new Event("input", { bubbles: true }));
              input.dispatchEvent(new Event("change", { bubbles: true }));
            } catch (_) {
            }
            try {
              const keys = Object.keys(input);
              const propsKey = keys.find((k) => k.startsWith("__reactProps$"));
              const fiberKey = keys.find((k) => k.startsWith("__reactFiber$"));
              const fakeEv = {
                target: input,
                currentTarget: input,
                type: "change",
                bubbles: true,
                cancelable: true,
                preventDefault() {
                },
                stopPropagation() {
                },
                isTrusted: false,
                nativeEvent: new Event("change", { bubbles: true })
              };
              let reacted = false;
              if (propsKey && typeof input[propsKey]?.onChange === "function") {
                input[propsKey].onChange(fakeEv);
                reacted = true;
              }
              let p = input.parentElement;
              for (let depth = 0; depth < 5 && p && !reacted; depth++) {
                const pk = Object.keys(p).find((k) => k.startsWith("__reactProps$"));
                if (pk && typeof p[pk]?.onChange === "function") {
                  p[pk].onChange({ ...fakeEv, currentTarget: p });
                  reacted = true;
                  break;
                }
                p = p.parentElement;
              }
              if (!reacted && fiberKey) {
                let fiber = input[fiberKey];
                for (let d = 0; d < 8 && fiber; d++) {
                  const mp = fiber.memoizedProps || fiber.pendingProps;
                  if (mp && typeof mp.onChange === "function") {
                    mp.onChange(fakeEv);
                    reacted = true;
                    break;
                  }
                  fiber = fiber.return;
                }
              }
              console.log(
                "[uploadFilesToFlow] set files",
                "accept=",
                input.getAttribute("accept") || "(none)",
                "files=",
                input.files?.length || 0,
                "reactOnChange=",
                reacted
              );
            } catch (re) {
              console.warn("[uploadFilesToFlow] React onChange fail:", re?.message || re);
            }
          };
          let flowInputs = _findFlowFileInputs();
          if (flowInputs.length === 0) {
            _clickFlowAddUploadButton();
            await sleep(400);
            const maxWaitMs = 1e4;
            const pollInterval = 200;
            let waited = 0;
            while (waited < maxWaitMs && flowInputs.length === 0) {
              await sleep(pollInterval);
              waited += pollInterval;
              flowInputs = _findFlowFileInputs();
              if (waited === 2e3 || waited === 5e3) _clickFlowAddUploadButton();
            }
            if (flowInputs.length === 0) {
              console.warn("[uploadFilesToFlow] No file input after " + maxWaitMs + "ms \u2014 s\u1EBD d\xF9ng drag-drop fallback per file");
            } else {
              console.log("[uploadFilesToFlow] Found " + flowInputs.length + " file input(s) after " + waited + "ms wait");
            }
          } else {
            console.log("[uploadFilesToFlow] Found " + flowInputs.length + " file input(s) immediately");
          }
          const orderedTileIds = [];
          const tileDetails = [];
          let consentConfirmed = false;
          for (let fileIdx = 0; fileIdx < filesData.length; fileIdx++) {
            const fd = filesData[fileIdx];
            const existingTiles = getUniqueTileIds(true);
            let rawB64 = String(fd.base64 || "");
            if (rawB64.includes(",")) rawB64 = rawB64.split(",")[1];
            rawB64 = rawB64.replace(/\s+/g, "");
            if (!rawB64 || rawB64.length < 100) {
              console.warn("[uploadFilesToFlow] base64 r\u1ED7ng/qu\xE1 ng\u1EAFn idx=", fileIdx, "len=", rawB64.length);
              continue;
            }
            let binary;
            try {
              binary = atob(rawB64);
            } catch (atobErr) {
              console.warn("[uploadFilesToFlow] atob fail:", atobErr?.message || atobErr);
              continue;
            }
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            const file = new File([bytes], fd.name || `upload-${fileIdx + 1}.png`, {
              type: fd.type || "image/png"
            });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            const isVideoFile = (fd.type || "").startsWith("video/") || /\.(mp4|mov|webm|avi|mkv|m4v)$/i.test(fd.name || "");
            if (isVideoFile) {
              await _dropVideoToFlow(file);
            } else {
              console.log(
                "[uploadFilesToFlow] v5-prod inject (labs.toby.vn copy), baselineTiles=",
                existingTiles.length,
                "url=",
                location.href.slice(0, 90),
                "file=",
                fd.name,
                "type=",
                fd.type || "image/png",
                "b64len=",
                (fd.base64 || "").length
              );
              flowInputs = _findFlowFileInputs();
              if (flowInputs.length === 0) {
                _clickFlowAddUploadButton();
                await sleep(500);
                _clickUploadMenuItem();
                await sleep(400);
                for (let w = 0; w < 20 && flowInputs.length === 0; w++) {
                  await sleep(200);
                  flowInputs = _findFlowFileInputs();
                }
              }
              const targetInputs = flowInputs.filter((input) => {
                const accept = (input.getAttribute("accept") || "").toLowerCase();
                if (!accept) return true;
                const acceptsVideo = accept.includes("video") || /(mp4|mov|webm|avi|mkv|m4v)/.test(accept);
                const acceptsImage = accept.includes("image") || /(png|jpe?g|webp|gif|heic|heif|avif)/.test(accept);
                return acceptsImage || !acceptsVideo;
              });
              const dispatchInputs = targetInputs.length > 0 ? targetInputs : flowInputs;
              let injected = 0;
              for (const input of dispatchInputs) {
                try {
                  _setFilesOnInput(input, dataTransfer);
                  injected++;
                } catch (e) {
                  console.warn("[uploadFilesToFlow] set files fail:", e?.message);
                }
              }
              console.log(
                "[uploadFilesToFlow] prod-inject",
                injected,
                "/",
                dispatchInputs.length,
                "accepts=",
                dispatchInputs.slice(0, 4).map((i) => i.getAttribute("accept") || "(none)")
              );
              try {
                document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
              } catch (_) {
              }
              await sleep(300);
            }
            let newTileId = null;
            let processingTileId = null;
            let processingSeenAt = 0;
            let waitTime = 0;
            const maxWait = 45e3;
            const checkInterval = 500;
            const processingAcceptDelay = 15e3;
            await sleep(1e3);
            waitTime += 1e3;
            let midRetryDone = false;
            while (waitTime < maxWait) {
              const uploadErr = _detectFlowUploadError();
              if (uploadErr) {
                console.warn("[uploadFilesToFlow] Flow blocked upload:", uploadErr);
                try {
                  FloatingTracker.updateLegacy({
                    status: "failed",
                    current: orderedTileIds.length,
                    total: filesData.length,
                    owner: "bridge-upload",
                    label: "Upload b\u1ECB ch\u1EB7n",
                    startedAt: _uploadStartedAt
                  });
                } catch (_) {
                }
                _endUploadUi(2500);
                return { tileIds: orderedTileIds, orderedTileIds, error: "UPLOAD_BLOCKED", errorMessage: uploadErr, blockedFile: fd.name, success: false };
              }
              if (!consentConfirmed) consentConfirmed = _clickUploadConsentModal();
              const currentTiles = getUniqueTileIds(true);
              const newTiles = currentTiles.filter((id) => !existingTiles.includes(id) && !orderedTileIds.includes(id));
              if (!midRetryDone && !isVideoFile && newTiles.length === 0 && waitTime >= 3e3) {
                midRetryDone = true;
                console.warn("[uploadFilesToFlow] no tile after 3s \u2014 retry inject ALL + menu + drop");
                _clickFlowAddUploadButton();
                await sleep(400);
                _clickUploadMenuItem();
                await sleep(400);
                const retryInputs = _findFlowFileInputs();
                const imgInputs = retryInputs.filter((input) => {
                  const accept = (input.getAttribute("accept") || "").toLowerCase();
                  if (!accept) return true;
                  const acceptsVideo = accept.includes("video");
                  const acceptsImage = accept.includes("image") || !accept;
                  return acceptsImage || !acceptsVideo;
                });
                for (const input of imgInputs.length ? imgInputs : retryInputs) {
                  try {
                    _setFilesOnInput(input, dataTransfer);
                  } catch (_) {
                  }
                }
                try {
                  document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
                } catch (_) {
                }
                await _dropImageToFlow(file);
                await _pasteImageToFlow(file);
              }
              if (newTiles.length > 0) {
                const tile = document.querySelector(`[data-tile-id="${newTiles[0]}"]`);
                if (tile) {
                  const status = detectTileStatus(tile);
                  if (status === "success") {
                    newTileId = newTiles[0];
                    break;
                  }
                  if (status === "failed") {
                    console.log("[uploadFilesToFlow] Tile failed, attempting auto-retry:", newTiles[0]);
                    const retryClicked = clickUploadRetryButton(newTiles[0]);
                    if (retryClicked) {
                      console.log("[uploadFilesToFlow] Retry button clicked, waiting for recovery...");
                      await sleep(2e3);
                      const retryTile = document.querySelector(`[data-tile-id="${newTiles[0]}"]`);
                      const retryStatus = detectTileStatus(retryTile);
                      if (retryStatus === "success") {
                        console.log("[uploadFilesToFlow] Tile recovered after retry:", newTiles[0]);
                        newTileId = newTiles[0];
                        break;
                      }
                      console.log("[uploadFilesToFlow] Tile still failed after retry, skipping:", newTiles[0]);
                    }
                    break;
                  }
                  if (!processingTileId) {
                    processingTileId = newTiles[0];
                    processingSeenAt = waitTime;
                  }
                  if (processingTileId && waitTime - processingSeenAt >= processingAcceptDelay) {
                    console.log("[uploadFilesToFlow] Tab inactive: tile stuck processing, trying to activate tab...");
                    try {
                      await new Promise((resolve) => {
                        chrome.runtime.sendMessage({ action: "ensureFlowTabActive" }, () => resolve());
                      });
                      await sleep(2e3);
                      const reCheckTile = document.querySelector(`[data-tile-id="${processingTileId}"]`);
                      const reCheckStatus = detectTileStatus(reCheckTile);
                      if (reCheckStatus === "success") {
                        console.log("[uploadFilesToFlow] Tab activated, tile now success:", processingTileId);
                        newTileId = processingTileId;
                        break;
                      } else if (reCheckStatus === "failed") {
                        console.log("[uploadFilesToFlow] Tab activated but tile failed, attempting auto-retry:", processingTileId);
                        const retryClicked = clickUploadRetryButton(processingTileId);
                        if (retryClicked) {
                          await sleep(2e3);
                          const retryTile = document.querySelector(`[data-tile-id="${processingTileId}"]`);
                          const retryStatus = detectTileStatus(retryTile);
                          if (retryStatus === "success") {
                            console.log("[uploadFilesToFlow] Tile recovered after retry:", processingTileId);
                            newTileId = processingTileId;
                            break;
                          }
                        }
                        break;
                      }
                      console.log("[uploadFilesToFlow] Tab activated but tile still processing, waiting 5s more...");
                      await sleep(5e3);
                      const finalTile = document.querySelector(`[data-tile-id="${processingTileId}"]`);
                      const finalStatus = detectTileStatus(finalTile);
                      if (finalStatus === "success") {
                        newTileId = processingTileId;
                        break;
                      }
                      console.warn("[uploadFilesToFlow] Tile still processing after tab activate + 5s wait, will timeout");
                    } catch (e) {
                      console.warn("[uploadFilesToFlow] ensureFlowTabActive failed:", e.message);
                    }
                  }
                }
              }
              await sleep(checkInterval);
              waitTime += checkInterval;
            }
            if (!newTileId && processingTileId) {
              console.warn("[uploadFilesToFlow] Timeout: tile still processing, NOT accepting:", processingTileId);
            }
            if (newTileId) {
              orderedTileIds.push(newTileId);
              const tile = _getTileById(newTileId);
              const media = tile?.querySelector("img, video");
              let fileName = extractFileName(tile);
              let thumbnailUrl = media?.src || "";
              const isValidThumbUrl = (url) => url && !url.startsWith("blob:") && !url.includes("placeholder");
              if ((!fileName || !isValidThumbUrl(thumbnailUrl)) && tile) {
                for (let fnWait = 0; fnWait < 5e3 && (!fileName || !isValidThumbUrl(thumbnailUrl)); fnWait += 500) {
                  await sleep(500);
                  const tileId = tile.dataset?.tileId;
                  if (tileId) _fileNameCache.delete(tileId);
                  fileName = extractFileName(tile);
                  const freshMedia = tile.querySelector("img, video");
                  if (freshMedia?.src) thumbnailUrl = freshMedia.src;
                }
                if (fileName) {
                  console.log("[uploadFilesToFlow] Got file_name after waiting:", fileName);
                } else {
                  console.warn("[uploadFilesToFlow] Could not get file_name for tile:", newTileId);
                }
                if (isValidThumbUrl(thumbnailUrl)) {
                  console.log("[uploadFilesToFlow] Got valid thumbnailUrl after waiting");
                } else {
                  console.warn("[uploadFilesToFlow] Could not get valid thumbnailUrl for tile:", newTileId);
                }
              }
              const flowInfo = extractFlowFileInfo(tile);
              tileDetails.push({
                id: newTileId,
                thumbnailUrl,
                ...fileName && { file_name: fileName },
                ...flowInfo && { file_id: flowInfo.file_id, project_id: flowInfo.project_id },
                originalName: fd.name,
                originalKey: fd.key
                // Fix: Track original key for correct mapping
              });
            }
            if (fileIdx < filesData.length - 1) {
              await sleep(200);
            }
          }
          const keyMapping = {};
          for (const detail of tileDetails) {
            if (detail.originalKey && detail.id) {
              keyMapping[detail.originalKey] = detail.id;
            }
          }
          const uploadOk = orderedTileIds.length > 0;
          console.log(
            "[uploadFilesToFlow] DONE ok=",
            uploadOk,
            "tiles=",
            orderedTileIds.length,
            "/",
            filesData.length,
            "url=",
            location.href.slice(0, 90)
          );
          try {
            FloatingTracker.updateLegacy({
              status: uploadOk ? "completed" : "failed",
              current: orderedTileIds.length,
              total: filesData.length,
              owner: "bridge-upload",
              label: uploadOk ? "Upload xong" : "Upload 0 tile",
              startedAt: _uploadStartedAt,
              items: orderedTileIds.map((id) => ({
                text: String(id).slice(0, 12),
                status: "completed"
              }))
            });
          } catch (_) {
          }
          _endUploadUi(uploadOk ? 1800 : 3200);
          return {
            tileIds: orderedTileIds,
            tileDetails,
            orderedTileIds,
            keyMapping,
            success: uploadOk,
            ...uploadOk ? {} : {
              error: "UPLOAD_NO_TILE",
              errorMessage: "Inject/drop kh\xF4ng t\u1EA1o tile tr\xEAn project. F5 Flow, b\u1EA5m \u2295 Th\xEAm n\u1ED9i dung, th\u1EED l\u1EA1i."
            }
          };
        },
        "downloadTileMedia": async () => {
          const tileId = message.tileId;
          const promptText = message.promptText || "flow";
          const taskName = message.taskName || null;
          const fileName = message.fileName || null;
          const resolution = message.resolution || null;
          const flowFileId = message.flowFileId || null;
          const index = message.index || null;
          const videoResolution = message.videoResolution || null;
          if (!tileId && !flowFileId) return { success: false, error: "No tileId or flowFileId" };
          try {
            const result = await downloadTileMedia(tileId, promptText, taskName, fileName, resolution, flowFileId, index, videoResolution);
            return { success: result !== false };
          } catch (e) {
            return { success: false, error: e.message };
          }
        },
        "extractTileIdentifiers": () => {
          const tileId = message.tileId;
          if (!tileId) return { fileName: null, thumbnailUrl: null };
          const tile = _getTileById(tileId);
          if (!tile) return { fileName: null, thumbnailUrl: null };
          const fileName = extractFileName(tile);
          const img = tile.querySelector("img");
          const src = img?.src || "";
          const thumbnailUrl = src && (src.startsWith("http://") || src.startsWith("https://")) && !src.startsWith("data:") && !src.startsWith("chrome-extension:") ? src : null;
          return { fileName, thumbnailUrl };
        },
        "scanGalleryTiles": () => {
          const tiles = scanGalleryTiles();
          return { tiles };
        },
        "scanFlowTiles": () => {
          const rawTiles = scanGalleryTiles();
          const tiles = rawTiles.filter((t) => t.status === "success" && t.thumbnail).map((t) => ({
            id: t.tileId,
            thumbnail: t.thumbnail,
            src: t.mediaSrc,
            type: t.mediaType,
            ...t.file_name && { file_name: t.file_name },
            ...t.file_id && { file_id: t.file_id },
            ...t.project_id && { project_id: t.project_id }
          }));
          return { tiles };
        },
        "downloadImage": async () => {
          const url = message.url;
          const filename = message.filename || `flow_${Date.now()}.png`;
          if (!url) return { success: false, error: "No URL" };
          try {
            const response = await fetch(url);
            const blob = await response.blob();
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = blobUrl;
            a.download = filename;
            a.style.display = "none";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
            return { success: true };
          } catch (e) {
            return { success: false, error: e.message };
          }
        },
        "getDownloadCounter": () => {
          return { count: getDownloadCounter() };
        },
        "checkTilesExist": () => {
          const tileIds = message.tileIds || [];
          const existing = [];
          const missing = [];
          for (const id of tileIds) {
            if (_getTileById(id)) {
              existing.push(id);
            } else {
              missing.push(id);
            }
          }
          return { existing, missing };
        },
        "checkFilesExist": () => {
          const fileNames = message.fileNames || [];
          const found = {};
          const tiles = document.querySelectorAll(_getTileSelectorString());
          const domFileNames = [];
          for (const tile of tiles) {
            const fn = extractFileName(tile);
            if (fn) {
              domFileNames.push(fn);
              if (fileNames.includes(fn)) found[fn] = true;
            }
          }
          const existing = fileNames.filter((fn) => found[fn]);
          const missing = fileNames.filter((fn) => !found[fn]);
          console.log(`[REUPLOAD_AUDIT] checkFilesExist: input=${JSON.stringify(fileNames)}, tiles=${tiles.length}, dom_fns_count=${domFileNames.length}, existing=${JSON.stringify(existing)}, missing=${JSON.stringify(missing)}`);
          if (missing.length > 0 && domFileNames.length > 0) {
            console.log(`[REUPLOAD_AUDIT] checkFilesExist DOM file_names sample (first 5): ${JSON.stringify(domFileNames.slice(0, 5))}`);
          }
          return { existing, missing };
        },
        // BUG FIX 2026-06-05 (Fix D2): expose ensureFlowTilesLoaded ra cho popup/sidebar gọi.
        // Trước: WorkflowExecutor.js Fix 4 + Fix D gọi window.MessageBridge.ensureFlowTilesLoaded()
        // nhưng method không tồn tại trên MessageBridge → silent fail → checkFilesExist query DOM
        // empty (vừa switch tab) → upstream Image tiles "missing" → reupload toàn bộ.
        // Sau: dùng MessageBridge.sendToContentScript('ensureFlowTilesLoaded') → handler này
        // zoom-out + scroll buộc Flow lazy-load tiles vào DOM TRƯỚC khi checkFilesExist.
        "ensureFlowTilesLoaded": async () => {
          if (typeof ensureFlowTilesLoaded !== "function") {
            return { success: false, error: "ensureFlowTilesLoaded not defined" };
          }
          try {
            const force = message.force === true;
            const targetFileNames = Array.isArray(message.targetFileNames) ? message.targetFileNames : [];
            const found = await ensureFlowTilesLoaded(force, targetFileNames);
            const tilesCount = document.querySelectorAll(_getTileSelectorString()).length;
            return { success: true, tilesCount, forced: force, found: found || {} };
          } catch (e) {
            return { success: false, error: e.message };
          }
        },
        // Zoom session: arm khi bắt đầu batch multi-prompt (chưa zoom — chỉ zoom khi có ref xa cần load).
        "beginFlowZoomSession": async () => {
          const factor = typeof message.factor === "number" ? message.factor : 0.3;
          const hold = message.hold === true;
          const _cur = window._tobyFlowZoomSession;
          if (_cur?.armed && _cur.factor === factor) {
            if (hold) _cur.refs = (_cur.refs || 0) + 1;
            return { ok: true, kept: true, refs: _cur.refs };
          }
          if (_cur?.active) {
            try {
              await _endZoomSession();
            } catch (_) {
            }
          }
          window._tobyFlowZoomSession = { armed: true, active: false, factor, refs: hold ? 1 : 0, mode: null, original: null, originalCss: null };
          console.log(`[TobyFlow] zoom session: armed (factor=${factor}, hold=${hold})`);
          return { ok: true };
        },
        "endFlowZoomSession": async () => {
          const s = window._tobyFlowZoomSession;
          if (!s) return { ok: true };
          if (message.force) {
            s.refs = 0;
            try {
              await _endZoomSession();
            } catch (_) {
            }
            return { ok: true };
          }
          if (message.release) {
            s.refs = Math.max(0, (s.refs || 0) - 1);
          }
          if ((s.refs || 0) > 0) return { ok: true, kept: true, refs: s.refs };
          try {
            await _endZoomSession();
          } catch (_) {
          }
          return { ok: true };
        },
        "fetchImageAsBase64": async () => {
          const url = message.url;
          if (!url || !url.startsWith("http")) return { success: false, error: "Invalid URL" };
          try {
            const resp = await fetch(url);
            if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
            const contentType = resp.headers.get("content-type") || "";
            if (!contentType.startsWith("image/")) return { success: false, error: `Not image: ${contentType}` };
            const buffer = await resp.arrayBuffer();
            const bytes = new Uint8Array(buffer);
            let binary = "";
            for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
            return { success: true, base64: btoa(binary), contentType };
          } catch (err) {
            return { success: false, error: err.message };
          }
        },
        "getProjectContext": () => {
          return {
            projectId: getCurrentProjectId(),
            projectName: extractProjectName(),
            documentTitle: document.title || null,
            projectError: _isFlowProjectErrorState(),
            // true = project lỗi/đã xoá (URL còn /project/ nhưng trang lỗi)
            mediaViewer: _isFlowMediaViewerOpen()
            // true = đang xem 1 ảnh/video (URL /edit/{fileId}) → editor chưa sẵn sàng gen
          };
        },
        "getFlowLoginState": () => _getFlowGoogleLoginState(),
        // Scan Flow home page DOM cho danh sách projects (cards/links).
        // Homepage: auto-scroll lazy-load TẤT CẢ project trước khi collect, rồi return scroll
        // về đầu (anti-loop trong _autoScrollLoadProjects). Trong project: collect thường.
        "scanFlowProjects": async () => {
          const isHomePage = !getCurrentProjectId();
          if (isHomePage) {
            try {
              await _autoScrollLoadProjects();
            } catch (_) {
            }
          }
          return { projects: _collectFlowProjects(), isHomePage };
        },
        "command": () => {
          if (message.command === "generate") {
            const startBtn = document.getElementById("startBtn");
            if (startBtn && !startBtn.classList.contains("hidden")) startBtn.click();
          }
          return { ok: true };
        },
        // === Q2.3: Screen Capture Crop Overlay ===
        "startCropSelection": () => {
          return new Promise((resolve) => {
            const existing = document.getElementById("tobyflow-crop-overlay");
            if (existing) existing.remove();
            const overlay = document.createElement("div");
            overlay.id = "tobyflow-crop-overlay";
            overlay.className = "tobyflow-crop-overlay";
            overlay.innerHTML = `
          <div class="tobyflow-crop-selection" id="tobyflow-crop-selection">
            <div class="tobyflow-crop-controls" id="tobyflow-crop-controls">
              <button class="tobyflow-crop-btn tobyflow-crop-btn-capture" id="tobyflow-crop-capture-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                  <circle cx="12" cy="13" r="4"></circle>
                </svg>
                Ch\u1EE5p
              </button>
              <button class="tobyflow-crop-btn tobyflow-crop-btn-cancel" id="tobyflow-crop-cancel-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
                H\u1EE7y
              </button>
            </div>
          </div>
        `;
            if (!document.getElementById("tobyflow-crop-styles")) {
              const style = document.createElement("style");
              style.id = "tobyflow-crop-styles";
              style.textContent = `
            .tobyflow-crop-overlay {
              position: fixed;
              inset: 0;
              background: rgba(0,0,0,0.5);
              z-index: 999999;
              cursor: crosshair;
            }
            .tobyflow-crop-selection {
              position: absolute;
              border: 2px dashed #fff;
              background: transparent;
              display: none;
              box-shadow: 0 0 0 9999px rgba(0,0,0,0.5);
            }
            .tobyflow-crop-controls {
              position: absolute;
              bottom: -52px;
              left: 50%;
              transform: translateX(-50%);
              display: none;
              gap: 8px;
              z-index: 1000000;
              white-space: nowrap;
            }
            .tobyflow-crop-controls.visible {
              display: flex;
            }
            .tobyflow-crop-btn {
              display: flex;
              align-items: center;
              gap: 6px;
              padding: 10px 20px;
              border: none;
              border-radius: 8px;
              font-size: 14px;
              font-weight: 500;
              cursor: pointer;
              transition: all 0.15s ease;
              box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            }
            .tobyflow-crop-btn svg {
              flex-shrink: 0;
            }
            .tobyflow-crop-btn-capture {
              background: #cdff01;
              color: #1c1c1f;
            }
            .tobyflow-crop-btn-capture:hover {
              background: #d4ff33;
              transform: scale(1.02);
            }
            .tobyflow-crop-btn-cancel {
              background: rgba(40,40,45,0.95);
              color: #fff;
              border: 1px solid rgba(255,255,255,0.15);
            }
            .tobyflow-crop-btn-cancel:hover {
              background: rgba(60,60,65,0.95);
            }
          `;
              document.head.appendChild(style);
            }
            document.body.appendChild(overlay);
            let startX = 0, startY = 0;
            let isDrawing = false;
            let hasSelection = false;
            const selection = document.getElementById("tobyflow-crop-selection");
            const controls = document.getElementById("tobyflow-crop-controls");
            overlay.addEventListener("mousedown", (e) => {
              if (e.target.closest(".tobyflow-crop-controls")) return;
              isDrawing = true;
              hasSelection = false;
              controls.classList.remove("visible");
              startX = e.clientX;
              startY = e.clientY;
              selection.style.left = startX + "px";
              selection.style.top = startY + "px";
              selection.style.width = "0px";
              selection.style.height = "0px";
              selection.style.display = "block";
            });
            overlay.addEventListener("mousemove", (e) => {
              if (!isDrawing) return;
              const w = e.clientX - startX;
              const h = e.clientY - startY;
              if (w < 0) {
                selection.style.left = e.clientX + "px";
                selection.style.width = -w + "px";
              } else {
                selection.style.left = startX + "px";
                selection.style.width = w + "px";
              }
              if (h < 0) {
                selection.style.top = e.clientY + "px";
                selection.style.height = -h + "px";
              } else {
                selection.style.top = startY + "px";
                selection.style.height = h + "px";
              }
            });
            overlay.addEventListener("mouseup", () => {
              if (!isDrawing) return;
              isDrawing = false;
              const rect = selection.getBoundingClientRect();
              if (rect.width >= 20 && rect.height >= 20) {
                hasSelection = true;
                controls.classList.add("visible");
              }
            });
            document.getElementById("tobyflow-crop-capture-btn").addEventListener("click", () => {
              const rect = selection.getBoundingClientRect();
              const cropRect = {
                x: Math.round(rect.left * window.devicePixelRatio),
                y: Math.round(rect.top * window.devicePixelRatio),
                width: Math.round(rect.width * window.devicePixelRatio),
                height: Math.round(rect.height * window.devicePixelRatio)
              };
              overlay.remove();
              if (cropRect.width < 10 || cropRect.height < 10) {
                resolve({ success: false, error: "V\xF9ng ch\u1ECDn qu\xE1 nh\u1ECF" });
              } else {
                resolve({ success: true, cropRect });
              }
            });
            document.getElementById("tobyflow-crop-cancel-btn").addEventListener("click", () => {
              overlay.remove();
              resolve({ success: false, cancelled: true });
            });
            const escHandler = (e) => {
              if (e.key === "Escape") {
                overlay.remove();
                document.removeEventListener("keydown", escHandler);
                resolve({ success: false, cancelled: true });
              }
            };
            document.addEventListener("keydown", escHandler);
          });
        },
        "cancelCropSelection": () => {
          const overlay = document.getElementById("tobyflow-crop-overlay");
          if (overlay) overlay.remove();
          return { success: true };
        },
        // --- PQ: PromptQueue Pipeline handlers ---
        "pq:getPreTileSnapshot": () => {
          const ids = getUniqueTileIds(true);
          const names = [...getExistingFileNames()];
          console.log(`[content.js] pq:getPreTileSnapshot \u2014 captured ${ids.length} tile IDs + ${names.length} file names (baseline TR\u01AF\u1EDAC submit)`);
          return {
            success: true,
            preTileIds: ids,
            preFileNames: names
          };
        },
        "pq:addRefImages": async () => {
          const { fileIds, fileNameMap } = message;
          console.log("[DEBUG_REF] pq:addRefImages called with fileIds:", fileIds, "fileNameMap keys:", Object.keys(fileNameMap || {}));
          let addedCount = 0;
          let failedIds = [];
          for (const fid of fileIds || []) {
            const result = await addFileToPrompt(fid, fileNameMap?.[fid]);
            if (result === false) {
              failedIds.push(fid);
            } else {
              addedCount++;
            }
          }
          const allSuccess = failedIds.length === 0;
          console.log("[DEBUG_REF] pq:addRefImages result:", { addedCount, failedIds, totalRequested: (fileIds || []).length });
          if (!allSuccess) {
            console.warn("[pq:addRefImages] Failed to add:", failedIds.length, "of", (fileIds || []).length, "ref images");
          }
          return { success: allSuccess, addedCount, failedIds, totalRequested: (fileIds || []).length };
        },
        "pq:removeExistingRefImages": async () => {
          console.log("[content.js] pq:removeExistingRefImages received");
          const removed = await removeExistingRefImages();
          console.log(`[content.js] pq:removeExistingRefImages done \u2014 removed ${removed} ref images`);
          return { success: true, removed };
        },
        "pq:verifySlateModel": () => {
          const editor = getEditor();
          if (!editor) return { success: true, hasContent: false };
          const noPlaceholder = editor.querySelector("[data-slate-placeholder]") === null;
          const hasText = editor.textContent?.trim().length > 0;
          const hasContent = noPlaceholder || hasText;
          return { success: true, hasContent };
        },
        "detectTileStatus": () => {
          const tile = document.querySelector(`[data-tile-id="${message.tileId}"]`);
          return { status: detectTileStatus(tile) };
        },
        "retryFailedTilesViaButton": async () => {
          shouldStop = false;
          const result = await retryFailedTilesViaButton(
            message.failedTileIds || [],
            message.timeout || 12e4,
            message.excludeTileIds || null
          );
          return result;
        },
        // Legacy: Tracker update từ sidePanel (task/workflow/angles owners)
        "legacyTrackerUpdate": () => {
          FloatingTracker.updateLegacy(message.data);
          return { success: true };
        },
        // PQ: Floating Tracker trong trang Flow (góc phải)
        "pq:trackerUpdate": () => {
          FloatingTracker.update(message.data);
          return { success: true };
        },
        "pq:trackerHide": () => {
          FloatingTracker.hide();
          return { success: true };
        },
        // Chunk Mode (2026-07-26): proactive reload status từ PromptQueue.
        // data: { phase: 'draining'|'reloading'|'resumed', chunkSize?, remaining?, completedChunks? }
        "pq:chunkStatus": () => {
          FloatingTracker.setChunkStatus(message.data);
          return { success: true };
        },
        // PQ: Đồng bộ pause/resume từ PromptQueue → content.js
        "pq:pauseExecution": () => {
          if (message.paused) {
            window._pqPaused = true;
          } else {
            window._pqPaused = false;
          }
          return { success: true };
        },
        // PQ + Workflow per-node: ExecutionBlocker — block user interaction khi gen node chạy.
        // Set _pipelineOwned để sanity check không auto-hide.
        // Show cancel pending-hide timer → 2 generate node liên tiếp không flicker.
        "pq:showBlocker": () => {
          if (ExecutionBlocker._pendingHideTimer) {
            clearTimeout(ExecutionBlocker._pendingHideTimer);
            ExecutionBlocker._pendingHideTimer = null;
          }
          ExecutionBlocker._pipelineOwned = true;
          ExecutionBlocker.show();
          return { success: true };
        },
        // Debounce hide 300ms — nếu node generate tiếp theo gửi showBlocker trong delay
        // thì cancel timer → giữ blocker visible, tránh hide/show flash.
        "pq:hideBlocker": () => {
          if (ExecutionBlocker._pendingHideTimer) clearTimeout(ExecutionBlocker._pendingHideTimer);
          ExecutionBlocker._pendingHideTimer = setTimeout(function() {
            ExecutionBlocker._pendingHideTimer = null;
            ExecutionBlocker._pipelineOwned = false;
            ExecutionBlocker.hide();
          }, 300);
          return { success: true };
        },
        "autoReloadFlow": async () => {
          console.log("[content.js] Auto-reloading Flow page...");
          try {
            const editor = getEditor();
            if (editor) {
              await clearEditor(editor);
              await sleep(100);
            }
          } catch (e) {
            console.warn("[autoReloadFlow] Clear editor before reload failed:", e.message);
          }
          setTimeout(() => {
            location.reload();
          }, 100);
          return { success: true };
        },
        // Phase FAR-1: Silent session refresh — KHÔNG reload trang, chỉ trigger Next.js
        // re-fetch session data để re-auth Bearer token. Plan Section 3.1.
        "flow:refreshSession": async () => {
          try {
            const ok = await refreshFlowSession("alarm");
            return { success: ok };
          } catch (e) {
            console.warn("[content.js] flow:refreshSession error:", e.message);
            return { success: false, error: e.message };
          }
        },
        // Phase FAR-3: Đếm pending tiles (in-flight, chưa success/failed) cho PromptQueue
        // pre-submit gate (DOM check). Plan Section 3.3.2.
        // CRITICAL: Flow KHÔNG set data-status attribute — phải dùng detectTileStatus() để
        // detect status từ DOM signals (img.src valid, warning icon, ...).
        "getPendingTileCount": () => {
          try {
            const { excludeClaimedTileIds = [] } = message;
            const excludeSet = new Set(excludeClaimedTileIds);
            const tiles = document.querySelectorAll(_getTileSelectorString());
            let pending = 0;
            for (const tile of tiles) {
              const tid = tile.dataset?.tileId;
              if (tid && excludeSet.has(tid)) continue;
              if (tile.querySelector('video[src^="http"], video[src^="blob:"]')) continue;
              if (Array.from(tile.querySelectorAll("i")).some((el) => el.textContent.trim() === "play_circle")) {
                pending++;
                continue;
              }
              const imgDone = tile.querySelector('img[src^="http"], img[src^="blob:"]');
              if (imgDone) {
                const src = imgDone.src || "";
                if (!src.includes("media.html") && !src.endsWith(".html")) {
                  continue;
                }
              }
              const status = detectTileStatus(tile);
              if (status === "processing") pending++;
            }
            return { count: pending };
          } catch (e) {
            return { count: 0, error: e.message };
          }
        },
        "checkContentScriptAlive": () => {
          return { alive: true, hasEditor: !!getEditor() };
        },
        // === MRC-3.4.1.1-1.3: Lấy trạng thái của danh sách tile IDs ===
        "getTileStatuses": () => {
          const { tileIds } = message;
          const statuses = {};
          for (const tileId of tileIds) {
            const tile = _getTileById(tileId);
            if (!tile) {
              statuses[tileId] = { status: "not_found" };
              continue;
            }
            const initialStatus = detectTileStatus(tile);
            const fileName = initialStatus === "success" ? extractFileName(tile) : null;
            const status = initialStatus === "success" && !fileName ? "processing" : initialStatus;
            const thumbnail = status === "success" ? extractThumbnailUrl(tile) : null;
            const mediaType = detectMediaType(tile);
            const videoUrl = mediaType === "video" && status === "success" ? extractVideoUrl(tile) : null;
            statuses[tileId] = {
              status,
              file_name: fileName,
              thumbnail,
              type: mediaType,
              ...videoUrl && { video_url: videoUrl }
              // Include video_url only if present
            };
          }
          return { success: true, statuses };
        },
        // === MRC-3.4.1.5-1.7: Quét tìm tiles mới không nằm trong danh sách exclude ===
        "scanNewTiles": () => {
          const { excludeTileIds = [], excludeFileNames = [] } = message;
          const excludeIdSet = new Set(excludeTileIds);
          const excludeFnSet = new Set(excludeFileNames.filter(Boolean));
          const allTiles = document.querySelectorAll(_getTileSelectorString());
          const newTiles = [];
          const seenTileIds = /* @__PURE__ */ new Set();
          for (const tile of allTiles) {
            const tileId = tile.dataset.tileId;
            if (!tileId) continue;
            if (seenTileIds.has(tileId)) continue;
            seenTileIds.add(tileId);
            if (excludeIdSet.has(tileId)) continue;
            const fileName = extractFileName(tile);
            if (fileName && excludeFnSet.has(fileName)) continue;
            newTiles.push({
              tile_id: tileId,
              file_name: fileName || null,
              // [Bug fix 2026-06-11] Return media_type để TileMonitor re-adopt logic filter
              // tránh grab tile sai loại (vd Video gen item adopt nhầm Image tile). detectMediaType
              // function dùng chung pattern với getNewTilesAfterSubmit handler line 10225+.
              media_type: detectMediaType(tile)
              // 'image' | 'video' | 'unknown'
            });
          }
          console.log(`[content.js] scanNewTiles \u2014 exclude ${excludeIdSet.size} IDs + ${excludeFnSet.size} fileNames | DOM ${allTiles.length} tiles | NEW ${newTiles.length}`);
          if (newTiles.length > 0) {
            console.log("[content.js] scanNewTiles preview:", newTiles.slice(0, 5).map((t) => t.tile_id.substring(0, 16)));
          }
          return { success: true, tiles: newTiles };
        },
        // === DOM Resilience: Refresh selector cache when backend pushes update ===
        "providerConfigUpdated": async () => {
          return new Promise((resolve) => {
            chrome.storage.local.get(["toby_provider_configs"], (res) => {
              if (res.toby_provider_configs?.data) {
                _selectorConfig = res.toby_provider_configs.data;
                _selectorConfigTime = Date.now();
                const keyCount = Object.keys(_selectorConfig.flow?.selectors || {}).length;
                console.log(`[TobyFlow] Provider config updated via SSE \u2014 reloaded ${keyCount} selectors`);
              } else {
                _selectorConfig = null;
                _selectorConfigTime = 0;
                console.warn("[TobyFlow] Provider config updated via SSE \u2014 storage empty, cache cleared");
              }
              resolve({ success: true });
            });
          });
        },
        // === API configs (download_resolutions, ratios, error_patterns) ===
        "providerApiConfigUpdated": async () => {
          return new Promise((resolve) => {
            chrome.storage.local.get(["toby_provider_api_configs"], (res) => {
              if (res.toby_provider_api_configs?.data) {
                _apiConfigsCacheLocal = res.toby_provider_api_configs;
                _apiConfigsCacheLocalTime = Date.now();
                const providers = Object.keys(res.toby_provider_api_configs.data || {});
                console.log(`[TobyFlow] Provider api_config updated via SSE \u2014 reloaded for: ${providers.join(", ")}`);
              } else {
                _apiConfigsCacheLocal = null;
                _apiConfigsCacheLocalTime = 0;
                console.warn("[TobyFlow] Provider api_config updated via SSE \u2014 storage empty, cache cleared");
              }
              resolve({ success: true });
            });
          });
        },
        // Flow Voice Selector — scrape advanced menu Voices tab
        "scrapeFlowVoices": async () => {
          return await scrapeFlowVoices();
        },
        // Flow Voice Selector — click voice option trong advanced menu (submit pipeline)
        "selectFlowVoice": async () => {
          return await selectFlowVoice(message.voice);
        },
        // Flow Character Selector — scrape advanced menu tab Nhân vật
        "scrapeFlowCharacters": async () => {
          return await scrapeFlowCharacters();
        },
        // Flow Character Selector — click character option trong advanced menu (submit pipeline)
        "selectFlowCharacter": async () => {
          return await selectFlowCharacter(message.character);
        },
        // Flow Agent Mode (2026-05-30) — check state cho sidebar reconfirm modal preflight
        "checkFlowAgentMode": async () => {
          const state = _isFlowAgentModeOn();
          return { success: true, ...state };
        },
        // Flow Agent Mode (2026-05-30) — auto-disable nếu đang ON (caller: sidebar reconfirm "Fix" button)
        "disableFlowAgentMode": async () => {
          return await _ensureFlowAgentModeOff();
        },
        // Flow Chat Agent Panel (2026-06-02) — check panel state
        "checkFlowChatAgentPanel": async () => {
          const state = _isFlowChatAgentPanelOpen();
          return { success: true, ...state };
        },
        // Flow Chat Agent Panel (2026-06-02) — auto-close panel nếu đang mở
        "closeFlowChatAgentPanel": async () => {
          return await _ensureFlowChatAgentClosed();
        },
        // Flow Agent Instruction Dialog (2026-06-02) — check dialog state
        "checkFlowAgentInstructionDialog": async () => {
          const state = _isFlowAgentInstructionDialogOpen();
          return { success: true, ...state };
        },
        // Flow Agent Instruction Dialog (2026-06-02) — click "Xong" nếu dialog đang mở
        "doneFlowAgentInstructionDialog": async () => {
          return await _ensureFlowAgentInstructionDone();
        },
        // Flow homepage — click "+ Dự án mới" (background gọi trước khi inject MAIN world)
        "clickCreateNewProject": async () => {
          return await _clickFlowNewProjectButton(message.iconText, message.textMatch);
        }
      };
      if (handlers[message.action]) {
        Promise.resolve().then(() => handlers[message.action]()).then((result) => {
          sendResponse(result || { success: true });
        }).catch((err) => {
          console.error("[FlowAuto] Handler error:", message.action, err);
          sendResponse({ error: err.message });
        });
        return true;
      }
    });
    _tileObserver = null;
    _setupTileObserver();
    if (document.readyState === "complete" || document.readyState === "interactive") {
      setTimeout(setupFlowSpaNavigateHookDeferred, 2e3);
    } else {
      window.addEventListener("DOMContentLoaded", () => {
        setTimeout(setupFlowSpaNavigateHookDeferred, 2e3);
      });
    }
    if (document.readyState === "complete" || document.readyState === "interactive") {
      setTimeout(setupFlowHomepageObserver, 2500);
    } else {
      window.addEventListener("DOMContentLoaded", () => {
        setTimeout(setupFlowHomepageObserver, 2500);
      });
    }
  }
  var isRunning;
  var shouldStop;
  var isPaused;
  var failedPrompts;
  var _tileCache;
  var _tileCacheTime;
  var _TILE_CACHE_TTL;
  var _FLOW_LOCALE_FALLBACKS;
  var _tileSelectorCache;
  var _SLATE_EDITOR_FALLBACK_SELECTORS;
  var _fileNameCache;
  var _statusCache;
  var _selectorConfig;
  var _selectorConfigTime;
  var _tobyVerboseFlowDebug;
  var _SELECTOR_CACHE_TTL;
  var _coldStartWarnedKeys;
  var _radixTriggerPattern;
  var _selectorConfigReady;
  var _SELECTOR_WAIT_MAX_MS;
  var _FLOW_LOCAL_DEV_BOOTSTRAP;
  var _SELECTOR_WAIT_INTERVAL_MS;
  var _OVERLAY_I18N;
  var _overlayLocale;
  var _TF_OPEN_LABEL;
  var _TF_HINT_LABEL;
  var _tfHintSeen;
  var _tfNavObserver;
  var _tfInjectInterval;
  var _apiConfigsCacheLocal;
  var _apiConfigsCacheLocalTime;
  var _API_CONFIGS_CACHE_TTL;
  var _trackerLocale;
  var _trackerTranslations;
  var downloadCounter;
  var FloatingTracker;
  var _origUpdate;
  var ExecutionBlocker;
  var _statQueue;
  var _ctxMenuLockQueue;
  var _ctxMenuLocked;
  var _retryingTiles;
  var _clickedRetryTileIds;
  var _retryMutex;
  var _cachedInputTimeoutMs;
  var _cachedDelayBetweenMs;
  var _FLOW_SETTINGS_KEY;
  var _flowSettingsApplied;
  var _flowSettingsLastAttemptAt;
  var _FLOW_SETTINGS_RETRY_COOLDOWN_MS;
  var _ZOOM_NOTICE_SVG;
  var _tileObserver;
  var _getFlowLocaleStrings2;
  var _getFlowLocaleStringsWithFallback2;
  var _isGroupViewTabLabel2;
  var _isNonViewSettingsControlLabel2;
  var _isLikelyGridViewLabel2;
  var _queryInputsByAriaLabels2;
  var _ariaLabelMatches2;
  var _textIncludesAny2;
  var _getTileSelector2;
  var _getTileSelectorString2;
  var _getSlateEditorSelectorString2;
  var _queryAllSlateEditors2;
  var _ensureSelectorsForExecution2;
  var _getMediaUrlPattern2;
  var _getCachedTiles2;
  var _invalidateTileCache2;
  var _getTileById2;
  var _loadRadixTriggerPattern2;
  var _buildRadixTriggerSelector2;
  var _shouldAllowFlowSelectorBootstrap2;
  var _storageTargetsLocalDev2;
  var _applyFlowSelectorBootstrap2;
  var _tfInjectHintStyle2;
  var _tfAttachHint2;
  var _tfDismissHint2;
  var _tfBuildOpenButton2;
  var _tfFindBrandLink2;
  var _tfWatchAnchor2;
  var _tfContextValid2;
  var _injectTobyFlowOpenButton2;
  var _runSelectorWaitLoop2;
  var _showConfigErrorOverlay2;
  var _showCloneDetectedOverlay2;
  var _hideCloneDetectedOverlay2;
  var _getDynamicSelector2;
  var _selStr2;
  var _q2;
  var _qa2;
  var _queryWithFallback2;
  var _findIconInElement2;
  var _findIconsInElement2;
  var _getApiConfigValue2;
  var _detectFlowUploadError2;
  var _clickUploadConsentModal2;
  var _getDownloadMenuLabel2;
  var _getDownloadFallbackChain2;
  var _getDownloadPixelWidth2;
  var _getTrackerT2;
  var incrementDownloadCounter2;
  var getDownloadCounter2;
  var debounce2;
  var sleep2;
  var _setReactInputValue2;
  var _findTabByIconText2;
  var _closeFlowAdvancedMenu2;
  var _extractCharOption2;
  var _incrementDailyStat2;
  var getInputTimeoutMs2;
  var getClearEditorDelay2;
  var getSubmitDelay2;
  var getAfterSubmitDelay2;
  var getSettingsStepDelay2;
  var getDelayBetweenPromptsMs2;
  var getRandomDelay2;
  var _isLogSelectorsEnabled2;
  var _logSelectorPick2;
  var getEditor2;
  var getSettingsButton2;
  var _getActiveSettingsPanel2;
  var getSubmitButton2;
  var sendLog2;
  var sendRetryStatus2;
  var isAutoDownloadEnabled2;
  var getDownloadSettings2;
  var _toAscii2;
  var _buildFilename2;
  var applyResolutionToUrl2;
  var _waitForElement2;
  var _waitForTileMediaReady2;
  var _closeContextMenu2;
  var _releaseCtxMenuLock2;
  var extractFileName2;
  var extractFileNameFromUrl2;
  var extractThumbnailUrl2;
  var extractVideoUrl2;
  var extractFlowFileInfo2;
  var getCurrentProjectId2;
  var _isFlowProjectErrorState2;
  var _isFlowMediaViewerOpen2;
  var findTileByFileId2;
  var extractProjectName2;
  var _qaProjectLinks2;
  var _getFlowGoogleLoginState2;
  var _collectFlowProjects2;
  var getUniqueTileIds2;
  var getExistingFileNames2;
  var isTileComplete2;
  var validateTileFile2;
  var clickTileRetryButton2;
  var clickUploadRetryButton2;
  var detectTileStatus2;
  var detectMediaType2;
  var extractTileProgress2;
  var isHumanizedEnabled2;
  var getHumanizedSpeed2;
  var getHumanizedDelay2;
  var injectSlateBridge2;
  var _slateBridgeCall2;
  var readCurrentSettings2;
  var ratioToIconName2;
  var simulateClick2;
  var simulateContextMenu2;
  var getExponentialBackoffMs2;
  var scanGalleryTiles2;
  var _checkFlowCreditLimit2;
  var _findFlowAgentButton2;
  var _isFlowAgentModeOn2;
  var _findFlowAgentInstructionDoneButton2;
  var _isFlowAgentInstructionDialogOpen2;
  var _findFlowChatAgentCloseButton2;
  var _stripIconFromButtonText2;
  var _isFlowChatAgentPanelOpen2;
  var _showZoomNotice2;
  var _hideZoomNotice2;
  var _applyZoomUx2;
  var _clearZoomUx2;
  var injectOverlayButtons2;
  var _setupTileObserver2;
  var setupFlowSpaNavigateHookDeferred2;
  var setupFlowHomepageObserver2;
})();
