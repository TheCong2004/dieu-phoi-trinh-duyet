(() => {
  // grok/GrokDomSelectors.ts
  var GROK_DOM_VERSION = "2026-07-13-type-to-imagine-en-vi";
  var GROK_DOM = {
    version: GROK_DOM_VERSION,
    editor: {
      /** Exact → fallback (ổn định trước, rộng sau). */
      selectors: [
        'div[contenteditable="true"][role="textbox"][aria-label="Ask Grok anything"]',
        'div[contenteditable="true"][aria-label="Ask Grok anything"]',
        '[aria-label="Ask Grok anything"][contenteditable="true"]',
        '[aria-label="Ask Grok anything"][contenteditable]',
        '[aria-label*="Ask Grok"][contenteditable]',
        'div.tiptap.ProseMirror[contenteditable="true"][role="textbox"]',
        'div.ProseMirror.tiptap[contenteditable="true"]',
        '.tiptap.ProseMirror[contenteditable="true"]',
        'div.ProseMirror[contenteditable="true"]',
        'div.tiptap[contenteditable="true"]',
        // Placeholder EN (user dump 2026-07-13 Simple Browser)
        'p[data-placeholder="Type to imagine"]',
        'p[data-placeholder*="Type to imagine" i]',
        '[data-placeholder="Type to imagine"]',
        '[data-placeholder*="Type to imagine" i]',
        // Placeholder VI
        'p[data-placeholder="G\xF5 \u0111\u1EC3 t\u01B0\u1EDFng t\u01B0\u1EE3ng"]',
        'p[data-placeholder*="t\u01B0\u1EDFng t\u01B0\u1EE3ng"]',
        'p[data-placeholder*="imagine" i]',
        "p.is-editor-empty[data-placeholder]",
        'div[role="textbox"][aria-multiline="true"][contenteditable="true"]',
        ".query-bar div[contenteditable]",
        '[data-testid="chat-input"] div[contenteditable]',
        ".query-bar .ProseMirror",
        '[data-testid="chat-input"] .ProseMirror',
        'form div[contenteditable][role="textbox"]',
        "form div[contenteditable]",
        '[contenteditable][role="textbox"]',
        "textarea",
        '[contenteditable="true"]'
      ],
      /** aria-label substring (lowercase) → luôn accept editor */
      ariaIncludes: ["ask grok", "t\u01B0\u1EDFng t\u01B0\u1EE3ng", "imagine", "type to"],
      /** data-placeholder substring (lowercase) */
      placeholderIncludes: [
        "type to imagine",
        "t\u01B0\u1EDFng t\u01B0\u1EE3ng",
        "imagine",
        "ask grok",
        "g\xF5 \u0111\u1EC3"
      ]
    },
    composerRoot: [
      '[data-testid="chat-input"]',
      ".query-bar",
      'form:has([contenteditable="true"])',
      "form:has(.ProseMirror)",
      '[class*="query-bar"]',
      "form"
    ],
    /** Quick query cho root discovery */
    composerRootProbe: 'div[contenteditable="true"][aria-label="Ask Grok anything"], div.tiptap.ProseMirror[contenteditable="true"], p[data-placeholder*="t\u01B0\u1EDFng t\u01B0\u1EE3ng"], p[data-placeholder*="Type to imagine" i], p[data-placeholder*="imagine" i]',
    submit: {
      /** Path d của SVG mũi tên lên (Imagine 2026 — nhiều variant path) */
      upArrowPathRegexSource: "M6 11L12 5|L12 5M12 5L18 11|M12 5V19|M12 19V5|m12 5|M5 12l7-7|m0 0l7 7|M12 4v16|M4 12h16",
      roundClassIncludes: ["rounded-full", "bg-button-filled", "bg-primary"],
      roundSizeMin: 24,
      roundSizeMax: 72,
      buttonSelectors: [
        'button[type="submit"][aria-label="G\u1EEDi"]',
        'button[aria-label="G\u1EEDi"]',
        'button[type="submit"][aria-label="Send"]',
        'button[aria-label="Send"]',
        'button[type="submit"][aria-label="Submit"]',
        'button[aria-label="Submit"]',
        '.query-bar button[type="submit"]',
        '.query-bar button[aria-label*="Submit"]',
        '.query-bar button[aria-label*="Send"]',
        '.query-bar button[aria-label*="G\u1EEDi"]',
        '[data-testid="chat-input"] button[type="submit"]',
        'form button[type="submit"]',
        'button[aria-label*="Submit"]',
        'button[aria-label*="Send"]',
        'button[aria-label*="G\u1EEDi"]',
        'button[type="submit"]'
      ],
      ariaIncludes: ["g\u1EEDi", "send", "submit", "generate", "t\u1EA1o", "arrow", "up", "enter"]
    },
    login: {
      selectors: [
        'a[href*="/sign-in"]',
        'a[href*="/signin"]',
        'a[href*="/login"]',
        'button[aria-label*="Log in"]',
        'button[aria-label*="Sign in"]',
        'a[href*="sign-up"]'
      ],
      /** Text trên button (logged-out header) */
      buttonTextPatterns: ["sign in", "sign up", "log in", "\u0111\u0103ng nh\u1EADp", "\u0111\u0103ng k\xFD"]
    },
    generating: {
      selectors: [".loading", 'button[aria-label="Stop generating"]']
    },
    cdnImage: {
      selectors: ['img[src*="grok"]']
    },
    ignoreClosest: "#tobyflow-grok-blocker, #tobyflow-grok-tracker, #tobyflow-config-error-overlay"
  };
  function buildGrokProviderBootstrap() {
    return {
      grok: {
        selectors: {
          composer: { selectors: [...GROK_DOM.editor.selectors] },
          submit_button: { selectors: [...GROK_DOM.submit.buttonSelectors] },
          login_button: { selectors: [...GROK_DOM.login.selectors] },
          generating_indicator: { selectors: [...GROK_DOM.generating.selectors] },
          cdn_image: { selectors: [...GROK_DOM.cdnImage.selectors] },
          // Extract result (extension-only bootstrap — server config hay miss)
          result_container: {
            selectors: [
              "main",
              '[role="main"]',
              "article",
              '[class*="post"]',
              "body"
            ]
          },
          result_image: {
            selectors: [
              'img[src*="/generated/"]',
              'img[src*="assets.grok.com"]',
              'img[src*="imagine-public"]',
              'img[src^="https://"]'
            ]
          },
          result_video: {
            selectors: ["video", "video source"]
          }
        },
        // Optional URL patterns for extract
        urls: {
          cdn_patterns: ["assets.grok.com", "grok.x.ai", "imagine-public.x.ai"]
        }
      }
    };
  }

  // grok/GrokFindDom.ts
  function defaultLog(...args) {
    console.log("[Grok]", ...args);
  }
  function isUsableEditor(el, dom = GROK_DOM, doc = document) {
    if (!el) return false;
    if (el.closest?.(dom.ignoreClosest)) return false;
    const tag = String(el.tagName || "").toLowerCase();
    const ce = el.getAttribute?.("contenteditable");
    const isCe = ce !== null && ce !== void 0 && ce !== "false";
    const isEditor = tag === "textarea" || isCe || el.getAttribute?.("role") === "textbox";
    if (!isEditor) return false;
    const aria = (el.getAttribute?.("aria-label") || "").toLowerCase();
    if (dom.editor.ariaIncludes.some((s) => aria.includes(s))) return true;
    try {
      const ph = el.getAttribute?.("data-placeholder") || el.querySelector?.("[data-placeholder]")?.getAttribute?.("data-placeholder") || "";
      const phL = String(ph).toLowerCase();
      if (dom.editor.placeholderIncludes.some((s) => phL.includes(s))) return true;
    } catch (_) {
    }
    if (el.classList?.contains("ProseMirror") || el.classList?.contains("tiptap")) {
      const style2 = doc.defaultView?.getComputedStyle?.(el);
      if (style2 && (style2.display === "none" || style2.visibility === "hidden")) return false;
      return true;
    }
    const rect = el.getBoundingClientRect?.();
    const style = doc.defaultView?.getComputedStyle?.(el);
    if (!rect || rect.width < 10) return false;
    if (style && (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0)) {
      return false;
    }
    return true;
  }
  function queryFirstUsable(selectors, opts = {}) {
    const doc = opts.doc || document;
    const dom = opts.dom || GROK_DOM;
    const log = opts.log || defaultLog;
    for (const selector of selectors) {
      try {
        const matches = Array.from(doc.querySelectorAll(selector));
        const usable = matches.find((el) => isUsableEditor(el, dom, doc));
        if (usable) {
          log(`Editor match: ${selector}`, {
            aria: usable.getAttribute?.("aria-label"),
            cls: String(usable.className || "").slice(0, 60)
          });
          return usable;
        }
      } catch (_) {
      }
    }
    return null;
  }
  function findGrokComposerRoot(opts = {}) {
    const doc = opts.doc || document;
    const dom = opts.dom || GROK_DOM;
    try {
      const ed = doc.querySelector(dom.composerRootProbe);
      const edEl = ed?.tagName === "P" ? ed.closest('[contenteditable="true"]') || ed.parentElement : ed;
      if (edEl) {
        const root = edEl.closest("form") || edEl.closest(".query-bar") || edEl.closest('[data-testid="chat-input"]') || edEl.closest('[class*="query"]') || edEl.closest("footer") || edEl.parentElement?.parentElement;
        if (root) return root;
      }
    } catch (_) {
    }
    for (const selector of dom.composerRoot) {
      try {
        const el = doc.querySelector(selector);
        if (el && el.getBoundingClientRect?.().width >= 20) return el;
      } catch (_) {
      }
    }
    return null;
  }
  function findGrokEditor(opts = {}) {
    const doc = opts.doc || document;
    const dom = opts.dom || GROK_DOM;
    const log = opts.log || defaultLog;
    const exact = queryFirstUsable([...dom.editor.selectors], opts);
    if (exact) {
      if (exact.tagName === "P" || !exact.isContentEditable) {
        const parent = exact.closest?.('[contenteditable="true"], [contenteditable]') || exact.parentElement;
        if (isUsableEditor(parent, dom, doc)) {
          log("Editor via placeholder parent");
          return parent;
        }
      } else {
        return exact;
      }
    }
    try {
      const root = findGrokComposerRoot(opts);
      log("findGrokEditor: composer root:", root ? root.className || root.tagName : "null");
      const sendBtns = [
        ...root ? Array.from(
          root.querySelectorAll(
            'button[type="submit"], button[aria-label*="Submit"], button[aria-label*="Send"], button[aria-label*="G\u1EEDi"]'
          )
        ) : [],
        ...Array.from(
          doc.querySelectorAll(
            'button[type="submit"][aria-label="G\u1EEDi"], button[aria-label="G\u1EEDi"], button[type="submit"]'
          )
        )
      ];
      for (const btn of sendBtns) {
        if (!btn || btn.getBoundingClientRect().width < 8) continue;
        let walk = btn.parentElement;
        for (let i = 0; i < 14 && walk; i++) {
          const candidates = walk.querySelectorAll?.(
            '[aria-label="Ask Grok anything"], .tiptap.ProseMirror[contenteditable], .ProseMirror[contenteditable], [contenteditable="true"]'
          );
          for (const ce of candidates || []) {
            if (isUsableEditor(ce, dom, doc)) {
              log("Editor match: near submit");
              return ce;
            }
          }
          walk = walk.parentElement;
        }
      }
    } catch (_) {
    }
    if (opts.queryConfiguredComposer) {
      const configured = opts.queryConfiguredComposer();
      log("findGrokEditor configured:", configured);
      if (isUsableEditor(configured, dom, doc)) return configured;
    }
    return null;
  }
  function isUpArrowSubmitEl(el, dom = GROK_DOM) {
    const d = el?.querySelector?.("svg path")?.getAttribute?.("d") || "";
    try {
      const re = new RegExp(dom.submit.upArrowPathRegexSource, "i");
      if (re.test(d)) return true;
    } catch (_) {
    }
    return d.includes("12 5") && d.includes("V19");
  }
  function isRoundSubmitChip(el, dom = GROK_DOM) {
    const cls = String(el.className || "");
    if (!dom.submit.roundClassIncludes.some((c) => cls.includes(c.replace("bg-button-filled", "bg-button-filled")) || cls.includes(c))) {
      if (!/rounded-full/.test(cls)) return false;
    }
    if (!el.querySelector?.("svg")) return false;
    const r = el.getBoundingClientRect?.();
    return !!r && r.width >= dom.submit.roundSizeMin && r.width <= dom.submit.roundSizeMax && r.height >= dom.submit.roundSizeMin && r.height <= dom.submit.roundSizeMax;
  }
  function findGrokSubmitBtn(editor, opts = {}) {
    const doc = opts.doc || document;
    const dom = opts.dom || GROK_DOM;
    const log = opts.log || defaultLog;
    const root = findGrokComposerRoot(opts) || editor?.closest?.("form") || editor?.closest?.('[class*="flex"]') || editor?.parentElement?.parentElement || doc.body;
    const divs = [
      ...root.querySelectorAll(
        'div.rounded-full, div[class*="rounded-full"], div[class*="bg-button-filled"]'
      )
    ].filter((el) => isUpArrowSubmitEl(el, dom) || isRoundSubmitChip(el, dom));
    if (divs.length) {
      divs.sort(
        (a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left
      );
      const up = divs.find((el) => isUpArrowSubmitEl(el, dom)) || divs[0];
      if (up) {
        log("Submit match: up-arrow div", String(up.className || "").slice(0, 60));
        return up;
      }
    }
    const ariaSubmit = (btn) => {
      const a = (btn.getAttribute?.("aria-label") || "").toLowerCase();
      return dom.submit.ariaIncludes.some((s) => a.includes(s)) || btn.getAttribute?.("type") === "submit";
    };
    const scoped = [
      ...root.querySelectorAll(
        'button[type="submit"], button[aria-label="G\u1EEDi"], button[aria-label="Send"], button[aria-label="Submit"]'
      ),
      ...root.querySelectorAll(
        'button[aria-label*="G\u1EEDi"], button[aria-label*="Send"], button[aria-label*="Submit"]'
      )
    ].filter(Boolean);
    const iconBtns = Array.from(root.querySelectorAll("button")).filter((btn) => {
      if (!btn || btn.disabled) return false;
      const r = btn.getBoundingClientRect?.();
      if (!r || r.width < 20 || r.height < 20) return false;
      if (ariaSubmit(btn)) return true;
      return !!btn.querySelector?.("svg") && (btn.getAttribute("aria-label") || btn.textContent || "").trim().length < 24;
    });
    const all = [...scoped, ...iconBtns];
    const scopedEnabled = all.find(
      (btn) => btn && !btn.disabled && ariaSubmit(btn)
    );
    if (scopedEnabled) return scopedEnabled;
    if (scoped[0]) return scoped[0];
    if (iconBtns.length) {
      iconBtns.sort(
        (a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left
      );
      return iconBtns[0];
    }
    for (const sel of dom.submit.buttonSelectors) {
      try {
        const el = doc.querySelector(sel);
        if (el) return el;
      } catch (_) {
      }
    }
    if (opts.queryConfiguredSubmit) {
      const cfg = opts.queryConfiguredSubmit();
      if (cfg) return cfg;
    }
    return null;
  }

  // grok/GrokInsertPrompt.ts
  function createInsertText(deps) {
    const log = deps.log || ((...a) => console.log("[Grok]", ...a));
    return async function insertText(editor, text, opts = {}) {
      if (!editor) editor = deps.findGrokEditor();
      const sanitized = String(text || "").replace(/@/g, "");
      if (!sanitized) return true;
      const preserveBaseline = opts.preserveBaseline === true;
      const head = sanitized.replace(/\s+/g, "").slice(0, 12);
      const looksInserted = (el) => {
        if (!el) return false;
        const t = (el.textContent || "").replace(/\s+/g, "");
        if (t.length < 1) return false;
        if (/^Gõđểtưởngtượng|^Type|^AskGrok/i.test(t) && t.length < 40) return false;
        if (head && t.includes(head.slice(0, Math.min(8, head.length)))) return true;
        return t.length >= Math.min(8, sanitized.replace(/\s+/g, "").length * 0.4);
      };
      try {
        log("Insert \u2192 MAIN (paste only, no submit)");
        const mw = await deps.mainWorldFill(sanitized, false);
        await deps.sleep(200);
        editor = deps.findGrokEditor() || editor;
        if (mw?.insertOk || mw?.textLen && mw.textLen > 0 || looksInserted(editor)) {
          log("\u2705 Insert OK MAIN", { textLen: mw?.textLen, insertOk: mw?.insertOk, dom: (editor?.textContent || "").slice(0, 40) });
          return true;
        }
        console.warn("[Grok] MAIN paste no visible text", mw);
      } catch (e) {
        console.warn("[Grok] MAIN insert err", e?.message || e);
      }
      editor = deps.findGrokEditor() || editor;
      if (!editor) return false;
      editor.focus();
      await deps.sleep(100);
      const fire = () => {
        try {
          editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: sanitized }));
        } catch (_) {
          editor.dispatchEvent(new Event("input", { bubbles: true }));
        }
      };
      try {
        if (!preserveBaseline) {
          document.execCommand("selectAll", false);
          document.execCommand("delete", false);
        }
        document.execCommand("insertText", false, sanitized);
        fire();
        await deps.sleep(100);
        editor = deps.findGrokEditor() || editor;
        if (looksInserted(editor)) {
          log("\u2705 Insert OK execCommand");
          return true;
        }
      } catch (_) {
      }
      try {
        const dt = new DataTransfer();
        dt.setData("text/plain", sanitized);
        editor.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
        fire();
        await deps.sleep(100);
        editor = deps.findGrokEditor() || editor;
        if (looksInserted(editor)) {
          log("\u2705 Insert OK paste");
          return true;
        }
      } catch (_) {
      }
      try {
        if (!preserveBaseline) editor.innerHTML = "";
        const p = document.createElement("p");
        p.textContent = sanitized;
        editor.appendChild(p);
        fire();
        if (looksInserted(editor)) {
          log("\u2705 Insert OK domWrite");
          return true;
        }
      } catch (_) {
      }
      console.warn("[Grok] \u274C Insert failed");
      return false;
    };
  }

  // grok/GrokSubmit.ts
  function createClickSubmit(deps) {
    const log = deps.log || ((...a) => console.log("[Grok]", ...a));
    const resolveSubmit = (editor) => {
      if (deps.findSubmitBtn) return deps.findSubmitBtn(editor);
      return findGrokSubmitBtn(editor, deps.findDomOpts || {});
    };
    return async function clickSubmit(editor) {
      if (!editor) editor = deps.findGrokEditor();
      if (!editor) return false;
      const force = window.__GROK_SUBMIT_FORCE_METHOD || document.documentElement.dataset.tobyGrokSubmitForce || null;
      editor.focus();
      await deps.sleep(200);
      const isEnabled = (el) => {
        if (!el) return false;
        if (el.disabled || el.hasAttribute?.("disabled")) return false;
        try {
          const s = window.getComputedStyle(el);
          if (s.pointerEvents === "none") return false;
          if (Number(s.opacity) < 0.35) return false;
        } catch (_) {
        }
        return true;
      };
      async function waitForSubmitEnabled(maxMs = 4e3) {
        const interval = 150;
        let elapsed = 0;
        while (elapsed < maxMs) {
          const btn2 = resolveSubmit(editor);
          const hasText = (editor.textContent || "").trim().length >= 1;
          if (btn2 && isEnabled(btn2) && hasText) {
            log("Submit control ready after", elapsed, "ms", btn2.tagName);
            return btn2;
          }
          if (hasText && elapsed > 0 && elapsed % 600 === 0) {
            try {
              editor.focus();
              editor.dispatchEvent(
                new InputEvent("input", { bubbles: true, inputType: "insertText" })
              );
            } catch (_) {
            }
          }
          await deps.sleep(interval);
          elapsed += interval;
        }
        const btn = resolveSubmit(editor);
        if (btn) {
          try {
            btn.removeAttribute?.("disabled");
            if ("disabled" in btn) btn.disabled = false;
            btn.setAttribute?.("aria-disabled", "false");
          } catch (_) {
          }
        }
        return btn;
      }
      async function verifySubmitted() {
        const href0 = location.href;
        const maxMs = 3500;
        const interval = 250;
        let elapsed = 0;
        while (elapsed < maxMs) {
          await deps.sleep(interval);
          elapsed += interval;
          if ((editor.textContent || "").trim().length < 3) {
            log("Submit verify: \u2705 editor cleared after " + elapsed + "ms");
            return true;
          }
          if (/\/imagine\/post\//i.test(location.href)) {
            log("Submit verify: \u2705 navigated post after " + elapsed + "ms");
            return true;
          }
          if (location.href !== href0 && /imagine/i.test(location.href)) {
            log("Submit verify: \u2705 url changed after " + elapsed + "ms");
            return true;
          }
          if (document.querySelector(
            'button[aria-label*="Stop" i], button[aria-label*="D\u1EEBng" i]'
          )) {
            log("Submit verify: \u2705 stop button after " + elapsed + "ms");
            return true;
          }
          const body = (document.body?.innerText || "").slice(0, 2500);
          if (/Generating|đang tạo/i.test(body)) {
            log("Submit verify: \u2705 generating text after " + elapsed + "ms");
            return true;
          }
        }
        log(
          "Submit verify: soft-OK (text c\xF2n, ch\u1EDD result page) len=" + (editor.textContent || "").trim().length
        );
        return true;
      }
      async function tryEnterKey() {
        log("Submit enterKey");
        editor.focus();
        for (const mods of [
          { key: "Enter", code: "Enter", keyCode: 13, ctrlKey: false, metaKey: false },
          { key: "Enter", code: "Enter", keyCode: 13, ctrlKey: true, metaKey: false },
          { key: "Enter", code: "Enter", keyCode: 13, ctrlKey: false, metaKey: true }
        ]) {
          editor.dispatchEvent(
            new KeyboardEvent("keydown", { ...mods, bubbles: true, cancelable: true })
          );
          editor.dispatchEvent(
            new KeyboardEvent("keypress", { ...mods, bubbles: true, cancelable: true })
          );
          editor.dispatchEvent(new KeyboardEvent("keyup", { ...mods, bubbles: true }));
          await deps.sleep(80);
        }
        return true;
      }
      async function tryFormRequestSubmit() {
        const submitBtn = resolveSubmit(editor);
        const form = submitBtn && submitBtn.closest("form") || editor.closest("form");
        if (!form || typeof form.requestSubmit !== "function") {
          log("formRequestSubmit skip: no form");
          return false;
        }
        log("Submit formRequestSubmit");
        try {
          if (submitBtn instanceof HTMLButtonElement && !submitBtn.disabled && !submitBtn.hasAttribute("disabled")) {
            form.requestSubmit(submitBtn);
          } else if (submitBtn instanceof HTMLInputElement && submitBtn.type === "submit") {
            form.requestSubmit(submitBtn);
          } else {
            form.requestSubmit();
          }
          return true;
        } catch (e) {
          log("formRequestSubmit error", e?.message);
          try {
            form.submit();
            return true;
          } catch (_) {
            return false;
          }
        }
      }
      async function trySimulateClick() {
        const submitBtn = await waitForSubmitEnabled(2500);
        if (!submitBtn) return false;
        try {
          submitBtn.removeAttribute?.("disabled");
          if ("disabled" in submitBtn) submitBtn.disabled = false;
        } catch (_) {
        }
        log(
          "Submit simulateClick on",
          submitBtn.tagName,
          String(submitBtn.className || "").slice(0, 40)
        );
        const r = submitBtn.getBoundingClientRect();
        const x = r.left + r.width / 2;
        const y = r.top + r.height / 2;
        for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
          try {
            submitBtn.dispatchEvent(
              new PointerEvent(type, {
                bubbles: true,
                cancelable: true,
                view: window,
                clientX: x,
                clientY: y,
                pointerId: 1,
                pointerType: "mouse"
              })
            );
          } catch (_) {
            submitBtn.dispatchEvent(
              new MouseEvent(
                type === "pointerdown" ? "mousedown" : type === "pointerup" ? "mouseup" : "click",
                { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }
              )
            );
          }
        }
        try {
          deps.simulateClick?.(submitBtn);
        } catch (_) {
        }
        try {
          submitBtn.click();
        } catch (_) {
        }
        return true;
      }
      async function tryNativeClick() {
        const submitBtn = await waitForSubmitEnabled(1500);
        if (!submitBtn) return false;
        try {
          submitBtn.removeAttribute?.("disabled");
          if ("disabled" in submitBtn) submitBtn.disabled = false;
        } catch (_) {
        }
        log("Submit nativeClick", submitBtn.tagName);
        submitBtn.click();
        return true;
      }
      await waitForSubmitEnabled(3e3);
      const impls = {
        formRequestSubmit: tryFormRequestSubmit,
        enterKey: tryEnterKey,
        simulateClick: trySimulateClick,
        nativeClick: tryNativeClick
      };
      const order = force && impls[force] ? [force] : ["formRequestSubmit", "enterKey", "simulateClick", "nativeClick"];
      for (const method of order) {
        try {
          const triggered = await impls[method]();
          if (!triggered) continue;
          if (await verifySubmitted()) {
            log("\u2705 Submit success via:", method);
            return true;
          }
        } catch (e) {
          console.warn("[Grok] Submit " + method + " error:", e?.message || e);
        }
      }
      console.warn("[Grok] \u274C All submit methods failed");
      return false;
    };
  }

  // grok/GrokContentScript.ts
  function installGrokContentScript() {
    const __TOBYFLOW_GROK_SCRIPT_VERSION = "2026-07-14-force-reload-v30";
    window.__tobyflowGrokLoaded__ = true;
    const sameVersion = window._grokInjected && window.__tobyflowGrokScriptVersion__ === __TOBYFLOW_GROK_SCRIPT_VERSION;
    if (sameVersion) {
      console.log("[Grok] already loaded", __TOBYFLOW_GROK_SCRIPT_VERSION);
      return;
    }
    window.__tobyflowGrokScriptVersion__ = __TOBYFLOW_GROK_SCRIPT_VERSION;
    window._grokInjected = true;
    try {
      document.documentElement.setAttribute("data-tobyflow-grok", __TOBYFLOW_GROK_SCRIPT_VERSION);
      document.documentElement.dataset.tobyflowGrok = __TOBYFLOW_GROK_SCRIPT_VERSION;
    } catch (_) {
    }
    console.log(
      "%c[Grok] content script LOADED",
      "color:#0f0;font-weight:bold;font-size:14px",
      __TOBYFLOW_GROK_SCRIPT_VERSION,
      location.href
    );
    console.log(
      '%c[Grok] Ki\u1EC3m tra version (page console): document.documentElement.getAttribute("data-tobyflow-grok")',
      "color:#cdff01"
    );
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const _i18n = {
      _lang: "vi",
      _strings: {
        vi: {
          preparing: "\u0110ang chu\u1EA9n b\u1ECB",
          waitingVerification: "Ch\u1EDD x\xE1c minh Cloudflare...",
          waitingResult: "\u0110ang ch\u1EDD k\u1EBFt qu\u1EA3..."
        },
        en: {
          preparing: "Preparing",
          waitingVerification: "Waiting for Cloudflare...",
          waitingResult: "Waiting for result..."
        },
        ja: {
          preparing: "\u6E96\u5099\u4E2D",
          waitingVerification: "Cloudflare\u8A8D\u8A3C\u5F85\u3061...",
          waitingResult: "\u7D50\u679C\u3092\u5F85\u3063\u3066\u3044\u307E\u3059..."
        },
        th: {
          preparing: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21",
          waitingVerification: "\u0E23\u0E2D Cloudflare...",
          waitingResult: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E23\u0E2D\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C..."
        }
      },
      t(key) {
        return this._strings[this._lang]?.[key] || this._strings.vi[key] || key;
      }
    };
    chrome.storage.local.get(["af_settings", "af_locale"], (res) => {
      _i18n._lang = res.af_locale || res.af_settings?.language || "vi";
      console.log(`[Grok-i18n] Language loaded: ${_i18n._lang}`);
    });
    const PROVIDER = "grok";
    let _selectorConfig = null;
    let _selectorConfigTime = 0;
    const _SELECTOR_CACHE_TTL = 3e4;
    const _SELECTOR_WAIT_MAX_MS = 1e4;
    const _SELECTOR_WAIT_INTERVAL_MS = 200;
    const _OVERLAY_I18N = {
      vi: { title: "M\u1EA5t k\u1EBFt n\u1ED1i server", desc: "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i t\u1EDBi m\xE1y ch\u1EE7 Toby. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i sau.", retry: "Th\u1EED l\u1EA1i" },
      en: { title: "Server Connection Lost", desc: "Unable to connect to Toby server. Please try again later.", retry: "Retry" },
      ja: { title: "\u30B5\u30FC\u30D0\u30FC\u63A5\u7D9A\u304C\u5207\u308C\u307E\u3057\u305F", desc: "Toby\u30B5\u30FC\u30D0\u30FC\u306B\u63A5\u7D9A\u3067\u304D\u307E\u305B\u3093\u3002\u5F8C\u3067\u3082\u3046\u4E00\u5EA6\u304A\u8A66\u3057\u304F\u3060\u3055\u3044\u3002", retry: "\u518D\u8A66\u884C" },
      th: { title: "\u0E02\u0E32\u0E14\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C", desc: "\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E01\u0E31\u0E1A\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C Toby \u0E01\u0E23\u0E38\u0E13\u0E32\u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07", retry: "\u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" }
    };
    const _GROK_LOCAL_DEV_BOOTSTRAP = buildGrokProviderBootstrap();
    function _normalizeProviderConfigData(data) {
      if (!data || typeof data !== "object") return data || {};
      const out = { ...data };
      for (const provider of Object.keys(out)) {
        const entry = out[provider];
        if (!entry || typeof entry !== "object") continue;
        if (!entry.selectors && entry.dom_selectors) {
          out[provider] = { ...entry, selectors: entry.dom_selectors };
        }
      }
      return out;
    }
    function _providerHasEssentials(data, provider) {
      const normalized = _normalizeProviderConfigData(data);
      const sel = normalized?.[provider]?.selectors;
      return !!(sel && sel.composer?.selectors?.length);
    }
    function _applyGrokSelectorBootstrap(source, existingData = {}) {
      const merged = { ...existingData, ..._GROK_LOCAL_DEV_BOOTSTRAP };
      _selectorConfig = merged;
      _selectorConfigTime = Date.now();
      try {
        chrome.storage.local.set({
          toby_provider_configs: {
            data: merged,
            expiresAt: Date.now() + 5 * 60 * 1e3,
            fetchedAt: Date.now(),
            source: source || "content_bootstrap"
          }
        });
      } catch (_) {
      }
      const keyCount = Object.keys(_selectorConfig[PROVIDER]?.selectors || {}).length;
      console.log(`[Selector:${PROVIDER}:ensure] \u2705 Local dev bootstrap (${source || "content"}, ${keyCount} selectors)`);
      return true;
    }
    (function _ensureSelectorConfig() {
      console.log(`[Selector:${PROVIDER}:ensure] \u23F3 Loading provider config...`);
      chrome.storage.local.get(["toby_provider_configs"], (res) => {
        const data = _normalizeProviderConfigData(res.toby_provider_configs?.data);
        if (_providerHasEssentials(data, PROVIDER)) {
          _selectorConfig = data;
          _selectorConfigTime = Date.now();
          const keyCount = Object.keys(_selectorConfig[PROVIDER]?.selectors || {}).length;
          console.log(`[Selector:${PROVIDER}:ensure] \u2705 Loaded ${keyCount} selectors from cache`);
          return;
        }
        console.log(`[Selector:${PROVIDER}:ensure] Bootstrap selectors (server/cache ch\u01B0a s\u1EB5n s\xE0ng)`);
        _applyGrokSelectorBootstrap("immediate_fallback", data || {});
        try {
          chrome.runtime.sendMessage({ action: "getProviderConfigs", provider: PROVIDER }, () => {
            if (chrome.runtime.lastError) {
            }
          });
        } catch (_) {
        }
      });
      try {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== "local" || !changes.toby_provider_configs) return;
          const next = _normalizeProviderConfigData(changes.toby_provider_configs.newValue?.data);
          if (_providerHasEssentials(next, PROVIDER)) {
            _selectorConfig = next;
            _selectorConfigTime = Date.now();
            const existingOverlay = document.getElementById("tobyflow-config-error-overlay");
            if (existingOverlay) existingOverlay.remove();
          }
        });
      } catch (_) {
      }
    })();
    function _showConfigErrorOverlay() {
      if (document.getElementById("tobyflow-config-error-overlay")) {
        console.log(`[Selector:${PROVIDER}:overlay] \u21A9 Overlay already mounted \u2014 skip`);
        return;
      }
      const lang = _i18n && _i18n._lang || "vi";
      const t = _OVERLAY_I18N[lang] || _OVERLAY_I18N.vi;
      const overlay = document.createElement("div");
      overlay.id = "tobyflow-config-error-overlay";
      overlay.className = "tobyflow-cfg-err-overlay";
      overlay.innerHTML = `
      <style>
        .tobyflow-cfg-err-overlay { position: fixed; inset: 0; z-index: 2147483647; background: rgba(10,10,14,0.95); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .tobyflow-cfg-err-content { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 32px; max-width: 320px; }
        .tobyflow-cfg-err-icon { width: 80px; height: 80px; border-radius: 50%; background: rgba(239,68,68,0.15); display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }
        .tobyflow-cfg-err-icon svg { color: #ef4444; }
        .tobyflow-cfg-err-title { font-size: 18px; font-weight: 600; color: #fff; margin: 0 0 8px 0; }
        .tobyflow-cfg-err-desc { font-size: 14px; color: rgba(255,255,255,0.6); margin: 0 0 24px 0; line-height: 1.5; }
        .tobyflow-cfg-err-retry-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #fff; color: #1a1a1e; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: opacity 0.2s; }
        .tobyflow-cfg-err-retry-btn:hover { opacity: 0.9; }
        .tobyflow-cfg-err-retry-btn:active { opacity: 0.8; }
        .tobyflow-cfg-err-retry-btn svg { color: #1a1a1e; }
      </style>
      <div class="tobyflow-cfg-err-content">
        <div class="tobyflow-cfg-err-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <line x1="2" y1="2" x2="22" y2="22"></line>
            <path d="M8.5 16.5a5 5 0 0 1 7 0"></path>
            <path d="M2 8.82a15 15 0 0 1 4.17-2.65"></path>
            <path d="M10.66 5c4.01-.36 8.14.9 11.34 3.76"></path>
            <path d="M16.85 11.25a10 10 0 0 1 2.22 1.68"></path>
            <path d="M5 13a10 10 0 0 1 5.24-2.76"></path>
            <line x1="12" y1="20" x2="12.01" y2="20"></line>
          </svg>
        </div>
        <h3 class="tobyflow-cfg-err-title"></h3>
        <p class="tobyflow-cfg-err-desc"></p>
        <button class="tobyflow-cfg-err-retry-btn" type="button">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M21 2v6h-6"></path>
            <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
            <path d="M3 22v-6h6"></path>
            <path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path>
          </svg>
          <span></span>
        </button>
      </div>
    `;
      overlay.querySelector(".tobyflow-cfg-err-title").textContent = t.title;
      overlay.querySelector(".tobyflow-cfg-err-desc").textContent = t.desc;
      overlay.querySelector(".tobyflow-cfg-err-retry-btn span").textContent = t.retry;
      document.body.appendChild(overlay);
      overlay.querySelector(".tobyflow-cfg-err-retry-btn").addEventListener("click", () => {
        console.log(`[Selector:${PROVIDER}:overlay] \u{1F504} User clicked retry \u2014 reloading page`);
        overlay.remove();
        location.reload();
      });
      console.warn(`[Selector:${PROVIDER}:overlay] \u{1F6AB} Config error overlay shown (lang=${lang}) \u2014 server unreachable, user action required`);
    }
    function _showCloneDetectedOverlay() {
      if (document.getElementById("tobyflow-clone-detected-overlay")) return;
      const _lang = _i18n && _i18n._lang || "vi";
      const titleMap = { vi: "Extension kh\xF4ng h\u1EE3p l\u1EC7", en: "Extension Not Authorized", ja: "\u62E1\u5F35\u6A5F\u80FD\u304C\u8A31\u53EF\u3055\u308C\u3066\u3044\u307E\u305B\u3093", th: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2D\u0E19\u0E38\u0E0D\u0E32\u0E15" };
      const descMap = { vi: "Phi\xEAn b\u1EA3n extension n\xE0y kh\xF4ng c\xF3 quy\u1EC1n truy c\u1EADp API Flow. Vui l\xF2ng c\xE0i l\u1EA1i t\u1EEB Chrome Web Store \u0111\u1EC3 ti\u1EBFp t\u1EE5c s\u1EED d\u1EE5ng.", en: "This extension version is not authorized to access Flow API. Please reinstall from the Chrome Web Store to continue.", ja: "\u3053\u306E\u62E1\u5F35\u6A5F\u80FD\u306E\u30D0\u30FC\u30B8\u30E7\u30F3\u306F Flow API \u3078\u306E\u30A2\u30AF\u30BB\u30B9\u304C\u8A31\u53EF\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002Chrome \u30A6\u30A7\u30D6\u30B9\u30C8\u30A2\u304B\u3089\u518D\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u3057\u3066\u304F\u3060\u3055\u3044\u3002", th: "\u0E2A\u0E48\u0E27\u0E19\u0E02\u0E22\u0E32\u0E22\u0E40\u0E27\u0E2D\u0E23\u0E4C\u0E0A\u0E31\u0E19\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E2D\u0E19\u0E38\u0E0D\u0E32\u0E15\u0E43\u0E2B\u0E49\u0E40\u0E02\u0E49\u0E32\u0E16\u0E36\u0E07 API \u0E02\u0E2D\u0E07 Flow \u0E42\u0E1B\u0E23\u0E14\u0E15\u0E34\u0E14\u0E15\u0E31\u0E49\u0E07\u0E43\u0E2B\u0E21\u0E48\u0E08\u0E32\u0E01 Chrome \u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E42\u0E15\u0E23\u0E4C" };
      const btnMap = { vi: "M\u1EDF Chrome Web Store", en: "Open Chrome Web Store", ja: "Chrome \u30A6\u30A7\u30D6\u30B9\u30C8\u30A2\u3092\u958B\u304F", th: "\u0E40\u0E1B\u0E34\u0E14 Chrome \u0E40\u0E27\u0E47\u0E1A\u0E2A\u0E42\u0E15\u0E23\u0E4C" };
      const overlay = document.createElement("div");
      overlay.id = "tobyflow-clone-detected-overlay";
      overlay.innerHTML = `
      <style>
        #tobyflow-clone-detected-overlay { position: fixed; inset: 0; z-index: 2147483647; background: rgba(10,10,14,0.97); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        #tobyflow-clone-detected-overlay .cd-content { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 32px; max-width: 340px; }
        #tobyflow-clone-detected-overlay .cd-icon { width: 80px; height: 80px; border-radius: 50%; background: rgba(239,68,68,0.15); display: flex; align-items: center; justify-content: center; margin-bottom: 20px; color: #ef4444; }
        #tobyflow-clone-detected-overlay .cd-title { font-size: 18px; font-weight: 600; color: #fff; margin: 0 0 8px 0; }
        #tobyflow-clone-detected-overlay .cd-desc { font-size: 14px; color: rgba(255,255,255,0.65); margin: 0 0 24px 0; line-height: 1.55; }
        #tobyflow-clone-detected-overlay .cd-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #fff; color: #1a1a1e; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; }
        #tobyflow-clone-detected-overlay .cd-btn:hover { opacity: 0.9; }
      </style>
      <div class="cd-content">
        <div class="cd-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            <line x1="9" y1="9" x2="15" y2="15"></line>
            <line x1="15" y1="9" x2="9" y2="15"></line>
          </svg>
        </div>
        <h3 class="cd-title">${titleMap[_lang] || titleMap.vi}</h3>
        <p class="cd-desc">${descMap[_lang] || descMap.vi}</p>
        <a class="cd-btn" target="_blank" rel="noopener" href="https://chromewebstore.google.com/">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
            <polyline points="15 3 21 3 21 9"></polyline>
            <line x1="10" y1="14" x2="21" y2="3"></line>
          </svg>
          <span>${btnMap[_lang] || btnMap.vi}</span>
        </a>
      </div>
    `;
      document.body.appendChild(overlay);
      console.error(`[Auth:${PROVIDER}] \u{1F6E1}\uFE0F Clone-detected overlay shown \u2014 extension not authorized`);
    }
    function _hideCloneDetectedOverlay() {
      const el = document.getElementById("tobyflow-clone-detected-overlay");
      if (el) el.remove();
    }
    (function _initCloneDetectedListener() {
      try {
        setTimeout(() => {
          chrome.storage.local.get("tobyflow_extension_not_authorized", (res) => {
            if (res && res.tobyflow_extension_not_authorized) _showCloneDetectedOverlay();
          });
        }, 800);
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== "local") return;
          if (changes.tobyflow_extension_not_authorized) {
            if (changes.tobyflow_extension_not_authorized.newValue) _showCloneDetectedOverlay();
            else _hideCloneDetectedOverlay();
          }
        });
        if (chrome.runtime && chrome.runtime.onMessage) {
          chrome.runtime.onMessage.addListener((msg) => {
            if (msg && msg.type === "EXTENSION_NOT_AUTHORIZED") _showCloneDetectedOverlay();
            else if (msg && msg.type === "EXTENSION_AUTHORIZED") _hideCloneDetectedOverlay();
          });
        }
        document.addEventListener("click", (e) => {
          if (e.target?.closest?.("#tobyflow-clone-detected-overlay")) {
            try {
              chrome.runtime.sendMessage({ type: "EXTENSION_AUTH_RETRY" });
            } catch (_) {
            }
          }
        }, true);
      } catch (_) {
      }
    })();
    function _getDynamicSelector(key) {
      const now = Date.now();
      if (_selectorConfig && now - _selectorConfigTime < _SELECTOR_CACHE_TTL) {
        return _selectorConfig?.[PROVIDER]?.selectors?.[key] || null;
      }
      chrome.storage.local.get(["toby_provider_configs"], (res) => {
        if (res.toby_provider_configs?.data) {
          _selectorConfig = res.toby_provider_configs.data;
          _selectorConfigTime = Date.now();
        }
      });
      return _selectorConfig?.[PROVIDER]?.selectors?.[key] || null;
    }
    function _selStr(key) {
      const cfg = _getDynamicSelector(key);
      return cfg?.selectors?.length ? cfg.selectors.join(", ") : null;
    }
    function _q(key, scope = document) {
      const s = _selStr(key);
      if (!s) {
        console.debug(`[Tier3] _q(${key}) miss`);
        return null;
      }
      return scope.querySelector(s);
    }
    function _qa(key, scope = document) {
      const s = _selStr(key);
      if (!s) {
        console.debug(`[Tier3] _qa(${key}) miss`);
        return [];
      }
      return scope.querySelectorAll(s);
    }
    function _queryWithFallback(key, defaultSelectors = null, options = {}) {
      const config = _getDynamicSelector(key);
      const hardcoded = defaultSelectors || [];
      const isDynamic = config?.selectors?.length > 0;
      const silent = options.silent || false;
      const tries = [];
      if (isDynamic) tries.push({ label: "\u{1F310} DYNAMIC", selectors: config.selectors });
      if (hardcoded.length > 0) tries.push({ label: "\u{1F4E6} HARDCODED", selectors: hardcoded });
      if (!silent) {
        console.log(`[Selector:${PROVIDER}:${key}] ${tries.map((t) => `${t.label}:${t.selectors.length}`).join(" | ") || "NO SELECTORS"}`);
      }
      for (const tier of tries) {
        for (let i = 0; i < tier.selectors.length; i++) {
          try {
            const el = document.querySelector(tier.selectors[i]);
            if (el) {
              console.log(`[Selector:${PROVIDER}:${key}] \u2705 Match ${tier.label} #${i + 1}: ${tier.selectors[i]}`);
              return el;
            }
          } catch (e) {
          }
        }
      }
      if (!silent) console.log(`[Selector:${PROVIDER}:${key}] \u274C No match`);
      return null;
    }
    function _queryAllWithFallback(key, defaultSelectors = null) {
      const config = _getDynamicSelector(key);
      const hardcoded = defaultSelectors || [];
      const tiers = [];
      if (config?.selectors?.length > 0) tiers.push(config.selectors);
      if (hardcoded.length > 0) tiers.push(hardcoded);
      for (const selectors of tiers) {
        for (let i = 0; i < selectors.length; i++) {
          try {
            const els = document.querySelectorAll(selectors[i]);
            if (els.length > 0) return els;
          } catch (e) {
          }
        }
      }
      return [];
    }
    let __grokInputTimeoutMs = 1200;
    let __grokMacroDelayMs = Math.round(1200 * 0.7);
    function getMacroDelay() {
      return __grokMacroDelayMs;
    }
    function simulateClick(el) {
      if (!el || !(el instanceof Element)) {
        console.warn("[Grok] simulateClick: invalid element type", el);
        return;
      }
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) {
        console.warn("[Grok] simulateClick: element zero-size (hidden/detached), skip", el);
        return;
      }
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0, pointerType: "mouse" };
      el.dispatchEvent(new PointerEvent("pointerdown", opts));
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new PointerEvent("pointerup", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
    }
    function clickViaReact(el) {
      if (!el) return false;
      const propsKey = Object.keys(el).find((k) => k.startsWith("__reactProps$"));
      if (propsKey && el[propsKey] && typeof el[propsKey].onClick === "function") {
        el[propsKey].onClick({
          preventDefault() {
          },
          stopPropagation() {
          },
          nativeEvent: new MouseEvent("click", { bubbles: true }),
          type: "click",
          target: el,
          currentTarget: el
        });
        return true;
      }
      return false;
    }
    async function waitForElement(selector, timeout = 1e4) {
      const start = Date.now();
      while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el) return el;
        await sleep(300);
      }
      return null;
    }
    const FloatingTracker = typeof window.createFloatingTrackerRich === "function" ? window.createFloatingTrackerRich({ id: "tobyflow-grok-tracker", title: "Grok" }) : {
      _el: null,
      show() {
      },
      update() {
      },
      hide() {
      },
      updateFromQueue() {
      }
    };
    let _ftRichActive = false;
    if (FloatingTracker && typeof FloatingTracker.show === "function" && typeof window.createFloatingTrackerRich === "function") {
      const _s = FloatingTracker.show.bind(FloatingTracker);
      const _u = FloatingTracker.update.bind(FloatingTracker);
      const _h = FloatingTracker.hide.bind(FloatingTracker);
      FloatingTracker.show = (a) => {
        if (!_ftRichActive) _s(a);
      };
      FloatingTracker.update = (a) => {
        if (!_ftRichActive) _u(a);
      };
      FloatingTracker.hide = () => {
        if (!_ftRichActive) _h();
      };
    }
    const ExecutionBlocker = {
      _el: null,
      _styleEl: null,
      _blocking: false,
      _escapeCount: 0,
      _escapeTimer: null,
      _timeoutId: null,
      // Image gen thường > 3 phút; chỉ bỏ block UI, không kill gen
      _MAX_BLOCK_TIME: 8 * 60 * 1e3,
      _injectStyles() {
        if (this._styleEl) return;
        const style = document.createElement("style");
        style.id = "tobyflow-grok-blocker-styles";
        style.textContent = `
        #tobyflow-grok-blocker {
          position: fixed; inset: 0; z-index: 2147483646;
          pointer-events: all; cursor: not-allowed;
          background: transparent;
          box-shadow: inset 0 0 0 3px rgba(205, 255, 1, 0.85);
        }
        #tobyflow-grok-blocker::after {
          content: 'TobyFlow \xB7 \u0111ang ch\u1EA1y Grok (Esc \xD73 \u0111\u1EC3 d\u1EEBng)';
          position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
          z-index: 2147483647; pointer-events: none;
          background: rgba(20,20,20,0.82); color: #cdff01;
          font: 600 12px/1.3 system-ui, sans-serif;
          padding: 6px 14px; border-radius: 999px;
          box-shadow: 0 2px 12px rgba(0,0,0,0.35);
        }
      `;
        document.head.appendChild(style);
        this._styleEl = style;
      },
      _blockEvent(e) {
        if (!ExecutionBlocker._blocking) return;
        if (!e.isTrusted) return;
        if (e.target?.closest?.("#tobyflow-grok-tracker")) return;
        if (e.type === "keydown" && e.key === "Escape") {
          ExecutionBlocker._escapeCount++;
          clearTimeout(ExecutionBlocker._escapeTimer);
          ExecutionBlocker._escapeTimer = setTimeout(() => {
            ExecutionBlocker._escapeCount = 0;
          }, 2e3);
          if (ExecutionBlocker._escapeCount >= 3) {
            console.warn("[Grok-ExecutionBlocker] Force hide via Escape x3 \u2192 abort");
            ExecutionBlocker._escapeCount = 0;
            ExecutionBlocker.hide();
            __grokAbort = true;
            __grokAbortAt = Date.now();
            return;
          }
        }
        e.stopPropagation();
        e.stopImmediatePropagation();
        e.preventDefault();
      },
      _attachBlockers() {
        if (this._blocking) return;
        this._blocking = true;
        const events = ["mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel", "touchstart", "touchend", "keydown", "keyup"];
        events.forEach((evt) => document.addEventListener(evt, this._blockEvent, { capture: true, passive: false }));
      },
      _detachBlockers() {
        if (!this._blocking) return;
        this._blocking = false;
        const events = ["mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel", "touchstart", "touchend", "keydown", "keyup"];
        events.forEach((evt) => document.removeEventListener(evt, this._blockEvent, { capture: true }));
      },
      show() {
        this._injectStyles();
        this._attachBlockers();
        this._startTimeout();
        if (this._el) {
          this._el.style.display = "block";
          return;
        }
        const el = document.createElement("div");
        el.id = "tobyflow-grok-blocker";
        document.body.appendChild(el);
        this._el = el;
      },
      _startTimeout() {
        this._stopTimeout();
        this._timeoutId = setTimeout(() => {
          console.warn("[Grok-ExecutionBlocker] Auto-timeout, force hiding (KH\xD4NG abort \u2014 wait/extract t\u1EF1 x\u1EED l\xFD)");
          this.hide();
        }, this._MAX_BLOCK_TIME);
      },
      _stopTimeout() {
        if (this._timeoutId) {
          clearTimeout(this._timeoutId);
          this._timeoutId = null;
        }
      },
      hide() {
        this._detachBlockers();
        this._stopTimeout();
        this._escapeCount = 0;
        clearTimeout(this._escapeTimer);
        if (this._el) this._el.style.display = "none";
      }
    };
    const _findDomOpts = () => ({
      doc: document,
      queryConfiguredComposer: () => _queryWithFallback("composer"),
      queryConfiguredSubmit: () => _queryWithFallback("submit_button"),
      log: (...a) => console.log("[Grok]", ...a)
    });
    function isUsableEditor2(el) {
      return isUsableEditor(el, void 0, document);
    }
    function findGrokComposerRoot2() {
      return findGrokComposerRoot(_findDomOpts());
    }
    function findGrokEditor2() {
      return findGrokEditor(_findDomOpts());
    }
    function findSubmitBtnForEditor(editor) {
      return findGrokSubmitBtn(editor, _findDomOpts());
    }
    function mainWorldFill(text, submit = false) {
      try {
        if (!window.__tobyflowGrokMwHooked) {
          const hook = function grokMwPasteHook() {
            if (window.__tobyflowGrokMwPageListener) return;
            window.__tobyflowGrokMwPageListener = true;
            window.addEventListener("message", async (ev) => {
              if (ev.source !== window || !ev.data || ev.data.type !== "tobyflow-grok-mw-paste") return;
              const { id: id2, text: t, submit: doSub } = ev.data;
              let result = { success: false, error: "PAGE_NO_FN" };
              try {
                const ed = document.querySelector('[contenteditable="true"][role="textbox"][aria-label="Ask Grok anything"]') || document.querySelector('[contenteditable="true"].ProseMirror') || document.querySelector('[contenteditable="true"]');
                if (!ed) {
                  result = { success: false, error: "NO_EDITOR" };
                } else {
                  ed.focus();
                  try {
                    document.execCommand("selectAll", false, null);
                    document.execCommand("insertText", false, String(t || ""));
                  } catch (_) {
                    ed.textContent = String(t || "");
                    ed.dispatchEvent(new InputEvent("input", { bubbles: true }));
                  }
                  const len = (ed.textContent || "").trim().length;
                  result = {
                    success: len > 0,
                    insertOk: len > 0,
                    textLen: len,
                    method: "page_execCommand",
                    submitted: false,
                    verified: false,
                    preview: (ed.textContent || "").slice(0, 40)
                  };
                  if (doSub && len > 0) {
                    await new Promise((r) => setTimeout(r, 200));
                    const form = ed.closest("form");
                    if (form && typeof form.requestSubmit === "function") {
                      try {
                        form.requestSubmit();
                        result.submitted = true;
                        result.submitMethod = "formRequestSubmit";
                      } catch (_) {
                      }
                    }
                    if (!result.submitted) {
                      const btn = document.querySelector('button[type="submit"], button[aria-label="G\u1EEDi"], button[aria-label="Send"]');
                      if (btn) {
                        btn.click();
                        result.submitted = true;
                        result.submitMethod = "buttonClick";
                      }
                    }
                    await new Promise((r) => setTimeout(r, 300));
                    const left = (ed.textContent || "").trim().length;
                    if (left === 0) result.verified = true;
                  }
                }
              } catch (e) {
                result = { success: false, error: e.message || "PAGE_EXCEPTION" };
              }
              window.postMessage({ type: "tobyflow-grok-mw-paste-result", id: id2, result }, "*");
            });
          };
          const s = document.createElement("script");
          s.textContent = "(" + hook.toString() + ")();";
          (document.documentElement || document.head).appendChild(s);
          s.remove();
          window.__tobyflowGrokMwHooked = true;
        }
      } catch (e) {
        console.warn("[Grok] mainWorldFill hook inject fail", e?.message);
      }
      const id = "mw_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
      return new Promise((resolve) => {
        const t = setTimeout(() => {
          window.removeEventListener("message", onRes);
          resolve({ success: false, error: "MW_PAGE_TIMEOUT" });
        }, 4e3);
        function onRes(ev) {
          if (ev.source !== window || !ev.data || ev.data.type !== "tobyflow-grok-mw-paste-result") return;
          if (ev.data.id !== id) return;
          clearTimeout(t);
          window.removeEventListener("message", onRes);
          const r = ev.data.result || { success: false, error: "NO_RESULT" };
          console.log("[Grok] mainWorldFill page result:", {
            insertOk: r.insertOk,
            textLen: r.textLen,
            submitted: r.submitted,
            method: r.method,
            error: r.error
          });
          resolve(r);
        }
        window.addEventListener("message", onRes);
        window.postMessage({ type: "tobyflow-grok-mw-paste", id, text: String(text || ""), submit: !!submit }, "*");
      });
    }
    let _grokPatterns = {
      rateLimit: [],
      contentBlocked: [],
      network: [],
      cloudflare: [],
      subscriptionRequired: [],
      notLoggedIn: []
      // [Bug 61 fix 2026-05-24] Text patterns detect button Sign in/Sign up khi chưa login
    };
    function _parsePatternStr(str) {
      if (!str || typeof str !== "string") return [];
      return str.split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
    }
    async function _loadGrokPatternsFromStorage() {
      try {
        const result = await new Promise((r) => chrome.storage.local.get(["af_grok_config"], r));
        const cfg = result?.af_grok_config?.data;
        if (!cfg) return false;
        _grokPatterns.rateLimit = _parsePatternStr(cfg.rate_limit_text);
        _grokPatterns.contentBlocked = _parsePatternStr(cfg.content_blocked_text);
        _grokPatterns.network = _parsePatternStr(cfg.network_error_text);
        _grokPatterns.cloudflare = _parsePatternStr(cfg.cloudflare_challenge_text);
        _grokPatterns.subscriptionRequired = _parsePatternStr(cfg.subscription_required_text);
        _grokPatterns.notLoggedIn = _parsePatternStr(cfg.not_logged_in_text);
        const total = Object.values(_grokPatterns).reduce((s, a) => s + a.length, 0);
        return total > 0;
      } catch (e) {
        return false;
      }
    }
    const _GROK_PATTERNS_WAIT_MAX_MS = 1e4;
    const _GROK_PATTERNS_WAIT_INTERVAL_MS = 500;
    (async function _ensureGrokPatternsConfig() {
      try {
        const ok = await _loadGrokPatternsFromStorage();
        if (ok) {
          const total = Object.values(_grokPatterns).reduce((s, a) => s + a.length, 0);
          console.debug(`[Grok:patterns] loaded ${total} error labels from storage`);
        } else {
          try {
            chrome.runtime.sendMessage({ action: "getProviderConfigs", provider: "grok" }, () => {
              void chrome.runtime.lastError;
            });
          } catch (_) {
          }
          console.debug("[Grok:patterns] no af_grok_config yet \u2014 paste/submit v\u1EABn ch\u1EA1y b\xECnh th\u01B0\u1EDDng");
        }
      } catch (_) {
      }
    })();
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.af_grok_config) {
          _loadGrokPatternsFromStorage();
        }
      });
    } catch (e) {
    }
    function detectCloudflareChallenge() {
      if (_queryWithFallback("cloudflare_iframe", null, { silent: true })) return true;
      if (_queryWithFallback("cloudflare_turnstile", null, { silent: true })) return true;
      const cloudflarePatterns = _grokPatterns.cloudflare;
      if (cloudflarePatterns.length === 0) return false;
      const overlays = _qa("cloudflare_overlay_dialog");
      for (const el of overlays) {
        const txt = (el.innerText || "").toLowerCase();
        if (cloudflarePatterns.some((p) => txt.includes(p))) {
          const style = window.getComputedStyle(el);
          if (style.display !== "none" && style.visibility !== "hidden") return true;
        }
      }
      return false;
    }
    function attemptCloudflareClick() {
      console.log("[Grok] Attempting Cloudflare verification trigger...");
      if (window.turnstile) {
        try {
          const turnstileIframe2 = _queryWithFallback("cloudflare_iframe");
          const widgetId = turnstileIframe2?.id?.replace("cf-chl-widget-", "") || null;
          if (typeof window.turnstile.execute === "function") {
            console.log("[Grok] Calling turnstile.execute()...");
            window.turnstile.execute(widgetId);
          } else if (typeof window.turnstile.reset === "function") {
            console.log("[Grok] Calling turnstile.reset() to retry verification...");
            window.turnstile.reset(widgetId);
          }
        } catch (e) {
          console.warn("[Grok] Turnstile API call failed:", e.message);
        }
      }
      const turnstileIframe = _queryWithFallback("cloudflare_iframe");
      if (turnstileIframe) {
        try {
          turnstileIframe.scrollIntoView({ behavior: "instant", block: "center" });
          turnstileIframe.focus();
          const rect = turnstileIframe.getBoundingClientRect();
          const checkboxX = rect.left + 25;
          const checkboxY = rect.top + rect.height / 2;
          const eventOptions = {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: checkboxX,
            clientY: checkboxY,
            button: 0,
            buttons: 1
          };
          turnstileIframe.dispatchEvent(new MouseEvent("mouseover", eventOptions));
          turnstileIframe.dispatchEvent(new MouseEvent("mousedown", eventOptions));
          turnstileIframe.dispatchEvent(new MouseEvent("mouseup", eventOptions));
          turnstileIframe.dispatchEvent(new MouseEvent("click", eventOptions));
          console.log("[Grok] Clicked turnstile iframe at checkbox position:", Math.round(checkboxX), Math.round(checkboxY));
          turnstileIframe.dispatchEvent(new KeyboardEvent("keydown", { key: " ", code: "Space", keyCode: 32, bubbles: true }));
          turnstileIframe.dispatchEvent(new KeyboardEvent("keyup", { key: " ", code: "Space", keyCode: 32, bubbles: true }));
          console.log("[Grok] Dispatched Space key on turnstile iframe");
        } catch (e) {
          console.warn("[Grok] Turnstile iframe interaction failed:", e.message);
        }
      }
      const turnstileContainer = _queryWithFallback("cloudflare_turnstile");
      if (turnstileContainer) {
        try {
          const rect = turnstileContainer.getBoundingClientRect();
          const centerX = rect.left + rect.width / 2;
          const centerY = rect.top + rect.height / 2;
          const clickEvent = new MouseEvent("click", {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: centerX,
            clientY: centerY
          });
          turnstileContainer.dispatchEvent(clickEvent);
          console.log("[Grok] Clicked turnstile container at", Math.round(centerX), Math.round(centerY));
        } catch (e) {
          console.warn("[Grok] Turnstile container click failed:", e.message);
        }
      }
      try {
        window.focus();
        document.body.focus();
        const bodyClickEvent = new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
          clientX: window.innerWidth / 2,
          clientY: window.innerHeight / 2
        });
        document.body.dispatchEvent(bodyClickEvent);
        console.log("[Grok] Clicked page body center");
      } catch (e) {
        console.warn("[Grok] Body click failed:", e.message);
      }
      try {
        const centerX = window.innerWidth / 2;
        const centerY = window.innerHeight / 2;
        for (let i = 0; i <= 5; i++) {
          const x = centerX * i / 5;
          const y = centerY * i / 5;
          document.body.dispatchEvent(new MouseEvent("mousemove", {
            bubbles: true,
            view: window,
            clientX: x,
            clientY: y
          }));
        }
        document.body.dispatchEvent(new MouseEvent("mousedown", {
          bubbles: true,
          cancelable: true,
          view: window,
          clientX: centerX,
          clientY: centerY,
          button: 0,
          buttons: 1
        }));
        document.body.dispatchEvent(new MouseEvent("mouseup", {
          bubbles: true,
          cancelable: true,
          view: window,
          clientX: centerX,
          clientY: centerY,
          button: 0,
          buttons: 0
        }));
        console.log("[Grok] Dispatched realistic mouse movement + click sequence");
      } catch (e) {
        console.warn("[Grok] Mouse sequence failed:", e.message);
      }
    }
    async function waitForCloudflareResolved(timeoutMs = 12e4) {
      if (!detectCloudflareChallenge()) return true;
      console.warn("[Grok] Cloudflare challenge detected \u2014 request tab activate + auto-click + ch\u1EDD verify");
      const _wasBlocking = ExecutionBlocker._blocking;
      if (_wasBlocking) {
        console.log("[Grok] \u1EA8n ExecutionBlocker \u0111\u1EC3 user click Cloudflare captcha");
        ExecutionBlocker.hide();
      }
      const _restoreBlocker = () => {
        if (_wasBlocking && !isAbortActive()) ExecutionBlocker.show();
      };
      const _notifySidebar = (phase, elapsedSec = 0) => {
        try {
          chrome.runtime.sendMessage({
            action: "cloudflare:challenge",
            provider: "grok",
            phase,
            // 'detected' | 'waiting' | 'resolved' | 'timeout'
            elapsedSec,
            timeoutSec: Math.round(timeoutMs / 1e3)
          }).catch(() => {
          });
        } catch (_) {
        }
      };
      _notifySidebar("detected", 0);
      try {
        await new Promise((resolve) => {
          chrome.runtime.sendMessage(
            { action: "grok:ensureActive", focusWindow: true, reason: "cloudflare_challenge" },
            () => resolve()
          );
        });
      } catch (_) {
      }
      await sleep(500);
      attemptCloudflareClick();
      const start = Date.now();
      let lastLog = 0;
      let clickAttempts = 1;
      const MAX_CLICK_ATTEMPTS = 5;
      const CLICK_RETRY_INTERVAL = 1e4;
      while (Date.now() - start < timeoutMs) {
        if (isAbortActive()) return false;
        if (!detectCloudflareChallenge()) {
          const elapsedSec = Math.round((Date.now() - start) / 1e3);
          console.log("[Grok] Cloudflare challenge resolved sau", elapsedSec, "s");
          _notifySidebar("resolved", elapsedSec);
          await sleep(800);
          _restoreBlocker();
          try {
            chrome.runtime.sendMessage({ action: "grok:restoreFocus" }, () => {
            });
          } catch (_) {
          }
          return true;
        }
        const elapsed = Date.now() - start;
        if (elapsed - lastLog >= 1e4) {
          const elapsedSec = Math.round(elapsed / 1e3);
          console.log("[Grok] V\u1EABn ch\u1EDD Cloudflare challenge resolved...", elapsedSec, "s");
          lastLog = elapsed;
          _notifySidebar("waiting", elapsedSec);
          if (clickAttempts < MAX_CLICK_ATTEMPTS) {
            console.log("[Grok] Retry click attempt", clickAttempts + 1);
            attemptCloudflareClick();
            clickAttempts++;
          }
        }
        await sleep(800);
      }
      console.error("[Grok] Cloudflare challenge timeout sau", timeoutMs / 1e3, "s");
      _notifySidebar("timeout", Math.round(timeoutMs / 1e3));
      return false;
    }
    function detectAgeVerificationModal() {
      const modal = _queryWithFallback("age_verification_modal");
      return !!modal;
    }
    async function handleAgeVerificationModal(timeoutMs = 3e4) {
      const modal = _queryWithFallback("age_verification_modal");
      if (!modal) return true;
      console.log("[Grok] Age verification modal detected \u2014 auto-selecting birth year");
      try {
        const scrollContainer = _q("age_verification_scroll_container", modal);
        if (!scrollContainer) {
          console.warn("[Grok] Age verification: kh\xF4ng t\xECm th\u1EA5y scroll container");
          return false;
        }
        const yearButtons = _qa("age_verification_year_button", scrollContainer);
        if (yearButtons.length === 0) {
          console.warn("[Grok] Age verification: kh\xF4ng t\xECm th\u1EA5y year buttons");
          return false;
        }
        const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
        const targetYear = currentYear - 25;
        let targetButton = null;
        for (const btn of yearButtons) {
          const yearText = (btn.textContent || "").trim();
          const year = parseInt(yearText, 10);
          if (!isNaN(year) && year <= targetYear) {
            targetButton = btn;
            break;
          }
        }
        if (!targetButton) {
          for (const btn of yearButtons) {
            const yearText = (btn.textContent || "").trim();
            if (yearText === "2000" || yearText === "1995" || yearText === "1990") {
              targetButton = btn;
              break;
            }
          }
        }
        if (!targetButton) {
          console.warn("[Grok] Age verification: kh\xF4ng t\xECm th\u1EA5y n\u0103m ph\xF9 h\u1EE3p");
          return false;
        }
        if (isAbortActive()) return false;
        targetButton.scrollIntoView({ behavior: "smooth", block: "center" });
        await sleep(300);
        if (isAbortActive()) return false;
        if (!clickViaReact(targetButton)) {
          simulateClick(targetButton);
        }
        console.log("[Grok] Age verification: \u0111\xE3 ch\u1ECDn n\u0103m", targetButton.textContent?.trim());
        await sleep(500);
        if (isAbortActive()) return false;
        const allBtns = _qa("age_verification_year_button", modal);
        let continueBtnFound = null;
        for (const btn of allBtns) {
          const txt = (btn.textContent || "").toLowerCase().trim();
          if (txt === "continue" && !btn.disabled) {
            continueBtnFound = btn;
            break;
          }
        }
        if (!continueBtnFound) {
          const footerBtns = _qa("age_verification_continue_button", modal);
          for (const btn of footerBtns) {
            if (!btn.disabled) {
              continueBtnFound = btn;
              break;
            }
          }
        }
        if (!continueBtnFound) {
          console.warn("[Grok] Age verification: Continue button v\u1EABn disabled ho\u1EB7c kh\xF4ng t\xECm th\u1EA5y");
          const start = Date.now();
          while (Date.now() - start < 5e3) {
            if (isAbortActive()) return false;
            await sleep(300);
            for (const btn of allBtns) {
              const txt = (btn.textContent || "").toLowerCase().trim();
              if (txt === "continue" && !btn.disabled) {
                continueBtnFound = btn;
                break;
              }
            }
            if (continueBtnFound) break;
          }
        }
        if (continueBtnFound) {
          if (isAbortActive()) return false;
          if (!clickViaReact(continueBtnFound)) {
            simulateClick(continueBtnFound);
          }
          console.log("[Grok] Age verification: \u0111\xE3 click Continue");
          await sleep(500);
          const closeStart = Date.now();
          while (Date.now() - closeStart < 5e3) {
            if (isAbortActive()) return false;
            if (!_queryWithFallback("age_verification_modal")) {
              console.log("[Grok] Age verification: modal \u0111\xE3 \u0111\xF3ng");
              return true;
            }
            await sleep(200);
          }
          console.warn("[Grok] Age verification: modal ch\u01B0a \u0111\xF3ng sau 5s");
          return !_queryWithFallback("age_verification_modal");
        }
        return false;
      } catch (err) {
        console.error("[Grok] Age verification error:", err.message);
        return false;
      }
    }
    async function clearEditor(editor) {
      if (!editor) editor = findGrokEditor2();
      if (!editor) return false;
      editor.focus();
      await sleep(100);
      document.execCommand("selectAll", false, null);
      document.execCommand("delete", false, null);
      editor.dispatchEvent(new InputEvent("beforeinput", {
        inputType: "deleteContentBackward",
        bubbles: true,
        cancelable: true
      }));
      if (!editor.textContent.trim()) return true;
      editor.innerHTML = "<p><br></p>";
      editor.dispatchEvent(new InputEvent("input", { bubbles: true }));
      return true;
    }
    const insertText = createInsertText({
      findGrokEditor: findGrokEditor2,
      mainWorldFill,
      sleep,
      log: (...a) => console.log("[Grok]", ...a)
    });
    const clickSubmit = createClickSubmit({
      findGrokEditor: findGrokEditor2,
      findSubmitBtn: findSubmitBtnForEditor,
      sleep,
      simulateClick: typeof simulateClick === "function" ? simulateClick : (el) => {
        try {
          el.click();
        } catch (_) {
        }
      },
      findDomOpts: _findDomOpts(),
      log: (...a) => console.log("[Grok]", ...a)
    });
    async function selectMode(mode) {
      const labelCfg = await _getGrokApiConfig("mode_labels");
      if (!labelCfg) console.debug("[Tier3] Grok selectMode: mode_labels config miss \u2192 fallback t\u1ED1i thi\u1EC3u");
      const rawLabels = labelCfg?.[mode] ?? (mode === "video" ? "Video" : "Image");
      const targetTexts = String(rawLabels).split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
      const group = _queryWithFallback("generation_mode");
      const svgPaths = await _getGrokApiConfig("mode_toggle_svg_paths");
      const pathPrefix = svgPaths?.[mode];
      if (group) {
        const radios = group.querySelectorAll('[role="radio"]');
        if (pathPrefix) {
          for (const radio of radios) {
            if (radio.querySelector(`path[d^="${pathPrefix}"]`)) {
              if (radio.getAttribute("aria-checked") === "true") return true;
              simulateClick(radio);
              return true;
            }
          }
        }
        for (const radio of radios) {
          const text = (radio.textContent || "").trim().toLowerCase();
          if (!text) continue;
          if (targetTexts.some((t) => text === t || text.includes(t))) {
            if (radio.getAttribute("aria-checked") === "true") return true;
            simulateClick(radio);
            return true;
          }
        }
      }
      if (pathPrefix) {
        const allBtns = document.querySelectorAll('button[role="radio"]');
        for (const btn of allBtns) {
          if (btn.querySelector(`path[d^="${pathPrefix}"]`)) {
            simulateClick(btn);
            return true;
          }
        }
      } else {
        console.debug("[Tier3] Grok mode_toggle_svg_paths config miss \u2014 strategy 2 skip");
      }
      return false;
    }
    async function _getGrokApiConfig(key) {
      try {
        const result = await new Promise((r) => chrome.storage.local.get(["toby_provider_api_configs"], r));
        const cfg = result?.toby_provider_api_configs?.data?.grok?.configs?.[key];
        return cfg ?? null;
      } catch (_) {
        return null;
      }
    }
    async function selectRatio(ratioKey) {
      const ratiosCfg = await _getGrokApiConfig("ratios");
      const list = ratiosCfg?.image || ratiosCfg?.video;
      if (!Array.isArray(list) || list.length === 0) {
        console.debug("[Tier3] Grok selectRatio: ratios config miss");
        return false;
      }
      const displayMap = {};
      for (const r of list) {
        if (r?.ui_name && r?.value) displayMap[r.ui_name] = r.value;
      }
      const targetRatio = displayMap[ratioKey] || ratioKey;
      const ratioBtn = _queryWithFallback("ratio_button");
      if (!ratioBtn) return false;
      const currentRatio = ratioBtn.querySelector("span")?.textContent?.trim();
      if (currentRatio === targetRatio) return true;
      const isOpen = ratioBtn.getAttribute("data-state") === "open" || ratioBtn.getAttribute("aria-expanded") === "true" || ratioBtn.closest("[data-state]")?.dataset.state === "open";
      if (!isOpen) {
        simulateClick(ratioBtn);
        await sleep(500);
        const menuVisible = _queryWithFallback("open_menu");
        if (!menuVisible) {
          clickViaReact(ratioBtn);
          await sleep(500);
        }
      }
      let menuItem = document.querySelector(`button[aria-label="${targetRatio}"]`);
      if (!menuItem) {
        const items = _qa("ratio_menu_item");
        for (const item of items) {
          const span = item.querySelector("span");
          if (span && span.textContent.trim() === targetRatio) {
            menuItem = item;
            break;
          }
        }
      }
      if (!menuItem) {
        for (let attempt = 0; attempt < 5; attempt++) {
          const _omS = _selStr("open_menu");
          const poppers = _omS ? document.querySelectorAll(_omS) : [];
          if (!_omS) console.debug("[Tier3] open_menu config miss");
          for (const popper of poppers) {
            const allEls = popper.querySelectorAll("span, div, button");
            for (const el of allEls) {
              if (el.textContent.trim() === targetRatio) {
                menuItem = el.closest('[role="menuitem"], [role="menuitemradio"], button, div[tabindex]') || el;
                break;
              }
            }
            if (menuItem) break;
          }
          if (menuItem) break;
          await sleep(150);
        }
      }
      if (menuItem) {
        simulateClick(menuItem);
        await sleep(200);
        const newRatio = ratioBtn.querySelector("span")?.textContent?.trim();
        if (newRatio === targetRatio) return true;
        clickViaReact(menuItem);
        await sleep(200);
        return true;
      }
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      return false;
    }
    async function selectVideoDuration(duration) {
      const supported = await _getGrokApiConfig("supported_durations");
      if (!Array.isArray(supported) || supported.length === 0) {
        console.debug("[Tier3] Grok selectVideoDuration: supported_durations config miss");
        return false;
      }
      if (!supported.includes(duration)) {
        console.warn(`[Grok] selectVideoDuration: "${duration}" kh\xF4ng c\xF3 trong supported [${supported.join(",")}]`);
        return false;
      }
      const group = _queryWithFallback("video_duration_picker");
      if (!group) {
        console.warn("[Grok] selectVideoDuration: picker group kh\xF4ng th\u1EA5y");
        return false;
      }
      const want = String(duration).trim().toLowerCase();
      const wantNum = want.replace(/[^0-9]/g, "");
      const radios = group.querySelectorAll('[role="radio"]');
      const seen = [];
      for (const radio of radios) {
        const txt = (radio.textContent || "").trim();
        seen.push(txt);
        const norm = txt.toLowerCase();
        if (norm === want || wantNum && norm.replace(/[^0-9]/g, "") === wantNum) {
          if (radio.getAttribute("aria-checked") === "true") {
            console.log(`[Grok] selectVideoDuration: "${duration}" \u0111\xE3 ch\u1ECDn s\u1EB5n`);
            return true;
          }
          simulateClick(radio);
          console.log(`[Grok] selectVideoDuration: clicked "${txt}" cho duration "${duration}"`);
          return true;
        }
      }
      console.warn(`[Grok] selectVideoDuration: KH\xD4NG match "${duration}". Radios: [${seen.join(" | ")}]`);
      return false;
    }
    async function selectVideoResolution(resolution) {
      const supported = await _getGrokApiConfig("supported_resolutions");
      if (!Array.isArray(supported) || supported.length === 0) {
        console.debug("[Tier3] Grok selectVideoResolution: supported_resolutions config miss");
        return false;
      }
      if (!supported.includes(resolution)) {
        console.warn(`[Grok] selectVideoResolution: "${resolution}" kh\xF4ng c\xF3 trong supported [${supported.join(",")}]`);
        return false;
      }
      const group = _queryWithFallback("video_resolution_picker");
      if (!group) {
        console.warn("[Grok] selectVideoResolution: picker group kh\xF4ng th\u1EA5y");
        return false;
      }
      const want = String(resolution).trim().toLowerCase();
      const wantNum = want.replace(/[^0-9]/g, "");
      const radios = group.querySelectorAll('[role="radio"]');
      const seen = [];
      for (const radio of radios) {
        const txt = (radio.textContent || "").trim();
        seen.push(txt);
        const norm = txt.toLowerCase();
        if (norm === want || wantNum && norm.replace(/[^0-9]/g, "") === wantNum) {
          if (radio.getAttribute("aria-checked") === "true") {
            console.log(`[Grok] selectVideoResolution: "${resolution}" \u0111\xE3 ch\u1ECDn s\u1EB5n`);
            return true;
          }
          simulateClick(radio);
          console.log(`[Grok] selectVideoResolution: clicked "${txt}" cho resolution "${resolution}"`);
          return true;
        }
      }
      console.warn(`[Grok] selectVideoResolution: KH\xD4NG match "${resolution}". Radios: [${seen.join(" | ")}]`);
      return false;
    }
    async function selectImageQuality(quality) {
      const supported = await _getGrokApiConfig("supported_image_qualities");
      if (!Array.isArray(supported) || supported.length === 0) {
        console.debug("[Tier3] Grok selectImageQuality: supported_image_qualities config miss");
        return false;
      }
      const target = String(quality || "").toLowerCase();
      if (!supported.includes(target)) return false;
      const labelCfg = await _getGrokApiConfig("image_quality_labels");
      if (!labelCfg) console.debug("[Tier3] Grok selectImageQuality: image_quality_labels config miss \u2192 fallback English Capitalize");
      const fallbackEn = target.charAt(0).toUpperCase() + target.slice(1);
      const rawLabels = labelCfg?.[target] ?? fallbackEn;
      const targetTexts = String(rawLabels).split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
      const group = _queryWithFallback("image_quality_picker");
      if (!group) return false;
      const radios = group.querySelectorAll('[role="radio"]');
      for (const radio of radios) {
        const text = (radio.textContent || "").trim().toLowerCase();
        if (!text) continue;
        if (targetTexts.some((t) => text === t || text.includes(t))) {
          if (radio.getAttribute("aria-checked") === "true") return true;
          simulateClick(radio);
          return true;
        }
      }
      return false;
    }
    async function applyGrokImageQualityOnly(settings) {
      const { mode, imageQuality } = settings || {};
      if (!imageQuality) return true;
      if (mode === "video") return true;
      const qOk = await selectImageQuality(imageQuality);
      await sleep(200);
      if (!qOk) {
        console.warn("[Grok] applyGrokImageQualityOnly (pre-upload) failed:", imageQuality);
        return false;
      }
      console.log("[Grok] applyGrokImageQualityOnly: applied", imageQuality, "(pre-upload)");
      return true;
    }
    async function applyGrokSettings(settings, opts = {}) {
      const { skipImageQuality = false } = opts;
      const { mode, ratio, duration, resolution, imageQuality } = settings || {};
      let ok = true;
      if (mode) {
        const modeOk = await selectMode(mode);
        await sleep(300);
        if (!modeOk) ok = false;
      }
      if (ratio) {
        const ratioOk = await selectRatio(ratio);
        await sleep(200);
        if (!ratioOk) ok = false;
      }
      if (!skipImageQuality && imageQuality && mode === "image") {
        const qOk = await selectImageQuality(imageQuality);
        await sleep(200);
        if (!qOk) console.warn("[Grok] selectImageQuality failed:", imageQuality);
      }
      if (duration) {
        const durOk = await selectVideoDuration(duration);
        await sleep(200);
        if (!durOk) ok = false;
      }
      if (resolution) {
        const resOk = await selectVideoResolution(resolution);
        await sleep(200);
        if (!resOk) ok = false;
      }
      return ok;
    }
    async function removeExistingRefImages() {
      const removeImageBtns = _queryAllWithFallback("remove_image_button");
      let removedCount = 0;
      for (const btn of removeImageBtns) {
        const propsKey = Object.keys(btn).find((k) => k.startsWith("__reactProps$"));
        if (propsKey && btn[propsKey]?.onClick) {
          try {
            btn[propsKey].onClick({
              preventDefault: function() {
              },
              stopPropagation: function() {
              },
              nativeEvent: new MouseEvent("click", { bubbles: true }),
              type: "click",
              target: btn,
              currentTarget: btn
            });
          } catch (_) {
            btn.style.opacity = "1";
            simulateClick(btn);
          }
        } else {
          btn.style.opacity = "1";
          simulateClick(btn);
        }
        removedCount++;
        await sleep(300);
      }
      if (removedCount === 0) {
        const cancelBtns = _queryAllWithFallback("remove_image_button_broad");
        const uploadContainerSel = _selStr("upload_container");
        const editorForm = document.querySelector("form");
        for (const btn of cancelBtns) {
          const isInForm = editorForm && editorForm.contains(btn);
          const isUploadRelated = uploadContainerSel ? !!btn.closest(uploadContainerSel) : false;
          if (isInForm || isUploadRelated) {
            simulateClick(btn);
            removedCount++;
            await sleep(200);
          }
        }
      }
      if (removedCount > 0) {
        console.log(`[Grok] removeExistingRefImages: \u0111\xE3 x\xF3a ${removedCount} ref image(s) c\u0169`);
      }
      return removedCount;
    }
    async function uploadImages(images) {
      if (!Array.isArray(images) || images.length === 0) return { success: true, count: 0 };
      let injectedCount = 0;
      let completedCount = 0;
      for (const data of images) {
        if (!data?.base64) continue;
        try {
          const binary = atob(data.base64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          const file = new File([bytes], data.name || "ref.png", { type: data.type || "image/png" });
          const fileInput = _queryWithFallback("file_input");
          if (!fileInput) {
            console.warn("[Grok] uploadImages: file input not found");
            continue;
          }
          const dt = new DataTransfer();
          dt.items.add(file);
          fileInput.files = dt.files;
          fileInput.dispatchEvent(new Event("change", { bubbles: true }));
          const propsKey = Object.keys(fileInput).find((k) => k.startsWith("__reactProps$"));
          if (propsKey && typeof fileInput[propsKey]?.onChange === "function") {
            fileInput[propsKey].onChange({
              target: fileInput,
              currentTarget: fileInput,
              preventDefault() {
              },
              stopPropagation() {
              },
              nativeEvent: new Event("change"),
              type: "change"
            });
          }
          injectedCount++;
          console.log(`[Grok] uploadImages: injected file ${injectedCount}/${images.length} (${data.name || "ref.png"})`);
          const uploadOk = await waitForUploadComplete(3e4);
          if (uploadOk) completedCount++;
        } catch (err) {
          console.warn("[Grok] uploadImages error:", err.message);
        }
      }
      return {
        success: injectedCount > 0,
        count: injectedCount,
        completed: completedCount,
        total: images.length
      };
    }
    async function waitForUploadComplete(timeout = 3e4) {
      await interruptibleSleep(1e3, "upload-initial-wait");
      const start = Date.now();
      while (Date.now() - start < timeout) {
        if (isAbortActive()) return false;
        const failed = _queryWithFallback("upload_error_icon");
        if (failed) {
          console.warn("[Grok] Upload \u1EA3nh th\u1EA5t b\u1EA1i, x\xF3a upload l\u1ED7i...");
          const removeBtn = failed.closest("button") || _q("upload_error_close_button")?.closest("button");
          if (removeBtn) {
            simulateClick(removeBtn);
            await sleep(500);
          }
          return false;
        }
        const loading = _queryWithFallback("upload_loading_indicator");
        if (!loading) return true;
        await sleep(300);
      }
      console.warn("[Grok] waitForUploadComplete timeout");
      return false;
    }
    function snapshotConversationState() {
      const feedSrcs = [];
      try {
        document.querySelectorAll("img").forEach((img) => {
          const s = img.currentSrc || img.src || "";
          if (!s) return;
          if (/^data:image\//i.test(s) && s.length > 200) {
            feedSrcs.push(`data:${s.length}:${s.slice(0, 64)}:${s.slice(-32)}`);
            return;
          }
          const base = s.split("?")[0];
          if (/^https?:/i.test(base) && /imagine-public|assets\.grok|\/generated\//i.test(base)) {
            feedSrcs.push(base);
          }
        });
      } catch (_) {
      }
      return {
        url: window.location.href,
        timestamp: Date.now(),
        feedSrcs
      };
    }
    function clickFeedCard(target) {
      const el0 = target;
      if (!el0) return;
      const r = el0.getBoundingClientRect();
      const cx = Math.max(1, Math.round(r.left + r.width / 2));
      const cy = Math.max(1, Math.round(r.top + r.height / 2));
      const pos = { bubbles: true, cancelable: true, composed: true, view: window, clientX: cx, clientY: cy, screenX: cx, screenY: cy, button: 0 };
      const pDown = { ...pos, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 1, width: 1, height: 1, pressure: 0.5 };
      const pUp = { ...pos, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: 0, width: 1, height: 1, pressure: 0 };
      const fireOn = (node) => {
        if (!node) return;
        try {
          node.dispatchEvent(new PointerEvent("pointerover", pDown));
          node.dispatchEvent(new PointerEvent("pointerenter", pDown));
          node.dispatchEvent(new MouseEvent("mouseover", pos));
          node.dispatchEvent(new PointerEvent("pointerdown", pDown));
          node.dispatchEvent(new MouseEvent("mousedown", { ...pos, buttons: 1 }));
          node.dispatchEvent(new PointerEvent("pointerup", pUp));
          node.dispatchEvent(new MouseEvent("mouseup", pos));
          node.dispatchEvent(new MouseEvent("click", { ...pos, detail: 1 }));
        } catch (_) {
        }
      };
      fireOn(el0);
      try {
        const card = el0.closest?.('a, button, [role="link"], [class*="masonry"], [class*="cursor-pointer"], [class*="media-post"]');
        if (card && card !== el0) fireOn(card);
      } catch (_) {
      }
      try {
        let el = el0;
        for (let depth = 0; el && depth < 10; depth++, el = el.parentElement) {
          const rk = Object.keys(el).find((x) => x.startsWith("__reactProps$"));
          const p = rk && el[rk];
          if (p && (typeof p.onClick === "function" || typeof p.onPointerDown === "function" || typeof p.onPointerUp === "function")) {
            const synth = (type, extra) => ({
              preventDefault() {
              },
              stopPropagation() {
              },
              isPropagationStopped: () => false,
              persist() {
              },
              nativeEvent: new MouseEvent(type, pos),
              type,
              target: el,
              currentTarget: el,
              clientX: cx,
              clientY: cy,
              screenX: cx,
              screenY: cy,
              button: 0,
              detail: 1,
              ...extra
            });
            try {
              p.onPointerDown && p.onPointerDown(synth("pointerdown", { buttons: 1, pointerId: 1, pointerType: "mouse" }));
            } catch (_) {
            }
            try {
              p.onPointerUp && p.onPointerUp(synth("pointerup", { buttons: 0, pointerId: 1, pointerType: "mouse" }));
            } catch (_) {
            }
            try {
              p.onClick && p.onClick(synth("click", {}));
            } catch (_) {
            }
            break;
          }
        }
      } catch (_) {
      }
    }
    function _imgMediaSrcs(img) {
      const out = [];
      const push = (u) => {
        if (!u) return;
        const s = String(u);
        if (s.startsWith("data:image/") && s.length > 200) {
          if (!out.includes(s)) out.push(s);
          return;
        }
        if (!s.startsWith("http")) return;
        const b = s.split("?")[0];
        if (!out.includes(b)) out.push(b);
      };
      push(img.currentSrc);
      push(img.src);
      const srcset = img.getAttribute?.("srcset") || "";
      for (const part of String(srcset).split(",")) {
        push(part.trim().split(/\s+/)[0]);
      }
      return out;
    }
    function _feedDedupeKey(src) {
      if (!src) return "";
      if (String(src).startsWith("data:image/")) {
        const s = String(src);
        return `data:${s.length}:${s.slice(0, 64)}:${s.slice(-32)}`;
      }
      return String(src).split("?")[0];
    }
    function findNewestFeedResult(baselineFeedSrcs) {
      const base = baselineFeedSrcs instanceof Set ? baselineFeedSrcs : new Set(Array.isArray(baselineFeedSrcs) ? baselineFeedSrcs : []);
      const roots = [
        document.querySelector('[id^="imagine-masonry-section-0"]'),
        document.querySelector('[id*="masonry"]'),
        document.querySelector("main"),
        document.body
      ].filter(Boolean);
      const seenEl = /* @__PURE__ */ new Set();
      const candidates = [];
      for (const root of roots) {
        root.querySelectorAll("img").forEach((img) => {
          if (seenEl.has(img)) return;
          seenEl.add(img);
          candidates.push(img);
        });
        if (candidates.length > 0 && root !== document.body) break;
      }
      const scored = [];
      for (const img of candidates) {
        const srcs = _imgMediaSrcs(img);
        if (!srcs.length) continue;
        let src = srcs.find((s) => /^data:image\//i.test(s)) || srcs.find((s) => /\/generated\//i.test(s)) || srcs.find((s) => /imagine-public\.x\.ai|assets\.grok\.com|grok\.x\.ai/i.test(s)) || null;
        if (!src) continue;
        if (/avatar|icon|logo|favicon|_next\/static|profile|emoji|cookielaw|onetrust/i.test(src)) continue;
        if (src.startsWith("http") && src.split("?")[0].endsWith("/content")) continue;
        const cls = String(img.className || "");
        if (cls.includes("blur-sm") || cls.includes("blur-md")) continue;
        if (img.alt === "Loading") continue;
        const rect = img.getBoundingClientRect?.() || { width: 0, height: 0, top: 0 };
        const nw = img.naturalWidth || 0;
        const nh = img.naturalHeight || 0;
        if (nw > 0 && nw < 48 && nh > 0 && nh < 48) continue;
        if (rect.width > 0 && rect.width < 48 && rect.height > 0 && rect.height < 48) continue;
        const isData = /^data:image\//i.test(src);
        const isCdn = isData || /imagine-public|assets\.grok|grok\.x\.ai|\/generated\//i.test(src);
        if (!isCdn) continue;
        const altGen = /generated image/i.test(img.alt || "");
        const key = _feedDedupeKey(src);
        const isNew = !base.has(key) && !base.has(src);
        const size = Math.max(nw, rect.width || 0);
        let score = (isNew ? 5e3 : 0) + Math.min(size, 2e3);
        if (isData) score += 800;
        if (altGen) score += 400;
        if (rect.top >= 0 && rect.top < (window.innerHeight || 900) * 0.85) score += 200;
        if (/\/generated\//i.test(src)) score += 100;
        scored.push({ img, src, isNew, score, size, key });
      }
      scored.sort((a, b) => b.score - a.score);
      const best = scored[0];
      if (!best) {
        return { img: null, src: null, isNew: false, postHref: null, cand: scored.length, totalImg: candidates.length, size: 0 };
      }
      let postHref = null;
      try {
        const a = best.img.closest('a[href*="/imagine/post/"]') || best.img.parentElement?.querySelector?.('a[href*="/imagine/post/"]') || best.img.closest('[class*="masonry"], [class*="media-post"], [class*="cursor-pointer"]')?.querySelector?.('a[href*="/imagine/post/"]');
        if (a?.href) postHref = a.href;
        else if (a?.getAttribute?.("href")) {
          postHref = new URL(a.getAttribute("href"), location.origin).href;
        }
      } catch (_) {
      }
      if (!postHref) {
        try {
          let el = best.img;
          for (let d = 0; el && d < 10; d++, el = el.parentElement) {
            for (const attr of ["data-post-id", "data-id", "data-media-id", "href"]) {
              const tid = el.getAttribute?.(attr) || "";
              const m = String(tid).match(/\/imagine\/post\/([a-f0-9-]{16,})/i) || String(tid).match(/^([a-f0-9-]{20,})$/i);
              if (m) {
                postHref = `${location.origin}/imagine/post/${m[1]}`;
                break;
              }
            }
            if (postHref) break;
          }
        } catch (_) {
        }
      }
      return {
        img: best.img,
        src: best.src,
        isNew: best.isNew,
        postHref,
        cand: scored.length,
        totalImg: candidates.length,
        size: best.size || 0
      };
    }
    async function waitForResultPage(baseline, timeout = 6e4) {
      const startTime = Date.now();
      const POLL_INTERVAL = 400;
      const FEED_MIN_WAIT = 2500;
      const baselineFeed = new Set(baseline?.feedSrcs || []);
      const baselineDataCount = [...baselineFeed].filter((k) => String(k).startsWith("data:")).length;
      let feedSettleKey = null;
      let feedSettleN = 0;
      let lastFeedClickAt = 0;
      let feedClickAttempts = 0;
      let lastLogAt = 0;
      let bestFeedSrc = null;
      let maxDataCountSeen = baselineDataCount;
      console.log(
        "%c[Grok-wait] start",
        "color:#0ff;font-weight:bold",
        __TOBYFLOW_GROK_SCRIPT_VERSION,
        "timeout=",
        timeout,
        "baseKeys=",
        baselineFeed.size,
        "baseData=",
        baselineDataCount,
        "href=",
        location.href.slice(0, 60)
      );
      const acceptFeed = (hit, why, extraUrls = null) => {
        if (!hit?.src && !(extraUrls && extraUrls.length)) return null;
        const urls = extraUrls?.length ? extraUrls : hit?.src ? [hit.src] : [];
        if (!urls.length) return null;
        const preview = String(urls[0]).startsWith("data:") ? `data:image\u2026(${Math.round(urls[0].length / 1024)}KB)` : String(urls[0]).slice(0, 80);
        console.log("%c[Grok-wait] ACCEPT feed media", "color:#0f0;font-weight:bold", why, "n=", urls.length, preview);
        return {
          redirected: false,
          url: window.location.href,
          mediaFeedUrl: urls[0],
          mediaFeedUrls: urls.slice(0, 4),
          feedFallback: true,
          postHref: hit?.postHref || null
        };
      };
      const countDataGenerated = () => {
        let n = 0;
        const urls = [];
        document.querySelectorAll("img").forEach((img) => {
          const s = img.currentSrc || img.src || "";
          if (!s.startsWith("data:image/") || s.length < 500) return;
          if (img.alt === "Loading") return;
          const nw = img.naturalWidth || 0;
          const rect = img.getBoundingClientRect?.() || { width: 0 };
          if (nw > 0 && nw < 64 && rect.width > 0 && rect.width < 64) return;
          if (!/generated image/i.test(img.alt || "") && nw < 200 && rect.width < 120) return;
          n++;
          urls.push(s);
        });
        return { n, urls };
      };
      while (Date.now() - startTime < timeout) {
        if (isAbortActive()) {
          console.log("[Grok-wait] Aborted \u2192 clicking Stop button");
          await clickGrokStopButton();
          return { redirected: false, url: window.location.href, aborted: true };
        }
        if (detectSubscribeModal()) {
          return { redirected: false, url: window.location.href, subscriptionRequired: true };
        }
        const currentUrl = window.location.href;
        const elapsed = Date.now() - startTime;
        if (currentUrl.includes("/imagine/post/")) {
          if (currentUrl !== baseline.url || elapsed > 2e3) {
            console.log("[Grok-wait] post page OK", currentUrl.slice(0, 80));
            return { redirected: true, url: currentUrl };
          }
        }
        if (currentUrl.includes("/imagine") && !currentUrl.includes("/imagine/post/") && elapsed > FEED_MIN_WAIT) {
          try {
            const dataSnap = countDataGenerated();
            if (dataSnap.n > maxDataCountSeen) maxDataCountSeen = dataSnap.n;
            const hit = findNewestFeedResult(baselineFeed);
            if (hit?.src) {
              bestFeedSrc = hit.src;
              const key = hit.src.startsWith("data:") ? `d:${hit.src.length}:${hit.src.slice(-64)}` : hit.src.length + ":" + hit.src.slice(-48);
              if (key === feedSettleKey) feedSettleN++;
              else {
                feedSettleKey = key;
                feedSettleN = 1;
              }
              if (hit.isNew && feedSettleN >= 2) {
                const ok = acceptFeed(hit, "early-new-stable");
                if (ok) return ok;
              }
              if (dataSnap.n > baselineDataCount && feedSettleN >= 2) {
                const fresh = dataSnap.urls.filter((u) => {
                  const k = _feedDedupeKey(u);
                  return !baselineFeed.has(k) && !baselineFeed.has(u);
                });
                if (fresh.length) {
                  const ok = acceptFeed(
                    { src: fresh[0], img: hit.img, postHref: hit.postHref },
                    "data-count-increased",
                    fresh.slice(0, 4)
                  );
                  if (ok) return ok;
                }
              }
              if (elapsed > 6e3 && feedSettleN >= 2 && hit.src.startsWith("data:image/")) {
                const ok = acceptFeed(hit, "early-data-image");
                if (ok) return ok;
              }
              if (elapsed > 1e4 && feedSettleN >= 2 && (hit.size >= 80 || hit.src.startsWith("data:"))) {
                const ok = acceptFeed(hit, "early-settled-any");
                if (ok) return ok;
              }
              if (feedSettleN >= 2 && Date.now() - lastFeedClickAt > 4e3) {
                lastFeedClickAt = Date.now();
                feedClickAttempts++;
                if (hit.img) clickFeedCard(hit.img);
                if (hit.postHref && feedClickAttempts >= 2) {
                  try {
                    window.location.assign(hit.postHref);
                  } catch (_) {
                  }
                }
              }
              if (Date.now() - lastLogAt > 2500) {
                lastLogAt = Date.now();
                const kind = hit.src.startsWith("data:") ? "data" : "http";
                console.log(
                  "[Grok-wait] Feed scan",
                  "t=",
                  Math.round(elapsed / 1e3) + "s",
                  "kind=",
                  kind,
                  "new=",
                  !!hit.isNew,
                  "settle=",
                  feedSettleN,
                  "dataN=",
                  dataSnap.n,
                  "baseData=",
                  baselineDataCount,
                  "cand=",
                  hit.cand,
                  "size=",
                  hit.size
                );
              }
            } else if (Date.now() - lastLogAt > 3e3) {
              lastLogAt = Date.now();
              console.log(
                "[Grok-wait] Feed scan empty",
                "t=",
                Math.round(elapsed / 1e3) + "s",
                "dataN=",
                dataSnap.n,
                "base=",
                baselineFeed.size,
                "cand=",
                hit?.cand,
                "imgs=",
                hit?.totalImg
              );
            }
          } catch (e) {
            if (Date.now() - lastLogAt > 5e3) {
              lastLogAt = Date.now();
              console.warn("[Grok-wait] Feed scan err", e?.message || e);
            }
          }
        }
        await sleep(POLL_INTERVAL);
      }
      try {
        const dataSnap = countDataGenerated();
        if (dataSnap.urls.length) {
          const fresh = dataSnap.urls.filter((u) => !baselineFeed.has(_feedDedupeKey(u)));
          const pick = fresh.length ? fresh : dataSnap.urls;
          return acceptFeed({ src: pick[0] }, fresh.length ? "timeout-data-fresh" : "timeout-data-any", pick.slice(0, 4));
        }
        const hit = findNewestFeedResult(baselineFeed);
        if (hit?.src) {
          return acceptFeed(hit, hit.isNew ? "timeout-new" : "timeout-best");
        }
        if (bestFeedSrc) {
          return acceptFeed({ src: bestFeedSrc }, "timeout-bestFeedSrc");
        }
      } catch (_) {
      }
      console.warn("[Grok-wait] TIMEOUT no media", "base=", baselineFeed.size, "url=", location.href.slice(0, 60));
      return { redirected: false, url: window.location.href };
    }
    function findGenerationProgress() {
      if (!window.location.href.includes("/imagine/post/")) return null;
      const allSpans = document.querySelectorAll("span");
      for (const span of allSpans) {
        const text = (span.textContent || "").trim();
        const match = text.match(/^(\d{1,3})%$/);
        if (!match) continue;
        const pct = parseInt(match[1], 10);
        if (pct < 0 || pct > 100) continue;
        const parent = span.parentElement;
        if (!parent) continue;
        const parentText = parent.textContent || "";
        if (/generating/i.test(parentText)) {
          return pct;
        }
      }
      return null;
    }
    function clickGeneratedVideoFilmstrip() {
      const itemSels = _getDynamicSelector("filmstrip_item")?.selectors || ["[data-filmstrip-item]"];
      let items = [];
      for (const s of itemSels) {
        try {
          const f = document.querySelectorAll(s);
          if (f.length) {
            items = [...f];
            break;
          }
        } catch (_) {
        }
      }
      for (const item of items) {
        const src = item.querySelector("img")?.src || "";
        if (src.includes("/generated/") && /preview_image/i.test(src)) {
          simulateClick(item);
          console.log("[Grok] Clicked generated-video filmstrip \u2192 load <video> v\xE0o main view");
          return true;
        }
      }
      return false;
    }
    function extractImageUrls(excludeUrls = null, cdnHosts = null) {
      if (!window.location.href.includes("/imagine/post/")) return { mediaUrls: [], mediaType: "image" };
      const hosts = Array.isArray(cdnHosts) && cdnHosts.length ? cdnHosts : ["assets.grok.com", "grok.x.ai", "imagine-public.x.ai"];
      let container = _queryWithFallback("result_container");
      if (!container) {
        container = document.querySelector("main") || document.querySelector('[role="main"]') || document.querySelector("article") || document.body;
        console.warn("[Grok-extract] result_container miss \u2014 fallback", container?.tagName || "null");
      }
      if (!container) return { mediaUrls: [], mediaType: "image" };
      const seenUrls = /* @__PURE__ */ new Set();
      const mediaUrls = [];
      let mediaType = "image";
      const collectImgSrcs = (img) => {
        const out = [];
        const push = (u) => {
          if (u && String(u).startsWith("http")) out.push(String(u));
        };
        push(img.currentSrc);
        push(img.src);
        const srcset = img.getAttribute?.("srcset") || "";
        for (const part of String(srcset).split(",")) {
          push(part.trim().split(/\s+/)[0]);
        }
        return out;
      };
      const queryInContainer = (key, fallbackSel) => {
        const sels = _getDynamicSelector(key)?.selectors || fallbackSel;
        for (const s of sels) {
          try {
            const found = container.querySelectorAll(s);
            if (found.length) return [...found];
          } catch (_) {
          }
        }
        return [];
      };
      const videos = queryInContainer("result_video", ["video"]);
      for (const video of videos) {
        const src = video.currentSrc || video.src || video.querySelector("source")?.src;
        if (!src || !src.startsWith("http")) continue;
        const baseUrl = src.split("?")[0];
        if (seenUrls.has(baseUrl) || baseUrl.endsWith("/content")) continue;
        if (!/\/generated\//i.test(baseUrl) && !hosts.some((h) => src.includes(h))) continue;
        seenUrls.add(baseUrl);
        mediaUrls.push(src);
        mediaType = "video";
      }
      if (mediaUrls.length === 0) {
        const imgs = queryInContainer("result_image", [
          'img[src*="/generated/"]',
          'img[src*="assets.grok"]',
          'img[src*="imagine-public"]',
          'img[src*="grok.x.ai"]',
          'img[src^="https://"]'
        ]);
        const list = imgs.length ? imgs : [...document.querySelectorAll(
          'img[src*="/generated/"], img[src*="assets.grok"], img[src*="imagine-public"], img[src*="grok.x.ai"], img[srcset*="assets.grok"], img[srcset*="generated"]'
        )];
        const scanList = list.length ? list : [...document.querySelectorAll("img")];
        let nCand = 0;
        let nReject = 0;
        const generated = [];
        const cdnOnly = [];
        for (const img of scanList) {
          if (img.alt === "Loading") continue;
          if (img.className && (String(img.className).includes("blur-sm") || String(img.className).includes("blur-md"))) continue;
          const rect = img.getBoundingClientRect?.() || { width: 0, height: 0 };
          if (rect.width > 0 && rect.width <= 24 && rect.height > 0 && rect.height <= 24) continue;
          if (img.naturalWidth > 0 && img.naturalWidth <= 10) continue;
          if (img.alt && String(img.alt).startsWith("Thumbnail")) continue;
          if (img.alt === "Most recent favorite") continue;
          if (img.closest("nav") || img.closest("aside") || img.closest('[aria-label="Saved"]')) continue;
          for (const src of collectImgSrcs(img)) {
            const isFromGrokCdn = hosts.some((h) => src.includes(h));
            const isGenerated = /\/generated\//i.test(src);
            const isAvatar = src.includes("/avatar") || src.includes("/profile");
            const isLogo = src.includes("/logo") || src.includes("/icon");
            if (!isFromGrokCdn && !isGenerated || isAvatar || isLogo) continue;
            nCand++;
            const baseUrl = src.split("?")[0];
            if (seenUrls.has(baseUrl)) continue;
            if (excludeUrls && excludeUrls.has(baseUrl)) {
              nReject++;
              continue;
            }
            if (baseUrl.endsWith("/content")) {
              nReject++;
              continue;
            }
            seenUrls.add(baseUrl);
            if (isGenerated) generated.push(src);
            else cdnOnly.push(src);
          }
        }
        const pick = generated.length ? generated : cdnOnly;
        for (const u of pick) mediaUrls.push(u);
        console.log(
          `[Grok-extract] scope=${container.tagName} imgs=${scanList.length} cand=${nCand} rej=${nReject} gen=${generated.length} cdn=${cdnOnly.length} \u2192 media=${mediaUrls.length}`,
          mediaUrls.map((u) => u.slice(0, 100))
        );
      }
      return { mediaUrls, mediaType };
    }
    async function navigateBack() {
      if (!window.location.href.includes("/imagine/post/")) return true;
      const backBtn = _queryWithFallback("back_button");
      if (backBtn) {
        const propsKey = Object.keys(backBtn).find((k) => k.startsWith("__reactProps$"));
        if (propsKey && backBtn[propsKey]?.onClick) {
          backBtn[propsKey].onClick({
            preventDefault() {
            },
            stopPropagation() {
            },
            nativeEvent: new MouseEvent("click", { bubbles: true }),
            type: "click",
            target: backBtn,
            currentTarget: backBtn
          });
        } else {
          simulateClick(backBtn);
        }
        for (let i = 0; i < 10; i++) {
          await sleep(500);
          if (!window.location.href.includes("/imagine/post/")) return true;
        }
      }
      window.history.back();
      for (let i = 0; i < 10; i++) {
        await sleep(500);
        if (!window.location.href.includes("/imagine/post/")) return true;
      }
      return false;
    }
    function detectError() {
      const text = (document.body?.innerText || "").toLowerCase();
      if (_grokPatterns.rateLimit.some((p) => text.includes(p))) return "RATE_LIMIT";
      if (_grokPatterns.contentBlocked.some((p) => text.includes(p))) return "CONTENT_BLOCKED";
      if (_grokPatterns.network.some((p) => text.includes(p))) return "NETWORK";
      return null;
    }
    function detectSubscribeModal() {
      if (window.location.hash === "#subscribe" || window.location.href.includes("#subscribe")) {
        return true;
      }
      const subscribePatterns = _grokPatterns.subscriptionRequired;
      if (subscribePatterns.length === 0) return false;
      const dialogs = _qa("modal_overlay_wrapper");
      for (const dialog of dialogs) {
        const text = (dialog.innerText || "").toLowerCase();
        if (subscribePatterns.some((p) => text.includes(p))) {
          const style = window.getComputedStyle(dialog);
          if (style.display !== "none" && style.visibility !== "hidden") {
            return true;
          }
        }
      }
      const overlays = _qa("modal_overlay_wrapper");
      for (const overlay of overlays) {
        const text = (overlay.innerText || "").toLowerCase();
        if (subscribePatterns.some((p) => text.includes(p))) {
          const style = window.getComputedStyle(overlay);
          if (style.display !== "none" && style.visibility !== "hidden" && overlay.offsetHeight > 100) {
            return true;
          }
        }
      }
      return false;
    }
    let __grokAbort = false;
    let __grokAbortAt = 0;
    let __grokCallStartAt = 0;
    function isAbortActive() {
      return __grokAbort && __grokAbortAt >= __grokCallStartAt;
    }
    function checkAbort(stage) {
      if (isAbortActive()) {
        console.log("[Grok-abort] Aborted at stage:", stage);
        throw new Error("ABORTED:" + stage);
      }
    }
    async function interruptibleSleep(totalMs, stage = "sleep") {
      const POLL = 200;
      const start = Date.now();
      while (Date.now() - start < totalMs) {
        if (isAbortActive()) {
          console.log("[Grok-abort] Interruptible sleep aborted at stage:", stage);
          throw new Error("ABORTED:" + stage);
        }
        const remaining = totalMs - (Date.now() - start);
        await sleep(Math.min(POLL, remaining));
      }
    }
    async function clickGrokStopButton() {
      const stopBtn = _queryWithFallback("stop_button");
      if (stopBtn && !stopBtn.disabled) {
        console.log("[Grok-abort] Clicking Grok Stop button to halt backend gen");
        try {
          stopBtn.click();
        } catch (e) {
        }
        try {
          simulateClick(stopBtn);
        } catch (e) {
        }
        await sleep(300);
        return true;
      }
      console.log("[Grok-abort] Stop button not found or disabled");
      return false;
    }
    function isLoggedIn() {
      const editor = findGrokEditor2();
      if (!editor) return false;
      const loginLink = _queryWithFallback("auth_link");
      if (loginLink) {
        const editorReadable = editor && editor.getAttribute("contenteditable") === "true";
        if (!editorReadable) return false;
      }
      return true;
    }
    function checkLoginRequired() {
      return !isLoggedIn();
    }
    async function handleSubmitAndWait(payload, sendResponse) {
      __grokCallStartAt = Date.now();
      if (__grokAbort && __grokAbortAt < __grokCallStartAt - 5e3) {
        __grokAbort = false;
        __grokAbortAt = 0;
      }
      const promptPreview = (payload.text || "").substring(0, 50);
      FloatingTracker.show({ current: 0, total: 1, phase: _i18n.t("preparing"), prompt: promptPreview });
      ExecutionBlocker.show();
      try {
        const { text, images, settings, timeout, taskName } = payload;
        const timeoutMs = timeout || 12e4;
        try {
          const sendBtn = document.querySelector(
            'button[aria-label="G\u1EEDi"], button[type="submit"][aria-label="G\u1EEDi"], button[aria-label="Send"], button[type="submit"]'
          );
          console.log("[Grok] DOM probe @submit:", {
            url: location.href,
            sendBtn: !!sendBtn,
            sendDisabled: sendBtn ? !!(sendBtn.disabled || sendBtn.hasAttribute("disabled")) : null,
            contenteditables: document.querySelectorAll("[contenteditable]").length,
            editorFound: !!findGrokEditor2(),
            textLen: (text || "").length
          });
        } catch (_) {
        }
        if (checkLoginRequired()) {
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          sendResponse({ success: false, error: "NOT_LOGGED_IN" });
          return;
        }
        checkAbort("after-login-check");
        if (detectCloudflareChallenge()) {
          FloatingTracker.update({ phase: _i18n.t("waitingVerification") });
          const resolved = await waitForCloudflareResolved(12e4);
          if (!resolved) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({
              success: false,
              error: "CLOUDFLARE_CHALLENGE_TIMEOUT",
              message: "Grok y\xEAu c\u1EA7u x\xE1c minh Cloudflare. Vui l\xF2ng m\u1EDF tab Grok, ho\xE0n th\xE0nh verification, sau \u0111\xF3 ch\u1EA1y l\u1EA1i."
            });
            return;
          }
          checkAbort("after-cloudflare");
        }
        const waitForEditorReady = async (timeoutMs2 = 12e3) => {
          const start = Date.now();
          while (Date.now() - start < timeoutMs2) {
            if (findGrokEditor2()) return true;
            await sleep(250);
          }
          return false;
        };
        const _curUrl = window.location.href;
        if (!_curUrl.includes("/imagine")) {
          console.warn("[Grok] handleSubmitAndWait: NOT on /imagine \u2014 abort for BG re-nav. url=", _curUrl);
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          sendResponse({
            success: false,
            error: "NEED_IMAGINE_PAGE",
            message: "Tab Grok ch\u01B0a \u1EDF /imagine. H\u1EC7 th\u1ED1ng s\u1EBD m\u1EDF l\u1EA1i v\xE0 th\u1EED l\u1EA1i."
          });
          return;
        }
        if (_curUrl.includes("/imagine/post/")) {
          console.log("[Grok] handleSubmitAndWait: \u0111ang \u1EDF result page, navigate back v\u1EC1 /imagine");
          await navigateBack();
          await sleep(500);
        } else if (_curUrl.includes("/imagine/saved") || _curUrl.match(/\/imagine\/projects/)) {
          console.log("[Grok] handleSubmitAndWait: \u0111ang \u1EDF /imagine/saved ho\u1EB7c /projects, navigate sang /imagine");
          const imagineNavBtn = _queryWithFallback("imagine_link");
          if (imagineNavBtn) {
            const propsKey = Object.keys(imagineNavBtn).find((k) => k.startsWith("__reactProps$"));
            if (propsKey && imagineNavBtn[propsKey]?.onClick) {
              try {
                imagineNavBtn[propsKey].onClick({
                  preventDefault: function() {
                  },
                  stopPropagation: function() {
                  },
                  nativeEvent: new MouseEvent("click", { bubbles: true }),
                  type: "click",
                  target: imagineNavBtn,
                  currentTarget: imagineNavBtn
                });
              } catch (_) {
                simulateClick(imagineNavBtn);
              }
            } else {
              simulateClick(imagineNavBtn);
            }
          } else {
            const urls = await _getGrokApiConfig("urls");
            const imagineUrl = urls?.imagine || "https://grok.com/imagine";
            console.log("[Grok] navigate fallback \u2192", imagineUrl);
            window.location.href = imagineUrl;
          }
          const navStart = Date.now();
          while (Date.now() - navStart < 12e3) {
            if (findGrokEditor2() && window.location.href.includes("/imagine") && !window.location.href.includes("/imagine/saved") && !window.location.href.includes("/imagine/projects")) {
              break;
            }
            await sleep(200);
          }
          await sleep(500);
        }
        checkAbort("after-navigate");
        const editorReady = await waitForEditorReady(1e4);
        console.log("[Grok] waitForEditorReady:", editorReady, "url=", location.href);
        const baseline = snapshotConversationState();
        await removeExistingRefImages();
        await sleep(300);
        checkAbort("after-remove-refs");
        let editor = findGrokEditor2();
        if (!editor) {
          console.warn("[Grok] EDITOR_NOT_FOUND isolated \u2014 try mainWorld insert as recovery");
          const early = await mainWorldFill(text || "", false);
          console.log("[Grok] early mainWorldFill:", early);
          editor = findGrokEditor2();
          if (!editor && !early?.success) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            const probeBtns = Array.from(document.querySelectorAll("button")).slice(0, 30).map((b) => ({
              aria: b.getAttribute("aria-label"),
              type: b.getAttribute("type"),
              text: (b.textContent || "").trim().slice(0, 40),
              disabled: b.disabled
            }));
            console.warn("[Grok] EDITOR_NOT_FOUND final", {
              url: location.href,
              send: !!document.querySelector('button[aria-label="G\u1EEDi"], button[type="submit"]'),
              ce: document.querySelectorAll("[contenteditable]").length,
              prose: document.querySelectorAll(".ProseMirror, .tiptap").length,
              queryBar: !!document.querySelector(".query-bar"),
              chatInput: !!document.querySelector('[data-testid="chat-input"]'),
              probeBtns
            });
            sendResponse({
              success: false,
              error: "EDITOR_NOT_FOUND",
              message: "Kh\xF4ng t\xECm th\u1EA5y \xF4 nh\u1EADp prompt tr\xEAn Grok. H\xE3y m\u1EDF https://grok.com/imagine, \u0111\u0103ng nh\u1EADp, r\u1ED3i th\u1EED l\u1EA1i."
            });
            return;
          }
        }
        const hasRefs = Array.isArray(images) && images.length > 0;
        window.__grokFastPathSubmitted = false;
        if (!hasRefs && (text || "").trim()) {
          console.log("%c[Grok] text-only paste+submit FAST (no SW)", "color:#0ff;font-weight:bold", __TOBYFLOW_GROK_SCRIPT_VERSION);
          FloatingTracker.update({ phase: _i18n.t("preparing"), prompt: promptPreview });
          let mw = await mainWorldFill(text || "", true);
          console.log("%c[Grok] MAIN/page result", "color:#0ff", {
            insertOk: mw?.insertOk,
            textLen: mw?.textLen,
            method: mw?.method,
            submitted: mw?.submitted,
            verified: mw?.verified,
            preview: mw?.preview,
            submitMethod: mw?.submitMethod,
            error: mw?.error
          });
          if (!(mw?.insertOk || mw?.textLen && mw.textLen > 0)) {
            editor = findGrokEditor2() || editor;
            if (editor) {
              const okIns = await insertText(editor, text || "");
              console.log("[Grok] isolated insertText", okIns, "len=", (editor.textContent || "").trim().length);
              mw = {
                ...mw || {},
                insertOk: !!okIns,
                textLen: (editor.textContent || "").trim().length,
                method: "isolated_execCommand"
              };
            }
          }
          if ((mw?.insertOk || mw?.textLen && mw.textLen > 0) && !(mw?.submitted || mw?.verified)) {
            await sleep(300);
            editor = findGrokEditor2() || editor;
            let pushed = editor ? await clickSubmit(editor) : false;
            console.log("[Grok] clickSubmit after paste:", pushed);
            if (pushed) mw = { ...mw, submitted: true, verified: true, submitMethod: "clickSubmit" };
          }
          window.__grokFastPathSubmitted = !!(mw?.submitted || mw?.verified);
          if (mw?.insertOk || mw?.textLen) editor = findGrokEditor2() || editor;
        } else if (editor && hasRefs) {
          await clearEditor(editor);
          await sleep(300);
        }
        checkAbort("after-clear-editor");
        if (settings) {
          await applyGrokImageQualityOnly(settings);
          checkAbort("after-apply-image-quality");
        }
        await sleep(getMacroDelay());
        let refUrlsToExclude = null;
        let uploadedCount = 0;
        if (Array.isArray(images) && images.length > 0) {
          const uploadResult = await uploadImages(images);
          if (!uploadResult.success) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({ success: false, error: "REF_UPLOAD_FAILED", message: "Kh\xF4ng th\u1EC3 upload ref image" });
            return;
          }
          uploadedCount = uploadResult.completed || uploadResult.count || 0;
          console.log(`[Grok] Upload result: injected=${uploadResult.count}, completed=${uploadResult.completed}, s\u1EBD @mention ${uploadedCount} images`);
          refUrlsToExclude = /* @__PURE__ */ new Set();
          const refImgs = _queryAllWithFallback("grok_cdn_image");
          for (const img of refImgs) {
            if (img.src) refUrlsToExclude.add(img.src.split("?")[0]);
          }
        }
        if (settings) {
          await applyGrokSettings(settings, { skipImageQuality: true });
          checkAbort("after-apply-settings");
          await sleep(getMacroDelay());
        }
        if (uploadedCount > 0) {
          console.log(`[Grok] @mention loop cho ${uploadedCount} ref image(s)`);
          const waitForMentionDropdown = async (timeoutMs2 = 1500) => {
            const start = Date.now();
            while (Date.now() - start < timeoutMs2) {
              const dropdown = document.querySelector(
                '[role="listbox"], [role="menu"][data-state="open"], [data-radix-popper-content-wrapper] [role="option"], [role="option"][aria-selected], [cmdk-list], [cmdk-list-sizer], [data-cmdk-list], [data-radix-popper-content-wrapper], div[role="presentation"][data-state="open"]'
              );
              if (dropdown) return true;
              await sleep(80);
            }
            return false;
          };
          const getMentionOptions = () => Array.from(document.querySelectorAll(
            '[data-radix-popper-content-wrapper] [role="option"], [role="listbox"] [role="option"], [cmdk-item], [data-cmdk-item], [role="menuitem"], [role="option"]'
          )).filter((el) => el.offsetParent !== null);
          for (let imgIdx = 0; imgIdx < uploadedCount; imgIdx++) {
            let curEditor = findGrokEditor2();
            if (!curEditor) {
              console.warn("[Grok] @mention: editor not found at iteration", imgIdx);
              break;
            }
            curEditor.focus();
            await sleep(150);
            document.execCommand("insertText", false, "@");
            const dropdownOpen = await waitForMentionDropdown(1500);
            await sleep(250);
            const options = getMentionOptions();
            if (options.length > 0) {
              const target = options[Math.min(imgIdx, options.length - 1)];
              simulateClick(target);
              console.log(`[Grok] @mention iter ${imgIdx + 1}: clicked option "${(target.textContent || "").trim().slice(0, 30)}" (${options.length} options visible)`);
              await sleep(400);
            } else {
              console.debug(`[Grok] @mention iter ${imgIdx + 1}: dropdownOpen=${dropdownOpen}, kh\xF4ng th\u1EA5y option element \u2192 fallback ArrowDown+Enter`);
              for (let arrowIdx = 0; arrowIdx < imgIdx; arrowIdx++) {
                curEditor.dispatchEvent(new KeyboardEvent("keydown", {
                  key: "ArrowDown",
                  code: "ArrowDown",
                  keyCode: 40,
                  bubbles: true,
                  cancelable: true
                }));
                curEditor.dispatchEvent(new KeyboardEvent("keyup", {
                  key: "ArrowDown",
                  code: "ArrowDown",
                  keyCode: 40,
                  bubbles: true
                }));
                await sleep(120);
              }
              curEditor.dispatchEvent(new KeyboardEvent("keydown", {
                key: "Enter",
                code: "Enter",
                keyCode: 13,
                bubbles: true,
                cancelable: true
              }));
              curEditor.dispatchEvent(new KeyboardEvent("keyup", {
                key: "Enter",
                code: "Enter",
                keyCode: 13,
                bubbles: true
              }));
              await sleep(400);
            }
            const vEditor = findGrokEditor2();
            console.log(`[Grok] @mention iter ${imgIdx + 1}: editor tail="${(vEditor?.textContent || "").slice(-40)}"`);
          }
          const finalEditor = findGrokEditor2();
          if (finalEditor) {
            finalEditor.dispatchEvent(new KeyboardEvent("keydown", {
              key: "Escape",
              code: "Escape",
              keyCode: 27,
              bubbles: true,
              cancelable: true
            }));
            finalEditor.dispatchEvent(new KeyboardEvent("keyup", {
              key: "Escape",
              code: "Escape",
              keyCode: 27,
              bubbles: true
            }));
          }
          await sleep(200);
        }
        checkAbort("after-mention-loop");
        await sleep(getMacroDelay());
        if (window.__grokFastPathSubmitted) {
          console.log("[Grok] FAST PATH already submitted \u2014 skip insert/click, wait result");
        }
        let editorAfterMention = findGrokEditor2() || editor;
        if (uploadedCount > 0 && editorAfterMention && !window.__grokFastPathSubmitted) {
          try {
            editorAfterMention.focus();
            await sleep(80);
            const sel = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(editorAfterMention);
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
            console.log("[Grok] Cursor moved to END before insertText (post-@mention)");
            await sleep(100);
          } catch (cursorErr) {
            console.warn("[Grok] Move cursor to end failed (non-fatal):", cursorErr.message);
          }
        }
        let submitOk = !!window.__grokFastPathSubmitted;
        if (window.__grokFastPathSubmitted) {
          console.log("[Grok] already paste/push \u2014 wait result only");
          submitOk = true;
        } else {
          const inserted = await insertText(editorAfterMention, text || "", {
            preserveBaseline: uploadedCount > 0
          });
          editorAfterMention = findGrokEditor2() || editorAfterMention;
          console.log("[Grok] insertText", inserted, "len=", (editorAfterMention?.textContent || "").trim().length);
          await sleep(400);
          checkAbort("after-insert-prompt");
          await sleep(getMacroDelay());
          checkAbort("before-submit");
          submitOk = await clickSubmit(editorAfterMention);
          if (!submitOk) {
            const mwSub = await mainWorldFill(text || "", true);
            submitOk = !!(mwSub?.submitted || mwSub?.verified || mwSub?.insertOk);
          }
        }
        if (!submitOk) {
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          const subDeadline = Date.now() + 1500;
          let _subDetectedEarly = false;
          while (Date.now() < subDeadline) {
            if (detectSubscribeModal()) {
              _subDetectedEarly = true;
              break;
            }
            await sleep(200);
          }
          if (_subDetectedEarly) {
            console.warn("[Grok] Subscribe modal detected sau clickSubmit fail \u2192 user ch\u01B0a mua g\xF3i");
            sendResponse({
              success: false,
              error: "SUBSCRIPTION_REQUIRED",
              message: "B\u1EA1n ch\u01B0a \u0111\u0103ng k\xFD g\xF3i Grok Premium. Vui l\xF2ng \u0111\u0103ng k\xFD t\u1EA1i grok.com \u0111\u1EC3 s\u1EED d\u1EE5ng t\xEDnh n\u0103ng t\u1EA1o \u1EA3nh/video."
            });
            return;
          }
          sendResponse({ success: false, error: "SUBMIT_FAILED" });
          return;
        }
        checkAbort("after-submit");
        await interruptibleSleep(800, "after-submit-grace");
        checkAbort("post-submit-grace");
        if (detectAgeVerificationModal()) {
          console.log("[Grok] Age verification modal detected sau submit \u2014 handling...");
          const ageOk = await handleAgeVerificationModal(3e4);
          checkAbort("after-age-verification");
          if (!ageOk) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({
              success: false,
              error: "AGE_VERIFICATION_FAILED",
              message: "Kh\xF4ng th\u1EC3 x\xE1c nh\u1EADn tu\u1ED5i t\u1EF1 \u0111\u1ED9ng. Vui l\xF2ng m\u1EDF tab Grok, ho\xE0n th\xE0nh x\xE1c nh\u1EADn tu\u1ED5i th\u1EE7 c\xF4ng, sau \u0111\xF3 ch\u1EA1y l\u1EA1i."
            });
            return;
          }
          await sleep(500);
          console.log("[Grok] Re-submitting sau age verification...");
          const editorRetry = findGrokEditor2();
          if (editorRetry) {
            submitOk = await clickSubmit(editorRetry);
            if (!submitOk) {
              FloatingTracker.hide();
              ExecutionBlocker.hide();
              sendResponse({ success: false, error: "SUBMIT_FAILED_AFTER_AGE_VERIFY" });
              return;
            }
          }
          await sleep(500);
        }
        const subModalDeadline = Date.now() + 3e3;
        let _subDetected = false;
        while (Date.now() < subModalDeadline) {
          if (isAbortActive()) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({ success: false, error: "ABORTED", message: "User stopped task" });
            return;
          }
          if (detectSubscribeModal()) {
            _subDetected = true;
            break;
          }
          await sleep(250);
        }
        if (_subDetected) {
          console.warn("[Grok] Subscribe modal detected sau submit");
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          sendResponse({
            success: false,
            error: "SUBSCRIPTION_REQUIRED",
            message: "B\u1EA1n ch\u01B0a \u0111\u0103ng k\xFD g\xF3i Grok Premium. Vui l\xF2ng \u0111\u0103ng k\xFD t\u1EA1i grok.com \u0111\u1EC3 s\u1EED d\u1EE5ng t\xEDnh n\u0103ng t\u1EA1o \u1EA3nh/video."
          });
          return;
        }
        FloatingTracker.update({ current: 1, total: 1, phase: _i18n.t("waitingResult"), prompt: promptPreview });
        const baselineAfterSubmit = snapshotConversationState();
        console.log(
          "%c[Grok] \u2192 waitForResultPage",
          "color:#0ff;font-weight:bold",
          __TOBYFLOW_GROK_SCRIPT_VERSION,
          "timeoutMs=",
          timeoutMs,
          "baseData=",
          (baselineAfterSubmit.feedSrcs || []).filter((k) => String(k).startsWith("data:")).length
        );
        const waitResult = await waitForResultPage(baseline, timeoutMs);
        if (!waitResult.redirected) {
          const feedUrls = Array.isArray(waitResult.mediaFeedUrls) && waitResult.mediaFeedUrls.length ? waitResult.mediaFeedUrls : waitResult.mediaFeedUrl ? [waitResult.mediaFeedUrl] : [];
          if (waitResult.feedFallback && feedUrls.length) {
            const preview = feedUrls[0].startsWith("data:") ? `data:image\u2026${Math.round(feedUrls[0].length / 1024)}KB` : feedUrls[0].slice(0, 80);
            console.log("[Grok] wait feedFallback \u2192 success", feedUrls.length, preview);
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            const fetchedMedia2 = feedUrls.filter((u) => String(u).startsWith("data:image/")).map((u) => ({
              url: u,
              base64: u,
              mime: (u.match(/^data:([^;]+);/) || [])[1] || "image/jpeg",
              size: Math.round(u.length * 0.75)
            }));
            sendResponse({
              success: true,
              mediaUrls: feedUrls,
              mediaType: "image",
              url: waitResult.url || window.location.href,
              via: "feed_fallback",
              postId: null,
              fetchedMedia: fetchedMedia2
            });
            return;
          }
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          if (waitResult.aborted) {
            sendResponse({
              success: false,
              error: "ABORTED",
              message: "User stopped task (Stop / Esc\xD73)"
            });
            return;
          }
          if (waitResult.subscriptionRequired) {
            sendResponse({
              success: false,
              error: "SUBSCRIPTION_REQUIRED",
              message: "B\u1EA1n ch\u01B0a \u0111\u0103ng k\xFD g\xF3i Grok Premium. Vui l\xF2ng \u0111\u0103ng k\xFD t\u1EA1i grok.com \u0111\u1EC3 s\u1EED d\u1EE5ng t\xEDnh n\u0103ng t\u1EA1o \u1EA3nh/video."
            });
            return;
          }
          const err = detectError();
          if (err) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({ success: false, error: err, message: "Detected error trong khi ch\u1EDD result" });
            return;
          }
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          sendResponse({
            success: false,
            error: "TIMEOUT",
            message: "H\u1EBFt th\u1EDDi gian ch\u1EDD trang k\u1EBFt qu\u1EA3 /imagine/post (feed click kh\xF4ng m\u1EDF post). Ki\u1EC3m tra tab Grok: \u1EA3nh \u0111\xE3 hi\u1EC7n tr\xEAn feed ch\u01B0a?"
          });
          return;
        }
        await interruptibleSleep(3e3, "pre-extract-grace");
        const isVideoMode = settings?.mode === "video";
        const extractBudget = isVideoMode ? Math.max(timeoutMs, 6e5) : Math.max(timeoutMs, 3e5);
        const HEARTBEAT_TIMEOUT = 9e4;
        const cdnHosts = (await _getGrokApiConfig("urls"))?.cdn_patterns;
        let mediaUrls = [];
        let mediaType = "image";
        let lastProgress = -1;
        let lastProgressChangeTime = Date.now();
        let progressDetectedOnce = false;
        const extractDeadline = Date.now() + extractBudget;
        const startExtract = Date.now();
        while (Date.now() < extractDeadline) {
          if (isAbortActive()) {
            console.log("[Grok] Extract loop aborted by user \u2192 clicking Stop button");
            await clickGrokStopButton();
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({ success: false, error: "ABORTED", message: "User stopped task" });
            return;
          }
          if (detectCloudflareChallenge()) {
            console.warn("[Grok] Cloudflare challenge re-emerged trong extract loop \u2192 abort");
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({
              success: false,
              error: "CLOUDFLARE_CHALLENGE_TIMEOUT",
              message: "Cloudflare challenge xu\u1EA5t hi\u1EC7n l\u1EA1i trong qu\xE1 tr\xECnh gen \u2014 session c\xF3 th\u1EC3 \u0111\xE3 h\u1EBFt h\u1EA1n. Vui l\xF2ng verify th\u1EE7 c\xF4ng v\xE0 ch\u1EA1y l\u1EA1i."
            });
            return;
          }
          const currentProgress = findGenerationProgress();
          if (currentProgress !== null) {
            progressDetectedOnce = true;
            if (currentProgress !== lastProgress) {
              const elapsedSec = Math.round((Date.now() - startExtract) / 1e3);
              console.log(`[Grok] Generating ${currentProgress}% (elapsed ${elapsedSec}s)`);
              lastProgress = currentProgress;
              lastProgressChangeTime = Date.now();
              try {
                chrome.runtime.sendMessage({
                  action: "grok:gen_progress",
                  progress: currentProgress,
                  mode: isVideoMode ? "video" : "image",
                  elapsed: elapsedSec
                }).catch(() => {
                });
              } catch (_) {
              }
            } else {
              const idleMs = Date.now() - lastProgressChangeTime;
              if (idleMs > HEARTBEAT_TIMEOUT) {
                console.warn(`[Grok] Progress stuck at ${currentProgress}% for ${Math.round(idleMs / 1e3)}s \u2192 timeout s\u1EDBm`);
                break;
              }
            }
          } else if (progressDetectedOnce) {
          }
          if (isVideoMode) {
            const rc = _queryWithFallback("result_container");
            if (rc && !rc.querySelector("video")) clickGeneratedVideoFilmstrip();
          }
          const extracted = extractImageUrls(refUrlsToExclude, cdnHosts);
          if (extracted.mediaUrls.length > 0) {
            mediaUrls = extracted.mediaUrls;
            mediaType = extracted.mediaType;
            try {
              const elapsedSec = Math.round((Date.now() - startExtract) / 1e3);
              chrome.runtime.sendMessage({
                action: "grok:gen_progress",
                progress: 100,
                mode: isVideoMode ? "video" : "image",
                elapsed: elapsedSec
              }).catch(() => {
              });
            } catch (_) {
            }
            break;
          }
          const err = detectError();
          if (err) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            sendResponse({ success: false, error: err });
            return;
          }
          await sleep(700);
        }
        if (mediaUrls.length === 0) {
          FloatingTracker.hide();
          ExecutionBlocker.hide();
          sendResponse({ success: false, error: "NO_MEDIA_FOUND", message: "Kh\xF4ng tr\xEDch xu\u1EA5t \u0111\u01B0\u1EE3c URL media t\u1EEB result page" });
          return;
        }
        const postIdMatch = waitResult.url.match(/\/imagine\/post\/([a-z0-9-]+)/i);
        const postId = postIdMatch ? postIdMatch[1] : null;
        const fetchedMedia = [];
        if (mediaUrls.length > 0) {
          FloatingTracker.update({ current: 1, total: 1, phase: "\u0110ang t\u1EA3i media...", prompt: promptPreview });
          for (let i = 0; i < mediaUrls.length; i++) {
            const mUrl = mediaUrls[i];
            if (isAbortActive()) {
              fetchedMedia.push({ url: mUrl, error: "ABORTED" });
              continue;
            }
            try {
              const bgResp = await new Promise((resolve) => {
                try {
                  chrome.runtime.sendMessage(
                    { action: "grok:fetchImage", url: mUrl },
                    (r) => {
                      if (chrome.runtime.lastError) {
                        resolve({ success: false, error: chrome.runtime.lastError.message });
                        return;
                      }
                      resolve(r || { success: false, error: "NO_RESPONSE" });
                    }
                  );
                } catch (e) {
                  resolve({ success: false, error: e?.message || "SEND_FAILED" });
                }
              });
              if (bgResp?.success && bgResp.base64) {
                fetchedMedia.push({
                  url: mUrl,
                  base64: bgResp.base64,
                  mime: bgResp.mime || (mediaType === "video" ? "video/mp4" : "image/jpeg"),
                  size: bgResp.size || 0
                });
                console.log(
                  "[Grok] pre-fetch ok (SW):",
                  ((bgResp.size || 0) / 1024).toFixed(0) + "KB",
                  mUrl.substring(0, 80)
                );
              } else {
                try {
                  const resp = await fetch(mUrl, { credentials: "omit", cache: "no-cache" });
                  if (!resp.ok) {
                    fetchedMedia.push({ url: mUrl, error: bgResp?.error || "HTTP_" + resp.status });
                    console.warn("[Grok] pre-fetch fail", bgResp?.error, resp.status, mUrl.substring(0, 80));
                    continue;
                  }
                  const blob = await resp.blob();
                  const base64 = await new Promise((resolveB64, rejectB64) => {
                    const reader = new FileReader();
                    reader.onload = () => resolveB64(reader.result);
                    reader.onerror = () => rejectB64(reader.error);
                    reader.readAsDataURL(blob);
                  });
                  fetchedMedia.push({
                    url: mUrl,
                    base64,
                    mime: blob.type || "image/jpeg",
                    size: blob.size
                  });
                  console.log("[Grok] pre-fetch ok (page omit):", (blob.size / 1024).toFixed(0) + "KB");
                } catch (e2) {
                  fetchedMedia.push({ url: mUrl, error: bgResp?.error || e2.message || "FETCH_EXCEPTION" });
                  console.warn("[Grok] pre-fetch exception:", bgResp?.error || e2.message, mUrl.substring(0, 100));
                }
              }
            } catch (e) {
              fetchedMedia.push({ url: mUrl, error: e.message || "FETCH_EXCEPTION" });
              console.warn("[Grok] pre-fetch exception:", e.message, mUrl.substring(0, 100));
            }
          }
        }
        FloatingTracker.hide();
        ExecutionBlocker.hide();
        sendResponse({
          success: true,
          mediaUrls,
          fetchedMedia,
          // Option C: base64 đã fetch trong page context, sidebar skip grokFetchImage
          mediaType,
          postId,
          url: waitResult.url
        });
      } catch (err) {
        FloatingTracker.hide();
        ExecutionBlocker.hide();
        if (err.message && err.message.startsWith("ABORTED")) {
          const stage = err.message.replace("ABORTED:", "");
          console.log("[Grok] Caught ABORT at stage:", stage, "\u2192 clicking Stop button");
          await clickGrokStopButton();
          sendResponse({
            success: false,
            error: "ABORTED",
            message: "User stopped at " + stage
          });
          return;
        }
        console.error("[Grok] handleSubmitAndWait error:", err);
        sendResponse({ success: false, error: "EXCEPTION", message: err.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh" });
      } finally {
        FloatingTracker.hide();
        ExecutionBlocker.hide();
      }
    }
    const onGrokMessage = (message, sender, sendResponse) => {
      if (!message || typeof message.action !== "string") return false;
      if (message.action === "pq:trackerUpdate") {
        const _d = message.data;
        _ftRichActive = !!(_d && _d.jobs && _d.jobs.length && _d.isRunning !== false);
        try {
          FloatingTracker.updateFromQueue(_d);
        } catch (e) {
        }
        sendResponse({ ok: true });
        return false;
      }
      if (message.action === "providerConfigUpdated") {
        chrome.storage.local.get(["toby_provider_configs"], (res) => {
          if (res.toby_provider_configs?.data) {
            _selectorConfig = res.toby_provider_configs.data;
            _selectorConfigTime = Date.now();
            const keyCount = Object.keys(_selectorConfig[PROVIDER]?.selectors || {}).length;
            console.log(`[Grok] Provider config updated via SSE \u2014 reloaded ${keyCount} selectors`);
          } else {
            _selectorConfig = null;
            _selectorConfigTime = 0;
            console.warn("[Grok] Provider config updated via SSE \u2014 storage empty, cache cleared");
          }
          sendResponse({ success: true });
        });
        return true;
      }
      if (message.action === "grok:submitAndWait") {
        if (window.__tobyflowGrokSubmitBusy) {
          console.warn("[Grok-listener] submit already in flight \u2014 ignore duplicate");
          sendResponse({ success: false, error: "BUSY", message: "Grok submit \u0111ang ch\u1EA1y" });
          return false;
        }
        window.__tobyflowGrokSubmitBusy = true;
        const innerPayload = message.payload && typeof message.payload === "object" ? message.payload : message;
        __grokInputTimeoutMs = Number(innerPayload.inputTimeoutMs) || 1200;
        __grokMacroDelayMs = Math.round(__grokInputTimeoutMs * 0.7);
        console.log(
          "[Grok-listener] grok:submitAndWait nh\u1EADn, text len:",
          (innerPayload.text || "").length,
          "images:",
          (innerPayload.images || []).length,
          "| Timing \u2014 inputTimeout:",
          __grokInputTimeoutMs,
          "ms | macroDelay:",
          __grokMacroDelayMs,
          "ms (70%)"
        );
        const done = (resp) => {
          window.__tobyflowGrokSubmitBusy = false;
          try {
            sendResponse(resp);
          } catch (_) {
          }
        };
        handleSubmitAndWait(innerPayload, done).catch((err) => {
          window.__tobyflowGrokSubmitBusy = false;
          try {
            sendResponse({ success: false, error: "EXCEPTION", message: err?.message || String(err) });
          } catch (_) {
          }
        });
        return true;
      }
      if (message.action === "grok:abort") {
        __grokAbort = true;
        __grokAbortAt = Date.now();
        console.log("[Grok-listener] grok:abort received \u2192 set abort flag at", __grokAbortAt);
        FloatingTracker.hide();
        ExecutionBlocker.hide();
        sendResponse({ success: true });
        return false;
      }
      if (message.action === "grok:applySettingsInline") {
        (async () => {
          try {
            const ok = await applyGrokSettings(message.settings || {});
            sendResponse({ success: !!ok });
          } catch (err) {
            sendResponse({ success: false, error: err.message || "APPLY_FAILED" });
          }
        })();
        return true;
      }
      if (message.action === "grok:checkStatus") {
        const editor = findGrokEditor2();
        const loginLink = _queryWithFallback("auth_link") || Array.from(document.querySelectorAll("a")).find((a) => /sign\s*in|log\s*in|đăng\s*nhập/i.test(a.textContent || ""));
        let signInButton = null;
        try {
          const patterns = _grokPatterns.notLoggedIn;
          if (patterns && patterns.length > 0) {
            const buttons = document.querySelectorAll('button[type="button"]');
            for (const btn of buttons) {
              const text = (btn.textContent || "").trim().toLowerCase();
              if (patterns.some((p) => text === p || text.includes(p))) {
                signInButton = btn;
                break;
              }
            }
          } else {
            console.warn("[Grok] checkStatus: _grokPatterns.notLoggedIn empty \u2014 admin c\u1EA7n config not_logged_in_text");
          }
        } catch (_) {
        }
        const loggedIn = !!editor && !loginLink && !signInButton;
        const cloudflareChallenge = detectCloudflareChallenge();
        if (signInButton) {
          console.log("[Grok] checkStatus: Sign in/up button detected \u2192 NOT logged in");
        }
        sendResponse({ loggedIn, cloudflareChallenge });
        return false;
      }
      return false;
    };
    window.__tobyflowGrokOnMessage = onGrokMessage;
    if (!window.__tobyflowGrokListenerBound) {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        const fn = window.__tobyflowGrokOnMessage;
        if (typeof fn === "function") return fn(message, sender, sendResponse);
        return false;
      });
      window.__tobyflowGrokListenerBound = true;
      console.log("[Grok] onMessage listener bound (once)");
    }
    let _lastUrl = location.href;
    const _notifyNavigate = () => {
      if (location.href !== _lastUrl) {
        _lastUrl = location.href;
        try {
          chrome.runtime.sendMessage({ action: "grok:navigated", url: location.href }).catch(() => {
          });
        } catch (e) {
        }
      }
    };
    try {
      const _origPushState = history.pushState;
      const _origReplaceState = history.replaceState;
      history.pushState = function() {
        _origPushState.apply(this, arguments);
        _notifyNavigate();
      };
      history.replaceState = function() {
        _origReplaceState.apply(this, arguments);
        _notifyNavigate();
      };
      window.addEventListener("popstate", _notifyNavigate);
    } catch (e) {
    }
    console.log("[Grok] Content script \u0111\xE3 \u0111\u01B0\u1EE3c inject (grok/GrokContentScript)");
  }

  // chat-content-grok.ts
  installGrokContentScript();
})();
