/**
 * Validate BuiltinWorkflowTemplates graph + convert port mapping (no browser).
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '../src/platforms/labs.toby.vn/dist/src');

function loadJs(rel) {
  const code = fs.readFileSync(path.join(root, rel), 'utf8');
  const sandbox = {
    window: global.window,
    console,
    chrome: undefined,
    Date,
    Math,
    JSON,
    Object,
    Array,
    String,
    Number,
    Boolean,
    Map,
    Set,
    RegExp,
    Error,
  };
  vm.runInNewContext(code, sandbox, { filename: rel });
  return sandbox.window;
}

global.window = {
  ApiBaseConfig: { shouldUseRemoteApi: () => false, isExtensionOnly: () => true },
  NodeTemplates: {
    getDefaults(type) {
      const map = {
        generate: { media_type: 'Image', ratio: '16:9', quantity: 1, enabled: true, status: 'pending', model: null },
        chatgpt: { ratio: 'story', enabled: true, status: 'pending' },
        grok: { ratio: 'widescreen', grok_mode: 'image', quantity: 1, enabled: true, status: 'pending' },
        text: { prompt: '', enabled: true, status: 'pending' },
        download: { download_resolution: '1k', enabled: true, status: 'pending' },
        note: { note_text: '', enabled: true },
      };
      return map[type] || { enabled: true, status: 'pending' };
    },
    getNodePorts(type, data = {}) {
      if (type === 'text') return { in: [], out: [{ name: 'text', type: 'text' }] };
      if (type === 'download') return { in: [{ name: 'media_in', type: 'any' }], out: [] };
      if (type === 'note') return { in: [], out: [] };
      // generate/chatgpt/grok image mode
      const isVideo = data.media_type === 'Video';
      const ins = [
        { name: 'image_ref', type: 'image' },
        { name: 'text', type: 'text' },
      ];
      if (isVideo) {
        ins.push({ name: 'frame_1', type: 'frame' }, { name: 'frame_2', type: 'frame' });
      }
      return { in: ins, out: [{ name: 'media', type: 'image' }] };
    },
    normalizeNodeData() {},
  },
  I18n: { t: (k, f) => f || k },
};

loadJs('workflow/BuiltinWorkflowTemplates.js');

const B = global.window.BuiltinWorkflowTemplates;
const list = B.list();
console.log('=== Builtin list count:', list.length);

let failed = 0;
for (const t of list) {
  const v = B.validate(t);
  console.log(`\n[${v.ok ? 'OK' : 'FAIL'}] ${t.id} — ${t.name}`);
  console.log('  nodes:', t.nodes.map((n) => `${n.id}:${n.type}`).join(', '));
  console.log('  edges:', t.edges.map((e) => {
    const sp = e.source_port || e.sourcePort;
    const tp = e.target_port || e.targetPort;
    return `${e.source}-(${sp})→(${tp})-${e.target}`;
  }).join(' | ') || '(none)');
  if (!v.ok) {
    console.log('  errors:', v.errors);
    failed++;
  }

  // Simulate convert (same rules as WorkflowTemplateList)
  const nodes = t.nodes.map((node) => {
    const data = node.data || {};
    const nodeType = node.type;
    const defaults = global.window.NodeTemplates.getDefaults(nodeType);
    return {
      ...defaults,
      ...data,
      node_id: node.id,
      node_type: nodeType,
      node_name: data.node_name || nodeType,
      pos_x: node.position?.x ?? 100,
      pos_y: node.position?.y ?? 100,
      enabled: true,
      status: 'pending',
      prompt: data.prompt ?? '',
      prompt_source: data.prompt_source,
      model: data.model || null,
    };
  });
  const edges = t.edges.map((edge) => ({
    edge_id: edge.id,
    source_node_id: edge.source,
    target_node_id: edge.target,
    source_handle: edge.source_handle || edge.sourceHandle || 'output_1',
    target_handle: edge.target_handle || edge.targetHandle || 'input_1',
    source_port: edge.source_port || edge.sourcePort || 'default',
    target_port: edge.target_port || edge.targetPort || 'default',
  }));

  // Check text→gen ports after convert
  for (const e of edges) {
    const src = nodes.find((n) => n.node_id === e.source_node_id);
    const tgt = nodes.find((n) => n.node_id === e.target_node_id);
    if (src?.node_type === 'text' && ['generate', 'chatgpt', 'grok'].includes(tgt?.node_type)) {
      if (e.target_port !== 'text') {
        console.log('  PORT BUG after convert:', e.edge_id, e.target_port);
        failed++;
      } else {
        console.log('  port OK: text→', tgt.node_type, 'target_port=text handle=', e.target_handle);
      }
      // prompt path
      const hasPrompt = (src.prompt || '').trim().length > 0;
      const genEmpty = !(tgt.prompt || '').trim();
      const srcMode = tgt.prompt_source;
      console.log(`  prompt path: text.len=${(src.prompt || '').length} genEmpty=${genEmpty} prompt_source=${srcMode}`);
      if (!hasPrompt) {
        console.log('  FAIL: text prompt empty');
        failed++;
      }
      if (srcMode !== 'upstream_node' && genEmpty) {
        console.log('  FAIL: expect prompt_source=upstream_node when gen empty');
        failed++;
      }
    }
  }

  // Solo generate with own prompt
  if (edges.length === 0) {
    const gen = nodes.find((n) => n.node_type === 'generate');
    if (gen && (gen.prompt || '').trim()) {
      console.log('  solo gen prompt OK, len=', gen.prompt.length, 'source=', gen.prompt_source);
    } else if (gen) {
      console.log('  FAIL: solo gen without prompt');
      failed++;
    }
  }
}

console.log('\n=== RESULT:', failed === 0 ? 'ALL PASS' : `${failed} FAILURES`);
process.exit(failed === 0 ? 0 : 1);
