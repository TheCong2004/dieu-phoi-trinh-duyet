/**
 * Copy TobyFlow dist + static assets to assets/tobyflow (Plasmo WAR).
 * Also refresh existing unpacked build folders so Chrome/Edge loaded from
 * build/chrome-mv3-dev does not keep stale TobyFlow files.
 *
 * NOTE: cpSync with { recursive: true } crashes on Windows when the path
 * contains non-ASCII characters (e.g. "mẻ"). Use robocopy for dir copies.
 */
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { execSync } from "node:child_process";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const SRC = join(ROOT, "src", "platforms", "labs.toby.vn");
const DIST = join(SRC, "dist");
const DEST = join(ROOT, "assets", "tobyflow");
const BUILD_ROOT = join(ROOT, "build");

const IS_WIN = process.platform === "win32";

/**
 * Cross-platform recursive directory copy.
 * On Windows, cpSync({ recursive: true }) can crash when paths contain
 * non-ASCII characters, so we use robocopy instead.
 */
function copyDir(src, dest) {
  if (IS_WIN) {
    mkdirSync(dest, { recursive: true });
    // robocopy exit codes 0-7 are success (bit flags for file counts)
    try {
      execSync(`robocopy "${src}" "${dest}" /E /NFL /NDL /NJH /NJS`, { stdio: "pipe" });
    } catch (e) {
      // robocopy exits with non-zero even on success (file count bits)
      if (e.status == null || e.status > 7) throw e;
    }
  } else {
    cpSync(src, dest, { recursive: true });
  }
}

if (!existsSync(join(DIST, "content.js"))) {
  console.error("Missing dist/content.js. Run: pnpm run build:tobyflow");
  process.exit(1);
}

if (existsSync(DEST)) {
  rmSync(DEST, { recursive: true, force: true });
}
mkdirSync(DEST, { recursive: true });

copyDir(DIST, join(DEST, "dist"));

for (const dir of ["lib", "icons"]) {
  const from = join(SRC, dir);
  if (existsSync(from)) copyDir(from, join(DEST, dir));
}

const staticFiles = readdirSync(SRC).filter(
  (file) => file.endsWith(".html") || file.endsWith(".css"),
);
for (const file of staticFiles) {
  cpSync(join(SRC, file), join(DEST, file));
}

/** Chromex popup: absolute /icons/* → extension root 404; use paths relative to assets/tobyflow/. */
function patchExtensionAssetUrls(cssPath) {
  if (!existsSync(cssPath)) return;
  const css = readFileSync(cssPath, "utf8");
  const next = css.replace(/url\(\/icons\//g, "url(icons/");
  if (next !== css) writeFileSync(cssPath, next, "utf8");
}

patchExtensionAssetUrls(join(DEST, "tobyflow.css"));

console.log(`Synced TobyFlow to assets/tobyflow (dist/ + ${staticFiles.length} static files)`);

if (existsSync(BUILD_ROOT)) {
  for (const dir of readdirSync(BUILD_ROOT)) {
    if (!dir.startsWith("chrome-mv3")) continue;
    const buildDir = join(BUILD_ROOT, dir);
    const buildAssetsRoot = join(buildDir, "assets");
    if (!existsSync(buildAssetsRoot)) continue;

    const buildTobyflow = join(buildAssetsRoot, "tobyflow");
    if (existsSync(buildTobyflow)) {
      rmSync(buildTobyflow, { recursive: true, force: true });
    }
    mkdirSync(buildAssetsRoot, { recursive: true });
    copyDir(DEST, buildTobyflow);
    console.log(`Synced TobyFlow to build/${dir}/assets/tobyflow`);

    // Legacy inject path: background grok:injectScript files:['chat-content-grok.js']
    // Copy dist script to extension root so on-demand inject works after unpack.
    const grokCs = join(DIST, "chat-content-grok.js");
    if (existsSync(grokCs)) {
      cpSync(grokCs, join(buildDir, "chat-content-grok.js"));
      console.log(`Synced chat-content-grok.js → build/${dir}/`);
    }
  }
}
