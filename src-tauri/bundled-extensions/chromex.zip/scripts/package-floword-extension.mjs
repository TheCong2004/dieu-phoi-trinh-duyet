import { access, cp, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { basename, extname, join, relative, resolve, sep } from "node:path";
import process from "node:process";
import JSZip from "jszip";

const root = resolve(process.cwd(), "../..");
const distDir = resolve(process.cwd(), "build/chrome-mv3-prod");
const outputDir = resolve(root, "artifacts/floword");
const stagingDir = resolve(outputDir, "chromex-staging");
const outputZip = resolve(outputDir, "chromex.zip");

await assertFile(resolve(distDir, "manifest.json"), "Production build output is missing build/chrome-mv3-prod/manifest.json.");
await rm(stagingDir, { recursive: true, force: true });
await mkdir(outputDir, { recursive: true });
await cp(distDir, stagingDir, { recursive: true });
await sanitizeAndValidateStaging(stagingDir);
await writeZip(stagingDir, outputZip);
await validateZip(outputZip);
await rm(stagingDir, { recursive: true, force: true });

console.log(`Floword extension package created: ${outputZip}`);

async function sanitizeAndValidateStaging(directory) {
  const manifestPath = join(directory, "manifest.json");
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  if (manifest.key) {
    delete manifest.key;
    await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
  }

  const files = await collectFiles(directory);
  const blocked = files.find((file) => /(?:\.map$|\.pem$|\.key$|\.crx$|\.env(?:\.|$)|\.DS_Store$)/iu.test(file));
  if (blocked) {
    throw new Error(`Production extension contains blocked artifact: ${blocked}`);
  }

  const javascript = (await Promise.all(
    files
      .filter((file) => extname(file).toLowerCase() === ".js")
      .map((file) => readFile(join(directory, file), "utf8")),
  )).join("\n");

  const requiredMarkers = [
    ["Grok production content script", "grok.com"],
    ["Facebook production health", "facebook.com"],
    ["TikTok production health", "tiktok.com"],
    ["YouTube Studio production health", "studio.youtube.com"],
  ];
  for (const [label, marker] of requiredMarkers) {
    if (!javascript.includes(marker)) {
      throw new Error(`${label} marker is missing from the production bundle.`);
    }
  }
  const youtubeScript = files
    .filter((file) => /tobyflow-youtube(?:\.|\/)/iu.test(file) && file.toLowerCase().endsWith(".js"))
    .map((file) => readFile(join(directory, file), "utf8"));
  if (youtubeScript.length === 0) {
    throw new Error("Production bundle is missing the YouTube Studio content script.");
  }
}

async function validateZip(path) {
  const info = await stat(path);
  if (info.size === 0) throw new Error("chromex.zip is empty.");
  const zip = await JSZip.loadAsync(await readFile(path));
  const manifestFile = zip.file("manifest.json");
  if (!manifestFile) throw new Error("chromex.zip must contain root manifest.json.");
  JSON.parse(await manifestFile.async("string"));

  const names = Object.keys(zip.files);
  const blocked = names.find((name) => /(?:\.map$|\.pem$|\.key$|\.crx$|\.env(?:\.|$)|\.DS_Store$|node_modules|__MACOSX)/iu.test(name));
  if (blocked) throw new Error(`chromex.zip contains blocked artifact: ${blocked}`);

  const javascript = (await Promise.all(
    names.filter((name) => name.toLowerCase().endsWith(".js")).map(async (name) => zip.file(name).async("string")),
  )).join("\n");
  for (const marker of ["grok.com", "facebook.com", "tiktok.com", "studio.youtube.com"]) {
    if (!javascript.includes(marker)) throw new Error(`chromex.zip is missing production marker: ${marker}`);
  }
  const manifest = JSON.parse(await manifestFile.async("string"));
  const youtubeMatches = (manifest.content_scripts ?? [])
    .filter((entry) => (entry.js ?? []).some((file) => /^tobyflow-youtube(?:\.|\/)/iu.test(file)))
    .flatMap((entry) => entry.matches ?? []);
  if (youtubeMatches.length !== 1 || youtubeMatches[0] !== "https://studio.youtube.com/*") {
    throw new Error(`YouTube Studio content script has an unsafe scope: ${youtubeMatches.join(", ")}`);
  }
}

async function writeZip(directory, path) {
  const zip = new JSZip();
  for (const file of await collectFiles(directory)) {
    zip.file(normalize(relative(directory, join(directory, file))), await readFile(join(directory, file)), {
      date: new Date(0),
      unixPermissions: 0o100644,
    });
  }
  await writeFile(path, await zip.generateAsync({
    type: "nodebuffer",
    compression: "DEFLATE",
    compressionOptions: { level: 9 },
    platform: "UNIX",
  }));
}

async function collectFiles(directory, current = directory) {
  const entries = await readdir(current, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = join(current, entry.name);
    if (entry.isDirectory()) files.push(...await collectFiles(directory, path));
    else if (entry.isFile()) files.push(normalize(relative(directory, path)));
  }
  return files;
}

async function assertFile(path, message) {
  try {
    const info = await stat(path);
    if (!info.isFile()) throw new Error(message);
    await access(path);
  } catch {
    throw new Error(message);
  }
}

function normalize(path) {
  return path.split(sep).join("/");
}
