/**
 * plasmo-build.mjs
 *
 * On Windows, @parcel/node-resolver-core (Rust native) crashes with
 * STATUS_ACCESS_VIOLATION (0xC0000005) when any path in the build tree
 * contains non-ASCII Unicode characters (e.g. "mẻ").
 *
 * Workaround:
 *  1. Mount the project root as an ASCII subst drive (X:).
 *  2. Load fs-unicode-patch.cjs via --require so that fs.realpath
 *     and path.resolve convert the real Unicode path back to X:
 *     before Parcel's Rust resolver ever sees it.
 *  3. Run plasmo build from X:\ as CWD.
 *
 * On Linux/macOS this is a no-op and plasmo runs directly.
 */
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));

// Just run plasmo directly. Since we use node-linker=hoisted in .npmrc, 
// there are no symlinks, so Parcel's Rust resolver won't crash on Windows.
const REPO_ROOT = join(ROOT, "..", "..");
// Set PARCEL_WORKER_BACKEND=process on Windows to prevent native multithreading crash with worker_threads
const env = {
  ...process.env,
  PARCEL_WORKER_BACKEND: "process",
};

const result = spawnSync(
  "node",
  [join(REPO_ROOT, "node_modules", "plasmo", "dist", "index.js"), "build"],
  { cwd: ROOT, stdio: "inherit", env },
);

process.exit(result.status ?? 1);

