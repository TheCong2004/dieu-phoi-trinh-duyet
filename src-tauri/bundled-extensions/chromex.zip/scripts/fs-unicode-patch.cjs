/**
 * fs-unicode-patch.cjs
 *
 * Loaded via `node --require` before plasmo/parcel starts.
 *
 * @parcel/node-resolver-core (Rust) crashes on Windows Unicode paths.
 * Strategy:
 *  1. Patch fs.realpath/realpathSync so JS code gets ASCII paths back
 *  2. Patch path.resolve so JS path math stays ASCII
 *  3. Intercept @parcel/resolver-default via Module._load and wrap its
 *     exported plugin to substitute projectRoot/filename before they
 *     reach the Rust constructor or resolve() call
 *
 * Env vars (set by plasmo-build.mjs):
 *   UNICODE_PATH_FROM  – real Unicode path  (e.g. D:\capcutpolot\mẻ\...)
 *   UNICODE_PATH_TO    – ASCII subst path   (e.g. X:\)
 */
"use strict";

const fs = require("fs");
const path = require("path");
const Module = require("module");

const FROM = (process.env.UNICODE_PATH_FROM || "").replace(/\//g, "\\").replace(/\\+$/, "");
const TO   = (process.env.UNICODE_PATH_TO   || "").replace(/\//g, "\\").replace(/\\+$/, "");

if (!FROM || !TO) {
  process.stderr.write("[fs-patch] No UNICODE_PATH_FROM/TO – skipping\n");
  return;
}

process.stderr.write(`[fs-patch] ${FROM} → ${TO}\n`);

// ── Path substitution helpers ────────────────────────────────────────────────
function sub(p) {
  if (typeof p !== "string") return p;
  const n = p.replace(/\//g, "\\");
  if (n.length >= FROM.length && n.slice(0, FROM.length).toLowerCase() === FROM.toLowerCase()) {
    return TO + n.slice(FROM.length);
  }
  return p;
}

function subDeep(v) {
  if (typeof v === "string") return sub(v);
  if (Array.isArray(v)) return v.map(subDeep);
  if (v && typeof v === "object") {
    const out = {};
    for (const k of Object.keys(v)) out[k] = subDeep(v[k]);
    return out;
  }
  return v;
}

// ── 1. fs.realpath / fs.realpathSync ────────────────────────────────────────
const _realpath = fs.realpath.bind(fs);
fs.realpath = function realpath(p, opts, cb) {
  if (typeof opts === "function") { cb = opts; opts = {}; }
  _realpath(p, opts, (err, res) => cb(err, err ? res : sub(res)));
};
const _realpathNative = (fs.realpath.native || _realpath).bind(fs);
fs.realpath.native = function(p, opts, cb) {
  if (typeof opts === "function") { cb = opts; opts = {}; }
  _realpathNative(p, opts, (err, res) => cb(err, err ? res : sub(res)));
};

const _realpathSync = fs.realpathSync.bind(fs);
fs.realpathSync = function(p, opts) { return sub(_realpathSync(p, opts)); };
const _realpathSyncNative = (fs.realpathSync.native || _realpathSync).bind(fs);
fs.realpathSync.native = function(p, opts) { return sub(_realpathSyncNative(p, opts)); };

// ── 2. path.resolve ──────────────────────────────────────────────────────────
const _resolve = path.resolve;
path.resolve = function(...args) { return sub(_resolve(...args)); };

// ── 3. Intercept @parcel/node-resolver-core via Module._load ────────────────
// We patch the Rust native class prototype since result.default is getter-only.
const _load = Module._load.bind(Module);
let resolverCorePatched = false;

Module._load = function(request, parent, isMain) {
  const result = _load(request, parent, isMain);

  if (!resolverCorePatched && request.includes("node-resolver-core")) {
    const NativeClass = result.default || result.ResolverBase;
    if (NativeClass && NativeClass.prototype && NativeClass.prototype.resolve) {
      const origResolve = NativeClass.prototype.resolve;
      NativeClass.prototype.resolve = function patchedResolve(opts) {
        const patched = subDeep(opts);
        // Log first few calls so we know what the Rust resolver sees
        if (process.env.PATCH_DEBUG) {
          process.stderr.write(`[fs-patch] resolve: filename=${patched.filename} parent=${patched.parent}\n`);
        }
        return origResolve.call(this, patched);
      };
      resolverCorePatched = true;
      process.stderr.write("[fs-patch] Patched ResolverBase.prototype.resolve\n");
    }
  }

  // Also patch @parcel/resolver-default: wrap the plugin's resolve() so that
  // options.projectRoot is always ASCII before reaching the native constructor
  if (request.includes("resolver-default")) {
    try {
      const plugin = result && (result.default || result);
      if (plugin && typeof plugin.resolve === "function") {
        const origPluginResolve = plugin.resolve;
        plugin.resolve = function patchedPluginResolve(opts) {
          return origPluginResolve.call(this, subDeep(opts));
        };
        process.stderr.write("[fs-patch] Patched @parcel/resolver-default plugin.resolve\n");
      }
    } catch {}
  }

  return result;
};

process.stderr.write("[fs-patch] Patches applied\n");
