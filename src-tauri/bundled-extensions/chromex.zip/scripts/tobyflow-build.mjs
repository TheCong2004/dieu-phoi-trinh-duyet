/**
 * Build TobyFlow platform — chạy từ Chromex root (pnpm run build:tobyflow).
 * Không dùng package.json riêng trong labs.toby.vn.
 */
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const EXT = fileURLToPath(new URL("..", import.meta.url));
const PLATFORM = join(EXT, "src", "platforms", "labs.toby.vn");
const SCRIPTS = join(PLATFORM, "scripts");

function run(name) {
  const script = join(SCRIPTS, name);
  if (!existsSync(script)) {
    console.error(`Missing script: ${script}`);
    process.exit(1);
  }
  console.log(`\n▶ tobyflow: ${name}`);
  const r = spawnSync(process.execPath, [script], {
    cwd: PLATFORM,
    stdio: "inherit",
    env: {
      ...process.env,
      CHROMEX_ROOT: EXT,
      TOBYFLOW_ROOT: PLATFORM,
    },
  });
  if (r.status !== 0) process.exit(r.status ?? 1);
}

console.log("🔧 TobyFlow platform build (Chromex integrated)");
run("merge-legacy-css.mjs");
run("build-css.mjs");
run("clean-js.mjs");
run("build.mjs");
run("build-infinite-canvas.mjs");
run("patch-html-dist.mjs");
run("verify.mjs");
console.log("\n✅ TobyFlow platform build complete");