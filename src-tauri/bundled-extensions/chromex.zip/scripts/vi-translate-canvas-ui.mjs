/**
 * Bulk-replace Chinese UI strings → Vietnamese in infinite-canvas canvas components.
 * Run: node scripts/vi-translate-canvas-ui.mjs
 */
import { readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const SRC = join(
  ROOT,
  "src/platforms/labs.toby.vn/src/workflow/infinite-canvas/web/src",
);

/** Longer phrases first */
const PAIRS = [
  ["复制生成该图片的提示词", "Sao chép prompt đã tạo ảnh này"],
  ["创建反推提示词的文本和配置节点", "Tạo node văn bản + cấu hình để suy ngược prompt"],
  ["添加蒙版遮罩后局部修改", "Thêm mask rồi chỉnh sửa vùng chọn"],
  ["图片已达到当前目标像素，无需放大", "Ảnh đã đạt độ phân giải đích, không cần phóng to"],
  ["图片已达到 4K，无需放大", "Ảnh đã đạt 4K, không cần phóng to"],
  ["选择你想在图片节点编辑栏中使用的快捷工具。", "Chọn công cụ nhanh trên thanh chỉnh sửa node ảnh."],
  ["例如：把衣服改成红色夹克，保持人物姿势不变", "VD: đổi áo thành áo khoác đỏ, giữ tư thế nhân vật"],
  ["调整相机角度后，将生成新的图片节点", "Điều chỉnh góc máy rồi tạo node ảnh mới"],
  ["张切片将创建为独立节点", " mảnh sẽ thành node riêng"],
  ["切换为等比缩放", "Chuyển sang giữ tỉ lệ"],
  ["切换为自由比例", "Chuyển sang tỉ lệ tự do"],
  ["裁剪并生成新节点", "Cắt ảnh và tạo node mới"],
  ["按行列切分图片", "Chia ảnh theo hàng/cột"],
  ["放大图片分辨率", "Phóng to độ phân giải ảnh"],
  ["查看图片详情", "Xem chi tiết ảnh"],
  ["显示按钮文字", "Hiện nhãn nút"],
  ["节点预览", "Xem trước node"],
  ["图片节点", "Node ảnh"],
  ["复制提示词", "Sao chép prompt"],
  ["反推提示词", "Suy ngược prompt"],
  ["替换图片", "Thay ảnh"],
  ["局部编辑", "Sửa cục bộ"],
  ["查看大图", "Xem ảnh lớn"],
  ["锁比例", "Khóa tỉ lệ"],
  ["自由比例", "Tỉ lệ tự do"],
  ["锁定比例", "Khóa tỉ lệ"],
  ["裁剪图片", "Cắt ảnh"],
  ["调整裁剪框", "Điều chỉnh khung cắt"],
  ["裁剪尺寸", "Kích thước cắt"],
  ["确认裁剪", "Xác nhận cắt"],
  ["图片放大", "Phóng to ảnh"],
  ["目标像素", "Độ phân giải đích"],
  ["放大算法", "Thuật toán phóng to"],
  ["输出尺寸", "Kích thước xuất"],
  ["生成放大图", "Tạo ảnh phóng to"],
  ["源图", "Ảnh nguồn"],
  ["原图", "Ảnh gốc"],
  ["读取中", "Đang đọc"],
  ["未知", "Không rõ"],
  ["比例", "Tỉ lệ"],
  ["裁剪", "Cắt ảnh"],
  ["切图", "Chia lưới"],
  ["放大", "Phóng to"],
  ["超分", "Siêu phân giải"],
  ["AI 超分", "AI siêu phân giải"],
  ["多角度", "Đa góc"],
  ["生成角度", "Tạo góc nhìn"],
  ["重置", "Đặt lại"],
  ["取消", "Hủy"],
  ["保存", "Lưu"],
  ["删除", "Xóa"],
  ["确认", "Xác nhận"],
  ["关闭", "Đóng"],
  ["请先绘制蒙版区域", "Hãy vẽ vùng mask trước"],
  ["请输入修改描述", "Nhập mô tả chỉnh sửa"],
  ["局部重绘", "Vẽ lại cục bộ"],
  ["画笔", "Cọ"],
  ["橡皮", "Tẩy"],
  ["蒙版提示词", "Prompt mask"],
  ["笔刷大小", "Cỡ cọ"],
  ["应用修改", "Áp dụng"],
  ["AI 修改", "Sửa bằng AI"],
  ["切分图片", "Chia ảnh"],
  ["行数", "Số hàng"],
  ["列数", "Số cột"],
  ["切片数", "Số mảnh"],
  ["单片尺寸", "Kích thước mỗi mảnh"],
  ["确认切分", "Xác nhận chia"],
  ["AI 多角度", "AI đa góc"],
  ["水平角度", "Góc ngang"],
  ["俯仰角度", "Góc nghiêng"],
  ["相机距离", "Khoảng cách camera"],
  ["镜头类型", "Loại ống kính"],
  ["标准", "Chuẩn"],
  ["广角", "Góc rộng"],
  ["AI 生成", "Tạo bằng AI"],
  ["素材库", "Thư viện media"],
  ["全部", "Tất cả"],
  ["文本", "Văn bản"],
  ["图片", "Ảnh"],
  ["视频", "Video"],
  ["音频", "Âm thanh"],
  ["选择", "Chọn"],
  ["搜索素材", "Tìm media"],
  ["暂无素材", "Chưa có media"],
  ["生成中", "Đang tạo"],
  ["停止生成", "Dừng tạo"],
  ["开始生成", "Bắt đầu tạo"],
  ["生成配置", "Cấu hình tạo"],
  ["创建节点", "Tạo node"],
  ["删除节点", "Xóa node"],
  ["连接节点", "Nối node"],
  ["移动节点", "Di chuyển node"],
  ["更新节点", "Cập nhật node"],
  ["生成图片", "Tạo ảnh"],
  ["生成视频", "Tạo video"],
  ["生成文本", "Tạo văn bản"],
  ["生成音频", "Tạo âm thanh"],
  ["请求已取消", "Đã hủy yêu cầu"],
  ["已复制", "Đã sao chép"],
  ["共 ", "Tổng "],
  [" 张", " mảnh"],
];

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(tsx?|jsx?)$/.test(name)) out.push(p);
  }
  return out;
}

const targets = [
  join(SRC, "components/canvas"),
  join(SRC, "components/model-picker.tsx"),
].flatMap((p) => {
  try {
    return statSync(p).isDirectory() ? walk(p) : [p];
  } catch {
    return [];
  }
});

let filesChanged = 0;
let totalRepl = 0;

for (const file of targets) {
  let text = readFileSync(file, "utf8");
  let n = 0;
  for (const [from, to] of PAIRS) {
    if (!text.includes(from)) continue;
    const parts = text.split(from);
    const count = parts.length - 1;
    if (count > 0) {
      text = parts.join(to);
      n += count;
    }
  }
  if (n > 0) {
    writeFileSync(file, text, "utf8");
    filesChanged++;
    totalRepl += n;
    console.log(`+${n}  ${relative(SRC, file)}`);
  }
}

console.log(`\nDone: ${filesChanged} files, ${totalRepl} replacements`);
