/**
 * Copy _locales → build output (thay robocopy — exit code ổn định trên PowerShell).
 * Usage: node scripts/copy-locales.mjs [dev|prod|all]
 *
 * Chrome MV3: manifest default_locale="en" BẮT BUỘC có build/.../_locales/en/messages.json.
 * Plasmo build có thể xóa/không copy _locales → luôn chạy script này sau build.
 */
import { cpSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const src = join(ROOT, "src", "_locales");
const mode = (process.argv[2] || "dev").toLowerCase();

const targets =
  mode === "all"
    ? ["chrome-mv3-dev", "chrome-mv3-prod", "chrome-mv3-dev-prod"]
    : mode === "prod"
      ? ["chrome-mv3-prod"]
      : ["chrome-mv3-dev"];

if (!existsSync(src)) {
  console.warn(`copy-locales: skip — missing ${src}`);
  process.exit(0);
}

const enMessages = join(src, "en", "messages.json");
if (!existsSync(enMessages)) {
  console.error(`copy-locales: FATAL — missing ${enMessages} (default_locale=en)`);
  process.exit(1);
}

for (const target of targets) {
  const buildDir = join(ROOT, "build", target);
  if (!existsSync(buildDir)) {
    console.warn(`copy-locales: skip ${target} — build folder not found`);
    continue;
  }
  const dest = join(buildDir, "_locales");
  // Xóa dest cũ nếu chỉ là folder rỗng / incomplete (Chrome: "subtree is missing")
  try {
    if (existsSync(dest) && !existsSync(join(dest, "en", "messages.json"))) {
      rmSync(dest, { recursive: true, force: true });
    }
  } catch (_) { /* ignore */ }
  mkdirSync(buildDir, { recursive: true });
  cpSync(src, dest, { recursive: true });
  console.log(`copy-locales: ${src} → ${dest}`);
}