(() => {
  // src/platforms/labs.toby.vn/chat-content-chatgpt.ts
  (function() {
    window.__tobyflowChatGPTLoaded__ = true;
    if (window._chatAIInjected) return;
    window._chatAIInjected = true;
    let __chatgptAbort = false;
    let __chatgptAbortAt = 0;
    let __chatgptCallStartAt = 0;
    function isAbortActive() {
      return __chatgptAbort && __chatgptAbortAt >= __chatgptCallStartAt;
    }
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    async function interruptibleSleep(totalMs, stage = "sleep") {
      const POLL = 200;
      const start = Date.now();
      while (Date.now() - start < totalMs) {
        if (isAbortActive()) {
          console.log("[ChatGPT-abort] Interruptible sleep aborted at stage:", stage);
          throw new Error("ABORTED:" + stage);
        }
        const remaining = totalMs - (Date.now() - start);
        await sleep(Math.min(POLL, remaining));
      }
    }
    const _NET_MSG = "tobyflow-chatgpt-net";
    const _REAL_IMAGE_FILE_ID_RE = /\b(file_00000000[a-f0-9]{24}|file_[a-f0-9]{16,})\b/gi;
    const _netCapture = {
      epoch: 0,
      baselineFileIds: /* @__PURE__ */ new Set(),
      // lowercase file_id / keys pre-submit
      // fileId → { url, ts, source }
      files: /* @__PURE__ */ new Map(),
      genHintAt: 0,
      // thấy image_gen / generating trong network
      lastEventAt: 0,
      hooked: false
    };
    function _estuaryUrlFromFileId(fileId) {
      const id = String(fileId || "").trim();
      if (!id) return "";
      return `https://chatgpt.com/backend-api/estuary/content?id=${id}`;
    }
    function _normalizeFileId(raw) {
      const s = String(raw || "").trim();
      if (!s) return "";
      const m = s.match(/file_00000000[a-f0-9]{24}/i) || s.match(/file_[a-f0-9]{16,}/i);
      return m ? m[0].toLowerCase() : "";
    }
    function _ingestNetFileIds(fileIds, source, epoch) {
      if (epoch != null && epoch !== _netCapture.epoch) return;
      if (!Array.isArray(fileIds) || !fileIds.length) return;
      let added = 0;
      for (const raw of fileIds) {
        const fid = _normalizeFileId(raw);
        if (!fid) continue;
        if (_netCapture.baselineFileIds.has(fid)) continue;
        if (_netCapture.files.has(fid)) continue;
        const url = _estuaryUrlFromFileId(fid);
        _netCapture.files.set(fid, { url, ts: Date.now(), source: source || "net" });
        added++;
      }
      if (added > 0) {
        _netCapture.lastEventAt = Date.now();
        console.log(
          "%c[ChatGPT-net] +file_id",
          "color:#0f0;font-weight:bold",
          "n=",
          added,
          "total=",
          _netCapture.files.size,
          "src=",
          source || "?",
          "epoch=",
          _netCapture.epoch
        );
      }
    }
    function _resetNetCaptureForTurn(baselineKeys) {
      _netCapture.epoch += 1;
      _netCapture.baselineFileIds = /* @__PURE__ */ new Set();
      _netCapture.files.clear();
      _netCapture.genHintAt = 0;
      _netCapture.lastEventAt = 0;
      if (baselineKeys) {
        for (const k of baselineKeys) {
          const fid = _normalizeFileId(k) || String(k || "").toLowerCase();
          if (fid) _netCapture.baselineFileIds.add(fid);
          if (k) _netCapture.baselineFileIds.add(String(k).toLowerCase());
        }
      }
      try {
        window.postMessage({ type: _NET_MSG, action: "reset", epoch: _netCapture.epoch }, "*");
      } catch (_) {
      }
      console.log(
        "%c[ChatGPT-net] reset turn",
        "color:#0ff;font-weight:bold",
        "epoch=",
        _netCapture.epoch,
        "baseline=",
        _netCapture.baselineFileIds.size
      );
    }
    function _getNetNewImageUrls() {
      const urls = [];
      for (const [, v] of _netCapture.files) {
        if (v?.url) urls.push(v.url);
      }
      return urls;
    }
    function _ensureMainWorldNetHook() {
      if (!_netCapture._listenerBound) {
        _netCapture._listenerBound = true;
        window.addEventListener("message", (ev) => {
          try {
            const d = ev?.data;
            if (!d || d.type !== _NET_MSG || d.action !== "hit") return;
            if (d.genHint) _netCapture.genHintAt = Date.now();
            if (Array.isArray(d.fileIds) && d.fileIds.length) {
              _ingestNetFileIds(d.fileIds, d.source || "main", d.epoch);
            }
          } catch (_) {
          }
        });
      }
      if (_netCapture.hooked) return;
      _netCapture.hooked = true;
      try {
        const s = document.createElement("script");
        s.textContent = `(() => {
  if (window.__tobyflowCgNetHook) return;
  window.__tobyflowCgNetHook = true;
  const MSG = ${JSON.stringify(_NET_MSG)};
  let epoch = 0;
  const FILE_RE = /\\b(file_00000000[a-f0-9]{24}|file_[a-f0-9]{16,})\\b/gi;
  const CONV_RE = /\\/backend-api\\/conversation/i;
  const GEN_HINT_RE = /image_gen|image_generation|async_task_type|Generating image|image_asset_pointer|file-service:\\/\\/|sediment:\\/\\//i;
  window.addEventListener('message', (ev) => {
    const d = ev && ev.data;
    if (!d || d.type !== MSG || d.action !== 'reset') return;
    epoch = d.epoch || 0;
  });
  function extractIds(text) {
    if (!text || typeof text !== 'string') return [];
    const out = [], seen = new Set(); let m; FILE_RE.lastIndex = 0;
    while ((m = FILE_RE.exec(text)) !== null) {
      const id = m[1].toLowerCase();
      if (!seen.has(id)) { seen.add(id); out.push(id); }
    }
    return out;
  }
  function emit(fileIds, source, genHint) {
    try {
      window.postMessage({ type: MSG, action: 'hit', epoch, fileIds: fileIds || [], source: source || 'fetch', genHint: !!genHint, ts: Date.now() }, '*');
    } catch (_) {}
  }
  function scanText(text, source) {
    if (!text) return;
    const genHint = GEN_HINT_RE.test(text);
    const ids = extractIds(text);
    if (ids.length || genHint) emit(ids, source, genHint);
  }
  const _fetch = window.fetch;
  window.fetch = async function(input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) ? input.url : String(input || '');
    const res = await _fetch.apply(this, arguments);
    try {
      if (!CONV_RE.test(url) && !/\\/backend-api\\/files\\//i.test(url)) return res;
      const ct = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
      if (ct.includes('text/event-stream') || ct.includes('text/plain') || /\\/conversation/i.test(url)) {
        const clone = res.clone();
        (async () => {
          try {
            const reader = clone.body && clone.body.getReader && clone.body.getReader();
            if (!reader) { scanText(await clone.text(), 'fetch-text'); return; }
            const dec = new TextDecoder(); let buf = '';
            for (;;) {
              const { done, value } = await reader.read();
              if (done) break;
              buf += dec.decode(value, { stream: true });
              if (buf.length > 200000) buf = buf.slice(-80000);
              scanText(buf, 'fetch-sse');
            }
            if (buf) scanText(buf, 'fetch-sse-end');
          } catch (_) {}
        })();
      } else if (ct.includes('json')) {
        res.clone().text().then((t) => scanText(t, 'fetch-json')).catch(() => {});
      }
    } catch (_) {}
    return res;
  };
  console.log('%c[ChatGPT-net] MAIN hook (script tag)', 'color:#0f0;font-weight:bold');
})();`;
        (document.documentElement || document.head || document.body).appendChild(s);
        s.remove();
        console.log("[ChatGPT-net] script-tag inject attempted");
      } catch (e) {
        console.warn("[ChatGPT-net] script-tag inject fail (CSP?):", e?.message || e);
      }
      try {
        chrome.runtime.sendMessage({ action: "chatgpt:injectNetHook" }, (resp) => {
          if (chrome.runtime.lastError) {
            console.warn("[ChatGPT-net] injectNetHook lastError:", chrome.runtime.lastError.message);
            return;
          }
          console.log("[ChatGPT-net] injectNetHook via SW:", resp);
        });
      } catch (e) {
        console.warn("[ChatGPT-net] injectNetHook send fail:", e?.message || e);
      }
    }
    try {
      _ensureMainWorldNetHook();
    } catch (_) {
    }
    const _i18n = {
      _lang: "vi",
      _strings: {
        vi: {
          preparing: "\u0110ang chu\u1EA9n b\u1ECB",
          waitingVerification: "Ch\u1EDD x\xE1c minh...",
          waitingResult: "\u0110ang ch\u1EDD k\u1EBFt qu\u1EA3..."
        },
        en: {
          preparing: "Preparing",
          waitingVerification: "Waiting for verification...",
          waitingResult: "Waiting for result..."
        },
        ja: {
          preparing: "\u6E96\u5099\u4E2D",
          waitingVerification: "\u8A8D\u8A3C\u5F85\u3061...",
          waitingResult: "\u7D50\u679C\u3092\u5F85\u3063\u3066\u3044\u307E\u3059..."
        },
        th: {
          preparing: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21",
          waitingVerification: "\u0E23\u0E2D\u0E01\u0E32\u0E23\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19...",
          waitingResult: "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E23\u0E2D\u0E1C\u0E25\u0E25\u0E31\u0E1E\u0E18\u0E4C..."
        }
      },
      t(key) {
        return this._strings[this._lang]?.[key] || this._strings.vi[key] || key;
      }
    };
    chrome.storage.local.get(["af_settings", "af_locale"], (res) => {
      _i18n._lang = res.af_locale || res.af_settings?.language || "vi";
      console.log(`[ChatGPT-i18n] Language loaded: ${_i18n._lang}`);
    });
    const PROVIDER = "chatgpt";
    let _selectorConfig = null;
    let _selectorConfigTime = 0;
    const _SELECTOR_CACHE_TTL = 3e4;
    const _SELECTOR_WAIT_MAX_MS = 1e4;
    const _SELECTOR_WAIT_INTERVAL_MS = 200;
    const _OVERLAY_I18N = {
      vi: { title: "M\u1EA5t k\u1EBFt n\u1ED1i server", desc: "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i t\u1EDBi m\xE1y ch\u1EE7 Toby. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i sau.", retry: "Th\u1EED l\u1EA1i" },
      en: { title: "Server Connection Lost", desc: "Unable to connect to Toby server. Please try again later.", retry: "Retry" },
      ja: { title: "\u30B5\u30FC\u30D0\u30FC\u63A5\u7D9A\u304C\u5207\u308C\u307E\u3057\u305F", desc: "Toby\u30B5\u30FC\u30D0\u30FC\u306B\u63A5\u7D9A\u3067\u304D\u307E\u305B\u3093\u3002\u5F8C\u3067\u3082\u3046\u4E00\u5EA6\u304A\u8A66\u3057\u304F\u3060\u3055\u3044\u3002", retry: "\u518D\u8A66\u884C" },
      th: { title: "\u0E02\u0E32\u0E14\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C", desc: "\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E01\u0E31\u0E1A\u0E40\u0E0B\u0E34\u0E23\u0E4C\u0E1F\u0E40\u0E27\u0E2D\u0E23\u0E4C Toby \u0E01\u0E23\u0E38\u0E13\u0E32\u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07", retry: "\u0E25\u0E2D\u0E07\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07" }
    };
    const _CHATGPT_LOCAL_DEV_BOOTSTRAP = {
      chatgpt: {
        selectors: {
          composer: {
            selectors: [
              // Ưu tiên ProseMirror / contenteditable — React state thật.
              // textarea.wcDTda_fallbackTextarea chỉ a11y fallback: set value KHÔNG submit được
              // (log: insert len=167 nhưng SUBMIT_FAILED / click nhầm radix popover).
              'div#prompt-textarea[contenteditable="true"]',
              '#prompt-textarea[contenteditable="true"]',
              'div.ProseMirror[contenteditable="true"]',
              '.ProseMirror[contenteditable="true"]',
              '[data-testid="prompt-textarea"][contenteditable="true"]',
              '.wcDTda_prosemirror-parent [contenteditable="true"]',
              "#prompt-textarea",
              '[data-testid="prompt-textarea"]',
              '[contenteditable="true"][role="textbox"]',
              // Fallback textarea (khi ProseMirror chưa mount)
              'textarea[name="prompt-textarea"]',
              "textarea.wcDTda_fallbackTextarea",
              'form[data-type="unified-composer"] textarea[name="prompt-textarea"]',
              'form.group\\/composer textarea[name="prompt-textarea"]',
              'textarea[placeholder*="Message"]',
              'textarea[placeholder*="Ask"]',
              'textarea[placeholder*="H\u1ECFi"]',
              'textarea[aria-label*="ChatGPT"]',
              "textarea",
              '[contenteditable="true"]'
            ]
          },
          submit_button: {
            selectors: [
              // DOM prod 2026 (dump user) — chuẩn nhất
              "#composer-submit-button",
              "button#composer-submit-button",
              'button[data-testid="send-button"]',
              "button.composer-submit-btn",
              'form[data-type="unified-composer"] button[data-testid="send-button"]',
              'form[data-type="unified-composer"] #composer-submit-button',
              // EN / VN aria
              'button[aria-label="G\u1EEDi l\u1EDDi nh\u1EAFc"]',
              'button[aria-label*="G\u1EEDi l\u1EDDi nh\u1EAFc"]',
              'button[aria-label="Send prompt"]',
              'button[aria-label*="Send prompt"]',
              'button[aria-label*="Send message"]',
              'button[data-testid="composer-send-button"]',
              'button[data-testid="fruitjuice-send-button"]',
              'button[aria-label*="Send"]',
              'button[aria-label*="G\u1EEDi tin"]',
              'button[aria-label*="G\u1EEDi"]',
              'form button[type="submit"]',
              'button[type="submit"]'
            ],
            // Mic / voice — KHÔNG phải Send (kể cả class hay nhầm submit)
            exclude_if_aria_contains: [
              "voice",
              "mic",
              "dictation",
              "speech",
              "microphone",
              "tho\u1EA1i",
              "ch\u1EBF \u0111\u1ED9 tho\u1EA1i",
              "b\u1EAFt \u0111\u1EA7u ch\u1EBF \u0111\u1ED9",
              "\u0111\u1ECDc ch\xEDnh t\u1EA3",
              "ghi \xE2m",
              "stop",
              "d\u1EEBng",
              "cancel",
              "h\u1EE7y"
            ]
          },
          // New chat (sidebar)
          new_chat_button: {
            selectors: [
              '[data-testid="create-new-chat-button"]',
              'a[data-testid="create-new-chat-button"]',
              'a[href="/"][data-sidebar-item="true"]'
            ]
          },
          // File ref upload (hidden input trong unified-composer)
          file_input: {
            selectors: [
              'form[data-type="unified-composer"] input#upload-files',
              "input#upload-files",
              'form.group\\/composer input[type="file"]'
            ]
          },
          login_button: {
            selectors: ['button[data-testid="login-button"]', 'a[href*="/auth/login"]']
          },
          auth_link: {
            selectors: ['a[href*="/auth/"]', 'button[data-testid="login-button"]']
          },
          generating_indicator: {
            selectors: [
              '[class*="result-streaming"]',
              ".result-streaming",
              'button[aria-label="Stop generating"]',
              'button[aria-label*="Stop"]',
              'button[data-testid="stop-button"]',
              'button[aria-label*="D\u1EEBng"]'
            ]
          },
          // Probe 2026-07 (user console): ảnh gen =
          //   https://chatgpt.com/backend-api/estuary/content?id=file_00000000...&t=...&sig=...
          // host=chatgpt.com — KHÔNG phải oaiusercontent.com. Server config cũ chỉ 2 selector
          // oaiusercontent/openai → DYNAMIC miss → turnCount 0 + "Đang chờ kết quả" dù ảnh đã xong.
          cdn_image: {
            selectors: [
              'img[src*="backend-api/estuary"]',
              'img[src*="/estuary/content"]',
              'img[src*="estuary/content"]',
              'img[src*="estuary"]',
              'img[src*="/backend-api/"]',
              'img[alt^="Generated image"]',
              'img[alt*="Generated image"]',
              'img[src*="oaiusercontent.com"]',
              'img[src*="files.oaiusercontent"]',
              'img[src*="openai.com"]',
              'img[src*="blob.core.windows.net"]',
              'main img[src*="estuary"]',
              'main img[src^="https://"]'
            ]
          },
          // DOM ChatGPT 2026 — thiếu bootstrap → turnCount luôn 0 dù UI đã có tin nhắn + ảnh
          conversation_turn: {
            selectors: [
              '[data-testid^="conversation-turn-"]',
              'article[data-testid^="conversation-turn-"]',
              'div[data-testid^="conversation-turn-"]',
              "[data-turn-id]",
              "main article",
              "main [data-message-author-role]"
            ]
          },
          assistant_turn: {
            selectors: [
              '[data-message-author-role="assistant"]',
              '[data-testid^="conversation-turn-"][data-turn="assistant"]',
              'article[data-testid^="conversation-turn-"]:has([data-message-author-role="assistant"])',
              'main article:has(img[alt*="Generated"])',
              'main article:has(img[src*="estuary"])',
              'main article:has(img[src*="oaiusercontent"])',
              'main article:has(img[src*="backend-api"])'
            ]
          },
          generated_image: {
            selectors: [
              'img[alt^="Generated image"]',
              'img[alt*="Generated image"]',
              'img[alt^="Image created"]',
              'img[src*="backend-api/estuary"]',
              'img[src*="/estuary/content"]',
              'img[src*="estuary"]',
              'img[src*="oaiusercontent.com"]',
              'img[src*="files.oaiusercontent"]',
              'img[src*="/backend-api/"]'
            ]
          },
          conversation_options_button: { selectors: ['button[aria-label*="options"]', 'button[id*="options"]'] },
          delete_confirm_button: { selectors: ["button.btn-danger", 'button[class*="danger"]'] },
          image_action_buttons: {
            selectors: [
              'button[aria-label*="Like this image"]',
              'button[aria-label*="Download"]',
              'button[aria-label*="T\u1EA3i"]',
              'button[class*="action"]'
            ]
          }
        }
      }
    };
    function _bootstrapSelectors(key) {
      return _CHATGPT_LOCAL_DEV_BOOTSTRAP.chatgpt?.selectors?.[key]?.selectors || [];
    }
    function _bootstrapExcludeAria(key) {
      return (_CHATGPT_LOCAL_DEV_BOOTSTRAP.chatgpt?.selectors?.[key]?.exclude_if_aria_contains || []).map((s) => String(s).toLowerCase());
    }
    function _normalizeProviderConfigData(data) {
      if (!data || typeof data !== "object") return data || {};
      const out = { ...data };
      for (const provider of Object.keys(out)) {
        const entry = out[provider];
        if (!entry || typeof entry !== "object") continue;
        if (!entry.selectors && entry.dom_selectors) {
          out[provider] = { ...entry, selectors: entry.dom_selectors };
        }
      }
      return out;
    }
    function _providerHasEssentials(data, provider) {
      const normalized = _normalizeProviderConfigData(data);
      const sel = normalized?.[provider]?.selectors;
      return !!(sel && sel.composer?.selectors?.length);
    }
    function _shouldAllowSelectorBootstrap(cb) {
      try {
        chrome.storage.local.get(["apiBaseUrl", "af_api_url", "af_auth"], (res) => {
          const urls = [
            res?.apiBaseUrl,
            res?.af_api_url,
            res?.af_auth?.apiBaseUrl
          ].map((v) => String(v || ""));
          if (urls.some((u) => /localhost|127\.0\.0\.1/.test(u))) {
            cb(true);
            return;
          }
          try {
            chrome.runtime.sendMessage({ action: "tobyflow:isDevBuild" }, (resp) => {
              if (!chrome.runtime.lastError && resp?.isDevBuild) {
                cb(true);
                return;
              }
              cb(true);
            });
          } catch (_) {
            cb(true);
          }
        });
      } catch (_) {
        cb(true);
      }
    }
    function _applyChatGPTSelectorBootstrap(source, existingData = {}) {
      const merged = { ...existingData, ..._CHATGPT_LOCAL_DEV_BOOTSTRAP };
      _selectorConfig = merged;
      _selectorConfigTime = Date.now();
      try {
        chrome.storage.local.set({
          toby_provider_configs: {
            data: merged,
            expiresAt: Date.now() + 5 * 60 * 1e3,
            fetchedAt: Date.now(),
            source: source || "content_bootstrap"
          }
        });
      } catch (_) {
      }
      const keyCount = Object.keys(_selectorConfig[PROVIDER]?.selectors || {}).length;
      console.log(`[Selector:${PROVIDER}:ensure] \u2705 Local dev bootstrap (${source || "content"}, ${keyCount} selectors)`);
      return true;
    }
    (function _ensureSelectorConfig() {
      console.log(`[Selector:${PROVIDER}:ensure] \u23F3 Loading provider config...`);
      _shouldAllowSelectorBootstrap(() => {
        chrome.storage.local.get(["toby_provider_configs"], (res) => {
          const data = _normalizeProviderConfigData(res.toby_provider_configs?.data);
          if (_providerHasEssentials(data, PROVIDER)) {
            _selectorConfig = data;
            _selectorConfigTime = Date.now();
            const keyCount = Object.keys(_selectorConfig[PROVIDER]?.selectors || {}).length;
            console.log(`[Selector:${PROVIDER}:ensure] \u2705 Loaded ${keyCount} selectors from cache`);
            return;
          }
          console.log(`[Selector:${PROVIDER}:ensure] Bootstrap selectors (server/cache ch\u01B0a s\u1EB5n s\xE0ng)`);
          _applyChatGPTSelectorBootstrap("immediate_fallback", data || {});
          try {
            chrome.runtime.sendMessage({ action: "getProviderConfigs", provider: PROVIDER }, () => {
              if (chrome.runtime.lastError) {
              }
            });
          } catch (_) {
          }
        });
      });
      try {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== "local" || !changes.toby_provider_configs) return;
          const next = _normalizeProviderConfigData(changes.toby_provider_configs.newValue?.data);
          if (_providerHasEssentials(next, PROVIDER)) {
            _selectorConfig = next;
            _selectorConfigTime = Date.now();
            const existingOverlay = document.getElementById("tobyflow-config-error-overlay");
            if (existingOverlay) existingOverlay.remove();
          }
        });
      } catch (_) {
      }
    })();
    function _showConfigErrorOverlay() {
      if (document.getElementById("tobyflow-config-error-overlay")) {
        console.log(`[Selector:${PROVIDER}:overlay] \u21A9 Overlay already mounted \u2014 skip`);
        return;
      }
      const lang = _i18n && _i18n._lang || "vi";
      const t = _OVERLAY_I18N[lang] || _OVERLAY_I18N.vi;
      const overlay = document.createElement("div");
      overlay.id = "tobyflow-config-error-overlay";
      overlay.className = "tobyflow-cfg-err-overlay";
      overlay.innerHTML = `
      <style>
        .tobyflow-cfg-err-overlay { position: fixed; inset: 0; z-index: 2147483647; background: rgba(10,10,14,0.95); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; color: #fff; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .tobyflow-cfg-err-content { display: flex; flex-direction: column; align-items: center; text-align: center; padding: 32px; max-width: 320px; }
        .tobyflow-cfg-err-icon { width: 80px; height: 80px; border-radius: 50%; background: rgba(239,68,68,0.15); display: flex; align-items: center; justify-content: center; margin-bottom: 20px; }
        .tobyflow-cfg-err-icon svg { color: #ef4444; }
        .tobyflow-cfg-err-title { font-size: 18px; font-weight: 600; color: #fff; margin: 0 0 8px 0; }
        .tobyflow-cfg-err-desc { font-size: 14px; color: rgba(255,255,255,0.6); margin: 0 0 24px 0; line-height: 1.5; }
        .tobyflow-cfg-err-retry-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #fff; color: #1a1a1e; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: opacity 0.2s; }
        .tobyflow-cfg-err-retry-btn:hover { opacity: 0.9; }
        .tobyflow-cfg-err-retry-btn:active { opacity: 0.8; }
        .tobyflow-cfg-err-retry-btn svg { color: #1a1a1e; }
      </style>
      <div class="tobyflow-cfg-err-content">
        <div class="tobyflow-cfg-err-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <line x1="2" y1="2" x2="22" y2="22"></line>
            <path d="M8.5 16.5a5 5 0 0 1 7 0"></path>
            <path d="M2 8.82a15 15 0 0 1 4.17-2.65"></path>
            <path d="M10.66 5c4.01-.36 8.14.9 11.34 3.76"></path>
            <path d="M16.85 11.25a10 10 0 0 1 2.22 1.68"></path>
            <path d="M5 13a10 10 0 0 1 5.24-2.76"></path>
            <line x1="12" y1="20" x2="12.01" y2="20"></line>
          </svg>
        </div>
        <h3 class="tobyflow-cfg-err-title"></h3>
        <p class="tobyflow-cfg-err-desc"></p>
        <button class="tobyflow-cfg-err-retry-btn" type="button">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M21 2v6h-6"></path>
            <path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path>
            <path d="M3 22v-6h6"></path>
            <path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path>
          </svg>
          <span></span>
        </button>
      </div>
    `;
      overlay.querySelector(".tobyflow-cfg-err-title").textContent = t.title;
      overlay.querySelector(".tobyflow-cfg-err-desc").textContent = t.desc;
      overlay.querySelector(".tobyflow-cfg-err-retry-btn span").textContent = t.retry;
      document.body.appendChild(overlay);
      overlay.querySelector(".tobyflow-cfg-err-retry-btn").addEventListener("click", () => {
        console.log(`[Selector:${PROVIDER}:overlay] \u{1F504} User clicked retry \u2014 reloading page`);
        overlay.remove();
        location.reload();
      });
      console.warn(`[Selector:${PROVIDER}:overlay] \u{1F6AB} Config error overlay shown (lang=${lang}) \u2014 server unreachable, user action required`);
    }
    function _getDynamicSelector(key) {
      const now = Date.now();
      if (_selectorConfig && now - _selectorConfigTime < _SELECTOR_CACHE_TTL) {
        return _selectorConfig?.[PROVIDER]?.selectors?.[key] || null;
      }
      chrome.storage.local.get(["toby_provider_configs"], (res) => {
        if (res.toby_provider_configs?.data) {
          _selectorConfig = res.toby_provider_configs.data;
          _selectorConfigTime = Date.now();
        }
      });
      return _selectorConfig?.[PROVIDER]?.selectors?.[key] || null;
    }
    function _queryWithFallback(key, defaultSelectors = null, options = {}) {
      const config = _getDynamicSelector(key);
      const bootstrap = _bootstrapSelectors(key);
      const hardcoded = defaultSelectors && defaultSelectors.length ? defaultSelectors : bootstrap;
      const isDynamic = config?.selectors?.length > 0;
      const selectors = isDynamic ? [...config.selectors, ...hardcoded.filter((s) => !config.selectors.includes(s))] : hardcoded;
      const silent = options.silent || false;
      const scope = options.scope || document;
      if (!silent) {
        console.log(
          `[Selector:${PROVIDER}:${key}] ${isDynamic ? "\u{1F310} DYNAMIC+bootstrap" : "\u{1F4E6} BOOTSTRAP"} | Trying ${selectors.length} selectors`
        );
      }
      const excludeAria = [
        ...config?.exclude_if_aria_contains || [],
        ..._bootstrapExcludeAria(key)
      ].map((s) => String(s).toLowerCase());
      const _isExcluded = (el) => {
        if (!el) return true;
        if (excludeAria.length) {
          const al = (el.getAttribute("aria-label") || el.getAttribute("title") || "").toLowerCase();
          if (excludeAria.some((x) => x && al.includes(x))) return true;
        }
        try {
          const r = el.getBoundingClientRect?.();
          if (r && (r.width < 2 || r.height < 2)) return true;
          const st = window.getComputedStyle?.(el);
          if (st && (st.display === "none" || st.visibility === "hidden" || st.opacity === "0")) return true;
        } catch (_) {
        }
        return false;
      };
      for (let i = 0; i < selectors.length; i++) {
        try {
          const els = scope.querySelectorAll(selectors[i]);
          for (const el of els) {
            if (el && !_isExcluded(el)) {
              if (!silent) console.log(`[Selector:${PROVIDER}:${key}] \u2705 Match #${i + 1}: ${selectors[i]}`);
              return el;
            }
          }
        } catch (e) {
        }
      }
      if (!silent) console.log(`[Selector:${PROVIDER}:${key}] \u274C No match`);
      if (key === "submit_button") {
        const heur = _findChatGptSendButton(options.editor || null);
        if (heur) {
          if (!silent) console.log(`[Selector:${PROVIDER}:${key}] \u2705 heuristic form+#prompt-textarea`);
          return heur;
        }
      }
      if (key === "composer") {
        const heur = _findChatGptComposer();
        if (heur) {
          if (!silent) console.log(`[Selector:${PROVIDER}:${key}] \u2705 heuristic #prompt-textarea`);
          return heur;
        }
      }
      return null;
    }
    function _isChatGptSpeechOrMicButton(btn) {
      if (!btn) return true;
      const aria = (btn.getAttribute("aria-label") || btn.getAttribute("title") || "").toLowerCase();
      const testid = (btn.getAttribute("data-testid") || "").toLowerCase();
      const cls = String(btn.className || "").toLowerCase();
      const style = String(btn.getAttribute("style") || "").toLowerCase();
      const vt = style.includes("speech") || style.includes("vt-composer-speech") || cls.includes("speech") || /speech-button|voice-button|dictation/i.test(cls + testid);
      if (/thoại|voice|mic|speech|dictat|microphone|ghi âm|đọc chính tả/.test(aria)) return true;
      if (vt) return true;
      if (/vt-composer-speech|composer-speech/.test(style)) return true;
      return false;
    }
    function _isChatGptMenuOrNonSendButton(btn) {
      if (!btn) return true;
      if (_isChatGptSpeechOrMicButton(btn)) return true;
      const testid = (btn.getAttribute("data-testid") || "").toLowerCase();
      const id = (btn.id || "").toLowerCase();
      const clsId = `${btn.id || ""} ${btn.className || ""}`.toLowerCase();
      if (id === "composer-submit-button" || testid === "send-button" || /composer-submit|fruitjuice-send/.test(clsId)) {
        return false;
      }
      const aria = (btn.getAttribute("aria-label") || btn.getAttribute("title") || "").toLowerCase();
      if (/^gửi$|^send$|send prompt|send message|gửi tin|gửi lời nhắc/.test(aria)) return false;
      const hasPopup = (btn.getAttribute("aria-haspopup") || "").toLowerCase();
      if (hasPopup === "menu" || hasPopup === "dialog" || hasPopup === "listbox" || hasPopup === "true") return true;
      if (btn.hasAttribute("aria-expanded") && !/send|gửi|submit/.test(aria + testid)) return true;
      const dataState = (btn.getAttribute("data-state") || "").toLowerCase();
      if ((dataState === "open" || dataState === "closed") && !/send|submit/.test(testid + id)) return true;
      if (/^radix-/.test(id) && !/send|submit/.test(testid)) return true;
      if (/plus|attach|upload|tools|open.?menu|model|switcher|search|web search|file|photo|image|dictat/.test(aria)) return true;
      if (/plus-button|attach|upload|composer-plus|open-menu|model-switcher/.test(testid + " " + id)) return true;
      return false;
    }
    function _composerHasText(ed) {
      if (!ed) return false;
      if (ed.tagName === "TEXTAREA" || ed instanceof HTMLTextAreaElement) {
        return String(ed.value || "").trim().length >= 1;
      }
      return String(ed.textContent || ed.innerText || "").trim().length >= 1;
    }
    function _findChatGptSendButton(editor = null) {
      const direct = document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]') || document.querySelector("button.composer-submit-btn");
      if (direct && !_isChatGptMenuOrNonSendButton(direct)) {
        console.log(
          "[ChatGPT] _findChatGptSendButton direct",
          direct.id || "",
          direct.getAttribute("data-testid") || "",
          "disabled=",
          !!direct.disabled,
          "aria=",
          (direct.getAttribute("aria-label") || "").slice(0, 40)
        );
        return direct;
      }
      const ed = editor || document.querySelector('#prompt-textarea[contenteditable="true"]') || document.querySelector('div.ProseMirror[contenteditable="true"]') || document.querySelector("#prompt-textarea") || document.querySelector('[data-testid="prompt-textarea"]') || document.querySelector('textarea[name="prompt-textarea"]');
      const form = ed?.closest?.("form") || document.querySelector('form[data-type="unified-composer"]') || document.querySelector("form.group\\/composer") || document.querySelector("form:has(#prompt-textarea)") || document.querySelector('form:has(textarea[name="prompt-textarea"])') || document.querySelector('form:has([contenteditable="true"])');
      const scope = form || document.body;
      const excludeRe = /voice|mic|dictat|speech|microphone|thoại|đọc chính tả|chế độ thoại|ghi âm|stop|dừng|cancel|hủy|attach|upload|photo|image|file|search|menu|plus|tools|model|switch/i;
      const preferRe = /send|gửi|submit|prompt/i;
      const hasText = _composerHasText(ed);
      const candidates = Array.from(scope.querySelectorAll('button, [role="button"]'));
      let best = null;
      let bestScore = -1;
      let edRect = null;
      try {
        edRect = ed?.getBoundingClientRect?.() || null;
      } catch (_) {
      }
      for (const btn of candidates) {
        if (_isChatGptMenuOrNonSendButton(btn)) continue;
        const aria = (btn.getAttribute("aria-label") || btn.getAttribute("title") || "").trim();
        const testid = (btn.getAttribute("data-testid") || "").trim();
        const name = (btn.getAttribute("name") || "").trim();
        const type = (btn.getAttribute("type") || "").trim();
        const cls = String(btn.className || "");
        const style = String(btn.getAttribute("style") || "");
        const txt = (btn.textContent || "").replace(/\s+/g, " ").trim().slice(0, 40);
        const blob = `${aria} ${testid} ${name} ${txt} ${cls} ${style}`.toLowerCase();
        if (excludeRe.test(blob)) continue;
        if (/speech|voice|mic/.test(style) || /speech|voice/.test(cls)) continue;
        let score = 0;
        if (btn.id === "composer-submit-button") score += 120;
        if (/send-button|composer-send|fruitjuice-send/i.test(testid)) score += 100;
        if (/composer-submit/i.test(cls) || /composer-submit/i.test(btn.id || "")) score += 90;
        if (preferRe.test(aria) && !/thoại|voice|mic/.test(aria.toLowerCase())) score += 80;
        if (type === "submit") score += 40;
        if (type === "button") score += 8;
        if (form && form.contains(btn)) score += 30;
        if (!testid && txt.length === 0 && hasText) score += 40;
        if (!aria && !testid && txt.length === 0 && hasText) score += 15;
        if (/^gửi$|^send$/i.test(aria) || /send prompt|send message|gửi tin|gửi lời nhắc/i.test(aria)) score += 50;
        const svg = btn.querySelector("svg");
        if (svg) {
          score += 15;
          const pathD = Array.from(svg.querySelectorAll("path")).map((p) => p.getAttribute("d") || "").join(" ");
          const useHref = svg.querySelector("use")?.getAttribute("href") || svg.querySelector("use")?.getAttribute("xlink:href") || "";
          if (/M\.5 1\.163|arrow|M12 5v14|M5 12h14|m12 4|polyline/i.test(pathD)) score += 30;
          else if (pathD.length > 15) score += 10;
          if (useHref) score += 5;
        }
        try {
          const r = btn.getBoundingClientRect();
          if (r.width < 8 || r.height < 8) continue;
          if (r.width > 80 && r.height > 80) score -= 20;
          if (edRect) {
            const midY = r.top + r.height / 2;
            if (midY >= edRect.top - 40 && midY <= edRect.bottom + 40) score += 25;
            if (r.left >= edRect.right - 30) score += 25;
            score += Math.min(15, Math.round(r.right / (window.innerWidth || 1) * 15));
          } else if (r.bottom > window.innerHeight * 0.55 && r.left > window.innerWidth * 0.45) {
            score += 12;
          }
          if (!btn.disabled) score += 8;
          if (hasText && r.left > (window.innerWidth || 0) * 0.7) score += 10;
        } catch (_) {
          continue;
        }
        if (score > bestScore) {
          bestScore = score;
          best = btn;
        }
      }
      if (form && ed && hasText && (!best || bestScore < 45)) {
        const iconBtns = candidates.filter((btn) => {
          if (_isChatGptMenuOrNonSendButton(btn)) return false;
          const aria = (btn.getAttribute("aria-label") || "").toLowerCase();
          if (excludeRe.test(`${btn.className} ${aria}`)) return false;
          try {
            const r = btn.getBoundingClientRect();
            return r.width >= 8 && r.height >= 8 && !!btn.querySelector("svg") && !btn.disabled;
          } catch (_) {
            return false;
          }
        }).sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
        if (iconBtns[0]) {
          best = iconBtns[0];
          bestScore = Math.max(bestScore, 55);
          console.log("[ChatGPT] _findChatGptSendButton fast-path rightmost non-speech SVG (hasText)");
        }
      }
      if (best && _isChatGptMenuOrNonSendButton(best)) {
        console.warn("[ChatGPT] _findChatGptSendButton: reject menu/speech button", best.id || "", best.getAttribute("data-testid") || "");
        return null;
      }
      if (best && hasText) {
        console.log(
          "[ChatGPT] _findChatGptSendButton score=",
          bestScore,
          "disabled=",
          !!best.disabled,
          "aria=",
          (best.getAttribute("aria-label") || "").slice(0, 50) || "(none)",
          "testid=",
          best.getAttribute("data-testid") || "(none)"
        );
      } else if (!best && hasText) {
        console.warn("[ChatGPT] _findChatGptSendButton: c\xF3 text nh\u01B0ng kh\xF4ng th\u1EA5y Send (DOM l\u1EA1)");
      }
      return best;
    }
    function _findChatGptComposer() {
      const isUsable = (el) => {
        if (!el || !el.isConnected) return false;
        try {
          const r = el.getBoundingClientRect();
          if (r.width < 20) return false;
          const style = window.getComputedStyle(el);
          if (style.visibility === "hidden" || style.display === "none") return false;
          return true;
        } catch (_) {
          return true;
        }
      };
      const pmCandidates = [
        document.querySelector('#prompt-textarea[contenteditable="true"]'),
        document.querySelector("div#prompt-textarea"),
        document.querySelector('[data-testid="prompt-textarea"][contenteditable="true"]'),
        document.querySelector('div.ProseMirror[contenteditable="true"]'),
        document.querySelector('.ProseMirror[contenteditable="true"]'),
        document.querySelector('.wcDTda_prosemirror-parent [contenteditable="true"]'),
        document.querySelector("#prompt-textarea"),
        document.querySelector('[data-testid="prompt-textarea"]')
      ].filter(Boolean);
      for (const el of pmCandidates) {
        if (el.tagName === "TEXTAREA") continue;
        if (isUsable(el) || el.getAttribute?.("contenteditable") === "true") {
          console.log("[ChatGPT] _findChatGptComposer \u2192 ProseMirror/contenteditable", el.tagName, el.id || "", el.className?.toString?.().slice?.(0, 40) || "");
          return el;
        }
      }
      const byName = document.querySelector('textarea[name="prompt-textarea"]') || document.querySelector("textarea.wcDTda_fallbackTextarea") || document.querySelector('form[data-type="unified-composer"] textarea');
      if (byName && isUsable(byName)) {
        console.warn("[ChatGPT] _findChatGptComposer \u2192 fallback TEXTAREA (ProseMirror ch\u01B0a c\xF3) \u2014 submit c\xF3 th\u1EC3 k\xE9m \u1ED5n \u0111\u1ECBnh");
        return byName;
      }
      let ed = null;
      try {
        const config = _getDynamicSelector("composer");
        const sels = [
          ...config?.selectors || [],
          ..._bootstrapSelectors("composer")
        ];
        for (const s of sels) {
          try {
            const el = document.querySelector(s);
            if (!el || !isUsable(el)) continue;
            if (el.tagName === "TEXTAREA") {
              const form2 = el.closest("form");
              const pm = form2?.querySelector?.('[contenteditable="true"]');
              if (pm && isUsable(pm)) {
                ed = pm;
                break;
              }
            }
            ed = el;
            break;
          } catch (_) {
          }
        }
      } catch (_) {
      }
      if (ed) return ed;
      const form = document.querySelector('form[data-type="unified-composer"]') || document.querySelector("form");
      const scope = form || document.body;
      const cands = Array.from(scope.querySelectorAll(
        '[contenteditable="true"], textarea[name="prompt-textarea"], [role="textbox"]'
      ));
      let best = null;
      let bestScore = -1;
      for (const el of cands) {
        let score = 0;
        const id = el.id || "";
        const testid = el.getAttribute("data-testid") || "";
        if (/prompt-textarea/i.test(id) || /prompt-textarea/i.test(testid)) score += 80;
        if (el.getAttribute("contenteditable") === "true") score += 40;
        if (el.tagName === "TEXTAREA") score -= 25;
        if (el.classList?.contains?.("wcDTda_fallbackTextarea")) score -= 40;
        if (el.closest("form")) score += 15;
        try {
          const r = el.getBoundingClientRect();
          if (r.width < 40 || r.height < 10) continue;
          if (r.bottom > window.innerHeight * 0.5) score += 10;
        } catch (_) {
          continue;
        }
        if (score > bestScore) {
          bestScore = score;
          best = el;
        }
      }
      if (best) console.log("[ChatGPT] _findChatGptComposer heuristic score=", bestScore, best.tagName);
      return best;
    }
    function _probeChatGptComposerControls() {
      const editor = _findChatGptComposer();
      const send = _findChatGptSendButton(editor);
      const report = {
        url: location.href,
        editor: editor ? {
          tag: editor.tagName,
          id: editor.id,
          name: editor.getAttribute?.("name"),
          testid: editor.getAttribute("data-testid"),
          contenteditable: editor.getAttribute("contenteditable"),
          class: String(editor.className || "").slice(0, 60),
          textLen: (editor.tagName === "TEXTAREA" ? editor.value || "" : editor.textContent || "").trim().length
        } : null,
        send: send ? {
          tag: send.tagName,
          id: send.id,
          disabled: !!send.disabled,
          aria: send.getAttribute("aria-label"),
          testid: send.getAttribute("data-testid"),
          type: send.getAttribute("type")
        } : null,
        composerSubmitExists: !!document.querySelector("#composer-submit-button"),
        proseMirrorExists: !!document.querySelector('#prompt-textarea[contenteditable="true"], div.ProseMirror[contenteditable="true"]')
      };
      console.log("%c[TobyFlow probe ChatGPT]", "color:#0f0;font-weight:bold", report);
      if (send) {
        try {
          send.style.outline = "3px solid lime";
        } catch (_) {
        }
      }
      if (editor) {
        try {
          editor.style.outline = "3px solid cyan";
        } catch (_) {
        }
      }
      return report;
    }
    function _probeChatGptImages() {
      const root = document.querySelector("main") || document.body;
      const all = Array.from(root.querySelectorAll("img"));
      const rows = [];
      for (const img of all) {
        let r = { w: 0, h: 0 };
        try {
          r = img.getBoundingClientRect();
        } catch (_) {
        }
        if (r.width < 40 && r.height < 40) continue;
        const src = img.currentSrc || img.src || "";
        const srcset = img.getAttribute("srcset") || "";
        const alt = img.getAttribute("alt") || "";
        const natural = { w: img.naturalWidth || 0, h: img.naturalHeight || 0 };
        const fileId = (src.match(/[?&]id=(file_[a-zA-Z0-9]+)/i) || [])[1] || (src.match(/\/(file_[a-zA-Z0-9]+)\b/i) || [])[1] || null;
        const host = (() => {
          try {
            return new URL(src, location.href).host;
          } catch (_) {
            return "";
          }
        })();
        const parentTestid = img.closest("[data-testid]")?.getAttribute("data-testid") || null;
        const turn = img.closest('[data-testid^="conversation-turn-"], [data-turn-id], article, [data-message-author-role]');
        const turnInfo = turn ? {
          tag: turn.tagName,
          testid: turn.getAttribute("data-testid"),
          turnId: turn.getAttribute("data-turn-id") || turn.dataset?.turnId,
          role: turn.getAttribute("data-message-author-role") || turn.querySelector?.("[data-message-author-role]")?.getAttribute("data-message-author-role")
        } : null;
        rows.push({
          display: `${Math.round(r.width)}x${Math.round(r.height)}`,
          natural: `${natural.w}x${natural.h}`,
          alt: alt.slice(0, 120),
          host,
          fileId,
          src: src.slice(0, 300),
          srcFull: src,
          srcset: srcset.slice(0, 200),
          className: String(img.className || "").slice(0, 80),
          parentTestid,
          turn: turnInfo,
          // Match probes — extension đang dùng gì
          match: {
            altGenerated: /^generated image/i.test(alt),
            oaiusercontent: /oaiusercontent/i.test(src),
            estuary: /estuary/i.test(src),
            openai: /openai\.com/i.test(src),
            backendApi: /backend-api/i.test(src),
            blob: /^blob:/i.test(src)
          }
        });
      }
      rows.sort((a, b) => {
        const area = (s) => {
          const [w, h] = String(s.display).split("x").map(Number);
          return (w || 0) * (h || 0);
        };
        return area(b) - area(a);
      });
      const turns = document.querySelectorAll(
        '[data-testid^="conversation-turn-"], [data-turn-id], main article, [data-message-author-role]'
      );
      const report = {
        url: location.href,
        pathname: location.pathname,
        turnCandidates: turns.length,
        imageCandidates: rows.length,
        images: rows,
        // Ảnh "có vẻ gen" — size lớn hoặc alt Generated
        likelyGen: rows.filter((x) => {
          const [w, h] = String(x.display).split("x").map(Number);
          return w >= 120 && h >= 120 || x.match.altGenerated || x.fileId;
        }),
        // CSS selector gợi ý từ host/alt thật
        suggestedSelectors: [...new Set(rows.flatMap((x) => {
          const s = [];
          if (x.match.altGenerated) s.push('img[alt^="Generated image"]');
          if (x.host) s.push(`img[src*="${x.host}"]`);
          if (x.fileId) s.push(`img[src*="${x.fileId}"]`);
          if (x.match.oaiusercontent) s.push('img[src*="oaiusercontent.com"]');
          if (x.match.estuary) s.push('img[src*="estuary"]');
          return s;
        }))]
      };
      console.log("%c[TobyFlow probe ChatGPT IMAGES]", "color:#0f0;font-weight:bold;font-size:14px", report);
      if (report.likelyGen[0]) {
        console.log("%c\u2192 \u1EA2nh gen ch\xEDnh (l\u1EDBn nh\u1EA5t):", "color:#0ff;font-weight:bold", report.likelyGen[0].srcFull);
        console.log("%c\u2192 Copy URL:", "color:#0ff", report.likelyGen[0].srcFull);
        try {
          const el = all.find((img) => (img.currentSrc || img.src) === report.likelyGen[0].srcFull);
          if (el) el.style.outline = "3px solid lime";
        } catch (_) {
        }
      } else {
        console.warn("[TobyFlow] Kh\xF4ng th\u1EA5y img l\u1EDBn trong main \u2014 th\u1EED scroll xu\u1ED1ng \u1EA3nh, ho\u1EB7c inspect th\u1EE7 c\xF4ng.");
      }
      console.table(rows.map((x) => ({
        size: x.display,
        alt: x.alt.slice(0, 40),
        host: x.host,
        fileId: x.fileId || "",
        src: x.src.slice(0, 80)
      })));
      return report;
    }
    try {
      window.__tobyProbeChatGptButtons = _probeChatGptComposerControls;
      window.__tobyFindChatGptSend = _findChatGptSendButton;
      window.__tobyFindChatGptComposer = _findChatGptComposer;
      window.__tobyProbeChatGptImages = _probeChatGptImages;
    } catch (_) {
    }
    function _queryAllWithFallback(key, defaultSelectors = null, scope = null) {
      const config = _getDynamicSelector(key);
      const hardcoded = defaultSelectors || [];
      const selectors = config?.selectors?.length > 0 ? config.selectors : hardcoded;
      const root = scope || document;
      for (let i = 0; i < selectors.length; i++) {
        try {
          const els = root.querySelectorAll(selectors[i]);
          if (els.length > 0) return els;
        } catch (e) {
        }
      }
      return [];
    }
    function _getSelectorsForKey(key) {
      const config = _getDynamicSelector(key);
      const bootstrap = _bootstrapSelectors(key);
      const isDynamic = config?.selectors?.length > 0;
      const selectors = isDynamic ? [...config.selectors, ...bootstrap.filter((s) => !config.selectors.includes(s))] : bootstrap.slice();
      if (!_getSelectorsForKey._logged) _getSelectorsForKey._logged = {};
      const sig = `${key}:${selectors.length}`;
      if (_getSelectorsForKey._logged[key] !== sig) {
        _getSelectorsForKey._logged[key] = sig;
        console.log(
          `[Selector:${PROVIDER}:${key}] ${isDynamic ? "\u{1F310} DYNAMIC+bootstrap" : "\u{1F4E6} BOOTSTRAP"} | ${selectors.length} selectors`
        );
      }
      return selectors;
    }
    function _hasGeneratingIndicator(el = document) {
      const selectors = _getSelectorsForKey("generating_indicator");
      for (const sel of selectors) {
        try {
          if (el.querySelector(sel)) return true;
        } catch (e) {
        }
      }
      return false;
    }
    const _CDN_HARD_FALLBACK = 'img[src*="backend-api/estuary"], img[src*="/estuary/content"], img[src*="estuary"], img[alt^="Generated image"], img[alt*="Generated image"], img[src*="oaiusercontent"], img[src*="files.oaiusercontent"], img[src*="/backend-api/"], main img[src^="https://"]';
    function _queryCdnImages(scope = document) {
      const selectors = _getSelectorsForKey("cdn_image");
      const results = [];
      const seen = /* @__PURE__ */ new Set();
      const pushAll = (list) => {
        for (const img of list) {
          if (!img || seen.has(img)) continue;
          seen.add(img);
          results.push(img);
        }
      };
      if (selectors.length > 0) {
        try {
          pushAll(scope.querySelectorAll(selectors.join(", ")));
        } catch (e) {
          for (const sel of selectors) {
            try {
              pushAll(scope.querySelectorAll(sel));
            } catch (_) {
            }
          }
        }
      }
      try {
        pushAll((scope || document).querySelectorAll(_CDN_HARD_FALLBACK));
      } catch (_) {
      }
      return results;
    }
    function _imageKeyFromSrc(src) {
      if (!src || typeof src !== "string") return "";
      const m = src.match(/[?&]id=(file_[a-zA-Z0-9]+)/i) || src.match(/\/(file_[a-zA-Z0-9]+)\b/i) || src.match(/file[_-]([a-zA-Z0-9]{8,})/i);
      if (m) return (m[1].startsWith("file_") ? m[1] : `file_${m[1]}`).toLowerCase();
      try {
        const u = new URL(src, location.href);
        return `${u.origin}${u.pathname}`.toLowerCase();
      } catch (_) {
        return src.split("?")[0].toLowerCase();
      }
    }
    function _isLikelyGeneratedImg(img) {
      if (!img || img.classList?.contains?.("blur-2xl")) return false;
      const src = img.currentSrc || img.src || "";
      if (!src || src.startsWith("data:")) return false;
      const alt = (img.getAttribute("alt") || "").trim();
      const altL = alt.toLowerCase();
      if (altL.startsWith("generated image") || altL.startsWith("image created")) return true;
      const isEstuaryCdn = /estuary|backend-api\/estuary|oaiusercontent|files\.oaiusercontent|backend-api|openai\.com|chatgpt\.com\/backend-api/i.test(src);
      if (alt === "" && isEstuaryCdn) return true;
      try {
        const r = img.getBoundingClientRect();
        if (r.width >= 100 && r.height >= 100 && isEstuaryCdn) return true;
      } catch (_) {
      }
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(alt)) return false;
      return false;
    }
    function _isRefUploading() {
      return !!_queryWithFallback("ref_upload_pending", null, { silent: true });
    }
    let __chatgptInputTimeoutMs = 1200;
    let __chatgptMacroDelayMs = Math.round(1200 * 0.7);
    function getMacroDelay() {
      return __chatgptMacroDelayMs;
    }
    function checkAbort(stage) {
      if (isAbortActive()) {
        console.log("[ChatGPT-abort] Aborted at stage:", stage);
        throw new Error("ABORTED:" + stage);
      }
    }
    async function clickChatGPTStopButton() {
      const stopBtn = _queryWithFallback("stop_button");
      if (stopBtn && !stopBtn.disabled) {
        console.log("[ChatGPT-abort] Clicking ChatGPT Stop button to halt backend gen");
        try {
          stopBtn.click();
        } catch (e) {
        }
        try {
          simulateClick(stopBtn);
        } catch (e) {
        }
        await sleep(300);
        return true;
      }
      console.log("[ChatGPT-abort] Stop button not found or disabled");
      return false;
    }
    async function deleteLastAssistantMessage(turnEl = null) {
      try {
        const headerSelectors = _getSelectorsForKey("conversation_options_button");
        let optionsBtn = null;
        for (const sel of headerSelectors) {
          optionsBtn = document.querySelector(sel);
          if (optionsBtn) break;
        }
        if (!optionsBtn) {
          console.warn("[ChatGPT-delete] Kh\xF4ng t\xECm th\u1EA5y n\xFAt conversation options trong header");
          return false;
        }
        console.log("[ChatGPT-delete] Clicking conversation options button...");
        simulateClick(optionsBtn);
        await sleep(500);
        let openMenu = null;
        const menuTimeout = Date.now() + 3e3;
        while (Date.now() < menuTimeout) {
          openMenu = _queryWithFallback("open_menu", null, { silent: true });
          if (openMenu) break;
          await sleep(200);
        }
        if (!openMenu) {
          console.warn("[ChatGPT-delete] Menu kh\xF4ng m\u1EDF");
          return false;
        }
        let deleteMenuItem = _queryWithFallback("delete_chat_menu_item", null, { scope: openMenu, silent: true });
        if (!deleteMenuItem) {
          const menuItems = _queryAllWithFallback("menu_items", null, openMenu);
          for (const item of menuItems) {
            const text = item.textContent?.trim().toLowerCase();
            if (text === "delete" || text === "x\xF3a" || text.includes("delete")) {
              deleteMenuItem = item;
              break;
            }
          }
        }
        if (!deleteMenuItem) {
          console.warn('[ChatGPT-delete] Kh\xF4ng t\xECm th\u1EA5y menu item "Delete"');
          document.body.click();
          return false;
        }
        console.log('[ChatGPT-delete] Clicking "Delete" menu item...');
        simulateClick(deleteMenuItem);
        await sleep(500);
        const confirmTimeout = Date.now() + 3e3;
        const confirmSelectors = _getSelectorsForKey("delete_confirm_button");
        let confirmBtn = null;
        while (Date.now() < confirmTimeout) {
          const dialog = _queryWithFallback("challenge_overlay", null, { silent: true });
          if (dialog) {
            for (const sel of confirmSelectors) {
              try {
                confirmBtn = dialog.querySelector(sel);
                if (confirmBtn) break;
              } catch (_) {
              }
            }
            if (!confirmBtn) {
              const buttons = dialog.querySelectorAll("button");
              for (const btn of buttons) {
                const text = btn.textContent?.trim().toLowerCase();
                if (text === "delete" || text === "x\xF3a") {
                  confirmBtn = btn;
                  break;
                }
              }
            }
          }
          if (confirmBtn) break;
          await sleep(200);
        }
        if (!confirmBtn) {
          console.warn("[ChatGPT-delete] Kh\xF4ng t\xECm th\u1EA5y n\xFAt x\xE1c nh\u1EADn trong modal");
          document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          return false;
        }
        console.log("[ChatGPT-delete] Clicking confirm button...");
        simulateClick(confirmBtn);
        await sleep(500);
        console.log("[ChatGPT-delete] \u2705 \u0110\xE3 x\xF3a conversation th\xE0nh c\xF4ng");
        return true;
      } catch (err) {
        console.error("[ChatGPT-delete] L\u1ED7i khi x\xF3a conversation:", err);
        return false;
      }
    }
    function simulateClick(el) {
      if (!el || !(el instanceof Element)) {
        console.warn("[ChatGPT] simulateClick: invalid element type", el);
        return;
      }
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) {
        console.warn("[ChatGPT] simulateClick: element zero-size (hidden/detached), skip", el);
        return;
      }
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 };
      el.dispatchEvent(new PointerEvent("pointerdown", opts));
      el.dispatchEvent(new MouseEvent("mousedown", opts));
      el.dispatchEvent(new PointerEvent("pointerup", opts));
      el.dispatchEvent(new MouseEvent("mouseup", opts));
      el.dispatchEvent(new MouseEvent("click", opts));
    }
    async function waitForElement(selector, timeout = 1e4) {
      const start = Date.now();
      while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el) return el;
        await sleep(300);
      }
      return null;
    }
    const FloatingTracker = typeof window.createFloatingTrackerRich === "function" ? window.createFloatingTrackerRich({ id: "tobyflow-chatgpt-tracker", title: "ChatGPT" }) : {
      // Fallback nếu helper chưa load (KHÔNG nên xảy ra vì manifest inject trước) — no-op stub.
      _el: null,
      show() {
      },
      update() {
      },
      hide() {
      },
      updateFromQueue() {
      }
    };
    let _ftRichActive = false;
    if (FloatingTracker && typeof FloatingTracker.show === "function" && typeof window.createFloatingTrackerRich === "function") {
      const _s = FloatingTracker.show.bind(FloatingTracker);
      const _u = FloatingTracker.update.bind(FloatingTracker);
      const _h = FloatingTracker.hide.bind(FloatingTracker);
      FloatingTracker.show = (a) => {
        if (!_ftRichActive) _s(a);
      };
      FloatingTracker.update = (a) => {
        if (!_ftRichActive) _u(a);
      };
      FloatingTracker.hide = () => {
        if (!_ftRichActive) _h();
      };
    }
    const ExecutionBlocker = {
      _el: null,
      _styleEl: null,
      _blocking: false,
      _escapeCount: 0,
      _escapeTimer: null,
      _timeoutId: null,
      _MAX_BLOCK_TIME: 7 * 60 * 1e3,
      // 7 phút — cao hơn detection timeout+grace (gen ảnh chậm) để overlay không tự ẩn giữa chừng
      _injectStyles() {
        if (this._styleEl) return;
        const style = document.createElement("style");
        style.id = "tobyflow-chatgpt-blocker-styles";
        style.textContent = `
        @keyframes tobyflow-glow-pulse {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 0.7; }
        }
        #tobyflow-chatgpt-blocker {
          position: fixed; inset: 0; z-index: 2147483646;
          pointer-events: all; cursor: not-allowed; background: transparent;
        }
        #tobyflow-chatgpt-blocker::before {
          content: ''; position: absolute; inset: 0;
          border: 5px solid #cdff01;
          box-shadow:
            inset 0 0 0 2px rgba(205,255,1,0.5),
            inset 0 0 15px rgba(205,255,1,0.3),
            0 0 15px rgba(205,255,1,0.5),
            0 0 35px rgba(205,255,1,0.35),
            0 0 60px rgba(205,255,1,0.2),
            0 0 100px rgba(205,255,1,0.1);
          animation: tobyflow-glow-pulse 1.8s ease-in-out infinite;
          will-change: opacity;
          pointer-events: none;
        }
      `;
        document.head.appendChild(style);
        this._styleEl = style;
      },
      _blockEvent(e) {
        if (!ExecutionBlocker._blocking) return;
        if (!e.isTrusted) return;
        if (e.target?.closest?.("#tobyflow-chatgpt-tracker")) return;
        if (e.type === "keydown" && e.key === "Escape") {
          ExecutionBlocker._escapeCount++;
          clearTimeout(ExecutionBlocker._escapeTimer);
          ExecutionBlocker._escapeTimer = setTimeout(() => {
            ExecutionBlocker._escapeCount = 0;
          }, 2e3);
          if (ExecutionBlocker._escapeCount >= 3) {
            console.warn("[ChatGPT-ExecutionBlocker] Force hide via Escape x3");
            ExecutionBlocker._escapeCount = 0;
            ExecutionBlocker.hide();
            __chatgptAbort = true;
            __chatgptAbortAt = Date.now();
            return;
          }
        }
        e.stopPropagation();
        e.stopImmediatePropagation();
        e.preventDefault();
      },
      _attachBlockers() {
        if (this._blocking) return;
        this._blocking = true;
        const events = ["mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel", "touchstart", "touchend", "keydown", "keyup"];
        events.forEach((evt) => document.addEventListener(evt, this._blockEvent, { capture: true, passive: false }));
      },
      _detachBlockers() {
        if (!this._blocking) return;
        this._blocking = false;
        const events = ["mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel", "touchstart", "touchend", "keydown", "keyup"];
        events.forEach((evt) => document.removeEventListener(evt, this._blockEvent, { capture: true }));
      },
      show() {
        this._injectStyles();
        this._attachBlockers();
        this._startTimeout();
        if (this._el) {
          this._el.style.display = "block";
          return;
        }
        const el = document.createElement("div");
        el.id = "tobyflow-chatgpt-blocker";
        document.body.appendChild(el);
        this._el = el;
      },
      _startTimeout() {
        this._stopTimeout();
        this._timeoutId = setTimeout(() => {
          console.warn("[ChatGPT-ExecutionBlocker] Auto-timeout, force hiding (KH\xD4NG abort \u2014 detection t\u1EF1 x\u1EED l\xFD)");
          this.hide();
        }, this._MAX_BLOCK_TIME);
      },
      _stopTimeout() {
        if (this._timeoutId) {
          clearTimeout(this._timeoutId);
          this._timeoutId = null;
        }
      },
      hide() {
        this._detachBlockers();
        this._stopTimeout();
        this._escapeCount = 0;
        clearTimeout(this._escapeTimer);
        if (this._el) this._el.style.display = "none";
      }
    };
    async function removeExistingChatGPTRefImages() {
      const removeBtns = _queryAllWithFallback("remove_ref_image_button");
      let removedCount = 0;
      for (const btn of removeBtns) {
        const propsKey = Object.keys(btn).find((k) => k.startsWith("__reactProps$"));
        if (propsKey && btn[propsKey]?.onClick) {
          try {
            btn[propsKey].onClick({
              preventDefault: function() {
              },
              stopPropagation: function() {
              },
              nativeEvent: new MouseEvent("click", { bubbles: true }),
              type: "click",
              target: btn,
              currentTarget: btn
            });
          } catch (_) {
            simulateClick(btn);
          }
        } else {
          simulateClick(btn);
        }
        removedCount++;
        await sleep(250);
      }
      if (removedCount > 0) {
        console.log(`[ChatGPT] removeExistingRefImages: \u0111\xE3 x\xF3a ${removedCount} ref image(s) c\u0169`);
      }
      return removedCount;
    }
    function detectChatGPTChallenge() {
      if (_queryWithFallback("cloudflare_iframe", null, { silent: true })) return true;
      const overlays = _queryAllWithFallback("challenge_overlay", null, { silent: true });
      const selectorConfig = _getDynamicSelector("challenge_overlay") || {};
      const textMatches = selectorConfig.text_match || [];
      for (const el of overlays) {
        const txt = (el.innerText || "").toLowerCase();
        const matchesServerPattern = textMatches.some((pattern) => txt.includes(pattern.toLowerCase()));
        const matchesCloudflare = txt.includes("verifying") && txt.includes("cloudflare");
        if (matchesServerPattern || matchesCloudflare) {
          const style = window.getComputedStyle(el);
          if (style.display !== "none" && style.visibility !== "hidden") return true;
        }
      }
      return false;
    }
    async function waitForChatGPTChallengeResolved(timeoutMs = 12e4) {
      if (!detectChatGPTChallenge()) return true;
      console.warn("[ChatGPT] Challenge detected \u2014 request tab activate + ch\u1EDD user verify");
      try {
        await new Promise((resolve) => {
          chrome.runtime.sendMessage(
            { action: "chatgpt:ensureActive", focusWindow: true, reason: "challenge" },
            () => resolve()
          );
        });
      } catch (_) {
      }
      const start = Date.now();
      let lastLog = 0;
      while (Date.now() - start < timeoutMs) {
        if (isAbortActive()) {
          console.log("[ChatGPT] Challenge wait aborted by user");
          return false;
        }
        if (!detectChatGPTChallenge()) {
          console.log("[ChatGPT] Challenge resolved sau", Math.round((Date.now() - start) / 1e3), "s");
          await sleep(800);
          return true;
        }
        const elapsed = Date.now() - start;
        if (elapsed - lastLog >= 1e4) {
          console.log("[ChatGPT] V\u1EABn ch\u1EDD challenge resolved...", Math.round(elapsed / 1e3), "s");
          lastLog = elapsed;
        }
        await sleep(800);
      }
      console.error("[ChatGPT] Challenge timeout sau", timeoutMs / 1e3, "s");
      return false;
    }
    async function clickNewChatAndWaitReady(timeoutMs = 1e4) {
      const log = (...args) => console.log("[ChatGPT-newchat]", ...args);
      const isAtEmptyHome = () => {
        const path = window.location.pathname;
        if (path !== "/" && path !== "") return false;
        const _maCfg = _getDynamicSelector("message_author");
        const _maSelectors = _maCfg?.selectors || [];
        const messages = _maSelectors.length > 0 ? document.querySelectorAll(_maSelectors.join(", ")) : [];
        return messages.length === 0;
      };
      if (isAtEmptyHome()) {
        log("\u0110\xE3 \u1EDF homepage v\u1EDBi empty conversation \u2014 skip click (tier 0)");
        return true;
      }
      let newChatBtn = _queryWithFallback("new_chat_button");
      if (!newChatBtn) {
        const cfg = _getDynamicSelector("chat_history_home_link");
        const selectors = cfg?.selectors || [];
        if (selectors.length > 0) {
          newChatBtn = document.querySelector(selectors.join(", "));
          if (newChatBtn) log("Tier 2 fallback: home link via chat_history_home_link");
        }
      }
      if (!newChatBtn) {
        log('Tier 3 fallback: synthetic anchor click "/"');
        try {
          const a = document.createElement("a");
          a.href = "/";
          a.style.display = "none";
          document.body.appendChild(a);
          a.click();
          a.remove();
        } catch (e) {
          log("WARN: synthetic anchor navigate fail:", e.message);
          return false;
        }
        const dl3 = Date.now() + timeoutMs;
        while (Date.now() < dl3) {
          const path3 = window.location.pathname;
          if (path3 === "/" || path3 === "") {
            const editor3 = _queryWithFallback("composer");
            if (editor3 && editor3.getAttribute("aria-disabled") !== "true" && !editor3.closest('[aria-busy="true"]')) {
              log("Homepage ready (tier 3) sau", timeoutMs - (dl3 - Date.now()), "ms");
              await sleep(300);
              return true;
            }
          }
          await sleep(200);
        }
        log("WARN: Tier 3 timeout \u2014 kh\xF4ng v\u1EC1 \u0111\u01B0\u1EE3c homepage");
        return false;
      }
      if (isAtEmptyHome()) {
        log("Tier 1/2 found button NH\u01AFNG \u0111\xE3 \u1EDF empty home \u2014 skip click");
        return true;
      }
      log("Click New chat button...");
      simulateClick(newChatBtn);
      const startTime = Date.now();
      let editorReady = false;
      while (Date.now() - startTime < timeoutMs) {
        const path = window.location.pathname;
        if (path !== "/" && path !== "") {
          await sleep(200);
          continue;
        }
        const editor = _queryWithFallback("composer");
        if (editor) {
          const isDisabled = editor.getAttribute("aria-disabled") === "true" || editor.closest('[aria-busy="true"]');
          if (!isDisabled) {
            editorReady = true;
            break;
          }
        }
        await sleep(200);
      }
      if (editorReady) {
        log("New chat ready sau", Date.now() - startTime, "ms");
        await sleep(300);
        return true;
      }
      log("WARN: Editor kh\xF4ng ready sau", timeoutMs, "ms");
      return false;
    }
    async function waitProviderReady(timeoutMs = 12e3) {
      const dl = Date.now() + timeoutMs;
      while (Date.now() < dl) {
        if (document.readyState === "complete") {
          const composer = _queryWithFallback("composer", null, { silent: true });
          if (composer && composer.getAttribute("aria-disabled") !== "true" && !composer.closest('[aria-busy="true"]')) {
            await sleep(250);
            return true;
          }
        }
        await sleep(250);
      }
      return false;
    }
    async function deactivateImageModeIfActive() {
      const active = _queryWithFallback("image_mode_pill") || _queryWithFallback("ratio_button");
      if (!active) return false;
      console.log("[ChatGPT] Image mode \u0111ang active \u2014 deactivate tr\u01B0\u1EDBc khi submit text");
      const clickEl = (el) => {
        if (!el) return;
        try {
          simulateClick(el);
        } catch (_) {
        }
        const propsKey = Object.keys(el).find((k) => k.startsWith("__reactProps$"));
        const props = propsKey ? el[propsKey] : null;
        try {
          if (props && typeof props.onSelect === "function") {
            props.onSelect({ preventDefault() {
            }, stopPropagation() {
            } });
          } else if (props && typeof props.onClick === "function") {
            props.onClick({ preventDefault() {
            }, stopPropagation() {
            }, nativeEvent: new MouseEvent("click"), type: "click", target: el, currentTarget: el });
          }
        } catch (_) {
        }
      };
      try {
        const openMenu = _queryWithFallback("open_menu");
        if (openMenu) {
          document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          await sleep(80);
        }
      } catch (_) {
      }
      const plusBtn = _queryWithFallback("plus_button");
      if (!plusBtn) {
        console.warn("[ChatGPT] deactivateImageMode: composer plus button kh\xF4ng t\xECm th\u1EA5y");
        return false;
      }
      clickEl(plusBtn);
      let menu = null;
      for (let i = 0; i < 6; i++) {
        await sleep(80);
        menu = _queryWithFallback("open_menu", null, { silent: true });
        if (menu) break;
      }
      if (!menu) {
        console.warn("[ChatGPT] deactivateImageMode: menu kh\xF4ng render");
        return false;
      }
      const createImgPatterns = await _getCreateImagePatterns();
      const items = _queryAllWithFallback("menu_items", null, menu);
      for (const item of items) {
        const text = (item.innerText || "").trim().toLowerCase();
        if (_matchesCreateImage(text, createImgPatterns)) {
          const checked = item.getAttribute("aria-checked") === "true" || item.getAttribute("data-state") === "checked";
          if (checked) {
            clickEl(item);
            console.log("[ChatGPT] deactivateImageMode: \u0111\xE3 click toggle off");
          }
          break;
        }
      }
      await sleep(150);
      try {
        document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      } catch (_) {
      }
      await sleep(150);
      const stillActive = !!_queryWithFallback("image_mode_pill") || !!_queryWithFallback("ratio_button");
      return !stillActive;
    }
    async function _getChatGPTApiConfig(key) {
      try {
        const result = await new Promise((r) => chrome.storage.local.get(["toby_provider_api_configs"], r));
        return result?.toby_provider_api_configs?.data?.chatgpt?.configs?.[key] ?? null;
      } catch (_) {
        return null;
      }
    }
    async function _getCreateImagePatterns() {
      const cfg = await _getChatGPTApiConfig("ui_text_patterns");
      const raw = cfg?.create_image_menu_text || "create image|create an image";
      return raw.split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
    }
    function _matchesCreateImage(text, patterns) {
      const t = (text || "").trim().toLowerCase();
      return (patterns || []).some((p) => t === p || t.startsWith(p));
    }
    async function selectChatGPTModel(modelValue) {
      if (!modelValue) return false;
      const labelCfg = await _getChatGPTApiConfig("chatgpt_model_labels");
      const rawLabels = labelCfg?.[modelValue] ?? modelValue;
      const targetTexts = String(rawLabels).split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
      if (targetTexts.length === 0) return false;
      const clickEl = (el) => {
        if (!el) return;
        try {
          simulateClick(el);
        } catch (_) {
        }
        const propsKey = Object.keys(el).find((k) => k.startsWith("__reactProps$"));
        const props = propsKey ? el[propsKey] : null;
        try {
          if (props && typeof props.onSelect === "function") {
            props.onSelect({ preventDefault() {
            }, stopPropagation() {
            } });
          } else if (props && typeof props.onClick === "function") {
            props.onClick({ preventDefault() {
            }, stopPropagation() {
            }, nativeEvent: new MouseEvent("click"), type: "click", target: el, currentTarget: el });
          }
        } catch (_) {
        }
      };
      const closeMenu = () => {
        try {
          document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        } catch (_) {
        }
      };
      const switcherBtn = _queryWithFallback("model_switcher_button", null, { silent: true });
      if (!switcherBtn) {
        console.warn("[ChatGPT] selectChatGPTModel: model_switcher_button kh\xF4ng th\u1EA5y");
        return false;
      }
      const curText = (switcherBtn.innerText || switcherBtn.textContent || "").trim().toLowerCase();
      if (targetTexts.some((t) => curText === t || curText.includes(t))) {
        console.log(`[ChatGPT] selectChatGPTModel: "${modelValue}" \u0111\xE3 active`);
        return true;
      }
      clickEl(switcherBtn);
      let items = [];
      for (let i = 0; i < 10; i++) {
        await sleep(100);
        items = Array.from(_queryAllWithFallback("mode_menu_item"));
        if (items.length > 0) break;
      }
      if (items.length === 0) {
        console.warn("[ChatGPT] selectChatGPTModel: menu model kh\xF4ng render");
        closeMenu();
        return false;
      }
      for (const item of items) {
        const txt = (item.innerText || item.textContent || "").trim().toLowerCase();
        if (targetTexts.some((t) => txt === t || txt.includes(t))) {
          clickEl(item);
          console.log(`[ChatGPT] selectChatGPTModel: clicked "${(item.innerText || "").trim()}" cho "${modelValue}"`);
          await sleep(200);
          closeMenu();
          return true;
        }
      }
      console.warn(`[ChatGPT] selectChatGPTModel: KH\xD4NG match "${modelValue}". Items: [${items.map((i) => (i.innerText || "").trim()).join(" | ")}]`);
      closeMenu();
      return false;
    }
    function ratioToPromptSuffix(ratio) {
      const map = {
        story: "9:16 (portrait)",
        "9:16": "9:16 (portrait)",
        portrait: "3:4 (portrait)",
        "3:4": "3:4 (portrait)",
        square: "1:1 (square)",
        "1:1": "1:1 (square)",
        landscape: "4:3 (landscape)",
        "4:3": "4:3 (landscape)",
        widescreen: "16:9 (widescreen)",
        "16:9": "16:9 (widescreen)"
      };
      const label = map[ratio];
      return label ? `

Generate the image in ${label} aspect ratio.` : "";
    }
    async function activateImageMode(ratio = "1:1") {
      const ratioBtn = _queryWithFallback("ratio_button");
      const modeActive = !!_queryWithFallback("image_mode_pill") || !!ratioBtn;
      let modeToggled = modeActive;
      const clickEl = (el) => {
        if (!el) return;
        try {
          simulateClick(el);
        } catch (_) {
        }
        const propsKey = Object.keys(el).find((k) => k.startsWith("__reactProps$"));
        const props = propsKey ? el[propsKey] : null;
        try {
          if (props && typeof props.onSelect === "function") {
            props.onSelect({ preventDefault() {
            }, stopPropagation() {
            } });
          } else if (props && typeof props.onClick === "function") {
            props.onClick({ preventDefault() {
            }, stopPropagation() {
            }, nativeEvent: new MouseEvent("click"), type: "click", target: el, currentTarget: el });
          }
        } catch (_) {
        }
      };
      if (!modeActive) {
        console.log("[ChatGPT] Image mode ch\u01B0a active \u2014 \u0111ang activate...");
        try {
          const openMenu = _queryWithFallback("open_menu");
          if (openMenu) {
            document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
            await sleep(80);
          }
        } catch (_) {
        }
        const plusBtn = _queryWithFallback("plus_button");
        if (!plusBtn) {
          console.warn("[ChatGPT] activateImageMode: composer plus button kh\xF4ng t\xECm th\u1EA5y");
          return false;
        }
        clickEl(plusBtn);
        let menu = null;
        for (let i = 0; i < 10; i++) {
          await sleep(80);
          menu = _queryWithFallback("open_menu", null, { silent: true });
          if (menu) break;
        }
        if (!menu) {
          console.warn('[ChatGPT] activateImageMode: open_menu kh\xF4ng match \u2014 fallback qu\xE9t to\xE0n document t\xECm "Create image"');
          menu = document;
        }
        const createImgPatterns = await _getCreateImagePatterns();
        const items = _queryAllWithFallback("menu_items", null, menu);
        let found = false;
        for (const item of items) {
          const text = (item.innerText || "").trim().toLowerCase();
          if (_matchesCreateImage(text, createImgPatterns)) {
            const checked = item.getAttribute("aria-checked") === "true" || item.getAttribute("data-state") === "checked";
            if (!checked) {
              clickEl(item);
              console.log('[ChatGPT] activateImageMode: \u0111\xE3 click toggle on "Create image"');
            }
            found = true;
            modeToggled = true;
            break;
          }
        }
        if (!found) {
          console.warn('[ChatGPT] activateImageMode: kh\xF4ng t\xECm th\u1EA5y "Create image" item');
          try {
            document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          } catch (_) {
          }
          return false;
        }
        let newRatioBtn = null;
        for (let i = 0; i < 8; i++) {
          await sleep(100);
          newRatioBtn = _queryWithFallback("ratio_button", null, { silent: true });
          if (newRatioBtn || _queryWithFallback("image_mode_pill", null, { silent: true })) break;
        }
        if (!newRatioBtn) {
          console.log("[ChatGPT] activateImageMode: kh\xF4ng c\xF3 ratio button (UI m\u1EDBi) \u2014 b\u1ECF qua ch\u1ECDn ratio, ratio \u0111i qua prompt");
        }
        await sleep(getMacroDelay());
      }
      let ratioSelected = false;
      const _ratioBtnNow = _queryWithFallback("ratio_button", null, { silent: true });
      if (ratio && _ratioBtnNow) {
        let newRatioBtn = null;
        for (let i = 0; i < 5; i++) {
          newRatioBtn = _queryWithFallback("ratio_button", null, { silent: i > 0 });
          if (newRatioBtn) break;
          await sleep(100);
        }
        if (newRatioBtn) {
          const RATIO_ARIA_MAP = {
            story: "Story 9:16",
            portrait: "Portrait 3:4",
            square: "Square 1:1",
            landscape: "Landscape 4:3",
            widescreen: "Widescreen 16:9",
            "9:16": "Story 9:16",
            "3:4": "Portrait 3:4",
            "1:1": "Square 1:1",
            "4:3": "Landscape 4:3",
            "16:9": "Widescreen 16:9"
          };
          const targetAriaLabel = RATIO_ARIA_MAP[ratio] || null;
          await sleep(300);
          clickEl(newRatioBtn);
          console.log("[ChatGPT] activateImageMode: \u0111\xE3 click ratio button, waiting for dropdown...");
          let ratioMenu = null;
          for (let i = 0; i < 10; i++) {
            await sleep(120);
            ratioMenu = _queryWithFallback("open_menu", null, { silent: true });
            if (!ratioMenu) {
              ratioMenu = document.querySelector('[role="listbox"]');
            }
            if (ratioMenu) break;
          }
          let ratioItems = [];
          if (ratioMenu) {
            console.log("[ChatGPT] activateImageMode: dropdown found, tagName:", ratioMenu.tagName, "role:", ratioMenu.getAttribute("role"));
            ratioItems = _queryAllWithFallback("menu_items", null, ratioMenu);
            if (ratioItems.length === 0) {
              ratioItems = ratioMenu.querySelectorAll('[role="option"], [role="menuitemradio"], [role="menuitem"]');
            }
            console.log("[ChatGPT] activateImageMode: found", ratioItems.length, "items in dropdown");
            if (ratioItems.length > 0) {
              const labels = Array.from(ratioItems).map((it) => it.getAttribute("aria-label") || it.innerText?.substring(0, 30)).join(", ");
              console.log("[ChatGPT] activateImageMode: item labels:", labels);
            }
          } else {
            console.log("[ChatGPT] activateImageMode: dropdown NOT found after retries");
          }
          if (ratioItems.length === 0 && targetAriaLabel) {
            const directMatch = document.querySelector(`[aria-label="${targetAriaLabel}"]`);
            if (directMatch) {
              ratioItems = [directMatch];
              console.log("[ChatGPT] activateImageMode: found ratio via direct aria-label query");
            } else {
              console.log("[ChatGPT] activateImageMode: direct aria-label query failed for:", targetAriaLabel);
            }
          }
          let found = false;
          for (const item of ratioItems) {
            if (targetAriaLabel && item.getAttribute("aria-label") === targetAriaLabel) {
              clickEl(item);
              console.log("[ChatGPT] activateImageMode: \u0111\xE3 ch\u1ECDn ratio via aria-label", ratio, targetAriaLabel);
              found = true;
              break;
            }
          }
          if (!found) {
            const ratioLower = ratio.toLowerCase();
            for (const item of ratioItems) {
              const text = (item.innerText || "").trim().toLowerCase();
              if (text === ratioLower || text.includes(ratioLower) || text.includes(ratio)) {
                clickEl(item);
                console.log("[ChatGPT] activateImageMode: \u0111\xE3 ch\u1ECDn ratio via text fallback", ratio);
                found = true;
                break;
              }
            }
          }
          await sleep(150);
          try {
            document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          } catch (_) {
          }
          ratioSelected = found;
        }
      }
      await sleep(200);
      const verified = !!_queryWithFallback("image_mode_pill") || !!_queryWithFallback("ratio_button");
      console.log("[ChatGPT] activateImageMode: modeToggled =", modeToggled, "verified =", verified, "ratioSelected =", ratioSelected);
      console.log("[IMG_VERIFY] activateImageMode DONE: pill=" + !!_queryWithFallback("image_mode_pill", null, { silent: true }) + " | ratioBtn=" + !!_queryWithFallback("ratio_button", null, { silent: true }) + " | result=" + (modeToggled || ratioSelected || verified) + ' | ratio="' + ratio + '"');
      return modeToggled || ratioSelected || verified;
    }
    async function getEnhancePrefix() {
      try {
        const result = await new Promise((resolve) => {
          chrome.storage.local.get(["toby_provider_api_configs", "af_locale"], (r) => resolve(r));
        });
        const locale = result?.af_locale || "en";
        const prefixMap = result?.toby_provider_api_configs?.data?.chatgpt?.configs?.ai_agent_prefix;
        if (!prefixMap || typeof prefixMap !== "object") {
          console.warn("[AI Agent] ai_agent_prefix config missing for chatgpt \u2014 skip prefix wrap (raw prompt)");
          return "";
        }
        return prefixMap[locale] || prefixMap.en || "";
      } catch (e) {
        console.warn("[AI Agent] getEnhancePrefix error:", e.message, "\u2014 skip prefix wrap");
        return "";
      }
    }
    async function injectRefImages(images) {
      if (!images || images.length === 0) return true;
      await removeExistingChatGPTRefImages();
      await sleep(300);
      const files = images.map((img) => {
        const binary = atob(img.base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return new File([bytes], img.name || "image.png", { type: img.type || "image/png" });
      });
      let fileInput = null;
      for (let retry = 0; retry < 15; retry++) {
        fileInput = _queryWithFallback("file_input");
        if (fileInput) break;
        await sleep(400);
      }
      if (!fileInput) {
        console.warn("[ChatGPT] #upload-photos kh\xF4ng t\xECm th\u1EA5y, fallback click plus button");
        const plusBtn = _queryWithFallback("plus_button");
        if (plusBtn) {
          simulateClick(plusBtn);
          await sleep(300);
          fileInput = _queryWithFallback("file_input");
          try {
            document.activeElement?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          } catch (_) {
          }
          await sleep(100);
        }
      }
      if (!fileInput) {
        console.error("[ChatGPT] Kh\xF4ng t\xECm th\u1EA5y input file \u0111\u1EC3 upload ref image");
        return false;
      }
      const dt = new DataTransfer();
      const _composerEl = _queryWithFallback("composer");
      const _scope = _composerEl && _composerEl.closest("form") || document.body;
      const _beforeImgs = _scope.querySelectorAll("img").length;
      files.forEach((f) => dt.items.add(f));
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event("change", { bubbles: true }));
      let _attached = false;
      for (let i = 0; i < 30; i++) {
        await interruptibleSleep(300, "await-upload-preview");
        if (__chatgptAbort) break;
        if (_scope.querySelectorAll("img").length > _beforeImgs) {
          _attached = true;
          break;
        }
      }
      await sleep(_attached ? 400 : 600);
      for (let i = 0; i < 50; i++) {
        if (__chatgptAbort) break;
        if (!_isRefUploading()) break;
        await interruptibleSleep(300, "await-ref-upload-complete");
      }
      await sleep(getMacroDelay());
      return true;
    }
    let _chatScrollEl = null;
    function _findChatScrollEl() {
      const root = document.querySelector("main") || document.body;
      let best = null, bestH = 0;
      root.querySelectorAll("*").forEach((e) => {
        const oy = getComputedStyle(e).overflowY;
        if ((oy === "auto" || oy === "scroll") && e.scrollHeight > e.clientHeight + 80 && e.scrollHeight > bestH) {
          best = e;
          bestH = e.scrollHeight;
        }
      });
      return best;
    }
    function _scrollChatToBottom() {
      try {
        if (!_chatScrollEl || !_chatScrollEl.isConnected) _chatScrollEl = _findChatScrollEl();
        if (_chatScrollEl) _chatScrollEl.scrollTop = _chatScrollEl.scrollHeight;
        else window.scrollTo(0, document.documentElement.scrollHeight);
      } catch (_) {
      }
    }
    async function injectKichBanAndSubmit(text) {
      const log = (...a) => console.log("%c[ChatGPT-k\u1ECBch-b\u1EA3n]", "color:#cdff01;font-weight:bold", ...a);
      const raw = String(text || "").trim();
      if (!raw) throw new Error("KICH_BAN_EMPTY");
      log("START paste k\u1ECBch b\u1EA3n C\xD9NG chat, len=", raw.length, raw.slice(0, 60));
      for (let i = 0; i < 3; i++) {
        try {
          document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        } catch (_) {
        }
        await sleep(80);
      }
      try {
        await Promise.race([deactivateImageModeIfActive(), sleep(2e3)]);
      } catch (_) {
      }
      let editor = null;
      for (let i = 0; i < 50 && !editor; i++) {
        editor = document.querySelector('div#prompt-textarea.ProseMirror[contenteditable="true"]') || document.querySelector("#prompt-textarea.ProseMirror") || document.querySelector('div#prompt-textarea[contenteditable="true"]') || document.querySelector('#prompt-textarea[contenteditable="true"]') || document.querySelector("div.ProseMirror#prompt-textarea") || document.querySelector('div.ProseMirror[contenteditable="true"]') || _findChatGptComposer() || document.querySelector("#prompt-textarea") || document.querySelector('textarea[name="prompt-textarea"]') || document.querySelector('[data-testid="prompt-textarea"]');
        if (!editor) await sleep(120);
      }
      if (!editor) throw new Error("EDITOR_NOT_FOUND_KICH_BAN");
      log(
        "editor DOM",
        editor.tagName,
        "#" + (editor.id || ""),
        "." + String(editor.className || "").split(/\s+/).slice(0, 3).join("."),
        "ce=",
        editor.getAttribute("contenteditable") || ""
      );
      try {
        editor.querySelectorAll?.("[data-inline-selection-pill]").forEach((p) => p.remove());
      } catch (_) {
      }
      editor.focus();
      await sleep(100);
      const isTa = editor.tagName === "TEXTAREA" || editor instanceof HTMLTextAreaElement;
      try {
        if (isTa) {
          const proto = window.HTMLTextAreaElement?.prototype;
          const desc = proto && Object.getOwnPropertyDescriptor(proto, "value");
          if (desc?.set) desc.set.call(editor, raw);
          else editor.value = raw;
          editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: raw }));
          editor.dispatchEvent(new Event("change", { bubbles: true }));
        } else {
          document.execCommand("selectAll", false, null);
          await sleep(40);
          document.execCommand("delete", false, null);
          await sleep(60);
          const okIns = document.execCommand("insertText", false, raw);
          log("execCommand insertText=", okIns);
          if (!okIns || !(editor.textContent || "").trim()) {
            try {
              const dt = new DataTransfer();
              dt.setData("text/plain", raw);
              editor.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
            } catch (_) {
            }
          }
          if (!(editor.textContent || "").trim()) {
            editor.innerHTML = `<p>${raw.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>`;
            editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: raw }));
          }
          editor.dispatchEvent(new InputEvent("input", {
            bubbles: true,
            cancelable: true,
            inputType: "insertFromPaste",
            data: raw
          }));
        }
      } catch (e) {
        log("insert error", e?.message || e);
        throw new Error("KICH_BAN_INSERT_FAILED");
      }
      await sleep(250);
      const afterLen = isTa ? (editor.value || "").trim().length : (editor.textContent || "").trim().length;
      log("sau paste editor len=", afterLen);
      if (afterLen < 3) throw new Error("KICH_BAN_INSERT_EMPTY");
      const findSend = () => {
        const d = document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]') || document.querySelector("button.composer-submit-btn") || document.querySelector('form[data-type="unified-composer"] button[type="submit"]') || document.querySelector('form.group\\/composer button[type="submit"]');
        if (d && !_isChatGptSpeechOrMicButton(d) && !_isChatGptMenuOrNonSendButton(d)) return d;
        return _findChatGptSendButton(editor);
      };
      let sendBtn = null;
      const t0 = Date.now();
      while (Date.now() - t0 < 1e4) {
        try {
          editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: "" }));
        } catch (_) {
        }
        sendBtn = findSend();
        if (sendBtn && !sendBtn.disabled) {
          log("Send enabled", sendBtn.id || sendBtn.getAttribute("data-testid") || sendBtn.tagName);
          break;
        }
        if (sendBtn && sendBtn.disabled && Date.now() - t0 > 2e3) {
          log("Send c\xF2n disabled \u2014 v\u1EABn th\u1EED click/Enter");
          break;
        }
        await sleep(200);
      }
      const dismissPreferUi = () => {
        let n = 0;
        const buttons = document.querySelectorAll('button, [role="button"]');
        for (const b of buttons) {
          const t = (b.textContent || b.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
          if (/i prefer this response|prefer this|tôi thích phản hồi|chọn phản hồi này/i.test(t)) {
            try {
              log("dismiss prefer UI:", t.slice(0, 40));
              b.click();
              n++;
            } catch (_) {
            }
          }
        }
        return n;
      };
      const dismissed = dismissPreferUi();
      if (dismissed) await sleep(600);
      const contentBefore = isTa ? (editor.value || "").trim() : (editor.textContent || "").trim();
      const turnCountBefore = document.querySelectorAll(
        '[data-message-author-role="user"], [data-turn="user"]'
      ).length;
      const isSubmitted = () => {
        const left = isTa ? (editor.value || "").trim() : (editor.textContent || "").trim();
        if (left.length < 5 || left.length < contentBefore.length * 0.25) return true;
        if (_queryWithFallback("stop_button", null, { silent: true })) return true;
        if (_hasGeneratingIndicator()) return true;
        const turns = document.querySelectorAll(
          '[data-message-author-role="user"], [data-turn="user"]'
        ).length;
        if (turns > turnCountBefore) return true;
        const sb = findSend();
        if (sb?.disabled && left.length > 10) {
        }
        return false;
      };
      const waitSubmitted = async (ms = 3500, label = "") => {
        const tEnd = Date.now() + ms;
        while (Date.now() < tEnd) {
          if (isSubmitted()) {
            log("OK", label || "submitted");
            return true;
          }
          await sleep(200);
        }
        return isSubmitted();
      };
      const hardClickSend = (btn) => {
        if (!btn) return;
        try {
          simulateClick(btn);
        } catch (_) {
        }
        try {
          btn.focus?.();
          btn.click();
        } catch (_) {
        }
        try {
          const rect = btn.getBoundingClientRect();
          const o = {
            bubbles: true,
            cancelable: true,
            view: window,
            composed: true,
            clientX: rect.left + rect.width / 2,
            clientY: rect.top + rect.height / 2,
            button: 0,
            buttons: 1,
            pointerType: "mouse"
          };
          btn.dispatchEvent(new PointerEvent("pointerdown", o));
          btn.dispatchEvent(new MouseEvent("mousedown", o));
          btn.dispatchEvent(new PointerEvent("pointerup", o));
          btn.dispatchEvent(new MouseEvent("mouseup", o));
          btn.dispatchEvent(new MouseEvent("click", o));
        } catch (_) {
        }
        try {
          const pk = Object.keys(btn).find((k) => k.startsWith("__reactProps$"));
          const props = pk ? btn[pk] : null;
          if (props) {
            const fake = {
              preventDefault() {
              },
              stopPropagation() {
              },
              type: "click",
              target: btn,
              currentTarget: btn,
              nativeEvent: new MouseEvent("click"),
              isTrusted: false
            };
            if (typeof props.onPointerDown === "function") props.onPointerDown(fake);
            if (typeof props.onClick === "function") props.onClick(fake);
            if (typeof props.onMouseDown === "function") props.onMouseDown(fake);
          }
        } catch (_) {
        }
        try {
          const fk = Object.keys(btn).find((k) => k.startsWith("__reactFiber$"));
          let fiber = fk ? btn[fk] : null;
          for (let d = 0; d < 12 && fiber; d++) {
            const mp = fiber.memoizedProps || fiber.pendingProps;
            if (mp && typeof mp.onClick === "function") {
              mp.onClick({
                preventDefault() {
                },
                stopPropagation() {
                },
                type: "click",
                target: btn,
                currentTarget: btn,
                nativeEvent: new MouseEvent("click")
              });
              break;
            }
            fiber = fiber.return;
          }
        } catch (_) {
        }
      };
      const fireEnter = (el) => {
        const enterOpts = {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true,
          composed: true,
          shiftKey: false,
          ctrlKey: false,
          metaKey: false,
          altKey: false
        };
        try {
          el.focus();
          el.dispatchEvent(new KeyboardEvent("keydown", enterOpts));
          el.dispatchEvent(new KeyboardEvent("keypress", enterOpts));
          el.dispatchEvent(new KeyboardEvent("keyup", enterOpts));
        } catch (_) {
        }
      };
      let _restoreBlocker = false;
      try {
        if (typeof ExecutionBlocker !== "undefined" && ExecutionBlocker._blocking) {
          ExecutionBlocker.hide();
          _restoreBlocker = true;
          log("t\u1EA1m \u1EA9n ExecutionBlocker \u0111\u1EC3 Send");
        }
      } catch (_) {
      }
      try {
        fireEnter(editor);
        if (await waitSubmitted(2e3, "via Enter")) return true;
        sendBtn = findSend() || sendBtn;
        if (sendBtn) {
          log("hardClick Send", sendBtn.id || sendBtn.getAttribute("data-testid") || "");
          hardClickSend(sendBtn);
          if (await waitSubmitted(3500, "via hardClick Send")) return true;
        }
        try {
          const form = editor.closest("form") || document.querySelector('form[data-type="unified-composer"]');
          if (form && typeof form.requestSubmit === "function") {
            log("form.requestSubmit");
            sendBtn = findSend() || sendBtn;
            try {
              if (sendBtn) form.requestSubmit(sendBtn);
              else form.requestSubmit();
            } catch (_) {
              form.requestSubmit();
            }
            if (await waitSubmitted(2500, "via form.requestSubmit")) return true;
          }
        } catch (e) {
          log("formRequestSubmit fail", e?.message || e);
        }
        dismissPreferUi();
        await sleep(400);
        sendBtn = findSend();
        if (sendBtn) {
          hardClickSend(sendBtn);
          if (await waitSubmitted(2500, "via click after dismiss prefer")) return true;
        }
        try {
          const form = editor.closest("form") || document.body;
          const near = form.querySelectorAll('button, [role="button"]');
          for (const b of near) {
            if (_isChatGptSpeechOrMicButton(b) || _isChatGptMenuOrNonSendButton(b)) continue;
            const id = (b.id || "") + (b.getAttribute("data-testid") || "");
            const aria = (b.getAttribute("aria-label") || "").toLowerCase();
            if (/composer-submit|send-button|^send$|gửi/.test(id + " " + aria) || b === sendBtn) {
              log("attempt E click", id || aria || b.tagName);
              hardClickSend(b);
              if (await waitSubmitted(2e3, "via near-composer send")) return true;
            }
          }
        } catch (_) {
        }
        try {
          fireEnter(document.activeElement || editor);
          document.dispatchEvent(new KeyboardEvent("keydown", {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            bubbles: true,
            cancelable: true,
            composed: true
          }));
          if (await waitSubmitted(2e3, "via document Enter")) return true;
        } catch (_) {
        }
        log(
          "FAIL submit \u2014 editor still has text len=",
          (isTa ? editor.value : editor.textContent || "").trim().length,
          "sendBtn=",
          !!sendBtn,
          "disabled=",
          sendBtn?.disabled,
          "stop=",
          !!_queryWithFallback("stop_button", null, { silent: true }),
          "preferUi=",
          !!document.body.innerText?.match?.(/I prefer this response/i)
        );
        throw new Error("KICH_BAN_SUBMIT_FAILED");
      } finally {
        if (_restoreBlocker) {
          try {
            ExecutionBlocker.show();
          } catch (_) {
          }
        }
      }
    }
    async function injectTextAndSubmit(text, opts = {}) {
      const textOnly = opts?.textOnly === true;
      const log = (...args) => console.log("%c[ChatGPT-submit]", "color:#0ff;font-weight:bold", ...args);
      console.log(
        "%c[ChatGPT-submit] PASTE+PUSH start",
        "color:#0f0;font-weight:bold;font-size:14px",
        "textOnly=",
        textOnly,
        "len=",
        String(text || "").length,
        String(text || "").slice(0, 80)
      );
      let editor = null;
      const editorTimeout = Date.now() + 1e4;
      while (Date.now() < editorTimeout) {
        editor = _findChatGptComposer() || _queryWithFallback("composer", null, { silent: true });
        if (editor) break;
        await sleep(200);
      }
      if (!editor) {
        log("FAIL: EDITOR_NOT_FOUND \u2014 ch\u1EA1y __tobyProbeChatGptButtons() tr\xEAn console tab ChatGPT");
        throw new Error("EDITOR_NOT_FOUND");
      }
      if (editor.tagName === "TEXTAREA") {
        const pm = document.querySelector('#prompt-textarea[contenteditable="true"]') || document.querySelector('div.ProseMirror[contenteditable="true"]') || editor.closest("form")?.querySelector?.('[contenteditable="true"]#prompt-textarea') || editor.closest("form")?.querySelector?.('.ProseMirror[contenteditable="true"]');
        if (pm && pm !== editor) {
          log("Step 1: upgrade TEXTAREA \u2192 ProseMirror (React state)");
          editor = pm;
        }
      }
      log(
        "Step 1: Editor found",
        editor.tagName,
        editor.id || "",
        editor.getAttribute?.("name") || "",
        editor.className?.toString?.().slice?.(0, 40) || ""
      );
      editor.focus();
      await sleep(150);
      const clearForce = document.documentElement.dataset.tobyChatgptClearForce || null;
      if (clearForce) log("Step 1b [FORCE=" + clearForce + "]");
      let modePill = editor.tagName !== "TEXTAREA" ? editor.querySelector?.("[data-inline-selection-pill]") : null;
      if (textOnly && modePill) {
        log("Step 1b[textOnly]: FORCE remove image pill \u2014 k\u1ECBch b\u1EA3n c\u1EA7n text reply, kh\xF4ng Create image");
        try {
          await deactivateImageModeIfActive();
        } catch (_) {
        }
        modePill = editor.querySelector?.("[data-inline-selection-pill]");
        if (modePill) {
          try {
            modePill.remove();
            editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContent" }));
            log("Step 1b[textOnly]: pill DOM removed");
          } catch (pe) {
            log("Step 1b[textOnly]: pill remove fail", pe?.message || pe);
          }
        }
        modePill = editor.querySelector?.("[data-inline-selection-pill]") || null;
      }
      if (modePill && !textOnly) {
        log("Step 1b: image mode pill present (" + (modePill.getAttribute("data-id") || "") + ") \u2014 SKIP clear \u0111\u1EC3 gi\u1EEF mode, s\u1EBD append text sau pill");
        try {
          const r = document.createRange();
          r.selectNodeContents(editor);
          r.collapse(false);
          const s = window.getSelection();
          s.removeAllRanges();
          s.addRange(r);
        } catch (_) {
        }
      }
      const editorTextBeforeClear = (editor.tagName === "TEXTAREA" ? editor.value || "" : editor.textContent || "").trim();
      const shouldClearEditor = textOnly ? editorTextBeforeClear.length > 0 || !!clearForce : !modePill && (editorTextBeforeClear.length > 0 || !!clearForce);
      if (shouldClearEditor) {
        log("Step 1b: Clearing editor (length=" + editorTextBeforeClear.length + ", textOnly=" + textOnly + ")");
        try {
          if (editor.tagName === "TEXTAREA") {
            const proto = window.HTMLTextAreaElement?.prototype;
            const desc = proto && Object.getOwnPropertyDescriptor(proto, "value");
            if (desc?.set) desc.set.call(editor, "");
            else editor.value = "";
            editor.dispatchEvent(new Event("input", { bubbles: true }));
            log("Step 1b OK: textarea cleared");
          } else {
            if (!clearForce || clearForce === "selectAllDelete") {
              log("Step 1b[selectAllDelete]: execCommand selectAll+delete");
              document.execCommand("selectAll", false, null);
              await sleep(50);
              document.execCommand("delete", false, null);
              await sleep(100);
            }
            const stillHasText = (editor.textContent || "").trim().length > 0;
            if (clearForce === "innerHTMLReset" || !clearForce && stillHasText) {
              log("Step 1b[innerHTMLReset]: editor.innerHTML reset");
              editor.innerHTML = '<p><br class="ProseMirror-trailingBreak"></p>';
              editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContent" }));
              await sleep(80);
            }
            log("Step 1b OK: editor cleared, current length=", (editor.textContent || "").length);
          }
        } catch (clearErr) {
          log("Step 1b clear failed (non-fatal):", clearErr.message);
        }
        editor.focus();
        await sleep(80);
      } else {
        log("Step 1b: Editor \u0111\xE3 empty, skip clear (tr\xE1nh ph\xE1 ProseMirror state)");
      }
      const insertForce = document.documentElement.dataset.tobyChatgptInsertForce || null;
      if (insertForce) log("Step 2 [FORCE=" + insertForce + "]");
      const _fileTileCount = () => {
        try {
          return _queryAllWithFallback("text_file_tile", null).length;
        } catch (_) {
          return 0;
        }
      };
      const _fileTileBaseline = _fileTileCount();
      const isTextarea = editor.tagName === "TEXTAREA" || editor instanceof HTMLTextAreaElement;
      const _editorText = () => isTextarea ? editor.value || "" : editor.textContent || "";
      const inserted = () => {
        if (_fileTileCount() > _fileTileBaseline) return true;
        if (text.length === 0) return true;
        const norm = (s) => String(s || "").replace(/\s+/g, "");
        const txt = norm(_editorText());
        const san = norm(text);
        const expected = san.length;
        if (expected === 0) return true;
        if (txt.length < Math.floor(expected * 0.95)) return false;
        const head = san.substring(0, Math.min(20, expected));
        if (!txt.includes(head)) return false;
        if (expected > 40) {
          const tail = san.substring(expected - 20);
          if (!txt.includes(tail)) return false;
        }
        return true;
      };
      if (isTextarea && (!insertForce || insertForce === "textareaValue")) {
        log("Step 2[textareaValue]: native value setter, length=", text.length);
        try {
          editor.focus();
          const proto = window.HTMLTextAreaElement?.prototype;
          const desc = proto && Object.getOwnPropertyDescriptor(proto, "value");
          if (desc?.set) desc.set.call(editor, text);
          else editor.value = text;
          try {
            editor.dispatchEvent(new InputEvent("input", {
              bubbles: true,
              cancelable: true,
              inputType: "insertText",
              data: text
            }));
          } catch (_) {
            editor.dispatchEvent(new Event("input", { bubbles: true }));
          }
          editor.dispatchEvent(new Event("change", { bubbles: true }));
          if (!inserted()) {
            document.execCommand("selectAll", false, null);
            document.execCommand("insertText", false, text);
          }
          await sleep(200);
          const _sendEl = document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]');
          log(
            "Step 2[textareaValue] after insert len=",
            (editor.value || "").length,
            "sendBtn=",
            _sendEl ? _sendEl.id || _sendEl.getAttribute("data-testid") || "yes" : "MISSING",
            "sendDisabled=",
            _sendEl ? !!_sendEl.disabled : "n/a"
          );
        } catch (e) {
          log("Step 2[textareaValue] fail:", e.message);
        }
      }
      if (!insertForce || insertForce === "pasteEvent") {
        if (!isTextarea || !inserted()) {
          log("Step 2[pasteEvent]: ClipboardEvent paste, length=", text.length);
          try {
            const dt = new DataTransfer();
            dt.setData("text/plain", text);
            editor.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
            await sleep(300);
            if (!insertForce) {
              for (let i = 0; i < 8 && !inserted(); i++) {
                await sleep(150);
              }
            }
          } catch (e) {
            log("Step 2[pasteEvent] fail:", e.message);
          }
        }
      }
      if (insertForce === "execCommand" || !insertForce && !inserted()) {
        log("Step 2[execCommand]: clear editor + document.execCommand insertText");
        log("[IMG_VERIFY] execCommand tier RAN (paste !inserted) | modePill=" + (modePill ? "yes" : "no"));
        if (modePill) {
          try {
            const range = document.createRange();
            range.setStartAfter(modePill);
            range.setEnd(editor, editor.childNodes.length);
            range.deleteContents();
            editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContent" }));
          } catch (_) {
          }
          try {
            const r = document.createRange();
            r.selectNodeContents(editor);
            r.collapse(false);
            const s = window.getSelection();
            s.removeAllRanges();
            s.addRange(r);
          } catch (_) {
          }
        } else {
          editor.innerHTML = "";
          editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
        }
        editor.focus();
        await sleep(100);
        document.execCommand("insertText", false, text);
        await sleep(200);
      }
      if (!modePill && (insertForce === "innerHTMLReplace" || !insertForce && !inserted())) {
        log("Step 2[innerHTMLReplace]: editor.innerHTML + InputEvent (last resort)");
        editor.innerHTML = `<p>${text.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>`;
        editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
        await sleep(200);
      }
      if (insertForce && !inserted()) {
        log("Step 2 [FORCE=" + insertForce + "] FAILED: tier kh\xF4ng insert \u0111\u01B0\u1EE3c text. Editor length=" + editor.textContent.length);
        throw new Error("FORCE_INSERT_TIER_FAILED:" + insertForce);
      }
      editor.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: "insertFromPaste",
        data: text
      }));
      await sleep(150);
      log("Step 2 OK: editor content length=", _editorText().length, "tag=", editor.tagName);
      try {
        const _ec = _editorText();
        const _ecNoWs = _ec.replace(/\s+/g, "").length;
        const _txNoWs = (text || "").replace(/\s+/g, "").length;
        log("[IMG_VERIFY] FINAL editor len=" + _ec.length + " | tag=" + editor.tagName + " | modePill=" + (modePill ? modePill.getAttribute("data-id") || "yes" : "no") + " | inserted=" + inserted() + ' | head="' + _ec.slice(0, 70).replace(/\s+/g, "\xB7") + '" | tail="' + _ec.slice(-70).replace(/\s+/g, "\xB7") + '"');
        if (_txNoWs > 15 && _ecNoWs > Math.floor(_txNoWs * 1.7)) {
          log("[IMG_VERIFY] \u26A0\uFE0F NGHI DOUBLE INSERT: editor(no-ws)=" + _ecNoWs + " >> text(no-ws)=" + _txNoWs);
        }
      } catch (_) {
      }
      if (!inserted() && text.length > 0) {
        log("FAIL: INSERT_FAILED \u2014 editor v\u1EABn r\u1ED7ng sau m\u1ECDi tier insert. len expected=", text.length);
        throw new Error("INSERT_FAILED");
      }
      const contentBeforeSubmit = _editorText().trim();
      log("Step 2d: content ready for submit, len=", contentBeforeSubmit.length);
      const submitForce = document.documentElement.dataset.tobyChatgptSubmitForce || null;
      if (submitForce) log("Step 3-7 [FORCE=" + submitForce + "]");
      const submitted = () => {
        if (contentBeforeSubmit.length < 3) return false;
        const left = _editorText().trim();
        return left.length < 5 || left.length < contentBeforeSubmit.length * 0.3;
      };
      if (!submitForce) {
        const gateStart = Date.now();
        let gateBtnSeen = false;
        while (Date.now() - gateStart < 12e3) {
          if (__chatgptAbort) break;
          if (_isRefUploading()) {
            await sleep(200);
            continue;
          }
          const b = document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]') || _queryWithFallback("submit_button", null, { silent: true }) || _findChatGptSendButton(editor);
          if (b && !_isChatGptMenuOrNonSendButton(b)) {
            gateBtnSeen = true;
            if (!b.disabled) {
              log("Step 2c: Send enabled \u2192 submit", b.id || b.getAttribute("data-testid") || b.tagName);
              break;
            }
          } else if (gateBtnSeen) break;
          await sleep(200);
        }
        await sleep(200);
      }
      if (!submitForce || submitForce === "enterKey") {
        log("Step 3[enterKey]: KeyboardEvent keydown+keypress+keyup");
        editor.focus();
        await sleep(80);
        const enterOpts = {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true,
          composed: true
        };
        try {
          editor.dispatchEvent(new KeyboardEvent("keydown", enterOpts));
          editor.dispatchEvent(new KeyboardEvent("keypress", enterOpts));
          editor.dispatchEvent(new KeyboardEvent("keyup", enterOpts));
        } catch (e) {
          log("Step 3[enterKey] dispatch fail:", e.message);
        }
        await sleep(1500);
        if (submitted()) {
          log("Step 4 OK: editor cleared \u2192 submit th\xE0nh c\xF4ng via enterKey");
          return true;
        }
        if (submitForce === "enterKey") {
          log("Step 4 [FORCE=enterKey] DONE: editor still has text");
          return true;
        }
      }
      let sendBtn = null;
      if (submitForce === "simulateClick" || submitForce === "reactOnClick" || !submitForce && !submitted()) {
        log("Step 5: t\xECm #composer-submit-button / send-button");
        const start = Date.now();
        const POLL_TIMEOUT = 3e4;
        let lastDiag = 0;
        while (Date.now() - start < POLL_TIMEOUT) {
          const candidate = document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]') || _queryWithFallback("submit_button", null, { silent: true }) || _findChatGptSendButton(editor);
          if (candidate && !_isChatGptMenuOrNonSendButton(candidate) && !candidate.disabled) {
            sendBtn = candidate;
            break;
          }
          if (candidate && candidate.disabled && _editorText().trim().length > 0 && Date.now() - start > 500) {
            try {
              editor.dispatchEvent(new InputEvent("input", {
                bubbles: true,
                inputType: "insertText",
                data: " "
              }));
            } catch (_) {
            }
          }
          if (Date.now() - lastDiag > 3e3) {
            const fileTile = _queryWithFallback("text_file_tile", null, { silent: true });
            log(`Step 5 polling: btn=${!!candidate} disabled=${candidate?.disabled} id=${candidate?.id || ""} textLen=${_editorText().trim().length}`);
            lastDiag = Date.now();
          }
          await sleep(200);
        }
        if (!sendBtn) {
          const forceCand = document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]') || _findChatGptSendButton(editor) || _queryWithFallback("submit_button", null, { silent: true });
          if (forceCand && !_isChatGptMenuOrNonSendButton(forceCand)) {
            log("Step 5: d\xF9ng n\xFAt Send (c\xF3 th\u1EC3 disabled=true tr\xEAn DOM)", forceCand.id || forceCand.getAttribute("data-testid"));
            sendBtn = forceCand;
          }
        }
        if (!sendBtn) {
          log("FAIL: SEND_BUTTON_NOT_FOUND_OR_DISABLED. Editor content:", _editorText().substring(0, 50));
          log("HINT: tr\xEAn tab ChatGPT ch\u1EA1y: __tobyProbeChatGptButtons()");
          if (submitForce) return true;
          throw new Error("SEND_BUTTON_NOT_FOUND");
        }
        if (!submitForce || submitForce === "simulateClick") {
          log(
            "Step 5[simulateClick]: click Send",
            "id=",
            sendBtn.id || "(none)",
            "testid=",
            sendBtn.getAttribute("data-testid") || "(none)",
            "type=",
            sendBtn.getAttribute("type") || "(none)",
            "aria=",
            (sendBtn.getAttribute("aria-label") || "").slice(0, 40) || "(none)"
          );
          try {
            sendBtn.focus?.();
            sendBtn.click();
          } catch (e) {
            log("Step 5 native click fail:", e.message);
          }
          const rect = sendBtn.getBoundingClientRect();
          const opts2 = {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: rect.left + rect.width / 2,
            clientY: rect.top + rect.height / 2
          };
          try {
            sendBtn.dispatchEvent(new PointerEvent("pointerdown", opts2));
            sendBtn.dispatchEvent(new MouseEvent("mousedown", opts2));
            sendBtn.dispatchEvent(new PointerEvent("pointerup", opts2));
            sendBtn.dispatchEvent(new MouseEvent("mouseup", opts2));
            sendBtn.dispatchEvent(new MouseEvent("click", opts2));
          } catch (e) {
            log("Step 5[simulateClick] fail:", e.message);
          }
        }
        if (submitForce === "reactOnClick" || !submitForce) {
          const propsKey = Object.keys(sendBtn).find((k) => k.startsWith("__reactProps$"));
          const props = propsKey ? sendBtn[propsKey] : null;
          if (props && typeof props.onClick === "function") {
            log("Step 5[reactOnClick]: React props onClick (plain object, no isTrusted)");
            try {
              props.onClick({
                preventDefault() {
                },
                stopPropagation() {
                },
                nativeEvent: new MouseEvent("click"),
                type: "click",
                target: sendBtn,
                currentTarget: sendBtn
              });
            } catch (e) {
              log("Step 5[reactOnClick] fail:", e.message);
            }
          } else if (submitForce === "reactOnClick") {
            log("Step 5[reactOnClick] skip: __reactProps.onClick not found");
          }
        }
        if (!submitForce) {
          await sleep(1500);
          if (submitted()) {
            log("Step 6 OK: editor cleared sau click \u2192 submit th\xE0nh c\xF4ng");
            return true;
          }
        } else if (submitForce === "simulateClick" || submitForce === "reactOnClick") {
          log("Step 6 [FORCE=" + submitForce + "] DONE");
          return true;
        }
      }
      if (submitForce === "formRequestSubmit" || !submitForce && !submitted()) {
        log("Step 7[formRequestSubmit]: form.requestSubmit() native HTML");
        try {
          const formBtn = (sendBtn && !_isChatGptMenuOrNonSendButton(sendBtn) ? sendBtn : null) || document.querySelector("#composer-submit-button") || document.querySelector('button[data-testid="send-button"]') || _queryWithFallback("submit_button", null, { silent: true }) || _findChatGptSendButton(editor);
          const form = formBtn && formBtn.closest("form") || editor.closest("form") || document.querySelector('form[data-type="unified-composer"]');
          if (form && typeof form.requestSubmit === "function") {
            const isValidSubmitter = formBtn && form.contains(formBtn) && (formBtn.tagName === "BUTTON" || formBtn.tagName === "INPUT") && !_isChatGptMenuOrNonSendButton(formBtn) && (formBtn.getAttribute("type") === "submit" || formBtn.id === "composer-submit-button" || formBtn.getAttribute("data-testid") === "send-button" || formBtn.tagName === "BUTTON" && !formBtn.getAttribute("type"));
            try {
              if (isValidSubmitter) {
                form.requestSubmit(formBtn);
              } else {
                form.requestSubmit();
              }
            } catch (reqErr) {
              log("Step 7[formRequestSubmit] retry bare:", reqErr.message);
              try {
                form.requestSubmit();
              } catch (_) {
              }
            }
            await sleep(1e3);
            if (submitted()) {
              log("Step 7[formRequestSubmit] OK: editor cleared");
              return true;
            }
            log("Step 7[formRequestSubmit] kh\xF4ng clear editor");
          } else {
            log("Step 7[formRequestSubmit] skip: form kh\xF4ng t\u1ED3n t\u1EA1i ho\u1EB7c kh\xF4ng h\u1ED7 tr\u1EE3 requestSubmit");
          }
        } catch (e) {
          log("Step 7[formRequestSubmit] fail:", e.message);
        }
      }
      await sleep(500);
      const urlAfter = location.pathname || "";
      const editorCleared = submitted();
      const navigatedToChat = /\/c\//.test(urlAfter) || /\/g\//.test(urlAfter);
      if (editorCleared || navigatedToChat) {
        log("Step 7 OK: submit verified", { editorCleared, navigatedToChat, url: urlAfter });
        return true;
      }
      log("FAIL: SUBMIT_FAILED \u2014 text still in editor, no navigation. content=", _editorText().slice(0, 80));
      throw new Error("SUBMIT_FAILED");
    }
    async function uploadImages(images) {
      try {
        return await injectRefImages(images);
      } catch (err) {
        console.error("[ChatAI] uploadImages error:", err.message);
        return false;
      }
    }
    async function insertText(text) {
      let editor = null;
      const timeout = Date.now() + 5e3;
      while (Date.now() < timeout) {
        editor = _findChatGptComposer() || _queryWithFallback("composer", null, { silent: true });
        if (editor) break;
        await sleep(200);
      }
      if (!editor) {
        console.error("[ChatAI] Kh\xF4ng t\xECm th\u1EA5y \xF4 nh\u1EADp text tr\xEAn ChatGPT \u2014 ch\u1EA1y __tobyProbeChatGptButtons()");
        return false;
      }
      editor.focus();
      await sleep(200);
      document.execCommand("insertText", false, text);
      await sleep(200);
      const insertedLen = (editor.textContent || "").length;
      const expectedLen = text.length;
      const matchRatio = expectedLen > 0 ? insertedLen / expectedLen : 1;
      if (matchRatio < 0.9) {
        console.warn(`[ChatAI] ChatGPT: insertText truncated (${insertedLen}/${expectedLen} = ${(matchRatio * 100).toFixed(0)}%) \u2192 fallback innerHTML`);
        editor.innerHTML = `<p>${text}</p>`;
        editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText" }));
      }
      return true;
    }
    async function clickSubmit() {
      await sleep(500);
      let sendBtn = null;
      const start = Date.now();
      while (Date.now() - start < 5e3) {
        sendBtn = _queryWithFallback("submit_button", null, { silent: true });
        if (sendBtn && !sendBtn.disabled) break;
        sendBtn = null;
        await sleep(300);
      }
      if (!sendBtn) {
        console.error("[ChatAI] Kh\xF4ng t\xECm th\u1EA5y n\xFAt g\u1EEDi tr\xEAn ChatGPT");
        return false;
      }
      simulateClick(sendBtn);
      return true;
    }
    function checkImageLimitAlert() {
      const normalize = (s) => (s || "").replace(/[’‘]/g, "'").replace(/[  ]/g, " ").toLowerCase();
      const bodyText = normalize(document.body?.innerText || "");
      const limitPhrase = "reached your image creation limit";
      if (!bodyText.includes(limitPhrase)) return null;
      const fullText = document.body?.innerText || "";
      const sentences = fullText.split(/[\n]+/);
      let matchSentence = "";
      for (const sent of sentences) {
        if (normalize(sent).includes(limitPhrase)) {
          matchSentence = sent.trim();
          break;
        }
      }
      return {
        detected: true,
        message: matchSentence || "You've reached your image creation limit on the free plan."
      };
    }
    function snapshotConversationState() {
      const turns = _queryAllWithFallback("conversation_turn");
      const existingImageFileIds = /* @__PURE__ */ new Set();
      const allCdnImgs = _queryCdnImages(document);
      for (const img of allCdnImgs) {
        const src = img.currentSrc || img.src;
        if (!src) continue;
        const key = _imageKeyFromSrc(src);
        if (key) existingImageFileIds.add(key);
      }
      const turnIds = /* @__PURE__ */ new Set();
      for (const t of turns) {
        const id = t.dataset?.turnId || t.dataset?.testid || t.getAttribute?.("data-testid") || t.getAttribute?.("data-turn-id");
        if (id) turnIds.add(id);
      }
      console.log("[ChatGPT-snapshot] \u{1F4F8} Baseline:", turns.length, "turns,", existingImageFileIds.size, "existing image keys (incl. refs)");
      try {
        _ensureMainWorldNetHook();
        _resetNetCaptureForTurn(existingImageFileIds);
      } catch (_) {
      }
      return {
        turnCount: turns.length,
        turnIds,
        // Set<turn-id> — primary check cho new turn detection (robust với new-chat race)
        existingImageFileIds,
        // Set<file_xxx|urlKey> — bao gồm cả generated + ref/uploaded
        lastTurnIds: Array.from(turns).slice(-5).map((t) => t.dataset?.turnId || t.dataset?.testid || t.getAttribute?.("data-testid")),
        timestamp: Date.now()
      };
    }
    function isStreaming(turnEl) {
      if (_hasGeneratingIndicator(turnEl)) return true;
      if (_hasGeneratingIndicator()) return true;
      if (_queryWithFallback("stop_button")) return true;
      const sendBtn = _queryWithFallback("submit_button");
      if (sendBtn?.disabled) return true;
      const hasSkeleton = turnEl.querySelector(
        '[class*="skeleton"], [class*="shimmer"], [class*="animate-pulse"]'
      );
      const hasImg = !!_findGeneratedImg(turnEl);
      if (hasSkeleton && !hasImg) return true;
      return false;
    }
    function _findGeneratedImg(turnEl) {
      const altMatch = _queryWithFallback("generated_image", null, { scope: turnEl, silent: true });
      if (altMatch && !altMatch.classList.contains("blur-2xl") && altMatch.src) return altMatch;
      const candidates = _queryCdnImages(turnEl);
      for (const img of candidates) {
        if (img.classList.contains("blur-2xl")) continue;
        const alt = img.getAttribute("alt") || "";
        const isGenerated = alt.toLowerCase().startsWith("generated image");
        const isSibling = alt === "";
        if (!isGenerated && !isSibling) continue;
        if (img.src) return img;
      }
      if (!_findGeneratedImg._lastDebug || Date.now() - _findGeneratedImg._lastDebug > 5e3) {
        const allImgs = turnEl.querySelectorAll("img");
        if (allImgs.length > 0) {
          console.log("[ChatGPT-find] \u{1F50D} No generated img found, turn has", allImgs.length, "imgs");
          for (let i = 0; i < Math.min(allImgs.length, 3); i++) {
            const img = allImgs[i];
            console.log("  [" + i + "] src:", (img.src || "").slice(0, 80), "| alt:", (img.alt || "").slice(0, 40));
          }
          _findGeneratedImg._lastDebug = Date.now();
        }
      }
      return null;
    }
    let _activePatterns = {
      rateLimit: [],
      contentBlocked: [],
      imageGenFailed: [],
      network: [],
      textOnly: [],
      cloudflare: []
    };
    function _parsePatternString(str) {
      if (!str || typeof str !== "string") return [];
      return str.split("|").map((s) => s.trim().toLowerCase()).filter(Boolean);
    }
    async function _loadPatternsFromStorage() {
      try {
        const result = await new Promise((r) => chrome.storage.local.get(["af_chatgpt_config"], r));
        const cfg = result?.af_chatgpt_config?.data;
        if (!cfg) return false;
        _activePatterns.rateLimit = _parsePatternString(cfg.rate_limit_error_text);
        _activePatterns.contentBlocked = _parsePatternString(cfg.content_blocked_text);
        _activePatterns.imageGenFailed = _parsePatternString(cfg.image_gen_failed_text);
        _activePatterns.network = _parsePatternString(cfg.network_error_text);
        _activePatterns.textOnly = _parsePatternString(cfg.text_only_pattern);
        _activePatterns.cloudflare = _parsePatternString(cfg.cloudflare_challenge_text);
        const total = Object.values(_activePatterns).reduce((s, a) => s + a.length, 0);
        return total > 0;
      } catch (e) {
        return false;
      }
    }
    const _PATTERNS_WAIT_MAX_MS = 1e4;
    const _PATTERNS_WAIT_INTERVAL_MS = 500;
    const _CHATGPT_PATTERNS_BOOTSTRAP = {
      not_logged_in_text: "log in|sign in|Log in|Sign in",
      rate_limit_error_text: "rate limit|try again|too many requests|Rate limit",
      content_blocked_text: "content policy|blocked|cannot generate|violated|not allowed",
      image_gen_failed_text: "failed to generate|image generation failed|unable to create",
      network_error_text: "network error|connection|something went wrong",
      text_only_pattern: "I cannot|I'm unable|as an AI|text only",
      cloudflare_challenge_text: "verify you are human|cloudflare|challenge",
      delete_menu_text: "Delete|X\xF3a|Remove",
      create_image_menu_text: "Create image|T\u1EA1o \u1EA3nh|Generate image",
      generated_image_alt_text: "Generated image|Image created|DALL"
    };
    function _applyChatGPTPatternsBootstrap(source) {
      try {
        chrome.storage.local.set({
          af_chatgpt_config: {
            data: _CHATGPT_PATTERNS_BOOTSTRAP,
            fetched_at: Date.now(),
            source: source || "content_bootstrap"
          }
        });
      } catch (_) {
      }
      _loadPatternsFromStorage();
      const total = Object.values(_activePatterns).reduce((s, a) => s + a.length, 0);
      console.log(`[ChatGPT:patterns:ensure] \u2705 Local patterns bootstrap (${source || "content"}, ${total} patterns)`);
      return total > 0;
    }
    (async function _ensurePatternsConfig() {
      const startTime = Date.now();
      let attempts = 0;
      let lastLogElapsed = 0;
      console.log(`[ChatGPT:patterns:ensure] \u23F3 Waiting for error patterns in chrome.storage.local.af_chatgpt_config (timeout ${_PATTERNS_WAIT_MAX_MS}ms)...`);
      while (Date.now() - startTime < _PATTERNS_WAIT_MAX_MS) {
        attempts++;
        const ok = await _loadPatternsFromStorage();
        if (ok) {
          const total = Object.values(_activePatterns).reduce((s, a) => s + a.length, 0);
          console.log(`[ChatGPT:patterns:ensure] \u2705 Loaded ${total} patterns across ${Object.keys(_activePatterns).length} categories after ${attempts} attempts (${Date.now() - startTime}ms)`);
          return;
        }
        try {
          chrome.runtime.sendMessage({ action: "getProviderApiConfigs" }, () => {
            if (chrome.runtime.lastError) {
            }
          });
        } catch (_) {
        }
        const elapsed = Date.now() - startTime;
        if (elapsed >= 800) {
          _applyChatGPTPatternsBootstrap("early_fallback");
          return;
        }
        if (elapsed - lastLogElapsed >= 2e3) {
          lastLogElapsed = elapsed;
          console.log(`[ChatGPT:patterns:ensure] \u23F3 Still waiting (${(elapsed / 1e3).toFixed(1)}s/${_PATTERNS_WAIT_MAX_MS / 1e3}s, attempt #${attempts})...`);
        }
        await new Promise((r) => setTimeout(r, _PATTERNS_WAIT_INTERVAL_MS));
      }
      _applyChatGPTPatternsBootstrap("timeout_fallback");
    })();
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.af_chatgpt_config) {
          _loadPatternsFromStorage();
        }
      });
    } catch (e) {
    }
    function detectError(turnEl) {
      const text = (turnEl.innerText || "").toLowerCase();
      if (_activePatterns.rateLimit.some((p) => text.includes(p))) return "RATE_LIMIT";
      if (_activePatterns.contentBlocked.some((p) => text.includes(p))) return "CONTENT_BLOCKED";
      if (_activePatterns.imageGenFailed.some((p) => text.includes(p))) return "IMAGE_GEN_FAILED";
      if (_activePatterns.network.some((p) => text.includes(p))) return "NETWORK";
      return null;
    }
    function extractImageUrls(turnEl) {
      const images = _queryCdnImages(turnEl);
      const allImgs = turnEl.querySelectorAll("img");
      if (allImgs.length > 0 && images.length === 0) {
        console.log("[ChatGPT-extract] \u{1F50D} DEBUG: CDN selector miss, dumping all", allImgs.length, "imgs:");
        for (let i = 0; i < Math.min(allImgs.length, 5); i++) {
          const img = allImgs[i];
          console.log("  [" + i + "] src:", (img.src || "").slice(0, 100), "| alt:", (img.alt || "").slice(0, 50));
        }
      }
      const urlByFileId = /* @__PURE__ */ new Map();
      const candidates = [];
      let debugInfo = { total: images.length, skippedBlur: 0, skippedRef: 0, skippedEmpty: 0 };
      for (const img of images) {
        if (img.classList.contains("blur-2xl")) {
          debugInfo.skippedBlur++;
          continue;
        }
        const src = img.src;
        if (!src) {
          debugInfo.skippedEmpty++;
          continue;
        }
        const alt = img.getAttribute("alt") || "";
        const isGenerated = alt.toLowerCase().startsWith("generated image");
        const isSibling = alt === "";
        if (!isGenerated && !isSibling) {
          console.log("[ChatGPT-extract] \u23ED\uFE0F Skip non-generated:", alt.slice(0, 50), "| file_id:", src.match(/[?&]id=(file_[a-z0-9]+)/i)?.[1]);
          debugInfo.skippedRef++;
          continue;
        }
        candidates.push({ src, alt });
      }
      console.log("[ChatGPT-extract] \u{1F4CA} Images in turn:", JSON.stringify(debugInfo), "| Candidates after filter:", candidates.length);
      candidates.sort((a, b) => {
        const aGen = a.alt.toLowerCase().startsWith("generated image") ? 0 : 1;
        const bGen = b.alt.toLowerCase().startsWith("generated image") ? 0 : 1;
        return aGen - bGen;
      });
      for (const c of candidates) {
        const key = _imageKeyFromSrc(c.src) || c.src;
        if (!urlByFileId.has(key)) {
          urlByFileId.set(key, c.src);
        } else if ((c.alt || "").toLowerCase().startsWith("generated image")) {
          urlByFileId.set(key, c.src);
        }
      }
      if (urlByFileId.size === 0) {
        const altMatches = _queryAllWithFallback("generated_image", null, turnEl);
        for (const img of altMatches) {
          if (img.classList.contains("blur-2xl")) continue;
          if (!img.src) continue;
          const a = img.getAttribute("alt") || "";
          if (!(a.toLowerCase().startsWith("generated image") || a === "")) continue;
          const fileIdMatch = img.src.match(/[?&]id=(file_[a-z0-9]+)/i);
          const key = fileIdMatch ? fileIdMatch[1] : img.src;
          if (!urlByFileId.has(key)) urlByFileId.set(key, img.src);
        }
      }
      return Array.from(urlByFileId.values());
    }
    function _findAssistantMessageEls() {
      const fromSel = Array.from(_queryAllWithFallback("assistant_turn") || []);
      if (fromSel.length) return fromSel;
      return Array.from(document.querySelectorAll(
        '[data-message-author-role="assistant"], [data-turn="assistant"]'
      ));
    }
    function _extractAssistantText(el) {
      if (!el) return "";
      try {
        const markdownEl = _queryWithFallback("response_text_content", null, { scope: el, silent: true });
        if (markdownEl && markdownEl.innerText) return String(markdownEl.innerText).trim();
        const roleWrapper = _queryWithFallback("message_author", null, { scope: el, silent: true });
        if (roleWrapper && roleWrapper.innerText) return String(roleWrapper.innerText).trim();
        const clone = el.cloneNode(true);
        if (clone.querySelectorAll) {
          clone.querySelectorAll('button, nav, [role="toolbar"]').forEach((n) => n.remove());
        }
        return String(clone.innerText || el.innerText || "").trim();
      } catch (_) {
        return String(el.innerText || "").trim();
      }
    }
    async function waitForTextResult(baseline, timeout = 6e4) {
      const startTime = Date.now();
      const pollInterval = 500;
      let lastDiag = 0;
      let lastTextLength = 0;
      let stableCount = 0;
      const STABLE_THRESHOLD = 6;
      const baselineAssistantCount = _findAssistantMessageEls().length;
      let baselineMaxAssistantLen = 0;
      try {
        for (const el of _findAssistantMessageEls()) {
          const L = _extractAssistantText(el).length;
          if (L > baselineMaxAssistantLen) baselineMaxAssistantLen = L;
        }
      } catch (_) {
      }
      while (Date.now() - startTime < timeout) {
        _scrollChatToBottom();
        if (isAbortActive()) {
          console.log("[ChatGPT-text] Aborted by user \u2192 clicking Stop button");
          await clickChatGPTStopButton();
          return { success: false, error: "ABORTED", message: "User stopped execution" };
        }
        const allAssistantTurns = _findAssistantMessageEls();
        const allTurns = _queryAllWithFallback("conversation_turn");
        const baselineIds = baseline.turnIds || /* @__PURE__ */ new Set();
        const newTurns = baselineIds.size > 0 ? Array.from(allTurns).filter((t) => {
          const id = t.dataset?.turnId || t.dataset?.testid || t.getAttribute?.("data-testid");
          return id && !baselineIds.has(id);
        }) : Array.from(allTurns).slice(baseline.turnCount || 0);
        const assistantGrew = allAssistantTurns.length > baselineAssistantCount;
        const hasNewTurn = newTurns.length > 0 || assistantGrew || allAssistantTurns.length > 0 && (allTurns.length === 0 || !baseline.turnCount) && Date.now() - startTime > 2500;
        if (!hasNewTurn) {
          const lastA = allAssistantTurns[allAssistantTurns.length - 1];
          const probe = _extractAssistantText(lastA);
          if (!(probe.length > baselineMaxAssistantLen + 20 && probe.length > 40)) {
            if (Date.now() - lastDiag > 4e3) {
              console.log(
                "[ChatGPT-text] Ch\u1EDD reply \u2014 turns:",
                allTurns.length,
                "base:",
                baseline.turnCount,
                "assistants:",
                allAssistantTurns.length,
                "baseAssist:",
                baselineAssistantCount
              );
              lastDiag = Date.now();
            }
            await sleep(pollInterval);
            continue;
          }
        }
        let lastAssistantTurn = null;
        for (let i = newTurns.length - 1; i >= 0; i--) {
          const t = newTurns[i];
          if (t.getAttribute?.("data-message-author-role") === "assistant" || t.getAttribute?.("data-turn") === "assistant" || t.querySelector?.('[data-message-author-role="assistant"]') || t.matches && t.matches('[data-turn="assistant"]')) {
            lastAssistantTurn = t.querySelector?.('[data-message-author-role="assistant"]') || t;
            break;
          }
        }
        if (!lastAssistantTurn) lastAssistantTurn = allAssistantTurns[allAssistantTurns.length - 1];
        if (!lastAssistantTurn) {
          await sleep(pollInterval);
          continue;
        }
        const error = detectError(lastAssistantTurn);
        if (error) {
          console.log("[ChatGPT-text] Error:", error);
          return {
            success: false,
            error,
            message: (lastAssistantTurn.innerText || "").slice(0, 500)
          };
        }
        const stopGenBtn = _queryWithFallback("stop_button");
        const stillGeneratingImg = _hasGeneratingIndicator(lastAssistantTurn);
        const hasThinkingIndicator = _queryWithFallback("thinking_indicator", null, { scope: lastAssistantTurn, silent: true });
        const signalStreaming = !!stopGenBtn || !!stillGeneratingImg || !!hasThinkingIndicator;
        const currentText = _extractAssistantText(lastAssistantTurn);
        const currentTextLength = currentText.length;
        if (currentTextLength === lastTextLength && currentTextLength > 0) {
          stableCount++;
        } else {
          stableCount = 0;
          lastTextLength = currentTextLength;
        }
        const isTextStable = stableCount >= STABLE_THRESHOLD;
        const stillStreaming = signalStreaming || !isTextStable && currentTextLength > 0;
        if (stillStreaming) {
          if (Date.now() - lastDiag > 4e3) {
            console.log("[ChatGPT-text] Streaming \u2014 stop:", !!stopGenBtn, "textLen:", currentTextLength, "stable:", stableCount);
            lastDiag = Date.now();
          }
          await sleep(pollInterval);
          continue;
        }
        if (!currentText || currentText.length < 1) {
          if (Date.now() - startTime < 5e3) {
            await sleep(pollInterval);
            continue;
          }
          return { success: false, error: "TEXT_EMPTY" };
        }
        if (currentText.length <= baselineMaxAssistantLen && !hasNewTurn && !assistantGrew) {
          await sleep(pollInterval);
          continue;
        }
        const turnId = lastAssistantTurn.dataset?.turnId || lastAssistantTurn.dataset?.testid || lastAssistantTurn.getAttribute?.("data-testid") || null;
        console.log(
          "%c[ChatGPT-text] DONE (k\u1ECBch b\u1EA3n)",
          "color:#0f0;font-weight:bold",
          "len=",
          currentText.length,
          "stable=",
          stableCount
        );
        return { success: true, text: currentText, turnId };
      }
      console.warn("[ChatGPT-text] TIMEOUT sau", timeout, "ms");
      try {
        const _aTurns = _findAssistantMessageEls();
        let best = "";
        for (const el of _aTurns) {
          const t = _extractAssistantText(el);
          if (t.length > best.length) best = t;
        }
        if (best.length > Math.max(40, baselineMaxAssistantLen + 10)) {
          console.warn("[ChatGPT-text] TIMEOUT \u2192 last-chance text len=", best.length);
          return { success: true, text: best, turnId: null, via: "timeout_last_chance" };
        }
        console.warn("[ChatGPT-text] TIMEOUT diag", {
          turns: _queryAllWithFallback("conversation_turn").length,
          baseTurns: baseline.turnCount,
          assistants: _aTurns.length,
          baselineMaxAssistantLen,
          bestLen: best.length
        });
      } catch (e) {
        console.warn("[ChatGPT-text] TIMEOUT diag failed:", e.message);
      }
      return { success: false, error: "TIMEOUT" };
    }
    async function captureChatGptImageBase64s(imageUrls) {
      const urls = Array.isArray(imageUrls) ? imageUrls : [];
      const out = [];
      const sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
      for (const url of urls) {
        let dataUrl = null;
        const fileIdMatch = String(url || "").match(/[?&]id=(file_[a-zA-Z0-9]+)/i);
        const fileId = fileIdMatch ? fileIdMatch[1] : "";
        try {
          const imgs = Array.from(document.querySelectorAll("img"));
          const scored = [];
          for (const img of imgs) {
            const src = img.currentSrc || img.src || "";
            if (!src) continue;
            const hit = fileId && src.includes(fileId) || src === url || url && src.split("?")[0] === String(url).split("?")[0];
            if (!hit) continue;
            const alt = (img.getAttribute("alt") || "").toLowerCase();
            let score = 0;
            if (alt.startsWith("generated image")) score += 100;
            try {
              const r = img.getBoundingClientRect();
              score += Math.min(50, r.width * r.height / 2e3);
            } catch (_) {
            }
            scored.push({ img, score });
          }
          scored.sort((a, b) => b.score - a.score);
          for (const { img } of scored) {
            if (!img.complete || !img.naturalWidth) {
              await new Promise((r) => {
                const done = () => r(null);
                img.addEventListener("load", done, { once: true });
                img.addEventListener("error", done, { once: true });
                setTimeout(done, 4e3);
              });
            }
            if (!img.naturalWidth || !img.naturalHeight) continue;
            try {
              const c = document.createElement("canvas");
              c.width = img.naturalWidth;
              c.height = img.naturalHeight;
              c.getContext("2d").drawImage(img, 0, 0);
              let du = c.toDataURL("image/jpeg", 0.9);
              if (!du || du.length < 500) du = c.toDataURL("image/png");
              if (du && du.length > 500) {
                dataUrl = du;
                console.log(
                  "[ChatGPT-capture] canvas OK",
                  img.naturalWidth,
                  "x",
                  img.naturalHeight,
                  Math.round(du.length / 1024) + "KB",
                  du.slice(5, 15)
                );
                break;
              }
            } catch (ce) {
              console.warn("[ChatGPT-capture] canvas fail:", ce?.message || ce);
            }
          }
        } catch (e) {
          console.warn("[ChatGPT-capture] canvas path error:", e?.message || e);
        }
        if (!dataUrl && url) {
          for (let attempt = 1; attempt <= 2 && !dataUrl; attempt++) {
            try {
              const resp = await fetch(url, {
                credentials: "include",
                cache: attempt === 1 ? "force-cache" : "reload"
              });
              if (!resp.ok) {
                console.warn("[ChatGPT-capture] fetch HTTP", resp.status, "attempt", attempt);
                await sleep2(400 * attempt);
                continue;
              }
              const blob = await resp.blob();
              if (blob && blob.size > 100) {
                dataUrl = await new Promise((resolve) => {
                  const reader = new FileReader();
                  reader.onload = () => resolve(reader.result);
                  reader.onerror = () => resolve(null);
                  reader.readAsDataURL(blob);
                });
                if (dataUrl) {
                  console.log("[ChatGPT-capture] fetch OK", Math.round(blob.size / 1024), "KB attempt", attempt);
                }
              }
            } catch (fe) {
              console.warn("[ChatGPT-capture] fetch fail attempt", attempt, fe?.message || fe);
              await sleep2(400 * attempt);
            }
          }
        }
        out.push(dataUrl || null);
      }
      return out;
    }
    async function waitForImageResult(baseline, timeout = 12e4) {
      const startTime = Date.now();
      const pollInterval = 1e3;
      let lastDiag = 0;
      let textOnlyStreamStart = null;
      let postCompleteTextOnlyStart = null;
      let noTurnWarnAt = 0;
      const NO_TURN_FAIL_MS = 25e3;
      const TEXT_ONLY_THRESHOLD_MS = 15e3;
      const POST_COMPLETE_GRACE_MS = 5e3;
      const MIN_WAIT_BEFORE_PATTERN_CHECK_MS = 5e3;
      const MIN_WAIT_WITH_POSITIVE_MS = 1e4;
      const MIN_TEXT_FOR_ERROR_CHECK = 80;
      const NET_SETTLE_MS = 1500;
      const NET_MIN_WAIT_AFTER_GEN_HINT_MS = 800;
      try {
        _ensureMainWorldNetHook();
      } catch (_) {
      }
      function tryNetDone() {
        const netUrls = _getNetNewImageUrls();
        if (!netUrls.length) return null;
        const globalGenerating = _hasGeneratingIndicator();
        if (globalGenerating) return null;
        const last = _netCapture.lastEventAt || 0;
        const sinceLast = Date.now() - last;
        if (last && sinceLast < NET_SETTLE_MS) return null;
        if (_netCapture.genHintAt && Date.now() - _netCapture.genHintAt < NET_MIN_WAIT_AFTER_GEN_HINT_MS) {
        }
        console.log(
          "%c[ChatGPT-detect] DONE (network file_id)",
          "color:#0f0;font-weight:bold;font-size:13px",
          "\u2014 urls:",
          netUrls.length,
          "epoch=",
          _netCapture.epoch,
          "url0=",
          (netUrls[0] || "").slice(0, 90)
        );
        return {
          success: true,
          imageUrls: netUrls,
          altPrompt: "",
          turnId: null,
          via: "network"
        };
      }
      const POSITIVE_INDICATORS = [
        "i'll create",
        "i'll generate",
        "i'll make",
        "let me create",
        "let me generate",
        "creating",
        "generating",
        "here's",
        "here is",
        "sure",
        "absolutely",
        "of course"
      ];
      function hasPositiveIndicator(text) {
        if (!text) return false;
        const lower = text.toLowerCase();
        return POSITIVE_INDICATORS.some((p) => lower.includes(p));
      }
      function matchesTextOnlyPattern(text) {
        if (!text || text.length < 50) return false;
        const lower = text.toLowerCase();
        const patterns = _activePatterns.textOnly || [];
        return patterns.some((p) => lower.includes(p));
      }
      function matchesAnyErrorPattern(text) {
        if (!text || text.length < MIN_TEXT_FOR_ERROR_CHECK) return null;
        const lower = text.toLowerCase();
        const checks = [
          { key: "rateLimit", error: "RATE_LIMIT" },
          { key: "contentBlocked", error: "CONTENT_BLOCKED" },
          { key: "imageGenFailed", error: "IMAGE_GEN_FAILED" }
        ];
        for (const { key, error } of checks) {
          const patterns = _activePatterns[key] || [];
          if (patterns.some((p) => lower.includes(p))) {
            return { error, text: text.slice(0, 500) };
          }
        }
        return null;
      }
      function findNewAssistantTurn() {
        const allAssistantTurns = _queryAllWithFallback("assistant_turn");
        if (!allAssistantTurns.length) return null;
        const actionBtnSelectors = _getSelectorsForKey("image_action_buttons");
        for (let i = allAssistantTurns.length - 1; i >= 0; i--) {
          const turn = allAssistantTurns[i];
          if (_hasGeneratingIndicator(turn)) return turn;
          for (const sel of actionBtnSelectors) {
            if (turn.querySelector(sel)) return turn;
          }
          if (_queryWithFallback("generated_image", null, { scope: turn, silent: true })) return turn;
        }
        const newTurns = Array.from(allAssistantTurns).filter((turn) => {
          const testid = turn.dataset.testid || turn.getAttribute("data-testid") || "";
          const m = testid.match(/conversation-turn-(\d+)/);
          if (!m) return false;
          return parseInt(m[1], 10) > baseline.turnCount;
        });
        if (newTurns.length > 0) return newTurns[newTurns.length - 1];
        return allAssistantTurns[allAssistantTurns.length - 1];
      }
      const MAX_WAIT = Math.max(timeout, 6e5);
      const HEARTBEAT_MS = 9e4;
      let genSeenOnce = false;
      let lastGenActive = Date.now();
      while (Date.now() - startTime < MAX_WAIT) {
        _scrollChatToBottom();
        if (isAbortActive()) {
          console.log("[ChatGPT-image] Aborted by user \u2192 clicking Stop button");
          await clickChatGPTStopButton();
          return { success: false, error: "ABORTED", message: "User stopped execution" };
        }
        if (detectChatGPTChallenge()) {
          console.warn("[ChatGPT-image] Challenge re-emerged mid-stream \u2192 abort");
          return {
            success: false,
            error: "CHALLENGE_TIMEOUT",
            message: "ChatGPT y\xEAu c\u1EA7u x\xE1c minh trong khi gen \u2014 vui l\xF2ng verify th\u1EE7 c\xF4ng v\xE0 ch\u1EA1y l\u1EA1i."
          };
        }
        const allTurns = _queryAllWithFallback("conversation_turn");
        const baselineFileIds = baseline.existingImageFileIds || /* @__PURE__ */ new Set();
        const _collectNewImages = () => {
          const urlByKey = /* @__PURE__ */ new Map();
          for (const img of _queryCdnImages(document)) {
            const src = img.currentSrc || img.src || "";
            if (!src || !src.startsWith("http") && !src.startsWith("blob:")) continue;
            if (!_isLikelyGeneratedImg(img)) continue;
            const key = _imageKeyFromSrc(src);
            if (!key || baselineFileIds.has(key)) continue;
            const m = src.match(/[?&]id=(file_[a-z0-9]+)/i);
            if (m && baselineFileIds.has(m[1].toLowerCase())) continue;
            if (!urlByKey.has(key)) urlByKey.set(key, src);
          }
          return urlByKey;
        };
        const _hasRealNewImage = () => _collectNewImages().size > 0;
        const allGenImgs = _queryCdnImages(document);
        const urlByFileId = _collectNewImages();
        const newImageUrls = Array.from(urlByFileId.values());
        const globalGenerating = _hasGeneratingIndicator();
        if (globalGenerating) {
          genSeenOnce = true;
          lastGenActive = Date.now();
        } else if (newImageUrls.length === 0 && _getNetNewImageUrls().length === 0) {
          if (genSeenOnce || _netCapture.genHintAt) {
            if (Date.now() - Math.max(lastGenActive, _netCapture.genHintAt || 0) > HEARTBEAT_MS) {
              console.warn(`[ChatGPT-detect] Heartbeat: indicator gen t\u1EAFt > ${HEARTBEAT_MS / 1e3}s + ch\u01B0a c\xF3 \u1EA3nh \u2192 stuck, d\u1EEBng ch\u1EDD`);
              break;
            }
          } else if (Date.now() - startTime > timeout) {
            console.warn("[ChatGPT-detect] Heartbeat: ch\u01B0a t\u1EEBng th\u1EA5y indicator gen sau", timeout, "ms \u2192 d\u1EEBng ch\u1EDD");
            break;
          }
        }
        {
          const netDone = tryNetDone();
          if (netDone) return netDone;
        }
        if (newImageUrls.length > 0 && !globalGenerating) {
          let altText = "";
          let preferredUrl = "";
          for (const img of allGenImgs) {
            if (!_isLikelyGeneratedImg(img)) continue;
            const src = img.currentSrc || img.src || "";
            const key = _imageKeyFromSrc(src);
            if (key && baselineFileIds.has(key)) continue;
            const alt = img.getAttribute("alt") || "";
            if (alt.toLowerCase().startsWith("generated image") || alt.toLowerCase().startsWith("image created")) {
              altText = alt;
              preferredUrl = src;
              break;
            }
            if (!altText) {
              altText = alt;
              preferredUrl = preferredUrl || src;
            }
          }
          let urls = newImageUrls.slice();
          if (preferredUrl) {
            urls = [preferredUrl, ...urls.filter((u) => _imageKeyFromSrc(u) !== _imageKeyFromSrc(preferredUrl))];
          }
          const seenKeys = /* @__PURE__ */ new Set();
          urls = urls.filter((u) => {
            const k = _imageKeyFromSrc(u) || u;
            if (seenKeys.has(k)) return false;
            seenKeys.add(k);
            return true;
          });
          console.log(
            "%c[ChatGPT-detect] DONE (global fallback)",
            "color:#0f0;font-weight:bold",
            "\u2014 NEW urls:",
            urls.length,
            "baseline c\u0169:",
            baselineFileIds.size,
            "alt:",
            altText.slice(0, 60),
            "url0:",
            (urls[0] || "").slice(0, 90)
          );
          return {
            success: true,
            imageUrls: urls,
            altPrompt: altText.replace(/^Generated image:\s*/i, "").replace(/^Image created:\s*/i, ""),
            turnId: null
          };
        }
        if (allTurns.length <= baseline.turnCount) {
          const elapsed = Date.now() - startTime;
          const stillHome = !/\/c\//.test(location.pathname || "") && !/\/g\//.test(location.pathname || "");
          if (!globalGenerating && stillHome && elapsed > NO_TURN_FAIL_MS) {
            console.error(
              "[ChatGPT-detect] FAIL fast: no turn after",
              Math.round(elapsed / 1e3),
              "s on homepage \u2014 submit kh\xF4ng t\u1EA1o conversation"
            );
            return {
              success: false,
              error: "SUBMIT_NO_TURN",
              message: "ChatGPT kh\xF4ng nh\u1EADn prompt (Send/paste fail). F5 chatgpt.com, reload extension, th\u1EED l\u1EA1i."
            };
          }
          if (!globalGenerating && !stillHome && elapsed > 8e3 && newImageUrls.length === 0) {
            const mainImgs = Array.from(document.querySelectorAll('main img[src^="http"]')).filter((img) => {
              try {
                const r = img.getBoundingClientRect();
                return r.width >= 100 && r.height >= 100 && _isLikelyGeneratedImg(img);
              } catch (_) {
                return false;
              }
            });
            const fresh = mainImgs.filter((img) => {
              const key = _imageKeyFromSrc(img.currentSrc || img.src);
              return key && !baselineFileIds.has(key);
            });
            if (fresh.length > 0) {
              const urls = fresh.map((img) => img.currentSrc || img.src);
              console.log("[ChatGPT-detect] DONE (main-img last-chance) \u2014 urls:", urls.length, "turnCount still", allTurns.length);
              return {
                success: true,
                imageUrls: [...new Set(urls)],
                altPrompt: (fresh[0].getAttribute("alt") || "").replace(/^Generated image:\s*/i, ""),
                turnId: null
              };
            }
          }
          if (Date.now() - lastDiag > 3e3) {
            const genState = globalGenerating ? "GENERATING (global)" : "idle";
            const url = window.location.pathname;
            const cdnN = allGenImgs.length;
            console.log(
              "[ChatGPT-detect] Ch\u01B0a c\xF3 turn m\u1EDBi \u2014 turnCount:",
              allTurns.length,
              "baseline:",
              baseline.turnCount,
              "state:",
              genState,
              "cdnImgs:",
              cdnN,
              "newImgs:",
              newImageUrls.length,
              "netFiles:",
              _netCapture.files.size,
              "url:",
              url,
              "elapsed:",
              Math.round(elapsed / 1e3) + "s"
            );
            lastDiag = Date.now();
          }
          {
            const netDone = tryNetDone();
            if (netDone) return netDone;
          }
          await sleep(pollInterval);
          continue;
        }
        const lastAssistantTurn = findNewAssistantTurn();
        if (!lastAssistantTurn) {
          await sleep(pollInterval);
          continue;
        }
        const error = detectError(lastAssistantTurn);
        if (error) {
          console.log("[ChatGPT-detect] Error:", error);
          return { success: false, error, message: (lastAssistantTurn.innerText || "").slice(0, 500) };
        }
        const paragenContainer = _queryWithFallback("paragen_container", null, { scope: lastAssistantTurn, silent: true }) || _queryWithFallback("paragen_container", null, { silent: true });
        if (paragenContainer) {
          const paragenImgs = Array.from(_queryAllWithFallback("generated_image", null, paragenContainer)).filter((img) => !img.classList.contains("blur-2xl") && img.src && img.src.startsWith("http"));
          const stillLoadingInParagen = !!_queryWithFallback("generating_indicator", null, { scope: paragenContainer, silent: true });
          if (paragenImgs.length >= 2 && !stillLoadingInParagen) {
            const paragenUrls = paragenImgs.map((img) => img.src);
            const seen = /* @__PURE__ */ new Set();
            const dedupedUrls = paragenUrls.filter((url) => {
              const m = url.match(/[?&]id=(file_[a-z0-9]+)/i);
              const key = m ? m[1] : url;
              if (seen.has(key)) return false;
              seen.add(key);
              return true;
            });
            console.log("[ChatGPT-detect] DONE (paragen-multigen) \u2014", dedupedUrls.length, "\u1EA3nh s\u1EB5n s\xE0ng");
            return {
              success: true,
              imageUrls: dedupedUrls,
              altPrompt: paragenImgs[0]?.alt?.replace(/^Generated image:?\s*/i, "") || "",
              turnId: lastAssistantTurn.dataset.turnId || lastAssistantTurn.dataset.testid || null
            };
          }
        }
        const generatedImg = _findGeneratedImg(lastAssistantTurn);
        let imageUrls = extractImageUrls(lastAssistantTurn);
        const preFilterCount = imageUrls.length;
        if (baselineFileIds.size > 0) {
          imageUrls = imageUrls.filter((url) => {
            const key = _imageKeyFromSrc(url);
            const isOld = key && baselineFileIds.has(key);
            if (isOld) console.log("[ChatGPT-detect] \u23ED\uFE0F Filter old/ref image:", key.slice(0, 60));
            return !isOld;
          });
        }
        if (preFilterCount !== imageUrls.length) {
          console.log("[ChatGPT-detect] \u{1F50D} Baseline filter:", preFilterCount, "\u2192", imageUrls.length, "| baselineIds:", baselineFileIds.size);
        }
        const postActionDone = !!_queryWithFallback("image_action_buttons", null, { scope: lastAssistantTurn, silent: true });
        if (generatedImg && imageUrls.length > 0) {
          const altText = generatedImg.getAttribute("alt") || "";
          const isGeneratedAlt = altText.toLowerCase().startsWith("generated image");
          if (postActionDone || isGeneratedAlt || !isStreaming(lastAssistantTurn)) {
            const turnId = lastAssistantTurn.dataset.turnId || lastAssistantTurn.dataset.testid || null;
            console.log("[ChatGPT-detect] DONE \u2014 urls:", imageUrls.length, "alt:", altText.slice(0, 60), "postAction:", postActionDone);
            return {
              success: true,
              imageUrls,
              altPrompt: isGeneratedAlt ? altText.replace(/^Generated image:\s*/i, "") : altText,
              turnId
            };
          }
        }
        if (isStreaming(lastAssistantTurn)) {
          const hasImageMarker = _hasGeneratingIndicator(lastAssistantTurn) || !!_queryWithFallback("generated_image", null, { scope: lastAssistantTurn, silent: true }) || _hasGeneratingIndicator();
          const currentText = (lastAssistantTurn.innerText || "").trim();
          const textLen = currentText.length;
          if (!hasImageMarker && textLen > 50) {
            const elapsedMs = Date.now() - startTime;
            const hasPositive = hasPositiveIndicator(currentText);
            const waitThreshold = hasPositive ? MIN_WAIT_WITH_POSITIVE_MS : MIN_WAIT_BEFORE_PATTERN_CHECK_MS;
            const shouldCheckPatterns = elapsedMs > waitThreshold;
            if (shouldCheckPatterns) {
              const errorMatch = matchesAnyErrorPattern(currentText);
              if (errorMatch) {
                console.log("[ChatGPT-detect]", errorMatch.error, "(pattern match):", currentText.slice(0, 100));
                return { success: false, error: errorMatch.error, text: errorMatch.text };
              }
              if (matchesTextOnlyPattern(currentText)) {
                const recheckMarker = _hasGeneratingIndicator(lastAssistantTurn) || !!_queryWithFallback("generated_image", null, { scope: lastAssistantTurn, silent: true }) || _hasGeneratingIndicator();
                if (recheckMarker || _hasRealNewImage()) {
                  console.log("[ChatGPT-detect] TEXT_ONLY avoided \u2014 generating indicator/\u1EA3nh m\u1EDBi (cdn) xu\u1EA5t hi\u1EC7n sau text");
                } else {
                  console.log("[ChatGPT-detect] TEXT_ONLY (pattern match):", currentText.slice(0, 100));
                  return { success: false, error: "TEXT_ONLY", text: currentText.slice(0, 500) };
                }
              }
            }
            if (!textOnlyStreamStart) {
              textOnlyStreamStart = Date.now();
              console.log("[ChatGPT-detect] TEXT_ONLY tracking started \u2014 textLen:", textLen, "hasPositive:", hasPositive);
            } else if (Date.now() - textOnlyStreamStart > TEXT_ONLY_THRESHOLD_MS) {
              const finalImg2 = _queryWithFallback("generated_image", null, { scope: lastAssistantTurn, silent: true }) || _queryWithFallback("generated_image", null, { silent: true }) || _queryWithFallback("generating_indicator", null, { scope: lastAssistantTurn, silent: true }) || _queryWithFallback("generating_indicator", null, { silent: true });
              if (finalImg2 || _hasRealNewImage()) {
                console.log("[ChatGPT-detect] TEXT_ONLY false positive avoided \u2014 image marker/cdn \u1EA3nh m\u1EDBi xu\u1EA5t hi\u1EC7n:", finalImg2?.tagName || "cdn");
                textOnlyStreamStart = null;
                await sleep(pollInterval);
                continue;
              }
              console.log("[ChatGPT-detect] TEXT_ONLY (timeout) \u2014 streaming text >" + TEXT_ONLY_THRESHOLD_MS / 1e3 + "s, no image marker:", currentText.slice(0, 100));
              return { success: false, error: "TEXT_ONLY", text: currentText.slice(0, 500) };
            }
          } else if (hasImageMarker) {
            textOnlyStreamStart = null;
          }
          if (Date.now() - lastDiag > 5e3) {
            console.log("[ChatGPT-detect] Streaming, hasImg:", !!generatedImg, "textOnlyTracking:", !!textOnlyStreamStart);
            lastDiag = Date.now();
          }
          await sleep(pollInterval);
          continue;
        }
        const pendingGenImg = _queryWithFallback("generated_image", null, { scope: lastAssistantTurn, silent: true }) || _queryWithFallback("generated_image", null, { silent: true });
        const imgPending = pendingGenImg && (!pendingGenImg.src || pendingGenImg.classList.contains("blur-2xl"));
        if (imgPending) {
          postCompleteTextOnlyStart = null;
          if (Date.now() - lastDiag > 3e3) {
            const reason = !pendingGenImg.src ? "src loading" : "blur-2xl transition";
            console.log("[ChatGPT-detect] Pending img (" + reason + "):", pendingGenImg.alt?.slice(0, 40));
            lastDiag = Date.now();
          }
          await sleep(pollInterval);
          continue;
        }
        const text = (lastAssistantTurn.innerText || "").trim();
        if (text.length > 20) {
          const errorMatch = matchesAnyErrorPattern(text);
          if (errorMatch) {
            console.log("[ChatGPT-detect]", errorMatch.error, "(post-complete):", text.slice(0, 100));
            return { success: false, error: errorMatch.error, text: errorMatch.text };
          }
          const globalGenImg = _queryWithFallback("generated_image", null, { silent: true });
          if (globalGenImg && globalGenImg.src && !globalGenImg.classList.contains("blur-2xl")) {
            const fileIdMatch = globalGenImg.src.match(/[?&]id=(file_[a-z0-9]+)/i);
            const fileId = fileIdMatch?.[1];
            const isNewImage = !fileId || !baselineFileIds.has(fileId);
            if (isNewImage) {
              console.log("[ChatGPT-detect] TEXT_ONLY avoided via global fallback \u2014 found new image:", globalGenImg.alt?.slice(0, 50));
              postCompleteTextOnlyStart = null;
              await sleep(pollInterval);
              continue;
            }
          }
          if (_hasGeneratingIndicator()) {
            console.log("[ChatGPT-detect] TEXT_ONLY avoided \u2014 global generating indicator present");
            postCompleteTextOnlyStart = null;
            await sleep(pollInterval);
            continue;
          }
          if (!postCompleteTextOnlyStart) {
            postCompleteTextOnlyStart = Date.now();
            console.log("[ChatGPT-detect] TEXT_ONLY grace period started \u2014 waiting for potential late image render");
          }
          if (Date.now() - postCompleteTextOnlyStart < POST_COMPLETE_GRACE_MS) {
            const allGenImgsGrace = _queryAllWithFallback("generated_image");
            let foundNewImageInGrace = false;
            for (const img of allGenImgsGrace) {
              if (img.classList.contains("blur-2xl") || !img.src) continue;
              const alt = img.getAttribute("alt") || "";
              const isGenerated = alt.toLowerCase().startsWith("generated image");
              const isSibling = alt === "";
              if (!isGenerated && !isSibling) continue;
              const m = img.src.match(/[?&]id=(file_[a-z0-9]+)/i);
              if (!m) continue;
              if (baselineFileIds.has(m[1])) continue;
              console.log("[ChatGPT-detect] TEXT_ONLY avoided during grace period \u2014 found new image:", alt.slice(0, 50));
              postCompleteTextOnlyStart = null;
              foundNewImageInGrace = true;
              break;
            }
            if (foundNewImageInGrace) {
              await sleep(pollInterval);
              continue;
            }
            await sleep(pollInterval);
            continue;
          }
          if (_hasRealNewImage()) {
            console.log("[ChatGPT-detect] TEXT_ONLY (post-complete) avoided \u2014 cdn \u1EA3nh m\u1EDBi hi\u1EC7n di\u1EC7n (alt set tr\u1EC5)");
            postCompleteTextOnlyStart = null;
            await sleep(pollInterval);
            continue;
          }
          console.log("[ChatGPT-detect] TEXT_ONLY (post-complete) after", POST_COMPLETE_GRACE_MS, "ms grace:", text.slice(0, 100));
          return { success: false, error: "TEXT_ONLY", text: text.slice(0, 500) };
        }
        await sleep(pollInterval);
      }
      const finalImg = _queryCdnImages(document).length > 0;
      const finalLoadingIndicator = _hasGeneratingIndicator();
      const hasPendingImage = !!(finalImg || finalLoadingIndicator);
      if (hasPendingImage) {
        console.warn("[ChatGPT-detect] TIMEOUT sau", timeout, "ms \u2014 c\xF3 image marker \u2192 extend grace \u0111\u1ED9ng (cap 240s, gen \u1EA3nh ch\u1EADm)");
        const graceMaxDeadline = Date.now() + 24e4;
        let postGenGraceStart = null;
        while (Date.now() < graceMaxDeadline) {
          if (isAbortActive()) {
            await clickChatGPTStopButton();
            return { success: false, error: "ABORTED", message: "User stopped during grace" };
          }
          const baseIds = baseline.existingImageFileIds || /* @__PURE__ */ new Set();
          const isRealGen = (img) => {
            if (!_isLikelyGeneratedImg(img)) return false;
            const src = img.currentSrc || img.src || "";
            if (!src.startsWith("http") && !src.startsWith("blob:")) return false;
            const key = _imageKeyFromSrc(src);
            if (key && baseIds.has(key)) return false;
            const m = src.match(/[?&]id=(file_[a-z0-9]+)/i);
            if (m && baseIds.has(m[1].toLowerCase())) return false;
            return true;
          };
          const genImgs = Array.from(_queryCdnImages(document)).filter(isRealGen);
          if (genImgs.length > 0) {
            console.log("[ChatGPT-detect] Image rendered trong grace period:", (genImgs[0].currentSrc || genImgs[0].src).slice(0, 80));
            const dedup = [...new Map(genImgs.map((img) => {
              const src = img.currentSrc || img.src;
              return [_imageKeyFromSrc(src) || src, src];
            })).values()];
            return {
              success: true,
              imageUrls: dedup,
              altPrompt: genImgs[0].alt?.replace(/^Generated image:\s*/i, "") || "",
              turnId: null
            };
          }
          if (!_hasGeneratingIndicator()) {
            if (!postGenGraceStart) {
              postGenGraceStart = Date.now();
            } else if (Date.now() - postGenGraceStart > 1e4) {
              console.warn("[ChatGPT-detect] Grace: indicator t\u1EAFt + kh\xF4ng c\xF3 \u1EA3nh sau 10s \u2192 k\u1EBFt th\xFAc");
              return { success: false, error: "TIMEOUT", hasPendingImage: false };
            }
          } else {
            postGenGraceStart = null;
          }
          await sleep(2e3);
        }
        console.warn("[ChatGPT-detect] TIMEOUT sau grace 240s \u2014 image v\u1EABn pending, return v\u1EDBi hasPendingImage hint");
        return { success: false, error: "TIMEOUT", hasPendingImage: true };
      }
      console.warn("[ChatGPT-detect] TIMEOUT sau", timeout, "ms \u2014 kh\xF4ng c\xF3 image marker");
      return { success: false, error: "TIMEOUT", hasPendingImage: false };
    }
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "pq:trackerUpdate") {
        const _d = message.data;
        _ftRichActive = !!(_d && _d.jobs && _d.jobs.length && _d.isRunning !== false);
        try {
          FloatingTracker.updateFromQueue(_d);
        } catch (e) {
        }
        sendResponse({ ok: true });
        return false;
      }
      if (message.action === "providerConfigUpdated") {
        _selectorConfig = null;
        _selectorConfigTime = 0;
        console.log("[ChatGPT] Provider config updated via SSE \u2014 selector cache invalidated");
        sendResponse({ success: true });
        return false;
      }
      if (message.action === "chatAI:execute") {
        (async () => {
          try {
            if (message.images && message.images.length > 0) {
              const uploaded = await uploadImages(message.images);
              if (!uploaded) {
                sendResponse({ success: false, error: "Kh\xF4ng th\u1EC3 upload \u1EA3nh l\xEAn ChatGPT" });
                return;
              }
            }
            const textInserted = await insertText(message.text);
            if (!textInserted) {
              sendResponse({ success: false, error: "Kh\xF4ng th\u1EC3 nh\u1EADp text v\xE0o ChatGPT" });
              return;
            }
            const submitted = await clickSubmit();
            if (!submitted) {
              sendResponse({ success: false, error: "Kh\xF4ng th\u1EC3 g\u1EEDi tin nh\u1EAFn tr\xEAn ChatGPT" });
              return;
            }
            sendResponse({ success: true });
          } catch (err) {
            sendResponse({ success: false, error: err.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh" });
          }
        })();
        return true;
      }
      if (message.action === "chatgpt:submitAndWait") {
        __chatgptCallStartAt = Date.now();
        if (__chatgptAbort && __chatgptAbortAt < __chatgptCallStartAt - 5e3) {
          __chatgptAbort = false;
          __chatgptAbortAt = 0;
        }
        __chatgptInputTimeoutMs = Number(message.inputTimeoutMs) || 1200;
        __chatgptMacroDelayMs = Math.round(__chatgptInputTimeoutMs * 0.7);
        console.log("[ChatGPT] Timing \u2014 inputTimeout:", __chatgptInputTimeoutMs, "ms | macroDelay:", __chatgptMacroDelayMs, "ms (70%)");
        const isTextMode = message.expectText === true || message.settings?.imageMode === false;
        const requestId = message.requestId || `cg_cs_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const storageKey = `af_chatgpt_result_${requestId}`;
        const LATEST_KEY = "af_chatgpt_result_latest";
        const deliverResult = (result) => {
          const out = {
            ...result && typeof result === "object" ? result : {},
            success: result?.success === true,
            imageUrls: result?.imageUrls || [],
            // Prefetch canvas/fetch lúc DONE — tránh bridge re-fetch estuary bị ERR_HTTP2
            imageBase64s: Array.isArray(result?.imageBase64s) ? result.imageBase64s : [],
            altPrompt: result?.altPrompt || "",
            text: result?.text || "",
            error: result?.error || null,
            message: result?.message || null,
            ts: Date.now(),
            requestId
          };
          console.log(
            "%c[ChatGPT] deliverResult",
            "color:#0f0;font-weight:bold;font-size:13px",
            "success=",
            out.success,
            "urls=",
            out.imageUrls.length,
            "b64=",
            (out.imageBase64s || []).filter(Boolean).length,
            "textLen=",
            (out.text || "").length,
            "rid=",
            requestId
          );
          if (Array.isArray(out.imageUrls)) {
            out.imageUrls = out.imageUrls.map((u, i) => {
              if (String(u || "").startsWith("data:image") && String(u).length > 400) {
                if (!out.imageBase64s[i]) {
                  if (!Array.isArray(out.imageBase64s)) out.imageBase64s = [];
                  out.imageBase64s[i] = u;
                }
                return String(u).slice(0, 32) + "\u2026";
              }
              return u;
            });
          }
          const b64Total = (out.imageBase64s || []).reduce((n, s) => n + (s ? String(s).length : 0), 0);
          const storageOut = b64Total > 6 * 1024 * 1024 ? { ...out, imageBase64s: [], _b64Stripped: true } : out;
          try {
            chrome.storage.local.set({ [storageKey]: storageOut, [LATEST_KEY]: storageOut }, () => {
              if (chrome.runtime.lastError) {
                console.warn("[ChatGPT] storage set fail, retry without b64:", chrome.runtime.lastError.message);
                const slim = { ...out, imageBase64s: [], _b64Stripped: true };
                chrome.storage.local.set({ [storageKey]: slim, [LATEST_KEY]: slim }, () => {
                  console.log("[ChatGPT] result \u2192 storage (slim)", storageKey);
                });
              } else {
                console.log("[ChatGPT] result \u2192 storage", storageKey, "+ latest", "b64Bytes=", b64Total);
              }
            });
          } catch (e) {
            console.warn("[ChatGPT] storage set fail:", e?.message || e);
          }
          try {
            chrome.runtime.sendMessage({
              action: "chatgpt:imageResultRelay",
              ...out
            }, (resp) => {
              if (chrome.runtime.lastError) {
                console.warn("[ChatGPT] imageResultRelay lastError:", chrome.runtime.lastError.message);
              } else {
                console.log("[ChatGPT] imageResultRelay OK", resp);
              }
            });
          } catch (e) {
            console.warn("[ChatGPT] imageResultRelay fail:", e?.message || e);
          }
          try {
            sendResponse(out);
          } catch (e) {
            console.warn("[ChatGPT] sendResponse fail (OK if storage/broadcast):", e?.message || e);
          }
          return out;
        };
        console.log(
          "[ChatGPT-listener] chatgpt:submitAndWait nh\u1EADn, mode:",
          isTextMode ? "text" : "image",
          "text len:",
          (message.text || "").length,
          "images:",
          (message.images || []).length,
          "requestId:",
          requestId || "(none)"
        );
        const promptPreview = (message.text || "").substring(0, 50);
        FloatingTracker.show({ current: 0, total: 1, phase: _i18n.t("preparing"), prompt: promptPreview });
        ExecutionBlocker.show();
        (async () => {
          try {
            if (detectChatGPTChallenge()) {
              FloatingTracker.update({ phase: _i18n.t("waitingVerification") });
              const resolved = await waitForChatGPTChallengeResolved(12e4);
              if (!resolved) {
                FloatingTracker.hide();
                ExecutionBlocker.hide();
                deliverResult({
                  success: false,
                  error: "CHALLENGE_TIMEOUT",
                  message: "ChatGPT y\xEAu c\u1EA7u x\xE1c minh. Vui l\xF2ng m\u1EDF tab ChatGPT, ho\xE0n th\xE0nh verification, sau \u0111\xF3 ch\u1EA1y l\u1EA1i."
                });
                return;
              }
            }
            checkAbort("after-challenge-check");
            if (isTextMode) {
              const forceNewChat = message.settings?.newChat === true || message.settings?.reuseChat === false;
              const reuseChat = !forceNewChat;
              console.log(
                "%c[ChatGPT] TEXT-ONLY path (k\u1ECBch b\u1EA3n)",
                "color:#0f0;font-weight:bold;font-size:13px",
                "reuseChat=",
                reuseChat,
                "len=",
                (message.text || "").length,
                "images=",
                (message.images || []).length,
                "url=",
                (location.pathname || "").slice(0, 40)
              );
              FloatingTracker.update({
                phase: reuseChat ? "AI: c\xF9ng chat + paste k\u1ECBch b\u1EA3n\u2026" : "AI: chat m\u1EDBi + paste\u2026",
                prompt: promptPreview
              });
              if (forceNewChat) {
                try {
                  const path = window.location.pathname || "";
                  if (path === "/" || path === "") {
                    console.log("[ChatGPT] text: \u0111\xE3 homepage (newChat)");
                  } else {
                    const ok = await clickNewChatAndWaitReady(1e4);
                    console.log("[ChatGPT] text newChat:", ok ? "OK" : "retry navigate /");
                    if (!ok) {
                      try {
                        window.location.assign("https://chatgpt.com/");
                        await sleep(2500);
                      } catch (_) {
                      }
                    }
                  }
                } catch (e) {
                  console.warn("[ChatGPT] text newChat skip:", e?.message || e);
                }
              } else {
                console.log(
                  "%c[ChatGPT] text REUSE same conversation \u2014 paste v\xE0o \xF4 gen \u1EA3nh",
                  "color:#0ff;font-weight:bold",
                  location.pathname
                );
                try {
                  _scrollChatToBottom();
                } catch (_) {
                }
                if ((location.pathname || "/") === "/" || (location.pathname || "") === "") {
                  console.warn("[ChatGPT] text reuse nh\u01B0ng \u0111ang homepage \u2014 ch\u1EDD composer / c\xF3 th\u1EC3 fail");
                }
              }
              checkAbort("after-chat-prepare-text");
              if (_hasGeneratingIndicator()) {
                console.log("[ChatGPT] text: ch\u1EDD gen \u1EA3nh xong max 45s (reuse chat)\u2026");
                FloatingTracker.update({ phase: "AI: ch\u1EDD \u1EA3nh xong r\u1ED3i paste\u2026", prompt: promptPreview });
                const t0 = Date.now();
                while (Date.now() - t0 < 45e3 && _hasGeneratingIndicator()) {
                  if (isAbortActive()) break;
                  await sleep(400);
                }
              }
              try {
                await Promise.race([deactivateImageModeIfActive(), sleep(2500)]);
              } catch (_) {
              }
              try {
                const edWait = Date.now() + 1e4;
                while (Date.now() < edWait) {
                  const ed = _findChatGptComposer() || _queryWithFallback("composer", null, { silent: true });
                  if (ed) break;
                  await sleep(200);
                }
              } catch (_) {
              }
              const baseline2 = snapshotConversationState();
              let textToSubmit2 = message.text || "";
              try {
                const enhancePrefix = await getEnhancePrefix();
                if (enhancePrefix && !/generate an image/i.test(enhancePrefix)) {
                  textToSubmit2 = enhancePrefix + textToSubmit2;
                } else if (enhancePrefix) {
                  console.log("[ChatGPT] text: skip image-style enhancePrefix");
                }
              } catch (_) {
              }
              if (!reuseChat && Array.isArray(message.images) && message.images.length > 0) {
                try {
                  await removeExistingChatGPTRefImages();
                  await injectRefImages(message.images);
                  await sleep(500);
                } catch (e) {
                  console.warn("[ChatGPT] text ref skip:", e?.message || e);
                }
              } else if (reuseChat) {
                console.log("[ChatGPT] text REUSE: skip re-upload ref \u2014 d\xF9ng \u1EA3nh \u0111\xE3 gen trong chat");
              }
              try {
                await Promise.race([deactivateImageModeIfActive(), sleep(1500)]);
                const stillPill = document.querySelector("[data-inline-selection-pill]");
                if (stillPill) {
                  console.warn("[ChatGPT] text: pill c\xF2n \u2014 force remove trong inject textOnly");
                }
              } catch (_) {
              }
              FloatingTracker.update({ phase: "AI: paste k\u1ECBch b\u1EA3n + Send\u2026", prompt: promptPreview });
              console.log(
                "%c[ChatGPT] TEXT \u2192 injectKichBanAndSubmit (c\xF9ng \xF4, path ri\xEAng)",
                "color:#cdff01;font-weight:bold;font-size:13px",
                "reuseChat=",
                reuseChat,
                "len=",
                textToSubmit2.length,
                textToSubmit2.slice(0, 80)
              );
              try {
                await injectKichBanAndSubmit(textToSubmit2);
              } catch (injErr) {
                console.warn("[ChatGPT] k\u1ECBch b\u1EA3n inject fail, retry 1\xD7:", injErr?.message || injErr);
                await sleep(1e3);
                try {
                  await deactivateImageModeIfActive();
                } catch (_) {
                }
                for (let e = 0; e < 2; e++) {
                  try {
                    document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
                  } catch (_) {
                  }
                  await sleep(100);
                }
                await injectKichBanAndSubmit(textToSubmit2);
              }
              checkAbort("before-wait-text");
              FloatingTracker.update({ current: 1, total: 1, phase: "AI: ch\u1EDD k\u1ECBch b\u1EA3n\u2026", prompt: promptPreview });
              const textTimeout = message.timeout || 12e4;
              const textResult = await waitForTextResult(baseline2, textTimeout);
              FloatingTracker.hide();
              ExecutionBlocker.hide();
              console.log(
                "%c[ChatGPT] TEXT result (k\u1ECBch b\u1EA3n)",
                "color:#0f0;font-weight:bold",
                "success=",
                textResult?.success,
                "len=",
                (textResult?.text || "").length,
                "err=",
                textResult?.error || null
              );
              if (textResult?.success && textResult?.text) {
                deliverResult({
                  success: true,
                  text: textResult.text,
                  turnId: textResult.turnId || null,
                  imageUrls: []
                });
              } else {
                deliverResult(textResult || { success: false, error: "TEXT_EMPTY" });
              }
              return;
            }
            const shouldNewChat = message.settings?.newChat !== false;
            if (shouldNewChat) {
              const currentPath = window.location.pathname;
              if (currentPath === "/" || currentPath === "") {
                console.log("[ChatGPT] Already at homepage (new chat) \u2014 skipping clickNewChatAndWaitReady");
              } else {
                console.log("[ChatGPT] Not at homepage, trying clickNewChatAndWaitReady...");
                const newChatReady = await clickNewChatAndWaitReady(8e3);
                if (!newChatReady) {
                  console.warn("[ChatGPT] New chat kh\xF4ng ready \u2014 ti\u1EBFp t\u1EE5c v\u1EDBi conversation hi\u1EC7n t\u1EA1i");
                }
              }
              checkAbort("after-new-chat");
              await sleep(getMacroDelay());
            }
            const limitAlert = checkImageLimitAlert();
            if (limitAlert?.detected) {
              console.warn("[ChatGPT-listener] LIMIT_ALERT detected \u2014 b\u1ECF qua submit:", limitAlert.message);
              FloatingTracker.hide();
              ExecutionBlocker.hide();
              deliverResult({
                success: false,
                error: "LIMIT_ALERT",
                message: limitAlert.message
              });
              return;
            }
            const existingGenIndicator = _hasGeneratingIndicator();
            if (existingGenIndicator) {
              console.log("[ChatGPT] \u0110ang c\xF3 image generation t\u1EEB task tr\u01B0\u1EDBc \u2014 ch\u1EDD ho\xE0n t\u1EA5t...");
              const maxWaitGen = 12e4;
              const startWaitGen = Date.now();
              while (Date.now() - startWaitGen < maxWaitGen) {
                if (isAbortActive()) {
                  FloatingTracker.hide();
                  ExecutionBlocker.hide();
                  deliverResult({ success: false, error: "ABORTED", message: "User stopped" });
                  return;
                }
                if (!_hasGeneratingIndicator()) {
                  console.log("[ChatGPT] Generation tr\u01B0\u1EDBc \u0111\xE3 ho\xE0n t\u1EA5t \u2014 ti\u1EBFp t\u1EE5c submit task m\u1EDBi");
                  break;
                }
                await sleep(1e3);
              }
              await sleep(500);
            }
            try {
              _ensureMainWorldNetHook();
            } catch (_) {
            }
            const baseline = snapshotConversationState();
            let textToSubmit = message.text || "";
            await removeExistingChatGPTRefImages();
            await sleep(200);
            checkAbort("after-remove-refs");
            if (Array.isArray(message.images) && message.images.length > 0) {
              const uploaded = await injectRefImages(message.images);
              if (!uploaded) {
                deliverResult({
                  success: false,
                  error: "REF_UPLOAD_FAILED",
                  message: "Kh\xF4ng th\u1EC3 upload ref image l\xEAn ChatGPT"
                });
                return;
              }
              checkAbort("after-upload-refs");
              await sleep(150);
            }
            if (message.settings?.model) {
              await selectChatGPTModel(message.settings.model);
              checkAbort("after-select-model");
              await sleep(getMacroDelay());
            }
            if (message.settings?.imageMode) {
              const ratio = message.settings?.ratio || "1:1";
              console.log("[ChatGPT] Activating image mode v\u1EDBi ratio:", ratio);
              const activated = await activateImageMode(ratio);
              if (!activated) {
                console.warn("[ChatGPT] Kh\xF4ng th\u1EC3 activate image mode \u2014 s\u1EBD d\xF9ng fallback prefix");
                if (message.settings?.fallbackPrefix) {
                  textToSubmit = message.settings.fallbackPrefix + textToSubmit;
                }
              }
              const _ratioSuffix = ratioToPromptSuffix(ratio);
              if (_ratioSuffix) {
                textToSubmit = textToSubmit + _ratioSuffix;
                console.log("[ChatGPT] Ratio nh\xFAng v\xE0o prompt:", _ratioSuffix.trim());
              }
              checkAbort("after-activate-image-mode");
              await sleep(getMacroDelay());
            }
            await injectTextAndSubmit(textToSubmit);
            checkAbort("before-wait-result");
            FloatingTracker.update({ current: 1, total: 1, phase: _i18n.t("waitingResult"), prompt: promptPreview });
            const timeout = message.timeout || 3e5;
            console.log(
              "%c[ChatGPT] waitForImageResult (hybrid B: network first)",
              "color:#0ff;font-weight:bold",
              "epoch=",
              _netCapture.epoch,
              "timeout=",
              timeout
            );
            const result = await waitForImageResult(baseline, timeout);
            if (result?.success && Array.isArray(result.imageUrls) && result.imageUrls.length) {
              try {
                FloatingTracker.update({
                  current: 1,
                  total: 1,
                  phase: "\u0110\xF3ng g\xF3i \u1EA3nh \u2192 Flow\u2026",
                  prompt: promptPreview
                });
                const b64s = await captureChatGptImageBase64s(result.imageUrls);
                const okB64 = b64s.filter((x) => x && String(x).length > 500);
                if (okB64.length) {
                  result.imageBase64s = b64s;
                  result._hasPrefetchB64 = true;
                  console.log(
                    "%c[ChatGPT] capture base64 cho bridge (gi\u1EEF estuary URL, b64 ri\xEAng)",
                    "color:#0f0;font-weight:bold",
                    okB64.length,
                    "/",
                    result.imageUrls.length,
                    "size0=",
                    Math.round((okB64[0]?.length || 0) / 1024),
                    "KB",
                    "url0=",
                    String(result.imageUrls[0] || "").slice(0, 70)
                  );
                } else {
                  console.warn(
                    "[ChatGPT] capture base64 FAIL \u2014 bridge s\u1EBD canvas/fetch l\u1EA1i tr\xEAn tab ChatGPT."
                  );
                }
              } catch (capErr) {
                console.warn("[ChatGPT] capture base64 error:", capErr?.message || capErr);
              }
            }
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            console.log(
              "%c[ChatGPT] IMAGE result \u2192 deliver (port+storage)",
              "color:#0f0;font-weight:bold;font-size:13px",
              "success=",
              result?.success,
              "urls=",
              result?.imageUrls?.length || 0,
              "b64=",
              result?.imageBase64s?.filter?.((x) => x)?.length || 0,
              "err=",
              result?.error || null,
              "url0=",
              (result?.imageUrls?.[0] || "").slice(0, 100),
              "requestId=",
              requestId || "(none)"
            );
            deliverResult(result);
          } catch (err) {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
            if (err.message && err.message.startsWith("ABORTED")) {
              const stage = err.message.replace("ABORTED:", "");
              console.log("[ChatGPT] Caught ABORT at stage:", stage, "\u2192 clicking Stop button");
              await clickChatGPTStopButton();
              deliverResult({
                success: false,
                error: "ABORTED",
                message: "User stopped at " + stage
              });
              return;
            }
            deliverResult({
              success: false,
              error: "EXCEPTION",
              message: err.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh"
            });
          } finally {
            FloatingTracker.hide();
            ExecutionBlocker.hide();
          }
        })();
        return true;
      }
      if (message.action === "provider:textTask") {
        __chatgptCallStartAt = Date.now();
        __chatgptAbort = false;
        __chatgptAbortAt = 0;
        ExecutionBlocker.show();
        (async () => {
          try {
            if (typeof detectChatGPTChallenge === "function" && detectChatGPTChallenge()) {
              const resolved = await waitForChatGPTChallengeResolved(12e4);
              if (!resolved) {
                sendResponse({ success: false, error: "CHALLENGE_TIMEOUT" });
                return;
              }
            }
            await waitProviderReady();
            let isolated = !message.newChat;
            if (message.newChat) {
              try {
                isolated = await clickNewChatAndWaitReady(8e3);
              } catch (_) {
                isolated = false;
              }
            }
            const baseline = snapshotConversationState();
            try {
              await deactivateImageModeIfActive();
            } catch (_) {
            }
            await removeExistingChatGPTRefImages();
            await sleep(200);
            if (Array.isArray(message.images) && message.images.length > 0) {
              const up = await injectRefImages(message.images);
              if (!up) {
                sendResponse({ success: false, error: "IMAGE_UPLOAD_FAILED" });
                return;
              }
              await sleep(250);
            }
            if (message.model) {
              try {
                await selectChatGPTModel(message.model);
              } catch (_) {
              }
            }
            await injectTextAndSubmit(message.text || "");
            const result = await waitForTextResult(baseline, message.timeout || 9e4);
            if (message.deleteAfter && result?.success && isolated) {
              try {
                await deleteLastAssistantMessage();
              } catch (e) {
                console.warn("[ChatGPT-i2p] delete after failed:", e.message);
              }
            } else if (message.deleteAfter && result?.success && !isolated) {
              console.warn("[ChatGPT-i2p] skip deleteAfter \u2014 ch\u01B0a m\u1EDF \u0111\u01B0\u1EE3c chat m\u1EDBi (tr\xE1nh \u0111\u1EE5ng chat user)");
            }
            sendResponse(result);
          } catch (err) {
            sendResponse({ success: false, error: "EXCEPTION", message: err.message || String(err) });
          } finally {
            ExecutionBlocker.hide();
          }
        })();
        return true;
      }
      if (message.action === "chatgpt:abort") {
        __chatgptAbort = true;
        __chatgptAbortAt = Date.now();
        console.log("[ChatGPT-listener] chatgpt:abort received \u2192 set abort flag at", __chatgptAbortAt);
        FloatingTracker.hide();
        ExecutionBlocker.hide();
        sendResponse({ success: true });
        return false;
      }
      if (message.action === "chatgpt:deleteLastMessage") {
        (async () => {
          try {
            const success = await deleteLastAssistantMessage();
            sendResponse({ success });
          } catch (err) {
            console.error("[ChatGPT-listener] deleteLastMessage error:", err);
            sendResponse({ success: false, error: err.message });
          }
        })();
        return true;
      }
      return false;
    });
    let _lastUrl = location.href;
    const _notifyNavigate = () => {
      if (location.href !== _lastUrl) {
        _lastUrl = location.href;
        try {
          chrome.runtime.sendMessage({ action: "chatgpt:navigated", url: location.href }).catch(() => {
          });
        } catch (e) {
        }
      }
    };
    try {
      const _origPushState = history.pushState;
      const _origReplaceState = history.replaceState;
      history.pushState = function() {
        _origPushState.apply(this, arguments);
        _notifyNavigate();
      };
      history.replaceState = function() {
        _origReplaceState.apply(this, arguments);
        _notifyNavigate();
      };
      window.addEventListener("popstate", _notifyNavigate);
    } catch (e) {
    }
    console.log("[ChatAI] Content script ChatGPT \u0111\xE3 \u0111\u01B0\u1EE3c inject (Phase X + CG-2 + CG-3)");
  })();
})();
